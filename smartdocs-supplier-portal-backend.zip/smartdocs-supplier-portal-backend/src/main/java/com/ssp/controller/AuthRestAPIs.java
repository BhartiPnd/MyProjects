package com.ssp.controller;

import java.time.ZonedDateTime;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssp.dto.JwtResponse;
import com.ssp.dto.LoginForm;
import com.ssp.mongo.collections.ApplicationLog;
import com.ssp.mongo.collections.User;
import com.ssp.mongo.collections.config.system.SystemConfiguration;
import com.ssp.mongo.util.JsonResponse;
import com.ssp.repository.ApplicationLogRepository;
import com.ssp.repository.UserRepository;
import com.ssp.rest.component.Translator;
import com.ssp.rest.daoimpl.SystemConfigurationDao;
import com.ssp.security.jwt.JwtProvider;
import com.ssp.security.services.UserDetailsServiceImpl;
import com.ssp.security.services.UserPrinciple;
//import com.ssp.service.MessageLocaleService;
import com.ssp.service.util.HttpReqRespUtils;
 
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/auth")
public class AuthRestAPIs {

	
	private final Logger log = LoggerFactory.getLogger(AuthRestAPIs.class);
			
    @Autowired
    private AuthenticationManager authenticationManager;

     
    @Autowired
    private JwtProvider jwtProvider;
    
    @Autowired
    private UserDetailsServiceImpl userDetailService;
    
    @Autowired
    private UserRepository userRepository;
   
    @Autowired
    private ApplicationLogRepository authLogRepository;
    
    @Autowired
    private SystemConfigurationDao systemConfigDao; 

//    @Autowired
//    private MessageLocaleService messageLocaleService;
    
    @PostMapping("/signin")
    @ApiOperation(notes = "This api helps in signin", value = "let's signin")
    public ResponseEntity<JwtResponse> authenticateUser(@Valid @RequestBody LoginForm loginRequest) {
    	try {
    		
    		//System.out.println(Translator.toLocale("hello"));
//    				String hello = messageLocaleService.getMessage("hello", "en");
//    				String hello1 = messageLocaleService.getMessageDbs("hello12", "en");
//    				System.out.println(hello);
//    				System.out.println(hello1);
    			Authentication authentication = authenticationManager.authenticate(
		                new UsernamePasswordAuthenticationToken(
		                        loginRequest.getUsername(),
		                        loginRequest.getPassword()
		                )
		        );
		        SecurityContextHolder.getContext().setAuthentication(authentication);
		        UserPrinciple user = ((UserPrinciple) authentication.getPrincipal());
		        String jwt = jwtProvider.generateJwtToken(authentication);
		        
		       // String ip,String type, String agent,String name, String itemType, String itemId, String title, String description
		        authLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),ApplicationLog.TYPE_USER_SIGNIN,user.getEmail(),user.getName(),null,null,user.getName()+" Successfully sign in ","","AuthRestAPIs:authenticateUser()","/auth/signin"));
		        Optional<User> entity = userRepository.findByEmailIgnoreCase(loginRequest.getUsername()) ;
				if(entity.isPresent()) {
					if(entity.get().getInvalidPasswordAttempts()>0)
					{
						entity.get().setInvalidPasswordAttempts(0);
					}
					entity.get().setAccessToken(jwt);
					entity.get().setLastLogin(ZonedDateTime.now());
					entity.get().setLastActivity(ZonedDateTime.now());
					if(StringUtils.isNotBlank(loginRequest.getLanguage())) {
						entity.get().setLanguage(loginRequest.getLanguage());
					}
					
					userRepository.save(entity.get());
				} 
				SystemConfiguration config = systemConfigDao.getSystemConfiguration();
		        return ResponseEntity.ok(new JwtResponse(jwt,user,JwtResponse.LOGIN_BASIC_UP,config));
    	}
    	
    	 
    	catch(BadCredentialsException ex) {
    		log.info("BadCredentialsException------------");
    		Optional<User> user = userRepository.findByEmailIgnoreCase(loginRequest.getUsername()) ;
    		if(user.isPresent()) {
    			user.get().addInvalidPasswordAttempt();
    			log.info("Update invalid password Attempt.");
    			userRepository.save(user.get());
    			throw new BadCredentialsException("INCORRECT_LOGIN_DETAIL___"+(7-user.get().getInvalidPasswordAttempts()));
    		}
    		else {
    			throw new BadCredentialsException("INCORRECT_LOGIN_DETAIL");
    		}
    	}
    }
    
    
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_USER', 'SYTEM_ADMIN','SUPPLIER_USER','SUPPLIER_ADMIN','SUPPLIER_LOGISTICS','SUPPLIER_ACCOUNTING')")
    @GetMapping("/signout")
    @ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header",  example = "Bearer access_token")
    @ApiOperation(notes = "Logout api", value = "")
    public ResponseEntity<JsonResponse> logout(HttpServletRequest request,@ApiIgnore Authentication authentication) {
    	JsonResponse jsonResponse=new JsonResponse();
    	 
    	UserPrinciple loggedInUser = (UserPrinciple) authentication.getPrincipal();
    	
    	String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		
    	if(loggedInUser!=null) {
    		boolean result=userDetailService.logoutDeleteToken(app,loggedInUser.getEmail());
        	if(result) {
        		jsonResponse.setResult("Logout successfully");
        		jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
        	}else {
        		jsonResponse.setResult("Some issue in logout");
        		jsonResponse.setStatus(JsonResponse.RESULT_FAILED);
        	}
    	}
    	else
    	{
    		jsonResponse.setResult("Logout successfully");
    		jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
    	}
    	return ResponseEntity.ok(jsonResponse);
     
    }
    
    @PreAuthorize("hasRole('SUPPLIER_ADMIN') or hasRole('SUPPLIER_ACCOUNTING')   or hasRole('SUPPLIER_LOGISTICS') ")
    @PostMapping("/swithAccount")
    @ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header",  example = "Bearer access_token")
    @ApiOperation(notes = "This api helps in signin", value = "let's signin")
    public ResponseEntity<JwtResponse> swithAccount(@ApiIgnore Authentication authentication, @RequestParam("supplierId") String supplierId) {
    	UserPrinciple logedInUser = (UserPrinciple) authentication.getPrincipal();
    	
        UserPrinciple user = userDetailService.switchAccount(supplierId,logedInUser.getEmail());
         SystemConfiguration config = systemConfigDao.getSystemConfiguration();
        if(user!=null) {
        	String jwt = jwtProvider.generateJwtToken(user);
        	Optional<User> entity = userRepository.findByEmailIgnoreCase(logedInUser.getEmail()) ;
			if(entity.isPresent()) {
				if(entity.get().getInvalidPasswordAttempts()>0)
				{
					entity.get().setInvalidPasswordAttempts(0);
				}
				entity.get().setAccessToken(jwt);
				entity.get().setLastLogin(ZonedDateTime.now());
				entity.get().setLastActivity(ZonedDateTime.now());
				userRepository.save(entity.get());
			} 
        	
            return ResponseEntity.ok(new JwtResponse(jwt,user,JwtResponse.LOGIN_BASIC_UP,config));
        }
        return ResponseEntity.ok(new JwtResponse("",user,JwtResponse.LOGIN_BASIC_UP,config));
    }
    

 
    
    
    
    
		 
}