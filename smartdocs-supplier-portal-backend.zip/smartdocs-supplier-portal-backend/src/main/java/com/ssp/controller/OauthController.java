package com.ssp.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssp.dto.AlkemResponse;
import com.ssp.dto.JwtResponse;
import com.ssp.mongo.collectionhelpers.Permission;
import com.ssp.mongo.collections.ApplicationLog;
import com.ssp.mongo.collections.User;
import com.ssp.mongo.collections.config.system.SystemConfiguration;
import com.ssp.mongo.util.JsonResponse;
import com.ssp.repository.ApplicationLogRepository;
import com.ssp.repository.UserRepository;
import com.ssp.rest.daoimpl.SystemConfigurationDao;
import com.ssp.rest.services.AuthProfileService;
import com.ssp.rest.services.UserService;
import com.ssp.security.jwt.JwtProvider;
import com.ssp.security.services.GoogleHttpHelper;
import com.ssp.security.services.UserPrinciple;
import com.ssp.service.OauthUtils;
import com.ssp.service.util.HttpReqRespUtils;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/sso")
public class OauthController {
	
	 private static final Logger logger = LoggerFactory.getLogger(OauthController.class);

	public static final String API_HOST = "graph.microsoft.com/v1.0/me";
	public static final String DEFAULT_SCHEME = "https";

	@Autowired
	private UserService userService;
	
	@Autowired
	private JwtProvider jwtProvider;

	@Value("${frontEndURL}")
	private String frontEndURL;
	
	
	@Value("${ssoURL}")
	private String ssoURL;
	
	@Value("${mobilefrontEndURL}")
	private String mobilefrontEndURL;
	
	@Value("${oauth.appId}")
	private String appId;
	
	@Value("${oauth.appSecreat}")
	private String appSecreat;
	
//	@Value("${alkem.xorKey}")
	private String xorKey;

//	@Value("${alkem.secretKey}")
	private String alkemSecretKey;
	
	@Autowired
	private ApplicationLogRepository authLogRepository;
	 
	@Autowired
	private AuthProfileService authProfileService;
	 
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private SystemConfigurationDao systemConfigDao; 

	@Autowired
	private GoogleHttpHelper googleHelper;

	  
//	@GetMapping("/auth")
//	public void authenticate(HttpServletRequest request, HttpServletResponse httpServletResponse)
//			throws IOException {
//		String app= request.getParameter("app");
//		
//		if(StringUtils.isBlank(app)) {
//			app="default";
//		}
//		String url = OauthUtils.authorize(request,appId,app);
//		httpServletResponse.sendRedirect(url);
//
//	}
//
//	@GetMapping("/redirect")
//	public String redirect(HttpServletRequest request, HttpServletResponse httpServletResponse)
//			throws IOException, JSONException {
//		String status = "Error";
//		String code = request.getParameter("code");
//		String app = request.getParameter("state");
//		if(StringUtils.isNotBlank(app) &&  "mobile".equalsIgnoreCase(app)) {
//			httpServletResponse.sendRedirect(mobilefrontEndURL+"/signin?msaauth="+code);
//		}
//		else {
//			httpServletResponse.sendRedirect(frontEndURL+"/sp/auth/login?msaauth="+code);
//		}
//		return status;
//
//	}
	@GetMapping("/ms/validate")
    @ApiOperation(notes = "This api helps in signin USING MICROSOFT SESSION", value = "let's signin")
    public ResponseEntity<?> authenticateUserMSA(HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {

		String code = request.getParameter("code");
		String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		JSONObject jsonObject = OauthUtils.getAccessToken(code,  ssoURL+"/ms/redirect",appId,appSecreat);
		if (jsonObject == null)
		{
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url. ",JsonResponse.STATUS_400)); 
		}
		String accessToken = (String) jsonObject.get("access_token");
		//String refreshToken = (String) jsonObject.get("refresh_token");
		if (accessToken != null) {
			String mail =  getOutlookName(accessToken);
			User user = userService.getUserByEmail(mail);
			if(user!=null && user.isEmailEnabled()){
				
	        	Map<String,Permission> pg= authProfileService.getAllPermissionGroups(user);
	        	 
				UserPrinciple userPrinciple = UserPrinciple.buildSSO(user,pg);
				String jwt = jwtProvider.generateJwtTokenForMSAUser(userPrinciple);
				authLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),ApplicationLog.TYPE_USER_SIGNIN,user.getEmail(),user.getName(),null,null,user.getName()+"SSO Successfully sign in ","","","/sso/ad/validate"));
				if(StringUtils.isNotBlank(app) &&  "mobile".equalsIgnoreCase(app)) {
					user.setMobileAccess(jwt);
				}
				else {
					user.setAccessToken(jwt);
				}
				user.setLastLogin(ZonedDateTime.now());
				user.setLastActivity(ZonedDateTime.now());
				user.setInvalidPasswordAttempts(0);
				userRepository.save(user);
				 	SystemConfiguration config = systemConfigDao.getSystemConfiguration();
	            return	ResponseEntity.ok(new JsonResponse(new JwtResponse(jwt,userPrinciple,JwtResponse.LOGIN_SSO,config),JsonResponse.RESULT_SUCCESS,JsonResponse.STATUS_200)); 
			}else{
				return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"User not exist into system",JsonResponse.STATUS_400)); 
			}
			
		} else {
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url",JsonResponse.STATUS_400)); 
		}
		
    }
	@GetMapping("/ms/validate/mobile")
    @ApiOperation(notes = "This api helps in signin USING MICROSOFT SESSION", value = "let's signin")
    public ResponseEntity<?> authenticateUserMSAMobile(HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {

		String code = request.getParameter("code");
		String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		JSONObject jsonObject = OauthUtils.getAccessToken(code,  ssoURL+"/ms/redirect/mobile",appId,appSecreat);
		if (jsonObject == null)
		{
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url. ",JsonResponse.STATUS_400)); 
		}
		String accessToken = (String) jsonObject.get("access_token");
		//String refreshToken = (String) jsonObject.get("refresh_token");
		if (accessToken != null) {
			String mail =  getOutlookName(accessToken);
			User user = userService.getUserByEmail(mail);
			if(user!=null && user.isEmailEnabled()){
				
	        	Map<String,Permission> pg= authProfileService.getAllPermissionGroups(user);
	        	 
				UserPrinciple userPrinciple = UserPrinciple.buildSSO(user,pg);
				String jwt = jwtProvider.generateJwtTokenForMSAUser(userPrinciple);
				authLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),ApplicationLog.TYPE_USER_SIGNIN,user.getEmail(),user.getName(),null,null,user.getName()+"SSO Successfully sign in ","","","/sso/ad/validate"));
				if(StringUtils.isNotBlank(app) &&  "mobile".equalsIgnoreCase(app)) {
					user.setMobileAccess(jwt);
				}
				else {
					user.setAccessToken(jwt);
				}
				user.setInvalidPasswordAttempts(0);
				user.setLastLogin(ZonedDateTime.now());
				user.setLastActivity(ZonedDateTime.now());
				userRepository.save(user);
					SystemConfiguration config=systemConfigDao.getSystemConfiguration();

                return	ResponseEntity.ok(new JsonResponse(new JwtResponse(jwt,userPrinciple,JwtResponse.LOGIN_SSO,config),JsonResponse.RESULT_SUCCESS,JsonResponse.STATUS_200));
			}else{
				return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"User not exist into system",JsonResponse.STATUS_400)); 
			}
			
		} else {
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url",JsonResponse.STATUS_400)); 
		}
		
    }
	@GetMapping("/google/validate")
    @ApiOperation(notes = "This api helps in signin USING MICROSOFT SESSION", value = "let's signin")
    public ResponseEntity<?> newToGoogleAuthSignin(HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {
		String code = request.getParameter("code");
		String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		return googleHelper.getAccessToken(ssoURL+"/google/redirect",code);
		
	}
	@GetMapping("/google/validate/mobile")
    @ApiOperation(notes = "This api helps in signin USING MICROSOFT SESSION", value = "let's signin")
    public ResponseEntity<?> newToGoogleAuthSigninMobile(HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {
		String code = request.getParameter("code");
		String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		return googleHelper.getAccessToken(ssoURL+"/google/redirect/mobile",code);
		
	}
//	@RequestMapping("/google/redirect")
//	@ApiOperation(hidden = true,notes = "", value = "callback")
//	public JsonResponse newToGoogleAuthSignin(@RequestParam("code") String oauthCode) {
//		JsonResponse jsonResponse=new JsonResponse();
//		
//		googleHelper.getAccessToken(oauthCode);
//		jsonResponse.setResult(oauthCode);
//		jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
//		return jsonResponse;
//	}
	public String getOutlookName(String accessToken) throws IOException {

		String responseString = null;
		String mail = null;
		URI uri;

		try {
			uri = new URIBuilder().setScheme(DEFAULT_SCHEME).setHost(API_HOST).build();
		} catch (URISyntaxException e) {
			throw new IllegalStateException("Invalid drives path", e);
		}
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Authorization", "Bearer " + accessToken);
			HttpResponse rawResponse = httpClient.execute(httpGet);

			int statusCode = rawResponse.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				HttpEntity responseEntity = rawResponse.getEntity();
				responseString = EntityUtils.toString(responseEntity);
				System.out.println("Response > "+responseString);
				JSONObject objs = new JSONObject(responseString);
				mail = objs.get("userPrincipalName").toString();
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return mail;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	////////////////////////////////////////
	
	
	
	
	
	
	
	
	
	
	
	
	
	    @GetMapping("/google/signin")
	  	public void newToGoogleAuthSignin(HttpServletRequest request,HttpServletResponse httpServletResponse) throws IOException 
	  	{
	  		String subdomain=request.getServerName().split("\\.")[0];
	  		System.out.println(subdomain);
	  		String url = ssoURL+"/google/signin?tanent="+subdomain;
	  		httpServletResponse.sendRedirect(url);

	  	}
	    @GetMapping(value ="/ms/signin")
	  	public void authenticate(HttpServletRequest request, HttpServletResponse httpServletResponse)
	  			throws IOException {
	  		String subdomain=request.getServerName().split("\\.")[0];
	  		System.out.println(subdomain);
	  		String url = ssoURL+"/ms/signin?tanent="+subdomain;
	  		httpServletResponse.sendRedirect(url);

	  	}
	    
		@GetMapping("/google/redirect")
		public String googleredirect(HttpServletRequest request, HttpServletResponse httpServletResponse)
				throws IOException {
			String status = "Error";
			String code = request.getParameter("code");
			httpServletResponse.sendRedirect(frontEndURL+"/sp/auth/login?google="+code);
			
			
			return code;
		}
		@GetMapping("/ms/redirect")
		public String msredirect(HttpServletRequest request, HttpServletResponse httpServletResponse)
				throws IOException {
			String code = request.getParameter("code");
			httpServletResponse.sendRedirect(frontEndURL+"/sp/auth/login?msaauth="+code);
			return code;
		}
		@GetMapping("/alkem/redirect")
		public String alkemRedirect(HttpServletRequest request, HttpServletResponse httpServletResponse)
				throws IOException {
			String payload = request.getParameter("payload");
			System.out.println("--------------------------------------------------");
			System.out.println(payload);
			httpServletResponse.sendRedirect(frontEndURL+"/sp/auth/login?alkem="+URLEncoder.encode(payload, "UTF-8"));
			return payload;
		}
 
		
	 
		
		@GetMapping("/google/signin/mobile")
	  	public void newToGoogleAuthSigninMobile(HttpServletRequest request,HttpServletResponse httpServletResponse) throws IOException 
	  	{
	  		String subdomain=request.getServerName().split("\\.")[0];
	  		System.out.println(subdomain);
	  		String url = ssoURL+"/google/signin/mobile?tanent="+subdomain;
	  		httpServletResponse.sendRedirect(url);

	  	}
	    @GetMapping(value ="/ms/signin/mobile")
	  	public void authenticateMobile(HttpServletRequest request, HttpServletResponse httpServletResponse)
	  			throws IOException {
	  		String subdomain=request.getServerName().split("\\.")[0];
	  		System.out.println(subdomain);
	  		String url = ssoURL+"/ms/signin/mobile?tanent="+subdomain;
	  		httpServletResponse.sendRedirect(url);

	  	}
	    
		@GetMapping("/google/redirect/mobile")
		public String googleredirectMobile(HttpServletRequest request, HttpServletResponse httpServletResponse)
				throws IOException {
			String status = "Error";
			String code = request.getParameter("code");
			httpServletResponse.sendRedirect(mobilefrontEndURL+"/signin?google="+code);
			
			
			return code;
		}
		@GetMapping("/ms/redirect/mobile")
		public String msredirectMobile(HttpServletRequest request, HttpServletResponse httpServletResponse)
				throws IOException {
			String code = request.getParameter("code");
			httpServletResponse.sendRedirect(mobilefrontEndURL+"/signin?msaauth="+code);
			return code;
		}
		
		
		@GetMapping("/alkem/validate")
	    public ResponseEntity<?> authenticateUserAlkem(@RequestParam(name = "payload") String payload,  HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {

			//String payload = request.getParameter("payload");
			System.out.println("--------------------------------------------------");
			System.out.println(payload);
			try {
			Encryptor ex=new Encryptor();
			String decodedString = new String(Base64.decodeBase64(payload.getBytes()));
			decodedString=ex.encrypt(decodedString, xorKey);
			String str1=new String(Base64.decodeBase64(decodedString.getBytes()));
			System.out.println(str1);
			str1=str1.replace("Uid", "uid");
			AlkemResponse userIdResult = new ObjectMapper().readValue(str1, AlkemResponse.class);
			
			String str2=ex.encryptThisString(userIdResult.getEmail()+alkemSecretKey);
			if(str2.equalsIgnoreCase(userIdResult.getHash())) {
				
				User user = userService.getUserByEmail(userIdResult.getEmail());
				if(user!=null && user.isEmailEnabled()){
					
		        	Map<String,Permission> pg= authProfileService.getAllPermissionGroups(user);
		        	 
					UserPrinciple userPrinciple = UserPrinciple.buildSSO(user,pg);
					String jwt = jwtProvider.generateJwtTokenForMSAUser(userPrinciple);
					authLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),ApplicationLog.TYPE_USER_SIGNIN,user.getEmail(),user.getName(),null,null,user.getName()+"SSO Successfully sign in ","","","/sso/ad/validate"));
//					if(StringUtils.isNotBlank(app) &&  "mobile".equalsIgnoreCase(app)) {
//						user.setMobileAccess(jwt);
//					}
//					else {
						user.setAccessToken(jwt);
					//}
					user.setLastLogin(ZonedDateTime.now());
					user.setLastActivity(ZonedDateTime.now());
					user.setInvalidPasswordAttempts(0);
					userRepository.save(user);
					 	SystemConfiguration config = systemConfigDao.getSystemConfiguration();
		            return	ResponseEntity.ok(new JsonResponse(new JwtResponse(jwt,userPrinciple,"alkem",config),JsonResponse.RESULT_SUCCESS,JsonResponse.STATUS_200)); 
				}else{
					return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"User not exist into system",JsonResponse.STATUS_400)); 
				}
			}
			else{
				return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"User not exist into system",JsonResponse.STATUS_400)); 
			}
			}catch(Exception ex) {
				ex.printStackTrace();
				
				return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url",JsonResponse.STATUS_400)); 
			}
			
			
				
			
			
	    }
}
