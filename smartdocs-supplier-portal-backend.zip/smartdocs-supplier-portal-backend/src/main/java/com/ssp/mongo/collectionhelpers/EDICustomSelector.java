package com.ssp.mongo.collectionhelpers;

import java.util.List;

import com.ssp.dto.EDICompanyDTO;

public class EDICustomSelector {

	public static final String TYPE_ALL = "*";
	public static final String TYPE_CUSTOM = "custom";

	private String type;
	private List<EDICompanyDTO> selected;

	public EDICustomSelector() {
		super();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<EDICompanyDTO> getSelected() {
		return selected;
	}

	public void setSelected(List<EDICompanyDTO> selected) {
		this.selected = selected;
	}

}
