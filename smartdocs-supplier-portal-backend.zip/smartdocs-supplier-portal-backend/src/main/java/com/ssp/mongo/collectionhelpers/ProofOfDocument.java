package com.ssp.mongo.collectionhelpers;

public class ProofOfDocument {

	private String uuid;
	private DocumentHelper attachment;
	private String title;
	private Long uploadedDate;
	
	public ProofOfDocument() {
		super();
	}	
	public ProofOfDocument(String uuid,DocumentHelper attachment, String title, Long uploadedDate) {
		super();
		this.uuid = uuid;
		this.attachment = attachment;
		this.title = title;
		this.uploadedDate = uploadedDate;
	}
	
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public Long getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(Long uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	
	@Override
	public String toString() {
		return "ProofOfDocument [uuid=" + uuid + ", attachment=" + attachment + ", title=" + title + ", uploadedDate="
				+ uploadedDate + "]";
	}	
}
