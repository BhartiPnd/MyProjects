package com.ssp.mongo.collections;


import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CalendarData")
public class CalendarData {
	@Id
	private String id;
	private String company;
	private String year;
	private Map<String,String> holidays;
	private List<String> workweeks;
	

	public CalendarData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CalendarData(String company, String year, Map<String,String> holidays, List<String> workweeks) {
		this.id = company.toUpperCase() + year;
		this.company = company.toUpperCase();
		this.year = year;
		this.holidays = holidays;
		this.workweeks = workweeks;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	
	public Map<String, String> getHolidays() {
		return holidays;
	}

	public void setHolidays(Map<String, String> holidays) {
		this.holidays = holidays;
	}

	public List<String> getWorkweeks() {
		return workweeks;
	}

	public void setWorkweeks(List<String> workweeks) {
		this.workweeks = workweeks;
	}

}



