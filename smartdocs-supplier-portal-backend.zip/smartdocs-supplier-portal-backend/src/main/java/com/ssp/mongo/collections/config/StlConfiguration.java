package com.ssp.mongo.collections.config;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "StlConfiguration")
public class StlConfiguration {

	public static final String TYPE_Invoice="Invoice";
	public  static final String TYPE_Sbuy="Sbuy";

	
	@Id
	private String id;
	
	private boolean webVerification;
	private String verificationUrl;
	
	private boolean webScan;
	private String webScanUrl;
	
	private boolean webGUIReadyToPost;
	private String webGUIURLReadyToPost;
	
	private boolean logicalSystem;
 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isWebVerification() {
		return webVerification;
	}

	public void setWebVerification(boolean webVerification) {
		this.webVerification = webVerification;
	}

	public String getVerificationUrl() {
		return verificationUrl;
	}

	public void setVerificationUrl(String verificationUrl) {
		this.verificationUrl = verificationUrl;
	}

	public boolean isWebScan() {
		return webScan;
	}

	public void setWebScan(boolean webScan) {
		this.webScan = webScan;
	}

	public String getWebScanUrl() {
		return webScanUrl;
	}

	public void setWebScanUrl(String webScanUrl) {
		this.webScanUrl = webScanUrl;
	}

	public boolean isWebGUIReadyToPost() {
		return webGUIReadyToPost;
	}

	public void setWebGUIReadyToPost(boolean webGUIReadyToPost) {
		this.webGUIReadyToPost = webGUIReadyToPost;
	}

	public String getWebGUIURLReadyToPost() {
		return webGUIURLReadyToPost;
	}

	public void setWebGUIURLReadyToPost(String webGUIURLReadyToPost) {
		this.webGUIURLReadyToPost = webGUIURLReadyToPost;
	}

	public boolean isLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(boolean logicalSystem) {
		this.logicalSystem = logicalSystem;
	}
	
	
	
	
	
}


