package com.ssp.mongo.collections.employee;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

@Document(collection = "EmployeeMasterDocumentVersionHistory")
public class EmployeeMasterDocumentVersionHistory {

	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}
	@Id
	private String id;
	//documentType_employeeId_version
	
	//private String empDocumentId;
	
	private String documentType;
	private int version;
	
	private String employeeId;
	//private String groupId;
	
	private DocumentHelper attachment;
	private ZonedDateTime expirationDate;
	
	
	
	
	
}
