package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.LineItems;
import com.ssp.mongo.collectionhelpers.OcrProcessLog;
import com.ssp.mongo.collectionhelpers.POitmHelper;
import com.ssp.mongo.collectionhelpers.PlantDataHelper;
import com.ssp.mongo.collectionhelpers.UomPriceFactor;
import com.ssp.mongo.collections.dataObject.MaterialMaster;

@Document(collection = "InvoiceBuffer")
public class InvoiceBuffer {

	public static final String STATUS_JUNK="JUNK";
	public static final String STATUS_OCR="OCR";
	public static final String STATUS_NEW="NEW";
	public static final String STATUS_PROCEED="PROCESSED";
	public static final String STATUS_REJECTED="REJECTED";
	
	@Id
	private String id;

	// sender email.
	private String fromEmail;
	private String subject;
	private String channelEmail;
	private String status;
	private int totalAttachments;
	private ZonedDateTime receivedDate;
	private OcrProcessLog ocrLog;
	private DocumentHelper email;
	private String invoiceDocId;
	private List<DocumentHelper> attachments;
	private String title;
	private String jobId;
	private String txDocId;
	private String groupId;
	private String abbyAuth;
	private String abbyBatchId;
	private String abbySessionId;
	
	private String invoiceNumber;
	private String companyCode;
	private String supplierId;
	private String supplier;

	private ZonedDateTime invoiceDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime supplyDate;
	private boolean creditMemo;
	private String currency;

	private float taxPercent; 
	//calculated
	private double subTotal;
	// editable.
	private double discount;
	// calculated
	//private double netAmount;
	// editable
	private double taxAmount;
	// editable
	private double freightAmount;
	// calculated
	private double totalAmount;
	// input
	private double totalInvoiceAmount;
	 
	 
	private String paymentterms;
	private String freightCarrier;
	private String poNumber;
	private String poDescription;

	private String invoiceCategory;

	private String invoiceType;
	private String creator;
	private String channel;
	
	private String requestor;
	private String requestorEmail;
	private String notes;
	// private String comments;
	private List<LineItems> invoiceitems;
	private String ocrXML;
	private String rejectionReason;
	private Address remitToAddress;
	private Address shipToAddress;
	
	private boolean editable;
	
	public InvoiceBuffer() {
		super();
	}

	public InvoiceBuffer(String fromEmail, String subject, String channelEmail, String status, int totalAttachments,
			OcrProcessLog ocrLog, List<DocumentHelper> attachments, String title, String jobId, String txDocId,
			String channel) {
		super();
		this.fromEmail = fromEmail;
		this.subject = subject;
		this.channelEmail = channelEmail;
		this.status = status;
		this.totalAttachments = totalAttachments;
		this.receivedDate = ZonedDateTime.now();
		this.ocrLog = ocrLog;
		this.attachments = attachments;
		this.title = title;
		this.jobId = jobId;
		this.txDocId = txDocId;
		this.channel = channel;
	
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getChannelEmail() {
		return channelEmail;
	}

	public void setChannelEmail(String channelEmail) {
		this.channelEmail = channelEmail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTotalAttachments() {
		return totalAttachments;
	}

	public void setTotalAttachments(int totalAttachments) {
		this.totalAttachments = totalAttachments;
	}

	public ZonedDateTime getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(ZonedDateTime receivedDate) {
		this.receivedDate = receivedDate;
	}

	public OcrProcessLog getOcrLog() {
		return ocrLog;
	}

	public void setOcrLog(OcrProcessLog ocrLog) {
		this.ocrLog = ocrLog;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getTxDocId() {
		return txDocId;
	}

	public void setTxDocId(String txDocId) {
		this.txDocId = txDocId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public ZonedDateTime getDueDate() {
		return dueDate;
	}

	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}

	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	 
	public String getPaymentterms() {
		return paymentterms;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public String getFreightCarrier() {
		return freightCarrier;
	}

	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDescription() {
		return poDescription;
	}

	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}

	public String getInvoiceCategory() {
		return invoiceCategory;
	}

	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getNotes() {
		return notes;
	}

	public List<LineItems> getInvoiceitems() {
		return invoiceitems;
	}

	public void setInvoiceitems(List<LineItems> invoiceitems) {
		this.invoiceitems = invoiceitems;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public DocumentHelper getEmail() {
		return email;
	}

	public void setEmail(DocumentHelper email) {
		this.email = email;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getInvoiceDocId() {
		return invoiceDocId;
	}

	public void setInvoiceDocId(String invoiceDocId) {
		this.invoiceDocId = invoiceDocId;
	}
 
	public String getOcrXML() {
		return ocrXML;
	}

	public void setOcrXML(String ocrXML) {
		this.ocrXML = ocrXML;
	}

	public Address getRemitToAddress() {
		return remitToAddress;
	}

	public void setRemitToAddress(Address remitToAddress) {
		this.remitToAddress = remitToAddress;
	}

	public Address getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(Address shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

 
	
	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getNetAmount() {
		return this.subTotal-discount;
	}


	public double getTotalAmount() {
		return totalAmount;
	}
	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	 
	private void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public void setFreightAmount(double freightAmount) {
		this.freightAmount = freightAmount;
	}
	
	public void reCalculate(PurchaseOrder purchaseOrder, List<MaterialMaster> materials) {
		double subtotal=0;
		if(invoiceitems!=null) {
			for(LineItems lineItem:invoiceitems) {
				List<UomPriceFactor> factors = null;
				String perUom = null;
				if (this.getInvoiceCategory().equalsIgnoreCase("PO")) {
					factors = getPriceFactorsForMaterial(materials, lineItem);
					perUom = getPerUomFromPurchaseOrder(purchaseOrder, lineItem.getMaterialCode(), lineItem.getPoLineNumber());
				}
				lineItem.reCalculate("PO".equalsIgnoreCase(this.getInvoiceCategory()), factors, perUom);
				subtotal=subtotal+lineItem.getSubTotal();
			}
		}
		this.subTotal=subtotal;
		this.totalAmount=this.subTotal-discount+this.getTaxAmount()+this.getFreightAmount();
		 
	}
	
	private String getPerUomFromPurchaseOrder(PurchaseOrder purchaseOrder, String materialCode, String poLineNumber) {
		if (purchaseOrder != null && purchaseOrder.getPoitms() != null && !purchaseOrder.getPoitms().isEmpty()) {
			if (StringUtils.isNotBlank(materialCode)) {
				for (POitmHelper poItem : purchaseOrder.getPoitms()) {
					if (poItem.getMAT_CODE().equals(materialCode)) {
						return poItem.getPerUOM();
					}
				}
			} else if (StringUtils.isNotBlank(poLineNumber)) {
				for (POitmHelper poItem : purchaseOrder.getPoitms()) {
					if (poItem.getPO_LNE() != null && poItem.getPO_LNE().toString().equals(poLineNumber)) {
						return poItem.getPerUOM();
					}
				}
			}

		}
		return null;
	}

	private List<UomPriceFactor> getPriceFactorsForMaterial(List<MaterialMaster> materials, LineItems lineItem) {
		List<UomPriceFactor> factors = null;
		if (materials != null && !materials.isEmpty() && lineItem.getMaterialCode() != null) {
			for (MaterialMaster material : materials) {
				if (material.getCode().equals(lineItem.getMaterialCode())
						&& (material.getpLantDataHelper() != null && !material.getpLantDataHelper().isEmpty())) {
					for (PlantDataHelper plant : material.getpLantDataHelper()) {
						if (plant.getPlant().equals(lineItem.getPlant())) {
							return plant.getFactors();
						}
					}

				}
			}
		}
		return factors;
	}
	
	
	public Double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	public Double getFreightAmount() {
		return freightAmount;
	}

	public Float getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(Float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setTaxPercent(float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public String getAbbyAuth() {
		return abbyAuth;
	}

	public void setAbbyAuth(String abbyAuth) {
		this.abbyAuth = abbyAuth;
	}

	public String getAbbyBatchId() {
		return abbyBatchId;
	}

	public void setAbbyBatchId(String abbyBatchId) {
		this.abbyBatchId = abbyBatchId;
	}

	public String getAbbySessionId() {
		return abbySessionId;
	}

	public void setAbbySessionId(String abbySessionId) {
		this.abbySessionId = abbySessionId;
	}

	public boolean isCreditMemo() {
		return creditMemo;
	}

	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
