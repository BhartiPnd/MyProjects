package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "GoodsIssueUpdateLog")
public class GoodsIssueUpdateLog {
	
	@Id
	private String id;
	private String goodsIssueId;
	private ZonedDateTime updatedOn;
	private String updatedBy;
	private List<GoodsIssueLineUpdate> lineItems;
	
	
	public GoodsIssueUpdateLog(String goodsIssueId, String updatedBy,
			List<GoodsIssueLineUpdate> lineItems) {
		super();
		this.goodsIssueId = goodsIssueId;
		this.updatedOn = ZonedDateTime.now();
		this.updatedBy = updatedBy;
		this.lineItems = lineItems;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public ZonedDateTime getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(ZonedDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public List<GoodsIssueLineUpdate> getLineItems() {
		return lineItems;
	}
	public void setLineItems(List<GoodsIssueLineUpdate> lineItems) {
		this.lineItems = lineItems;
	}

	public String getGoodsIssueId() {
		return goodsIssueId;
	}

	public void setGoodsIssueId(String goodsIssueId) {
		this.goodsIssueId = goodsIssueId;
	}	

	
}
