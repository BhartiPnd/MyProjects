package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class CommentLog {

	private String comment;
	private ZonedDateTime dateTime; 
	private String userEmail;
	private String previousStatus;
	private String newStatus;
	private boolean workFlow;
	public CommentLog() {
		super();
	}
	public CommentLog(boolean workFlow,String comment, String userEmail,String previousStatus,String newStatus) {
		super();
		this.workFlow=workFlow;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.userEmail = userEmail;
		this.previousStatus=previousStatus;
		this.newStatus=newStatus;
	}
	public CommentLog(boolean workFlow,String comment,String userEmail) {
		super();
		this.workFlow=workFlow;
		this.comment = comment;
		this.dateTime =  ZonedDateTime.now();
		this.userEmail = userEmail;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getPreviousStatus() {
		return previousStatus;
	}
	public void setPreviousStatus(String previousStatus) {
		this.previousStatus = previousStatus;
	}
	public String getNewStatus() {
		return newStatus;
	}
	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}
	public boolean isWorkFlow() {
		return workFlow;
	}
	public void setWorkFlow(boolean workFlow) {
		this.workFlow = workFlow;
	}
	
	
}
