package com.ssp.mongo.collections.rfx;

import java.util.List;

public class RequiredDocumentType {
	private String documentName;
	private List<String> supportedFileFormates;
	private String maxSize;
	private String maxsizeUnit;
	private boolean mandatory;

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public List<String> getSupportedFileFormates() {
		return supportedFileFormates;
	}

	public void setSupportedFileFormates(List<String> supportedFileFormates) {
		this.supportedFileFormates = supportedFileFormates;
	}

	public String getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(String maxSize) {
		this.maxSize = maxSize;
	}

	public String getMaxsizeUnit() {
		return maxsizeUnit;
	}

	public void setMaxsizeUnit(String maxsizeUnit) {
		this.maxsizeUnit = maxsizeUnit;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

}
