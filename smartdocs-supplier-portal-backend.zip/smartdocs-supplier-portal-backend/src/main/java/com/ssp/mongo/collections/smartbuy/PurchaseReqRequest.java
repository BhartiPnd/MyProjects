package com.ssp.mongo.collections.smartbuy;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.smartbuy.CreatePurchaseReqRequest;
import com.ssp.dto.smartbuy.CreatePurchaseReqRequestLine;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.Agent;

@Document(collection = "PurchaseReqRequest")
public class PurchaseReqRequest {
	
	@Id
	private String id;
	private String requestId;
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String receiverEmail;
	private String receiverName;
	private Double amount;
	private String currency;
	private String supplierId;
	private ZonedDateTime createdDate;
	private String status;
	private String createdBy;
	private String plant;
	private String storageLocation;
	private List<DocumentHelper> attachments;
	private List<PurchaseReqRequestLine> requestItems;
	private Double totalAmount;
	private List<GIReceiver> receivers;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	//newly added
	private String type;
	private String typeDesc;
	private String agentName;
	private String requestor;
	private String requestorEmail;
	private GeneralState state;
	private String notes;
	private ZonedDateTime deliveryDate;
	
	
	public PurchaseReqRequest() {
		super();
	}
	public PurchaseReqRequest(CreatePurchaseReqRequest  createpurchaseOrderReq  ) {
		super();
	 
		 
		this.title = createpurchaseOrderReq.getTitle();
		this.description = createpurchaseOrderReq.getDescription();
		this.companyCode = createpurchaseOrderReq.getCompanyCode();
		this.purchasingOrg = createpurchaseOrderReq.getPurchasingOrg();
		this.purchasingGroup = createpurchaseOrderReq.getPurchasingGroup();
		this.paymentTerms = createpurchaseOrderReq.getPaymentTerms();
		this.totalAmount = createpurchaseOrderReq.getTotalAmount();
		this.currency = createpurchaseOrderReq.getCurrency();
		this.supplierId = createpurchaseOrderReq.getSupplierId();
		this.createdDate = ZonedDateTime.now();
		this.storageLocation = createpurchaseOrderReq.getStorageLocation();
		this.plant = createpurchaseOrderReq.getPlant();
		this.attachments = createpurchaseOrderReq.getAttachments();
		this.isSAPSynch = false;
		this.syncToSAP = false;
		this.type = createpurchaseOrderReq.getType(); //newly added
		this.requestorEmail=createpurchaseOrderReq.getRequestorEmail();//newly added
		this.notes=createpurchaseOrderReq.getNotes();
		this.deliveryDate=createpurchaseOrderReq.getDeliveryDate();
		int index=1; 
		List<PurchaseReqRequestLine> lineitem=new ArrayList<>();
		for(CreatePurchaseReqRequestLine line:createpurchaseOrderReq.getRequestItems()) 
		{
			PurchaseReqRequestLine lne=new PurchaseReqRequestLine(line);
			lne.setId(id+"-"+index);
			lne.setLineNo(index);
			lne.setRequestId(String.valueOf(id));
			lne.setStatus(status);
			lineitem.add(lne);
			index++;
		}
		this.setRequestItems(lineitem);
		this.receivers = createpurchaseOrderReq.getReceivers();
		this.receiverEmail = createpurchaseOrderReq.getReceiverEmail();
		this.receiverName = createpurchaseOrderReq.getReceiverName();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	 
	 
	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}
	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}
 
	public boolean isSAPSynch() {
		return isSAPSynch;
	}
	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	 
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	 
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	//newly added
	public void updateAgent(Agent agent) 
	{
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
		
	}
	public List<PurchaseReqRequestLine> getRequestItems() {
		return requestItems;
	}
	public void setRequestItems(List<PurchaseReqRequestLine> requestItems) {
		this.requestItems = requestItems;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public GeneralState getState() {
		return state;
	}
	public void setState(GeneralState state) {
		this.state = state;
	}
	public boolean isSyncToSAP() {
		return syncToSAP;
	}
	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public String getTypeDesc() {
		return typeDesc;
	}
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getReceiverEmail() {
		return receiverEmail;
	}
	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public List<GIReceiver> getReceivers() {
		return receivers;
	}
	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}

	
}
