package com.ssp.mongo.collections.rfx;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.AwardedLine;
import com.ssp.dto.smartbuy.CreateRfx;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.RFxQandA;

@Document(collection = "rfx")
public class Rfx {
	
	public static final String STATUS_NEW="NEW";
	public static final String STATUS_PUBLISHED="PUBLISHED";
	public static final String STATUS_INEVALUATION="INEVALUATION";
	public static final String STATUS_COMPLETED="COMPLETED";
	public static final String STATUS_CANCELED="CANCELED";
	public static final String STATUS_CLOSED = "CLOSED";
	public static final String STATUS_AWARDED = "AWARDED";
	public static final String STATUS_INPROCESS="INPROCESS";
	public static final String STATUS_REVOKE="REVOKE";
	public static final String STATUS_DRAFT="DRAFT";	
	
	
	public static final String VISIBILITY_PUBLIC = "PUBLIC";
	public static final String VISIBILITY_PRIVATE = "PRIVATE";
	
	public static final String BID_SELECTED_PENDING = "Pending";
	public static final String BID_SELECTED_SELECTED = "Selected";
	
	
	@Id
	private String id;
	private String title;
	private String companyCode;
	private String rfxNo;
	private String type;
	
	private String visibility;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;
	
	private String requestorEmail;
	private String requestorName;
	
	private String buyerEmail;
	private String buyerName;

	private List<RFXItems> items;
	private List<RFXBidder> bidders;
	private List<RequiredDocumentType> requiredDocuments;
	private List<RequiredInfo> requiredInfo;
	private List<RFxQandA> questions; 
	
//	from when vendor can submit their bid
	private ZonedDateTime submissionStartDate;
	
//	till when vendor can submit their bid
	private ZonedDateTime submissionEndDate;
	
//	till when vendor can ask question
	private ZonedDateTime qAndADeadline;
	
//	when rfx published
	private ZonedDateTime publishedDate;
	
	private String status;

	private List<DocumentHelper> attachments;
	private boolean isErpSynch;
	private Long erpSynchDate;
	private boolean isErpSynchAck;
	private boolean syncToERP;
	
	private String createdBy;
	private ZonedDateTime createdDate;
	private String lastModifiedBy;
	private ZonedDateTime lastModifiedDate;
	
	private int questionSequenceNo;
	private boolean canBid;
	private boolean canQanda;
	
	private boolean isAwarded;

	private String bidSelected;
	private String selectedBidId;
	
	private String error;
	private boolean splitAward;
	private List<AwardedLine> selectedLines;

	public Rfx() {
		
	}
	
	public Rfx(CreateRfx  createRfx) {
		 
	            super();
		this.title = createRfx.getTitle();
		this.companyCode = createRfx.getCompanyCode();
		this.type = createRfx.getType();
		this.submissionStartDate = createRfx.getSubmissionStartDate();
		this.submissionEndDate = createRfx.getSubmissionEndDate();
		this.qAndADeadline = createRfx.getqAndADeadline();
		this.visibility = createRfx.getVisibility();
		this.purchasingGroup = createRfx.getPurchasingGroup();
		this.purchasingGroupDesc = createRfx.getPurchasingGroupDesc();
		this.purchasingOrg = createRfx.getPurchasingOrg();
		this.purchasingOrgDesc = createRfx.getPurchasingOrgDesc();
		this.requestorEmail = createRfx.getRequestorEmail();
		this.requestorName = createRfx.getRequestorName();
		this.buyerEmail = createRfx.getBuyerEmail();
		this.buyerName = createRfx.getBuyerName();
		this.attachments = createRfx.getAttachments();
		this.isErpSynch = false;
		this.syncToERP = false;
		this.items = createRfx.getItems();
		this.bidders = createRfx.getBidders();
		this.requiredDocuments = createRfx.getRequiredDocuments();
		this.requiredInfo = createRfx.getRequiredInfo();
		this.publishedDate = createRfx.getPublishedDate();
		this.attachments = createRfx.getAttachments();
	}
	
	public void addItems(List<RFXItems> items,int m) {
		if (this.items == null) {
			this.setItems(new ArrayList<>());
		}
		for (RFXItems rfxItem : items) {
			rfxItem.setLineNo(++m+"");
			this.getItems().add(rfxItem);
			
		}
//		this.getItems().addAll(items);
	}
	
	public void addBidders(List<RFXBidder> bidders) {
		if (this.bidders == null) {
			this.setBidders(new ArrayList<>());
		}
		this.getBidders().addAll(bidders);
	}

	public void addRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		if (this.requiredDocuments == null) {
			this.setRequiredDocuments(new ArrayList<>());
		}
		this.getRequiredDocuments().addAll(requiredDocuments);
	}
	
	public void addRequiredInfo(List<RequiredInfo> requiredInfo) {
		if (this.requiredInfo == null) {
			this.setRequiredInfo(new ArrayList<>());
		}
		this.getRequiredInfo().addAll(requiredInfo);
	}
	
	public void addAttachments(List<DocumentHelper> attachment) {
		if (this.attachments == null) {
			this.setAttachments(new ArrayList<>());
		}
		this.getAttachments().addAll(attachment);
	}


	public String getRfxNo() {
		return rfxNo;
	}

	public List<RFxQandA> getQuestions() {
		return questions;
	}

	public void setQuestions(List<RFxQandA> questions) {
		this.questions = questions;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public List<RFXItems> getItems() {
		return items;
	}

	public void setItems(List<RFXItems> items) {
		this.items = items;
	}

	public List<RFXBidder> getBidders() {
		return bidders;
	}

	public void setBidders(List<RFXBidder> bidders) {
		this.bidders = bidders;
	}

	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public List<RequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}

	public void setRequiredInfo(List<RequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public boolean isErpSynch() {
		return isErpSynch;
	}

	public void setErpSynch(boolean isErpSynch) {
		this.isErpSynch = isErpSynch;
	}

	public Long getErpSynchDate() {
		return erpSynchDate;
	}

	public void setErpSynchDate(Long erpSynchDate) {
		this.erpSynchDate = erpSynchDate;
	}

	public boolean isErpSynchAck() {
		return isErpSynchAck;
	}

	public void setErpSynchAck(boolean isErpSynchAck) {
		this.isErpSynchAck = isErpSynchAck;
	}

	public boolean isSyncToERP() {
		return syncToERP;
	}

	public void setSyncToERP(boolean syncToERP) {
		this.syncToERP = syncToERP;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public ZonedDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(ZonedDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getQuestionSequenceNo() {
		return questionSequenceNo;
	}

	public void setQuestionSequenceNo(int questionSequenceNo) {
		this.questionSequenceNo = questionSequenceNo;
	}

	public boolean isCanBid() {
		return canBid;
	}

	public void setCanBid(boolean canBid) {
		this.canBid = canBid;
	}
	

	public boolean isCanQanda() {
		return canQanda;
	}

	public void setCanQanda(boolean canQanda) {
		this.canQanda = canQanda;
	}

	public boolean isAwarded() {
		return isAwarded;
	}

	public void setAwarded(boolean isAwarded) {
		this.isAwarded = isAwarded;
	}

	public String getBidSelected() {
		return bidSelected;
	}

	public void setBidSelected(String bidSelected) {
		this.bidSelected = bidSelected;
	}

	public String getSelectedBidId() {
		return selectedBidId;
	}

	public void setSelectedBidId(String selectedBidId) {
		this.selectedBidId = selectedBidId;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public boolean isSplitAward() {
		return splitAward;
	}

	public void setSplitAward(boolean splitAward) {
		this.splitAward = splitAward;
	}

	public List<AwardedLine> getSelectedLines() {
		return selectedLines;
	}

	public void setSelectedLines(List<AwardedLine> selectedLines) {
		this.selectedLines = selectedLines;
	}
	
	

}
