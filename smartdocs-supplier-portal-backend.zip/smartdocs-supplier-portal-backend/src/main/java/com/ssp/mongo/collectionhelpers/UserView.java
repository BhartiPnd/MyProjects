package com.ssp.mongo.collectionhelpers;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "user")
public class UserView {

	private String email;

	private String firstname;
	private String lastname;
	private String mobile;
	private String role;
	private List<CustomRoles> userRoles;
	public String getEmail() {
		return email;
	}
	public String getFirstname() {
		return firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public String getMobile() {
		return mobile;
	}
	public String getRole() {
		return role;
	}
	public List<CustomRoles> getUserRoles() {
		return userRoles;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public void setUserRoles(List<CustomRoles> userRoles) {
		this.userRoles = userRoles;
	}
	
	
}
