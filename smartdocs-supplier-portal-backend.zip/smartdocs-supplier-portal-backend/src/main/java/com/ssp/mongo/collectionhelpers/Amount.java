package com.ssp.mongo.collectionhelpers;

public class Amount {
	
	private Double value;
	private String currency;
	
	public Amount() {
	}
	public Amount(Double value, String currency) {
		super();
		this.value = value;
		this.currency = currency;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	
	
}
