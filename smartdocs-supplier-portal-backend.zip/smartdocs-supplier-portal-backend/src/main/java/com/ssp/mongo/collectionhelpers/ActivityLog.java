package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class ActivityLog {
	
	public static final String TYPE_SYSTEM="SYSTEM";
	public static final String TYPE_USER="USER";
	
	private int step;
	private int seq;
	private String activityCode;
	private String activity;
	private String userName;
	private String userEmail;
	
	private String actualUser;

	private String comment;
	private ZonedDateTime dateTime;
	
	private boolean isCollaborate;
	private String collaboratedWith;
	
	private boolean synWithSAP;
	private String channel;
	private String type;
	private String exception;
	
	/**
	 * These two fields will be used to log the
	 * detail of the person who will do signature activity
	 */
	private String onBehalfEmail;
	private String onBehalfUserName;
	private String signedPersonRole;
	private String bidno;
	private String vendorId;
	
	private List<DocumentHelper> attachments;
	
	public void addAttachments(DocumentHelper attachment) {
		if (this.attachments == null) {
			this.setAttachments(new ArrayList<>());
		}
		this.getAttachments().add(attachment);
	}

	
	public ActivityLog() {
		super();
		this.dateTime = ZonedDateTime.now();
	}
	public ActivityLog(
			int step, 
			int seq, 
			String comment,
			String type) {
		super();
		this.synWithSAP=false;
		this.step = step;
		this.seq = seq;
		 
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel="PORTAL";
		this.type="";
	}
	public ActivityLog(
			int step, 
			int seq, 
			String activityCode,
			String activity,
			String userEmail, 
			String comment) {
		super();
		this.synWithSAP=false;
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userEmail = userEmail;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel="PORTAL";
	}
	public ActivityLog(
			int step, 
			int seq, 
			String activityCode,
			String activity,
			String username, 
			String userEmail, 
			String comment) {
		super();
		this.synWithSAP=false;
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName=username;
		this.userEmail = userEmail;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel="PORTAL";
	}

	public ActivityLog(int step, int seq, boolean isCollaborated, String collaboratedWith, String activityCode,
			String activity, String username, String userEmail,String actualUser, String comment) {
		super();
		this.synWithSAP = false;
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = username;
		this.userEmail = userEmail;
		this.comment = comment;
		this.isCollaborate = isCollaborated;
		this.collaboratedWith = collaboratedWith;
		this.actualUser = actualUser;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
	}
	
	public ActivityLog(int step, String activityCode, String activity, String userName, String userEmail,
			String onBehalfEmail, String onBehalfUserName, String actualUser) {
		super();
		this.step = step;
		this.seq = 1;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = userName;
		this.userEmail = userEmail;
		this.onBehalfEmail = onBehalfEmail;
		this.onBehalfUserName = onBehalfUserName;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
		this.actualUser = actualUser;
	}
	
	public ActivityLog(int step, String activityCode, String activity, String userName, String userEmail,
			String onBehalfEmail, String onBehalfUserName, String actualUser, String signedPersonRole) {
		super();
		this.step = step;
		this.seq = 1;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = userName;
		this.userEmail = userEmail;
		this.onBehalfEmail = onBehalfEmail;
		this.onBehalfUserName = onBehalfUserName;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
		this.actualUser = actualUser;
		this.signedPersonRole = signedPersonRole;
	}
	
	public ActivityLog(int step, int seq, String activityCode, String activity, String userName, String userEmail,
			String actualUser, String comment) {
		super();
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = userName;
		this.userEmail = userEmail;
		this.actualUser = actualUser;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
	}
	public ActivityLog(int step, int seq, String activityCode, String activity, String userName, String userEmail,
			String actualUser, String comment,String exception) {
		super();
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = userName;
		this.userEmail = userEmail;
		this.actualUser = actualUser;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
		this.exception=exception;
	}
	public ActivityLog(int step, int seq, String activityCode, String activity, String userName, String userEmail,
			String comment, DocumentHelper attachment) {
		this.step = step;
		this.seq = seq;
		this.activityCode = activityCode;
		this.activity = activity;
		this.userName = userName;
		this.userEmail = userEmail;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.channel = "PORTAL";
		addAttachments(attachment);
	}
	public int getStep() {
		return step;
	}
	public int getSeq() {
		return seq;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public String getActivity() {
		return activity;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public String getComment() {
		return comment;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getActualUser() {
		return actualUser;
	}

	public void setActualUser(String actualUser) {
		this.actualUser = actualUser;
	}

	public boolean isSynWithSAP() {
		return synWithSAP;
	}

	public void setSynWithSAP(boolean synWithSAP) {
		this.synWithSAP = synWithSAP;
	}

	@Override
	public String toString() {
		return "ActivityLog [step=" + step + ", seq=" + seq + ", activityCode=" + activityCode + ", activity="
				+ activity + ", userName=" + userName + ", userEmail=" + userEmail + ", actualUser=" + actualUser
				+ ", comment=" + comment + ", dateTime=" + dateTime + ", synWithSAP=" + synWithSAP + "]";
	}

	public boolean isCollaborate() {
		return isCollaborate;
	}

	public void setCollaborate(boolean isCollaborate) {
		this.isCollaborate = isCollaborate;
	}

	public String getCollaboratedWith() {
		return collaboratedWith;
	}

	public void setCollaboratedWith(String collaboratedWith) {
		this.collaboratedWith = collaboratedWith;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}
	
	public String getOnBehalfEmail() {
		return onBehalfEmail;
	}
	
	public void setOnBehalfEmail(String onBehalfEmail) {
		this.onBehalfEmail = onBehalfEmail;
	}
	
	public String getOnBehalfUserName() {
		return onBehalfUserName;
	}
	
	public void setOnBehalfUserName(String onBehalfUserName) {
		this.onBehalfUserName = onBehalfUserName;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}


	public String getSignedPersonRole() {
		return signedPersonRole;
	}


	public void setSignedPersonRole(String signedPersonRole) {
		this.signedPersonRole = signedPersonRole;
	}


	public String getBidno() {
		return bidno;
	}


	public void setBidno(String bidno) {
		this.bidno = bidno;
	}


	public String getVendorId() {
		return vendorId;
	}


	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

 
	
	
	
	
	
}
