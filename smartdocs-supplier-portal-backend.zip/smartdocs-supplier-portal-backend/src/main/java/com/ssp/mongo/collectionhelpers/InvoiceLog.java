package com.ssp.mongo.collectionhelpers;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class InvoiceLog {
	 
		private String message;
		private String comment;
		private ZonedDateTime date;
		private LogUser user;
		
		// logType==0 if system log; 
		// logType ==1 if user log;
		 private int logType;

		 
		 
		 public InvoiceLog() {}
		 public InvoiceLog(String message,String comment,LogUser user,int logType) {
				this.message=message;
				this.comment=comment;
				this.user=user;
				this.logType=logType;
				this.date=ZonedDateTime.now(ZoneId.systemDefault());
		 }
		  
		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getComment() {
			return comment;
		}

		public void setComment(String comment) {
			this.comment = comment;
		}

		public ZonedDateTime getDate() {
			return date;
		}

		public void setDate(ZonedDateTime date) {
			this.date = date;
		}

		public int getLogType() {
			return logType;
		}

		public void setLogType(int logType) {
			this.logType = logType;
		}

		public LogUser getUser() {
			return user;
		}

		public void setUser(LogUser user) {
			this.user = user;
		}
		
}
