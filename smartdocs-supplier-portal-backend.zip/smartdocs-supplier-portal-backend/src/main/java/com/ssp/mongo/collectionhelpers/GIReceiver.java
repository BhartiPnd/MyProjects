package com.ssp.mongo.collectionhelpers;

public class GIReceiver {

	private String receiverEmail;
	private String receiverName;

	public GIReceiver() {
		super();
	}

	public GIReceiver(String receiverEmail, String receiverName) {
		super();
		this.receiverEmail = receiverEmail;
		this.receiverName = receiverName;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

}
