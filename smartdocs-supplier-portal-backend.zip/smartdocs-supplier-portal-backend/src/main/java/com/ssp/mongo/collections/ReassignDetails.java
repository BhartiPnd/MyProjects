package com.ssp.mongo.collections;

import java.util.List;

import com.ssp.mongo.collections.workflow.WorkItem;

public class ReassignDetails {

	
	//private String fromUser;
	private String toUser;
	private List<WorkItem> workitems;
	/*public String getFromUser() {
		return fromUser;
	}
	public void setFromUser(String fromUser) {
		this.fromUser = fromUser;
	}*/
	public String getToUser() {
		return toUser;
	}
	public void setToUser(String toUser) {
		this.toUser = toUser;
	}
	public List<WorkItem> getWorkitems() {
		return workitems;
	}
	public void setWorkitems(List<WorkItem> workitems) {
		this.workitems = workitems;
	}
	
	
	
	
	
}
