package com.ssp.mongo.collections.smartbuy;

import java.time.ZonedDateTime;

public class PRLineItemUpdate {
	private String activity;
	private ZonedDateTime date;
	 
	private String refNo;
	private Double qty;
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	
	
}
