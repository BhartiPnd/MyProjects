package com.ssp.mongo.collections.inventory;

import java.util.ArrayList;
import java.util.List;



public class StorageLocationInfo {
	
	private String plantCode;
	private String companyCode;
	
	private String plantDesc;
	
	private Double unresStock;
	private Double qainsStock;
	
	private Double reservedStock;
	private Double onRoadStock;
	private Double slocTransderStock;
	private Double grBlockedStock;
	
	private Double blockedStock;
	private Double breturnedStock;
	
	private List<StorageLocationStock> slocStock;

	public StorageLocationInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPlantCode() {
		return plantCode;
	}


	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public Double getUnresStock() {
		return unresStock;
	}

	public void setUnresStock(Double unresStock) {
		this.unresStock = unresStock;
	}

	public Double getQainsStock() {
		return qainsStock;
	}

	public void setQainsStock(Double qainsStock) {
		this.qainsStock = qainsStock;
	}

	public Double getReservedStock() {
		return reservedStock;
	}

	public void setReservedStock(Double reservedStock) {
		this.reservedStock = reservedStock;
	}

	public Double getOnRoadStock() {
		return onRoadStock;
	}

	public void setOnRoadStock(Double onRoadStock) {
		this.onRoadStock = onRoadStock;
	}

	public Double getSlocTransderStock() {
		return slocTransderStock;
	}

	public void setSlocTransderStock(Double slocTransderStock) {
		this.slocTransderStock = slocTransderStock;
	}

	public Double getGrBlockedStock() {
		return grBlockedStock;
	}

	public void setGrBlockedStock(Double grBlockedStock) {
		this.grBlockedStock = grBlockedStock;
	}

	public Double getBlockedStock() {
		return blockedStock;
	}

	public void setBlockedStock(Double blockedStock) {
		this.blockedStock = blockedStock;
	}

	public Double getBreturnedStock() {
		return breturnedStock;
	}

	public void setBreturnedStock(Double breturnedStock) {
		this.breturnedStock = breturnedStock;
	}

	public List<StorageLocationStock> getSlocStock() {
		return slocStock;
	}

	public void setSlocStock(List<StorageLocationStock> slocStock) {
		this.slocStock = slocStock;
	}

	
	
	
	

}
