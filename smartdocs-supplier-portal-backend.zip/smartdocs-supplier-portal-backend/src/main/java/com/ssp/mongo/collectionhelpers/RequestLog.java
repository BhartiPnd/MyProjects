package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class RequestLog {
	private String step;
	private String seq;
	private String activity;
	private String activityText;
	private String userEmail;
	private String comment;
	private ZonedDateTime dateTime;
	
	public RequestLog() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RequestLog(String step, String seq, String activity, String activityText, String userEmail, String comment,
			ZonedDateTime dateTime) {
		super();
		this.step = step;
		this.seq = seq;
		this.activity = activity;
		this.activityText = activityText;
		this.userEmail = userEmail;
		this.comment = comment;
		this.dateTime = dateTime;
	}
	
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getActivityText() {
		return activityText;
	}
	public void setActivityText(String activityText) {
		this.activityText = activityText;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
	

}
