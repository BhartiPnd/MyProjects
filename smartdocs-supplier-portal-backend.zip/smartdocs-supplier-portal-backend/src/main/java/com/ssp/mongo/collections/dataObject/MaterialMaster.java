package com.ssp.mongo.collections.dataObject;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.PlantDataHelper;

@Document(collection = "MaterialMaster")
public class MaterialMaster {

	@Id
	private String code;
	private String desc;
	
	private String uom;
	private String uomDesc;
	private String grp;
	private String grpDesc;
	
	private String matType;
	private String hsnCode;
	private String orderUom;
	private String orderUomDesc;
	
	private boolean inventory;
	private String baseUom;
	
	private boolean catchWeight;
	
	//newly added
	@Field("pLantDataHelper")
	private List<PlantDataHelper> pLantDataHelper = null;
	
	public List<PlantDataHelper> getpLantDataHelper() {
		return pLantDataHelper;
	}
	public void setpLantDataHelper(List<PlantDataHelper> pLantDataHelper) {
		this.pLantDataHelper = pLantDataHelper;
	}	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	
	
	
	
	@Override
	public String toString() {
		return "MaterialMaster [code=" + code + ", desc=" + desc + ", uom=" + uom + ", uomDesc=" + uomDesc + ", grp="
				+ grp + ", grpDesc=" + grpDesc + ", matType=" + matType + ", hsnCode=" + hsnCode + ", orderUom="
				+ orderUom + ", orderUomDesc=" + orderUomDesc + ", inventory=" + inventory + ", baseUom=" + baseUom
				+ ", pLantDataHelper=" + pLantDataHelper + "]";
	}
	public String getGrp() {
		return grp;
	}
	public void setGrp(String grp) {
		this.grp = grp;
	}
	public String getGrpDesc() {
		return grpDesc;
	}
	public void setGrpDesc(String grpDesc) {
		this.grpDesc = grpDesc;
	}
	public String getMatType() {
		return matType;
	}
	public void setMatType(String matType) {
		this.matType = matType;
	}
	
	public boolean isCatchWeight() {
		return catchWeight;
	}
	public void setCatchWeight(boolean catchWeight) {
		this.catchWeight = catchWeight;
	}
	public String getHsnCode() {
		return hsnCode;
	}
	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}
	public String getOrderUom() {
		return orderUom;
	}
	public void setOrderUom(String orderUom) {
		this.orderUom = orderUom;
	}
	public String getOrderUomDesc() {
		return orderUomDesc;
	}
	public void setOrderUomDesc(String orderUomDesc) {
		this.orderUomDesc = orderUomDesc;
	}
	public boolean isInventory() {
		return inventory;
	}
	public void setInventory(boolean inventory) {
		this.inventory = inventory;
	}
	public String getBaseUom() {
		return baseUom;
	}
	public void setBaseUom(String baseUom) {
		this.baseUom = baseUom;
	}
	public String getUomDesc() {
		return uomDesc;
	}
	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}
	
	
}
