package com.ssp.mongo.collectionhelpers;


import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import com.ssp.dto.CreateGIRLineItems;
import com.ssp.mongo.collections.MaterialInventoryView;
import com.ssp.mongo.collections.dataObject.MaterialMaster;

public class GoodsIssueItems {
	
	
	private int itemNo;
	private String materialCode;
	private String materialDesc;
	private double giQty;
	private double originalQty;
	private String giUOM;
	private double giUnitPrice;
	private String plant;
	private String storageLocation;
	private ZonedDateTime deliveryDate;
	private long per;
	private String perUOM;
	private String UOM;
	private String suppliedBy;
	private double unitPrice;
	private double netValue;
	private String currency;
	private String glAccount;
	private double taxAmount;
	private String costCenter;
	private String materialGroup;
	private String materialGroupDesc;
	private String storageLocationDesc;
 	private String plantDesc;
 	private String costCenterDesc;
 	private String glAccountDesc;
 	private String status;
 	private boolean deleted;
 	private String comment;
 	private String itemCategory;
 	private String accountAssignmentType;
 	private String wbsElementNo;
 	private String wbsElementNoDesc;
 	private MaterialMaster materialMasterObject;
 	private MaterialInventoryView inventory;
	public List<GIRLineItemUpdate> lineUpdate;
 	private Double factor;
 	private Double perFactor;
 	
	public GoodsIssueItems() {
		
	}
	public GoodsIssueItems(CreateGIRLineItems line) {
		this.materialCode = line.getMaterialCode();
		this.materialDesc = line.getMaterialDesc();
		this.materialGroup = line.getMaterialGroup();
		this.suppliedBy = line.getSuppliedBy();
		this.giQty = line.getQty();
		this.giUOM = line.getUom();
		this.UOM=line.getUom();
		this.unitPrice = line.getUnitprice();
		this.currency = line.getCurrency();
		this.perUOM = line.getPerUOM();
		this.per = line.getPer();
		this.plant = line.getPlant();
		this.costCenter=line.getCostCenter();
		this.taxAmount=line.getTaxAmount();
		this.storageLocation=line.getStorageLocation();
		this.costCenter=line.getCostCenter();
		this.glAccount=line.getGlAccount();
		this.originalQty=line.getOriginalQty();
		this.deleted=line.isDeleted();
		this.comment=line.getComment();
		this.itemCategory=line.getCategory();
		this.accountAssignmentType = line.getAccountAssignmentType();
		this.materialGroupDesc = line.getMaterialGroupDesc();
		this.glAccountDesc = line.getGlAccountDesc();
		this.costCenterDesc=line.getCostCenterDesc();
		this.wbsElementNo = line.getWbsElementNo();
		this.wbsElementNoDesc = line.getWbsElementNoDesc();
		this.plantDesc = line.getPlantDesc();
		this.storageLocationDesc = line.getStorageLocationDesc();
		this.deliveryDate = line.getDeliveryDate();
		this.factor = line.getFactor();
		this.perFactor = line.getPerFactor();
	} 
	
	public void addGIRLineItemUpdate(GIRLineItemUpdate lineItemUpdate) {
		if (this.lineUpdate == null) {
			this.lineUpdate = new ArrayList<>();
		}

		this.lineUpdate.add(lineItemUpdate);
	}
	
	public int getItemNo() {
		return itemNo;
	}
	public void setItemNo(int itemNo) {
		this.itemNo = itemNo;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public double getGiQty() {
		return giQty;
	}
	
	
	public MaterialMaster getMaterialMasterObject() {
		return materialMasterObject;
	}
	public void setMaterialMasterObject(MaterialMaster materialMasterObject) {
		this.materialMasterObject = materialMasterObject;
	}
	public String getUOM() {
		return UOM;
	}
	public void setUOM(String uOM) {
		UOM = uOM;
	}
	public void setGiQty(double giQty) {
		this.giQty = giQty;
	}
	public String getGiUOM() {
		return giUOM;
	}
	public void setGiUOM(String giUOM) {
		this.giUOM = giUOM;
	}
	public double getGiUnitPrice() {
		return giUnitPrice;
	}
	public void setGiUnitPrice(double giUnitPrice) {
		this.giUnitPrice = giUnitPrice;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public long getPer() {
		return per;
	}
	public void setPer(long per) {
		this.per = per;
	}
	public String getPerUOM() {
		return perUOM;
	}
	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	public String getSuppliedBy() {
		return suppliedBy;
	}
	public void setSuppliedBy(String suppliedBy) {
		this.suppliedBy = suppliedBy;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public double getNetValue() {
		return netValue;
	}
	public void setNetValue(double netValue) {
		this.netValue = netValue;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}

	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}

	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public String getCostCenterDesc() {
		return costCenterDesc;
	}

	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}

	public String getGlAccountDesc() {
		return glAccountDesc;
	}

	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getOriginalQty() {
		return originalQty;
	}
	public void setOriginalQty(double originalQty) {
		this.originalQty = originalQty;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getItemCategory() {
		return itemCategory;
	}
	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	public String getAccountAssignmentType() {
		return accountAssignmentType;
	}
	public void setAccountAssignmentType(String accountAssignmentType) {
		this.accountAssignmentType = accountAssignmentType;
	}
	public String getMaterialGroupDesc() {
		return materialGroupDesc;
	}
	public void setMaterialGroupDesc(String materialGroupDesc) {
		this.materialGroupDesc = materialGroupDesc;
	}
	public String getWbsElementNo() {
		return wbsElementNo;
	}
	public void setWbsElementNo(String wbsElementNo) {
		this.wbsElementNo = wbsElementNo;
	}
	public String getWbsElementNoDesc() {
		return wbsElementNoDesc;
	}
	public void setWbsElementNoDesc(String wbsElementNoDesc) {
		this.wbsElementNoDesc = wbsElementNoDesc;
	}
	public MaterialInventoryView getInventory() {
		return inventory;
	}
	public void setInventory(MaterialInventoryView inventory) {
		this.inventory = inventory;
	}
	public Double getFactor() {
		return factor;
	}
	public void setFactor(Double factor) {
		this.factor = factor;
	}
	public Double getPerFactor() {
		return perFactor;
	}
	public void setPerFactor(Double perFactor) {
		this.perFactor = perFactor;
	}
	
	
}
