package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "emailChannelLog")
public class EmailChannelLog {

	@Id
	private String id;
	private ZonedDateTime date;
	private String latestEmailFrom;
	private String latestEmailSubject;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	public String getLatestEmailFrom() {
		return latestEmailFrom;
	}
	public void setLatestEmailFrom(String latestEmailFrom) {
		this.latestEmailFrom = latestEmailFrom;
	}
	public String getLatestEmailSubject() {
		return latestEmailSubject;
	}
	public void setLatestEmailSubject(String latestEmailSubject) {
		this.latestEmailSubject = latestEmailSubject;
	}
	
}
