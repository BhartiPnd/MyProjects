package com.ssp.mongo.collections;

public class GoodsIssueLineUpdate {
	
	private int lineNo;
	private String materialCode;
	private double qty;
	private double originalQty;
	private boolean deleted;
	private boolean changeDetected;
	private String change;
	
	public GoodsIssueLineUpdate(int lineNo, String materialCode, double qty, double originalQty, boolean deleted,
			boolean changeDetected, String change) {
		super();
		this.lineNo = lineNo;
		this.materialCode = materialCode;
		this.qty = qty;
		this.originalQty = originalQty;
		this.deleted = deleted;
		this.changeDetected = changeDetected;
		this.change = change;
	}
	
	public int getLineNo() {
		return lineNo;
	}
	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public double getOriginalQty() {
		return originalQty;
	}
	public void setOriginalQty(double originalQty) {
		this.originalQty = originalQty;
	}
	
	public boolean isChangeDetected() {
		return changeDetected;
	}
	public void setChangeDetected(boolean changeDetected) {
		this.changeDetected = changeDetected;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getChange() {
		return change;
	}

	public void setChange(String change) {
		this.change = change;
	}

}
