package com.ssp.mongo.collections.diversitySpend;

import java.time.ZonedDateTime;

import com.ssp.dto.DBSubmissionRequest;
import com.ssp.mongo.util.GeneralUtil;

public class LatestDBSubmission {

	
	private double totalDBAmountPaidtillDate;
	
	//% of DB in relation to contracts
	private double dbGoalAchivedPercent;
	
	//% of DB amount in relation to Amount paid to Prime vendor
	private double dbPercentOfAmountPaidtoPrimeVendor;
	
	// this is % of total amount paid to prime in relation to Total contract amount.
	private double percentPaidtoPrime;
	
	private ZonedDateTime latestDBSubmissionDate;
	
	private boolean finalReport;
	private String reportId;
	private String year;
	private String month;
	private ZonedDateTime reportDate;
	
	private boolean hasAttachment;
	
	private double totalContractAmountPaidTillDate;
	
	// construction.
	private double totalCommitedAmount=0.0;
	private double totalEarnedTillDate=0.0;
	private double totalPaidTillDate=0.0;
	
	public LatestDBSubmission() {
		
	}
	public LatestDBSubmission(DBSubmissionRequest report,String requestId , Double targetValue) {
		
		this.year=report.getYear();
		this.month=report.getMonth();
		this.reportDate =GeneralUtil.getMidDate(report.getMonth(), report.getYear());

        this.hasAttachment = report.getAttachments() != null && report.getAttachments().size() > 0;
		this.totalContractAmountPaidTillDate=report.getContractAmountPaidTillDate();
		this.reportId=requestId;
		this.latestDBSubmissionDate = ZonedDateTime.now();
		
		this.finalReport=report.isFinalReport();
		 
		
		try{
			this.percentPaidtoPrime = report.getContractAmountPaidTillDate()*100/targetValue;
		}
		catch(Exception ex) {
			this.percentPaidtoPrime =0.0d;
		}	
	}
	
	public double getTotalDBAmountPaidtillDate() {
		return totalDBAmountPaidtillDate;
	}
	public double getDbGoalAchivedPercent() {
		return dbGoalAchivedPercent;
	}
	public double getDbPercentOfAmountPaidtoPrimeVendor() {
		return dbPercentOfAmountPaidtoPrimeVendor;
	}
	public ZonedDateTime getLatestDBSubmissionDate() {
		return latestDBSubmissionDate;
	}
	public boolean isFinalReport() {
		return finalReport;
	}
	public String getReportId() {
		return reportId;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public double getTotalCommitedAmount() {
		return totalCommitedAmount;
	}
	public double getTotalEarnedTillDate() {
		return totalEarnedTillDate;
	}
	public double getTotalPaidTillDate() {
		return totalPaidTillDate;
	}
	public void setTotalDBAmountPaidtillDate(double totalDBAmountPaidtillDate) {
		this.totalDBAmountPaidtillDate = totalDBAmountPaidtillDate;
	}
	public void setDbGoalAchivedPercent(double dbGoalAchivedPercent) {
		this.dbGoalAchivedPercent = dbGoalAchivedPercent;
	}
	public void setDbPercentOfAmountPaidtoPrimeVendor(double dbPercentOfAmountPaidtoPrimeVendor) {
		this.dbPercentOfAmountPaidtoPrimeVendor = dbPercentOfAmountPaidtoPrimeVendor;
	}
	public void setLatestDBSubmissionDate(ZonedDateTime latestDBSubmissionDate) {
		this.latestDBSubmissionDate = latestDBSubmissionDate;
	}
	public void setFinalReport(boolean finalReport) {
		this.finalReport = finalReport;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setTotalCommitedAmount(double totalCommitedAmount) {
		this.totalCommitedAmount = totalCommitedAmount;
	}
	public void setTotalEarnedTillDate(double totalEarnedTillDate) {
		this.totalEarnedTillDate = totalEarnedTillDate;
	}
	public void setTotalPaidTillDate(double totalPaidTillDate) {
		this.totalPaidTillDate = totalPaidTillDate;
	}
	public boolean isHasAttachment() {
		return hasAttachment;
	}
	public void setHasAttachment(boolean hasAttachment) {
		this.hasAttachment = hasAttachment;
	}
	
	public double getPercentPaidtoPrime() {
		return percentPaidtoPrime;
	}
	public void setPercentPaidtoPrime(double percentPaidtoPrime) {
		this.percentPaidtoPrime = percentPaidtoPrime;
	}
	public ZonedDateTime getReportDate() {
		return reportDate;
	}
	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	public double getTotalContractAmountPaidTillDate() {
		return totalContractAmountPaidTillDate;
	}
	public void setTotalContractAmountPaidTillDate(double totalContractAmountPaidTillDate) {
		this.totalContractAmountPaidTillDate = totalContractAmountPaidTillDate;
	}
	
}
