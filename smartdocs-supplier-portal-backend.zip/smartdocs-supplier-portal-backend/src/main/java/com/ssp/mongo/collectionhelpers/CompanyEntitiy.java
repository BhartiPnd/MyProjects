package com.ssp.mongo.collectionhelpers;

public class CompanyEntitiy {

	private String companyCode;
	private String  paymentTerm;
	private boolean paymentBlock;
	
	
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPaymentTerm() {
		return paymentTerm;
	}
	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}
	public boolean isPaymentBlock() {
		return paymentBlock;
	}
	public void setPaymentBlock(boolean paymentBlock) {
		this.paymentBlock = paymentBlock;
	}
	
	
	
}
