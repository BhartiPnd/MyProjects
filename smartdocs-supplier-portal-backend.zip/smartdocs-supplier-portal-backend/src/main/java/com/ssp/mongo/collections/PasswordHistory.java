package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class PasswordHistory {

	private String userId;
	private String password;
	private ZonedDateTime dateChanged;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public ZonedDateTime getDateChanged() {
		return dateChanged;
	}
	public void setDateChanged(ZonedDateTime dateChanged) {
		this.dateChanged = dateChanged;
	}
	

}
