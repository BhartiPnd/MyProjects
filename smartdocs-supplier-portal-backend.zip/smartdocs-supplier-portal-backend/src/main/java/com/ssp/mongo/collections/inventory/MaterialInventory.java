package com.ssp.mongo.collections.inventory;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "MaterialInventory")
public class MaterialInventory {
	@Id
	private String id;
	private String materialCode;
	private String materialDesc;
	private String status;
	private String category;
	private List<InventoryUom> uoms;

	public MaterialInventory() {
		super();
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<InventoryUom> getUoms() {
		return uoms;
	}

	public void setUoms(List<InventoryUom> uoms) {
		this.uoms = uoms;
	}

	
}
