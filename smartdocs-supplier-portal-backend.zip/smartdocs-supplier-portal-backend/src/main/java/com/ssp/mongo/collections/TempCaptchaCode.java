package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="tempCaptchaCode")
public class TempCaptchaCode {
	
	@Id
	private String captcha;
	private String token;
	private String ipAddress;
	private boolean isUsed;
	private ZonedDateTime validity;
	 
	public String getCaptcha() {
		return captcha;
	}
	public String getToken() {
		return token;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public boolean isUsed() {
		return isUsed;
	}
	public ZonedDateTime getValidity() {
		return validity;
	}
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public void setUsed(boolean isUsed) {
		this.isUsed = isUsed;
	}
	public void setValidity(ZonedDateTime validity) {
		this.validity = validity;
	}
 

}
