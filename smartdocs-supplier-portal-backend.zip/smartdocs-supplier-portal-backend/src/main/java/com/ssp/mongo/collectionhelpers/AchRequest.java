package com.ssp.mongo.collectionhelpers;

public class AchRequest {
	
	public static final String ACCOUNT_STATUS_NEW="NEW";
	public static final String ACCOUNT_STATUS_CHANGE_ACC="EXISTING_CHANGE";

 	
	private Boolean achCcd;
	private Boolean achCcdPlus;
	private Boolean achCtx;
	
	private String emailAddress ;
	private String accountStatus;// New, Change Account Profile
	
	 
	private String accountType;
	// if accountType=other then other should be there.
	private String other;
	
	private String bankName;
	private String bankRoutingNo;
	private String bankAccountNo;
	
	private String street;
	private String city;
	private String state;
	private String zip;
	private String country;
	private Phone phone;
	private String achDec;
	public Boolean getAchCcd() {
		return achCcd;
	}
	public void setAchCcd(Boolean achCcd) {
		this.achCcd = achCcd;
	}
	public Boolean getAchCcdPlus() {
		return achCcdPlus;
	}
	public void setAchCcdPlus(Boolean achCcdPlus) {
		this.achCcdPlus = achCcdPlus;
	}
	public Boolean getAchCtx() {
		return achCtx;
	}
	public void setAchCtx(Boolean achCtx) {
		this.achCtx = achCtx;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	 
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankRoutingNo() {
		return bankRoutingNo;
	}
	public void setBankRoutingNo(String bankRoutingNo) {
		this.bankRoutingNo = bankRoutingNo;
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public Phone getPhone() {
		return phone;
	}
	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAchDec() {
		return achDec;
	}
	public void setAchDec(String achDec) {
		this.achDec = achDec;
	}
	 
	
	
}
