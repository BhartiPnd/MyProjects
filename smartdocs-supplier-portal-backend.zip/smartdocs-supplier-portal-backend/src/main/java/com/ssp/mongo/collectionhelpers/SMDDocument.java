package com.ssp.mongo.collectionhelpers;

import java.util.ArrayList;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collections.requests.FieldValues;
import com.ssp.mongo.collections.requests.VendorMasterDocumentChangeRequest;
 


@Document(collection = "smdDocument")
public class SMDDocument {
	
	@Id
	private String id;
	private String supplierId;
	private String supplierName;

	private String documentType;
	private String classification;
	private String description;
	
	// this is actual doc type value that come from sap.
	private String docTypeTag;
	private DocumentHelper latestDocument;
	
	private int activeVersion;
	
	//	//private String parentDocumentId;
	//private Map<String, Object> attributes; 
	private List<DocumentHelper> document;
	private String status;

	private List<FieldValues> fieldValues;
	
	private List<ActivityLog> activityLogs;
	private boolean isSAPSynch;
	private Long sapSynchDate;
	private boolean isSAPSynchACK;
	private boolean zeroDaysNotification;
	private boolean thirtyDaysNotification;
	private boolean  sixtyDaysNotification;
	
	
	private SMDDocument(VendorMasterDocumentChangeRequest request) {
		super();
		this.documentType=request.getDocumentType();
		this.setSupplierId(request.getSupplierId());
		request.getDocument().setVersionNo(String.valueOf(1));
		request.getDocument().setExpiryDate(request.getValidityEndDate());
		request.getDocument().setValidFromDate(request.getValidityStartDate());
		this.setActiveVersion(1);
		this.setLatestDocument(request.getDocument());
		this.addDocument(request.getDocument());
	}
	
	private SMDDocument() {
		super();
	}
	public String getId() {
		return id;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public String getDocumentType() {
		return documentType;
	}
	
	public DocumentHelper getLatestDocument() {
		return latestDocument;
	}
	public int getActiveVersion() {
		return activeVersion;
	}
	
	public List<DocumentHelper> getDocument() {
		return document;
	}
	public String getStatus() {
		return status;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public boolean isSAPSynch() {
		return isSAPSynch;
	}
	public Long getSapSynchDate() {
		return sapSynchDate;
	}
	public boolean isSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	
	public void setLatestDocument(DocumentHelper latestDocument) {
		this.latestDocument = latestDocument;
	}
	public void setActiveVersion(int activeVersion) {
		this.activeVersion = activeVersion;
	}
	
	public void setDocument(List<DocumentHelper> document) {
		this.document = document;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public void addActivityLogs(ActivityLog  activityLog) {
			if(this.getActivityLogs()==null){
				this.setActivityLogs(new ArrayList<>());
			}
			if(this.getActivityLogs().size()>1){
				ActivityLog activityLog2=this.activityLogs.get(this.getActivityLogs().size()-1);
				if(activityLog.getStep()==activityLog2.getStep()){
					activityLog.setSeq(activityLog2.getSeq()+1);
				}
			}
			
			this.getActivityLogs().add(activityLog);
	 } 
	public void addActivityLogs(List<ActivityLog>  activityLogs) 
	{
		if(activityLogs!=null) {
			if(this.getActivityLogs()==null){
				this.setActivityLogs(new ArrayList<>());
			}
			for(ActivityLog activityLog:activityLogs) {
				this.getActivityLogs().add(activityLog);
			}
		}
		
	}
	public void addDocument(DocumentHelper  documentHelper) {
		if(this.getDocument()==null){
			this.setDocument(new ArrayList<>());
		}
		this.getDocument().add(documentHelper);
		 
	}

	public String getDocTypeTag() {
		return docTypeTag;
	}

	public void setDocTypeTag(String docTypeTag) {
		this.docTypeTag = docTypeTag;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public List<FieldValues> getFieldValues() {
		return fieldValues;
	}

	public void setFieldValues(List<FieldValues> fieldValues) {
		this.fieldValues = fieldValues;
	}

	public boolean isZeroDaysNotification() {
		return zeroDaysNotification;
	}

	public void setZeroDaysNotification(boolean zeroDaysNotification) {
		this.zeroDaysNotification = zeroDaysNotification;
	}

	public boolean isThirtyDaysNotification() {
		return thirtyDaysNotification;
	}

	public void setThirtyDaysNotification(boolean thirtyDaysNotification) {
		this.thirtyDaysNotification = thirtyDaysNotification;
	}

	public boolean isSixtyDaysNotification() {
		return sixtyDaysNotification;
	}

	public void setSixtyDaysNotification(boolean sixtyDaysNotification) {
		this.sixtyDaysNotification = sixtyDaysNotification;
	}
	
}
