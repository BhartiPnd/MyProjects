package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class VendorMasterDocumentHelper {

	
	private String documentid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	//private String filebase64;
	public String uploadBy;
	public ZonedDateTime uploadedDate;
	
	public String documentType;
	private ZonedDateTime validityStartDate;
	private ZonedDateTime expiryDate;
	private String versionNo;
	//private String status;
	public String getDocumentid() {
		return documentid;
	}
	public String getFilename() {
		return filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public String getAttid() {
		return attid;
	}
	public String getArid() {
		return arid;
	}
	public String getUploadBy() {
		return uploadBy;
	}
	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}
	public String getDocumentType() {
		return documentType;
	}
	public ZonedDateTime getValidityStartDate() {
		return validityStartDate;
	}
	public ZonedDateTime getExpiryDate() {
		return expiryDate;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setDocumentid(String documentid) {
		this.documentid = documentid;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public void setAttid(String attid) {
		this.attid = attid;
	}
	public void setArid(String arid) {
		this.arid = arid;
	}
	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}
	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public void setValidityStartDate(ZonedDateTime validityStartDate) {
		this.validityStartDate = validityStartDate;
	}
	public void setExpiryDate(ZonedDateTime expiryDate) {
		this.expiryDate = expiryDate;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	
	
}
