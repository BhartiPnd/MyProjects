package com.ssp.mongo.collections.bidsheet;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.bidSheet.CreateBidSheetRequest;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.AuditTrackingLog;

@Document(collection = "bidSheetRequest")
public class BidSheetRequest {

	@Id
	private String id;
	private String requestId;
	private String title;
	private String proposalType;
	private String companyCode;
	private String companyName;
	private String purchasingOrg;
	private String purchasingOrgDesc;
	private String requestorEmail;
	private String requestorName;
	private String plant;
	private String purchasingGrp;
	private String purchasingGrpDesc;
	private boolean scheduled;
	private List<AuditTrackingLog> logs;
	private String frequency;
	private String occurance;

	private List<DocumentHelper> attachments;
	private List<BidSheetItems> items;
	private List<VendorDetail> vendors;
	
	private List<Map<String, String>> bidSheetItems;

	private ZonedDateTime startDate;
	private ZonedDateTime endDate;
	
	//added for OneTime Frequency
	private ZonedDateTime effectiveDate;
	private ZonedDateTime expirationDate;
	
	private ZonedDateTime publishedDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime lastModifiedDate;

	private String status;
	private String fileName;
	private String createdBy;
	private String lastModifiedBy;

	public BidSheetRequest() {
		super();
	}

	public BidSheetRequest(CreateBidSheetRequest createBidSheetRequest) {
		this.title = createBidSheetRequest.getTitle();
		this.proposalType = createBidSheetRequest.getProposalType();
		this.companyCode = createBidSheetRequest.getCompanyCode();
		this.companyName = createBidSheetRequest.getCompanyName();
		this.purchasingOrg = createBidSheetRequest.getPurchasingOrg();
		this.purchasingOrgDesc = createBidSheetRequest.getPurchasingOrgDesc();
		this.requestorEmail = createBidSheetRequest.getRequestorEmail();
		this.requestorName = createBidSheetRequest.getRequestorName();
		this.scheduled = createBidSheetRequest.isScheduled();
		this.logs = createBidSheetRequest.getLogs();
		this.frequency = createBidSheetRequest.getFrequency();
		this.occurance = createBidSheetRequest.getOccurance();
		this.startDate = createBidSheetRequest.getStartDate();
		this.endDate = createBidSheetRequest.getEndDate();
		this.attachments = createBidSheetRequest.getAttachments();
		this.items = createBidSheetRequest.getItems();
		this.vendors = createBidSheetRequest.getVendors();
		this.publishedDate = createBidSheetRequest.getPublishedDate();
		this.status = createBidSheetRequest.getStatus();
		this.fileName = createBidSheetRequest.getFileName();
		this.bidSheetItems = createBidSheetRequest.getBidSheetItems();
		this.plant = createBidSheetRequest.getPlant();
		this.purchasingGrp = createBidSheetRequest.getPurchasingGrp();
		this.purchasingGrpDesc = createBidSheetRequest.getPurchasingGrpDesc();
		this.effectiveDate = createBidSheetRequest.getEffectiveDate();
		this.expirationDate = createBidSheetRequest.getExpirationDate();

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ZonedDateTime getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(ZonedDateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getProposalType() {
		return proposalType;
	}

	public void setProposalType(String proposalType) {
		this.proposalType = proposalType;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public boolean isScheduled() {
		return scheduled;
	}

	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	public List<AuditTrackingLog> getLogs() {
		return logs;
	}

	public void setLogs(List<AuditTrackingLog> logs) {
		this.logs = logs;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getOccurance() {
		return occurance;
	}

	public void setOccurance(String occurance) {
		this.occurance = occurance;
	}

	public ZonedDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}

	public ZonedDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public List<BidSheetItems> getItems() {
		return items;
	}

	public void setItems(List<BidSheetItems> items) {
		this.items = items;
	}

	public List<VendorDetail> getVendors() {
		return vendors;
	}

	public void setVendors(List<VendorDetail> vendors) {
		this.vendors = vendors;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public ZonedDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(ZonedDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public List<Map<String, String>> getBidSheetItems() {
		return bidSheetItems;
	}

	public void setBidSheetItems(List<Map<String, String>> bidSheetItems) {
		this.bidSheetItems = bidSheetItems;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPurchasingGrp() {
		return purchasingGrp;
	}

	public void setPurchasingGrp(String purchasingGrp) {
		this.purchasingGrp = purchasingGrp;
	}

	public String getPurchasingGrpDesc() {
		return purchasingGrpDesc;
	}

	public void setPurchasingGrpDesc(String purchasingGrpDesc) {
		this.purchasingGrpDesc = purchasingGrpDesc;
	}
	
	

}
