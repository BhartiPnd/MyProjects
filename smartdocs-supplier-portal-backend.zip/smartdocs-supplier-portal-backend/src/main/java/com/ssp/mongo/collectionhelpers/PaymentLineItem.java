package com.ssp.mongo.collectionhelpers;

public class PaymentLineItem {

	private String invoiceNumber;

	private String finincialYear;
	private String invoiceRefNo;

	private String invoiceAmount;
	
	private String invoicePostedDate;
	private String poNo;
	private String invoiceCategory;
	private String invoiceType;
	private String invoiceTypeDesc;
	private String docId;
	private String channel;
	
	public PaymentLineItem(){}
	public PaymentLineItem(String invoiceNumber,String finincialYear,String invoiceRefNo,String invoiceAmount,String invoicePostedDate,String poNo,String invoiceCategory,String invoiceType){
		super();

		this.invoiceNumber=invoiceNumber;
		this.finincialYear=finincialYear;
		this.invoiceRefNo=invoiceRefNo;

	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getFinincialYear() {
		return finincialYear;
	}

	public void setFinincialYear(String finincialYear) {
		this.finincialYear = finincialYear;
	}
	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}
	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}
	public String getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public String getInvoicePostedDate() {
		return invoicePostedDate;
	}
	public void setInvoicePostedDate(String invoicePostedDate) {
		this.invoicePostedDate = invoicePostedDate;
	}
	public String getPoNo() {
		return poNo;
	}
	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}
	public String getInvoiceCategory() {
		return invoiceCategory;
	}
	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getInvoiceTypeDesc() {
		return invoiceTypeDesc;
	}
	public void setInvoiceTypeDesc(String invoiceTypeDesc) {
		this.invoiceTypeDesc = invoiceTypeDesc;
	}
	public String getDocId() {
		return docId;
	}
	public String getChannel() {
		return channel;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
}
