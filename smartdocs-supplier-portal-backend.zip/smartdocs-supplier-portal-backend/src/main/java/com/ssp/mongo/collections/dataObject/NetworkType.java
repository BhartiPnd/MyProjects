package com.ssp.mongo.collections.dataObject;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "NetworkType")
public class NetworkType {
	
	
	@Id
	private String stfNetworkNo;
	private String networkNo;
	private String description;
	
	public NetworkType() {
		
	}
	
	public String getStfNetworkNo() {
		return stfNetworkNo;
	}
	public void setStfNetworkNo(String stfNetworkNo) {
		this.stfNetworkNo = stfNetworkNo;
	}
 
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNetworkNo() {
		return networkNo;
	}
	public void setNetworkNo(String networkNo) {
		this.networkNo = networkNo;
	}
	
	
}
 