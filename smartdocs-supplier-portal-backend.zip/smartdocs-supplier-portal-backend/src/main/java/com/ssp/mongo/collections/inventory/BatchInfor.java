package com.ssp.mongo.collections.inventory;



public class BatchInfor {
	
	private String batchNo;
	private double unresStock;
	
	
	public BatchInfor() {
		
	}
	
	
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public double getUnresStock() {
		return unresStock;
	}
	public void setUnresStock(double unresStock) {
		this.unresStock = unresStock;
	}
	
	
	
	

}
