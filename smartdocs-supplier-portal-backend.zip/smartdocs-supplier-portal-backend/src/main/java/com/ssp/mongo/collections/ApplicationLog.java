package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "applicationLog")
public class ApplicationLog {
	
	
	
	public static final String TYPE_USER_SIGNIN="SignIn";
	
	public static final String TYPE_REG_REQ_SUBMISSION="RegistrationRequestSubmission";
	public static final String TYPE_VENDOR_CHANGE_REQ_SUBMISSION="VendorChangeRequestSubmission";
	public static final String TYPE_INVOICE_SUBMISSION="InvoiceSubmission";
	public static final String TYPE_OA_SUBMISSION="OASubmission";
	public static final String TYPE_ASN_SUBMISSION="ASNSubmission";
	
	
	public static final String TYPE_USER_SIGNOUT="SignOut";
	public static final String TYPE_USER_PASSWORDCHANGE="PasswordChange";
	public static final String TYPE_PROFILEUPDATE="ProfileUpdate";

	public static final String TYPE_VENDOR_DOCUMENT_UPLOAD="VendorDocumentUpload";
	public static final String TYPE_SUBSTITUTION_SETTION_CHANGED="SubstitutionSettingsChange";
	
	
	
	//public static final String TYPE_USER_SIGNIN="All inbox actions";
	public static final String TYPE_EXPENSE_SUBMISSION="ExpenseSubmission";

	
	
	public static final String TYPE_WORKFLOW_REASSIGNED="WorkFlowReassigned";
	public static final String TYPE_USER_CREATED="UserCreation";
	public static final String TYPE_ANNOUNCEMENT_CREATED="AnnouncementsCreation";
	
	public static final String TYPE_INVOICE_DELETION="InvoiceDeletion";
	public static final String TYPE_RXPORT_DATA_OBJECT="CroneJobTriggerdForExportDataObject";
	
	public static final String TYPE_BID_AWARD="BidAward";
	
	public static final String TYPE_INVOICE_BUFFER_MOVE_TO_JUNK="InvoiceBufferMovetoJunk";
	
	@Id
	private String id;
	
	private String ip;
	
	private ZonedDateTime dateTime;
	
	private String type;
	
	//agent means who user did this activity.
	private String agent;
	
	private String name;
	
	private String itemType;
	
	private String itemId;
	
	private String title;
	
	private String description;
	
	private String supplierId;
	
	private String logSource;
	
	private String apiPath;
	
	public ApplicationLog() {
		super();
	}

	public ApplicationLog(String ip,String type, String agent,String name, String itemType, String itemId,
			String title, String description,String logSource,String apiPath) {
		super();
		this.ip = ip;
		this.dateTime = ZonedDateTime.now();
		this.type = type;
		this.agent = agent;
		this.name = name;
		this.itemType = itemType;
		this.itemId = itemId;
		this.title = title;
		this.description = description;
		this.logSource=logSource;
		this.apiPath=apiPath;
	}
	public ApplicationLog(String ip,String type, String agent,String name, String itemType, String itemId,
			String title, String description,String logSource,String apiPath,String supplierId) {
		super();
		this.ip = ip;
		this.dateTime = ZonedDateTime.now();
		this.type = type;
		this.agent = agent;
		this.name = name;
		this.itemType = itemType;
		this.itemId = itemId;
		this.title = title;
		this.description = description;
		this.logSource=logSource;
		this.apiPath=apiPath;
		this.supplierId=supplierId;
	}
	public String getId() {
		return id;
	}

	public String getIp() {
		return ip;
	}

	public ZonedDateTime getDateTime() {
		return dateTime;
	}

	public String getType() {
		return type;
	}

	public String getAgent() {
		return agent;
	}

	public String getItemType() {
		return itemType;
	}

	public String getItemId() {
		return itemId;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLogSource() {
		return logSource;
	}

	public void setLogSource(String logSource) {
		this.logSource = logSource;
	}

	public String getApiPath() {
		return apiPath;
	}

	public void setApiPath(String apiPath) {
		this.apiPath = apiPath;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	
	
	
	
	
}
