package com.ssp.mongo.collections.diversitySpend;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.dto.DBSubmissionLine;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.util.GeneralUtil;

@Document(collection = "Tier2Submittion")
public class Tier2Submission {

 	public static final String STATUS_NEW = "NEW";


	public static final String SUBMISSIONTYPE_PROFESSIONAL = "Professional";
	public static final String SUBMISSIONTYPE_CONSTRUCTION = "Construction";

	@Id
	private String id;

	private String requestId;

	private String contractId;
    private String contractName;

	private String primeVendorId;
	private String primeVendorName;

	private String submissionType;
	private String title;
	private boolean isFinalReport;
	
	private String year;
	private String month;
	
	
	private String subcontractorId;
	private boolean isSubContractorDBVendor;
	private String subcontractorName;
	private boolean isSubContractorPortalVendor;
	//private List<String> productCategoriesOfSubContractor;

	
	
	//private Double contractAmountPaidTillDate;
	
	// CommitedAmountOn Commitement Sheet.
	private Double commitedAmount;
	private Double amountOfSubcontracts;
	private Double amountEarnedThisMonth;
	private Double amountPaidThisMonth;	
	private Double amountEarnedToDate;
	private Double amountPaidToDate;
	
	//private String paymentTxNumber;
	
	private ZonedDateTime submissionDate;
	
	private Float dbGoalPercent;
	private double contractAmountPaidTillDate;
	
	@Field("currency")
	private String currency;

	private List<String> dbeTypes;

	@Field("createdDate")
	private ZonedDateTime createdDate;

	 
	private String comment;

	//private List<DocumentHelper> attachments;

	private List<ActivityLog> activityLogs;
	
	private ZonedDateTime reportDate;
		
	public Tier2Submission() {
		
	}
	public Tier2Submission(DBSubmissionLine line,DBSubmission dbSubmission,Float dbGoalPercent) {
		super();
		this.requestId = dbSubmission.getRequestId();
		this.contractId = dbSubmission.getContractId();
		this.contractName = dbSubmission.getContractName();
		this.primeVendorId = dbSubmission.getPrimeVendorId();
		this.primeVendorName = dbSubmission.getPrimeVendorName();
		this.submissionType = dbSubmission.getSubmissionType();
		this.title = dbSubmission.getTitle();
		this.isFinalReport = dbSubmission.isFinalReport();
		this.subcontractorId = line.getSubcontractorId();
		this.isSubContractorDBVendor = line.isSubContractorDBVendor();
		this.subcontractorName = line.getSubcontractorName();
		//this.contractAmountPaidTillDate = contractAmountPaidTillDate;
		this.commitedAmount = line.getCommitedAmount();
		this.amountOfSubcontracts = line.getAmountOfSubcontracts();
		this.amountEarnedThisMonth = line.getAmountEarnedThisMonth();
		this.amountPaidThisMonth = line.getAmountPaidThisMonth();
		this.amountEarnedToDate = line.getAmountEarnedToDate();
		this.amountPaidToDate = line.getAmountPaidToDate();
		this.submissionDate = dbSubmission.getSubmissionDate();
		this.currency = dbSubmission.getCurrency();
		this.createdDate = ZonedDateTime.now();
		this.dbeTypes=line.getDbeTypes();
		this.isSubContractorPortalVendor=line.isSubContractorPortalVendor();
		
		this.year=dbSubmission.getYear();
		this.month=dbSubmission.getMonth();
		this.reportDate=GeneralUtil.getMidDate(dbSubmission.getMonth(), dbSubmission.getYear());
		
	 	this.dbGoalPercent=dbGoalPercent;
		this.contractAmountPaidTillDate=dbSubmission.getContractAmountPaidToDate();
	}
 
 

	public void setSubContractorDBVendor(boolean isSubContractorDBVendor) {
		this.isSubContractorDBVendor = isSubContractorDBVendor;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getPrimeVendorId() {
		return primeVendorId;
	}

	public void setPrimeVendorId(String primeVendorId) {
		this.primeVendorId = primeVendorId;
	}

	public String getSubcontractorId() {
		return subcontractorId;
	}

	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}

	public String getSubcontractorName() {
		return subcontractorName;
	}

	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	 
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
 

	public List<String> getDbeTypes() {
		return dbeTypes;
	}

	public void setDbeTypes(List<String> dbeTypes) {
		this.dbeTypes = dbeTypes;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
 

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	 
 
	public Double getAmountOfSubcontracts() {
		return amountOfSubcontracts;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	 
	public void setAmountOfSubcontracts(Double amountOfSubcontracts) {
		this.amountOfSubcontracts = amountOfSubcontracts;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public String getPrimeVendorName() {
		return primeVendorName;
	}

	public void setPrimeVendorName(String primeVendorName) {
		this.primeVendorName = primeVendorName;
	}


	public String getTitle() {
		return title;
	}

	public boolean isFinalReport() {
		return isFinalReport;
	}

	public Double getCommitedAmount() {
		return commitedAmount;
	}

	public Double getAmountEarnedThisMonth() {
		return amountEarnedThisMonth;
	}

	public Double getAmountPaidThisMonth() {
		return amountPaidThisMonth;
	}

	public Double getAmountEarnedToDate() {
		return amountEarnedToDate;
	}

	public Double getAmountPaidToDate() {
		return amountPaidToDate;
	}

	public ZonedDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setFinalReport(boolean isFinalReport) {
		this.isFinalReport = isFinalReport;
	}

	public void setCommitedAmount(Double commitedAmount) {
		this.commitedAmount = commitedAmount;
	}

	public void setAmountEarnedThisMonth(Double amountEarnedThisMonth) {
		this.amountEarnedThisMonth = amountEarnedThisMonth;
	}

	public void setAmountPaidThisMonth(Double amountPaidThisMonth) {
		this.amountPaidThisMonth = amountPaidThisMonth;
	}

	public void setAmountEarnedToDate(Double amountEarnedToDate) {
		this.amountEarnedToDate = amountEarnedToDate;
	}

	public void setAmountPaidToDate(Double amountPaidToDate) {
		this.amountPaidToDate = amountPaidToDate;
	}
	public void setSubmissionDate(ZonedDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}
	 public void addActivityLogs(ActivityLog  activityLog) {
			if(this.getActivityLogs()==null){
				this.setActivityLogs(new ArrayList<>());
			}
			if(this.getActivityLogs().size()>1){
				ActivityLog activityLog2=this.activityLogs.get(this.getActivityLogs().size()-1);
				if(activityLog.getStep()==activityLog2.getStep()){
					activityLog.setSeq(activityLog2.getSeq()+1);
				}
			}
			
			this.getActivityLogs().add(activityLog);
	 }
 
	public boolean isSubContractorDBVendor() {
		return isSubContractorDBVendor;
	}

	public void setSubContractorDBVendor(Boolean isSubContractorDBVendor) {
		this.isSubContractorDBVendor = (isSubContractorDBVendor==null)?false:isSubContractorDBVendor;
		
	}
	public boolean isSubContractorPortalVendor() {
		return isSubContractorPortalVendor;
	}
	public void setSubContractorPortalVendor(boolean isSubContractorPortalVendor) {
		this.isSubContractorPortalVendor = isSubContractorPortalVendor;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public ZonedDateTime getReportDate() {
		return reportDate;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	public Float getDbGoalPercent() {
		return dbGoalPercent;
	}
	 
	public void setDbGoalPercent(Float dbGoalPercent) {
		this.dbGoalPercent = dbGoalPercent;
	}
	public double getContractAmountPaidTillDate() {
		return contractAmountPaidTillDate;
	}
	public void setContractAmountPaidTillDate(double contractAmountPaidTillDate) {
		this.contractAmountPaidTillDate = contractAmountPaidTillDate;
	}
	 
}
