package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.TaxCodeComponentHelper;

@Document(collection = "taxcode")
public class TaxCode 
{
	@Id
	private String id;


	private String taxProcedure;

	private String taxId;

	private String taxType;

	private String taxIdDec;
	
	private Double taxPercentage;
	
	@Field("taxComponentHelper")
	private List<TaxCodeComponentHelper> taxComponentHelper = null;
	
	public List<TaxCodeComponentHelper> getTaxComponentHelper() {
		return taxComponentHelper;
	}

	public void setTaxComponentHelper(List<TaxCodeComponentHelper> taxComponentHelper) {
		this.taxComponentHelper = taxComponentHelper;
	}

	private Double percentage;

	private String tcomponent;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTaxProcedure() {
		return taxProcedure;
	}

	public void setTaxProcedure(String taxProcedure) {
		this.taxProcedure = taxProcedure;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getTaxType() {
		return taxType;
	}

	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	public String getTaxIdDec() {
		return taxIdDec;
	}

	public void setTaxIdDec(String taxIdDec) {
		this.taxIdDec = taxIdDec;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public String getTcomponent() {
		return tcomponent;
	}

	public void setTcomponent(String tcomponent) {
		this.tcomponent = tcomponent;
	}

	public Double getTaxPercentage() {
		return taxPercentage;
	}

	public void setTaxPercentage(Double taxPercentage) {
		this.taxPercentage = taxPercentage;
	}

	 

	
}
