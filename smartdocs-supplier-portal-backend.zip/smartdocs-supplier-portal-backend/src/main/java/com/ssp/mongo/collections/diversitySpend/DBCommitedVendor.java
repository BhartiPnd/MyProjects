package com.ssp.mongo.collections.diversitySpend;

public class DBCommitedVendor {
	
	private String subcontractorId;
	private String subcontractorName;
	private double commitedAmount;
	
	public String getSubcontractorId() {
		return subcontractorId;
	}
	public String getSubcontractorName() {
		return subcontractorName;
	}
	public double getCommitedAmount() {
		return commitedAmount;
	}
	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}
	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}
	public void setCommitedAmount(double commitedAmount) {
		this.commitedAmount = commitedAmount;
	}

/*	private boolean isSubContractorDBVendor;
	private boolean isSubContractorPortalVendor;
	private double amountOfSubcontracts;
	private double amountEarnedToDate;
	private double amountPaidToDate;
	private List<String> dbeTypes;
	private ZonedDateTime lastUpdated ;
*/
	
}