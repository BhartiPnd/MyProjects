package com.ssp.mongo.collectionhelpers;

public class RfxPermission {
	
	private boolean canEdit;
	private boolean respondQAndA;
	private boolean revoke;
	private boolean evaluate;
	
	public RfxPermission() {
		super();
	}
	
	public boolean isCanEdit() {
		return canEdit;
	}
	public void setCanEdit(boolean canEdit) {
		this.canEdit = canEdit;
	}
	public boolean isRespondQAndA() {
		return respondQAndA;
	}
	public void setRespondQAndA(boolean respondQAndA) {
		this.respondQAndA = respondQAndA;
	}
	public boolean isRevoke() {
		return revoke;
	}
	public void setRevoke(boolean revoke) {
		this.revoke = revoke;
	}
	public boolean isEvaluate() {
		return evaluate;
	}
	public void setEvaluate(boolean evaluate) {
		this.evaluate = evaluate;
	}
	
	
}
