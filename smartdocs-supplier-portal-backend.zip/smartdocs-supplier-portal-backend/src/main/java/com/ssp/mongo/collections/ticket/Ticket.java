package com.ssp.mongo.collections.ticket;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.CreateTicketRequest;
import com.ssp.mongo.collectionhelpers.DocumentHelper;


@Document(collection = "Ticket")
public class Ticket {
	
	public static final String TYPE_PO="PO";
	public static final String TYPE_INVOICE="Invoice";
	public static final String TYPE_GIR="GIR";
	public static final String TYPE_OTHER="Other";
	
	public static final String STATUS_NEW="New";
	public static final String STATUS_ACCEPTED="Accepted";
	public static final String STATUS_RESOLVED="Resolved";
	public static final String STATUS_CLOSED="Closed";
	
	
	
	@Id
	private String id;
	private String ticketNo;
	
	private String category;
	private String subCategory;
	
	private String title;
	private String description;
	
	private String itemType;
	private String itemId;
	private ZonedDateTime createdDate;
	private ZonedDateTime lastUpdated;
	private ZonedDateTime lastAction;
	private String vendorId;
	private String createdBy;
	private String status;
	private String severity;
	
	private String owner;
	
	private boolean internal;

	private List<TicketLog> activityLogs;
	private List<DocumentHelper> attachments;
	private Map<String, String> metaData;
	private ZonedDateTime nextEscalationNotificationDate;
	public Ticket() {	super();}
	public Ticket(String vendorId,CreateTicketRequest ticketRequest) {
		super();
	 
		this.title = ticketRequest.getTitle();
		this.description = ticketRequest.getDescription();
		this.itemType = ticketRequest.getItemType();
		this.itemId = ticketRequest.getItemId();
		this.createdDate = ZonedDateTime.now();
		this.lastUpdated = ZonedDateTime.now();
        this.vendorId = vendorId;
		this.status = STATUS_NEW;
		this.severity = ticketRequest.getSeverity();
		this.category = ticketRequest.getCategory();
		this.subCategory=ticketRequest.getSubCategory();
		this.attachments = ticketRequest.getAttachments();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	 

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	 
	public List<TicketLog> getActivityLogs() {
		return activityLogs;
	}
	public void setActivityLogs(List<TicketLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
 
	public Map<String, String> getMetaData() {
		return metaData;
	}
	public void setMetaData(Map<String, String> metaData) {
		this.metaData = metaData;
	}
	public void addActivityLogs(TicketLog activityLog) {
		if (this.getActivityLogs() == null) {
			this.setActivityLogs(new ArrayList<>());
		}
		this.getActivityLogs().add(activityLog);
	}
	public ZonedDateTime getLastAction() {
		return lastAction;
	}
	public void setLastAction(ZonedDateTime lastAction) {
		this.lastAction = lastAction;
	}
	public ZonedDateTime getNextEscalationNotificationDate() {
		return nextEscalationNotificationDate;
	}
	public void setNextEscalationNotificationDate(ZonedDateTime nextEscalationNotificationDate) {
		this.nextEscalationNotificationDate = nextEscalationNotificationDate;
	}
	public boolean isInternal() {
		return internal;
	}
	public void setInternal(boolean internal) {
		this.internal = internal;
	} 
	
}
