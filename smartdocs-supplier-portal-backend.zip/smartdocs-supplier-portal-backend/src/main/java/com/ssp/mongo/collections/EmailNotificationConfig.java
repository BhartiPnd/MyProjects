package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "emailNotificationConfig")
public class EmailNotificationConfig {

	@Id
	private String id;
	private String email;
	private String vendorId;
	private String notificationType;
	private String notificationTypeLable;
	private String group;
	private boolean isEnabled;
	public EmailNotificationConfig() {
		super();
	}
	
	public EmailNotificationConfig(String email, String vendorId, String notificationType,
			String notificationTypeLable, boolean isEnabled) {
		super();
		this.id=email+notificationType;

		this.email = email;
		this.vendorId = vendorId;
		this.notificationType = notificationType;
		this.notificationTypeLable = notificationTypeLable;
		this.isEnabled = isEnabled;
	}

	public EmailNotificationConfig(String notificationType, String notificationTypeLable,String group, boolean isEnabled) {
		super();
		this.id=email+notificationType;

		this.notificationType = notificationType;
		this.notificationTypeLable = notificationTypeLable;
		this.group=group;
		this.isEnabled = isEnabled;
	}
	public String getId() {
		return id;
	}
	public String getEmail() {
		return email;
	}
	public String getVendorId() {
		return vendorId;
	}

	public String getNotificationTypeLable() {
		return notificationTypeLable;
	}
	 
	public void setId(String id) {
		this.id = id;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public void setNotificationTypeLable(String notificationTypeLable) {
		this.notificationTypeLable = notificationTypeLable;
	}
	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}
	
	
}
