package com.ssp.mongo.collections;


import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Channel;
import com.ssp.mongo.collectionhelpers.CustomRoles;
import com.ssp.mongo.collectionhelpers.CustomUserCompanies;


@Document(collection = "DeletedUsers")
public class DeletedUser {

	@Id
	private String id;
	private String email;
	private String name;
	private String password;
	private String firstname;
	private String lastname;
	private String mobile;
	private String location;
	private String language;
	private String timezone;
	private String dateformate;
	private String dateAndTimeFormate;
	private String decimalformate;
	private String currency;
	private CustomUserCompanies allowedCompanies;
	private String defaultSupplierId;
	private String defaultSupplier;
	private String supplier;
	private String supplierId;
	private String role;
	private String companycode;
	private String azureId;
	private String timeFormate;
	private String pic;
	private String dafaultPOInvoiceType;
	private String dafaultNPOInvoiceType;
	private Long createddatetime;
	private Long modifieddatetime;
	private List<Channel> channel;
	private int invalidPasswordAttempts;
	private String profileId;
	private List<String> authPermissionGroups;
	private List<CustomRoles> userRoles;
	private ZonedDateTime passwordExpiry;
	private ZonedDateTime lastLogin;
	private ZonedDateTime lastActivity;
	private boolean isEmailEnabled;
	private boolean analyticsSyncStatus;
	private String mobileAccess;
	private String accessToken;
	private boolean isSAPSynchACK;
	private String userDeletedBy;
	private ZonedDateTime userDeletedOn;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getDateformate() {
		return dateformate;
	}

	public void setDateformate(String dateformate) {
		this.dateformate = dateformate;
	}

	public String getDateAndTimeFormate() {
		return dateAndTimeFormate;
	}

	public void setDateAndTimeFormate(String dateAndTimeFormate) {
		this.dateAndTimeFormate = dateAndTimeFormate;
	}

	public String getDecimalformate() {
		return decimalformate;
	}

	public void setDecimalformate(String decimalformate) {
		this.decimalformate = decimalformate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public CustomUserCompanies getAllowedCompanies() {
		return allowedCompanies;
	}

	public void setAllowedCompanies(CustomUserCompanies allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}

	public String getDefaultSupplierId() {
		return defaultSupplierId;
	}

	public void setDefaultSupplierId(String defaultSupplierId) {
		this.defaultSupplierId = defaultSupplierId;
	}

	public String getDefaultSupplier() {
		return defaultSupplier;
	}

	public void setDefaultSupplier(String defaultSupplier) {
		this.defaultSupplier = defaultSupplier;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getAzureId() {
		return azureId;
	}

	public void setAzureId(String azureId) {
		this.azureId = azureId;
	}

	public String getTimeFormate() {
		return timeFormate;
	}

	public void setTimeFormate(String timeFormate) {
		this.timeFormate = timeFormate;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getDafaultPOInvoiceType() {
		return dafaultPOInvoiceType;
	}

	public void setDafaultPOInvoiceType(String dafaultPOInvoiceType) {
		this.dafaultPOInvoiceType = dafaultPOInvoiceType;
	}

	public String getDafaultNPOInvoiceType() {
		return dafaultNPOInvoiceType;
	}

	public void setDafaultNPOInvoiceType(String dafaultNPOInvoiceType) {
		this.dafaultNPOInvoiceType = dafaultNPOInvoiceType;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public List<Channel> getChannel() {
		return channel;
	}

	public void setChannel(List<Channel> channel) {
		this.channel = channel;
	}

	public int getInvalidPasswordAttempts() {
		return invalidPasswordAttempts;
	}

	public void setInvalidPasswordAttempts(int invalidPasswordAttempts) {
		this.invalidPasswordAttempts = invalidPasswordAttempts;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public List<String> getAuthPermissionGroups() {
		return authPermissionGroups;
	}

	public void setAuthPermissionGroups(List<String> authPermissionGroups) {
		this.authPermissionGroups = authPermissionGroups;
	}

	public List<CustomRoles> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<CustomRoles> userRoles) {
		this.userRoles = userRoles;
	}

	public ZonedDateTime getPasswordExpiry() {
		return passwordExpiry;
	}

	public void setPasswordExpiry(ZonedDateTime passwordExpiry) {
		this.passwordExpiry = passwordExpiry;
	}

	public ZonedDateTime getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(ZonedDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public ZonedDateTime getLastActivity() {
		return lastActivity;
	}

	public void setLastActivity(ZonedDateTime lastActivity) {
		this.lastActivity = lastActivity;
	}

	public boolean isEmailEnabled() {
		return isEmailEnabled;
	}

	public void setEmailEnabled(boolean isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}

	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}

	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}

	public String getMobileAccess() {
		return mobileAccess;
	}

	public void setMobileAccess(String mobileAccess) {
		this.mobileAccess = mobileAccess;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public boolean isSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public String getUserDeletedBy() {
		return userDeletedBy;
	}

	public void setUserDeletedBy(String userDeletedBy) {
		this.userDeletedBy = userDeletedBy;
	}

	public ZonedDateTime getUserDeletedOn() {
		return userDeletedOn;
	}

	public void setUserDeletedOn(ZonedDateTime userDeletedOn) {
		this.userDeletedOn = userDeletedOn;
	}

	public DeletedUser() {
		super();
	}
	
	public DeletedUser(User user, String deletedByEmail) {
		this.id = user.getId();
		this.email = user.getEmail();
		this.name = user.getName();
		this.password = user.getPassword();
		this.firstname = user.getFirstname();
		this.lastname = user.getLastname();
		this.mobile = user.getMobile();
		this.location = user.getLocation();
		this.language = user.getLanguage();
		this.timezone = user.getTimezone();
		this.dateformate = user.getDateformate();
		this.dateAndTimeFormate = user.getDateAndTimeFormate();
		this.decimalformate = user.getDecimalformate();
		this.currency = user.getCurrency();
		this.allowedCompanies = user.getAllowedCompanies();
		this.defaultSupplierId = user.getDefaultSupplierId();
		this.defaultSupplier = user.getDefaultSupplier();
		this.supplier = user.getSupplier();
		this.supplierId = user.getSupplierId();
		this.role = user.getRole();
		this.companycode = user.getCompanycode();
		this.azureId = user.getAzureId();
		this.timeFormate = user.getTimeFormate();
		this.pic = user.getPic();
		this.dafaultPOInvoiceType = user.getDafaultPOInvoiceType();
		this.dafaultNPOInvoiceType = user.getDafaultNPOInvoiceType();
		this.createddatetime = user.getCreateddatetime();
		this.modifieddatetime = user.getModifieddatetime();
		this.channel = user.getChannel();
		this.invalidPasswordAttempts = user.getInvalidPasswordAttempts();
		this.profileId = user.getProfileId();
		this.authPermissionGroups = user.getAuthPermissionGroups();
		this.userRoles = user.getUserRoles();
		this.passwordExpiry = user.getPasswordExpiry();
		this.lastLogin = user.getLastLogin();
		this.lastActivity = user.getLastActivity();
		this.isEmailEnabled = user.isEmailEnabled();
		this.analyticsSyncStatus = user.isAnalyticsSyncStatus();
		this.mobileAccess = user.getMobileAccess();
		this.accessToken = user.getAccessToken();
		this.isSAPSynchACK = user.isSAPSynchACK();
		this.userDeletedBy = deletedByEmail;
		this.userDeletedOn = ZonedDateTime.now();
	}
}