package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class CustomSelector {

	public static final String TYPE_ALL="*";
	public static final String TYPE_CUSTOM="custom";

	private String type;
	private List<String> selected;
	
	public String getType() {
		return type;
	}
	public List<String> getSelected() {
		return selected;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setSelected(List<String> selected) {
		this.selected = selected;
	}
}
