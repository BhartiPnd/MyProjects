package com.ssp.mongo.collections.config;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.bol.secure.Encrypted;


@Document(collection = "SmtpServerConfiguration")
public class SmtpServerConfiguration {

	@Id
	private String id;
	private String username;
	private String host;
	private String port;

	@Encrypted
	private String password;
	private String protocol;
	private boolean customConfig;
	private String auth;
	private String serverName;
	private boolean tls;
	private boolean authentication;
	private boolean startTLS;
	private int sucessCount;
	private int failedCount;
	private boolean enable;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public boolean isAuthentication() {
		return authentication;
	}
	public void setAuthentication(boolean authentication) {
		this.authentication = authentication;
	}
	public boolean isStartTLS() {
		return startTLS;
	}
	public void setStartTLS(boolean startTLS) {
		this.startTLS = startTLS;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "SmtpServerConfiguration [id=" + id + ", serverName=" + serverName + ", port=" + port
				+ ", authentication=" + authentication + ", startTLS=" + startTLS + ", username=" + username
				+ ", password=" + password + "]";
	}
	public boolean isCustomConfig() {
		return customConfig;
	}
	public void setCustomConfig(boolean customConfig) {
		this.customConfig = customConfig;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public boolean isTls() {
		return tls;
	}
	public void setTls(boolean tls) {
		this.tls = tls;
	}
	public int getSucessCount() {
		return sucessCount;
	}
	public void setSucessCount(int sucessCount) {
		this.sucessCount = sucessCount;
	}
	public int getFailedCount() {
		return failedCount;
	}
	public void setFailedCount(int failedCount) {
		this.failedCount = failedCount;
	}
	public boolean isEnable() {
		return enable;
	}
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
		
}
