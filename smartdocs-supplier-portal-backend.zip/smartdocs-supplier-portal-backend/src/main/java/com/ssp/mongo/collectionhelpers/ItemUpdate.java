package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class ItemUpdate {
	
	private String id;
	private Long readyDate;
	private String productionVolume;
	private String unitPrice;
	private String reasonCode;
	private String poLine;
	private String poNumberId;
	private Long createdDate;
	private String status;	
	private String poItemDescription;
	private String comments;
	private List<PoAttachments> attachments = null;	
 
	private Boolean isSAPSynch;
	private Long sapSynchDate;
	private Boolean isSAPSynchACK;
	
	
	public ItemUpdate() {
		super();
	}	
	 

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public Long getReadyDate() {
		return readyDate;
	}
	public void setReadyDate(Long readyDate) {
		this.readyDate = readyDate;
	}
	
	public String getProductionVolume() {
		return productionVolume;
	}
	public void setProductionVolume(String productionVolume) {
		this.productionVolume = productionVolume;
	}
	
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	
	public String getPoLine() {
		return poLine;
	}
	public void setPoLine(String poLine) {
		this.poLine = poLine;
	}
	
	public String getPoNumberId() {
		return poNumberId;
	}
	public void setPoNumberId(String poNumberId) {
		this.poNumberId = poNumberId;
	}
	
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	
	public String getPoItemDescription() {
		return poItemDescription;
	}
	public void setPoItemDescription(String poItemDescription) {
		this.poItemDescription = poItemDescription;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public List<PoAttachments> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<PoAttachments> attachments) {
		this.attachments = attachments;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public Long getSapSynchDate() {
		return sapSynchDate;
	}
	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	@Override
	public String toString() {
		return "ItemUpdate [id=" + id + ", readyDate=" + readyDate + ", productionVolume=" + productionVolume
				+ ", unitPrice=" + unitPrice + ", reasonCode=" + reasonCode + ", poLine=" + poLine + ", poNumberId="
				+ poNumberId + ", createdDate=" + createdDate + ", status=" + status + ", poItemDescription="
				+ poItemDescription + ", comments=" + comments + ", attachments=" + attachments + "]";
	}		
}
