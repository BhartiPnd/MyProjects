package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class CustomCountries {
	
	public static final String TYPE_ALL="*";
	public static final String TYPE_CUSTOM="custom";
	
	private String type;
	private List<String> allowedCountries;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<String> getAllowedCountries() {
		return allowedCountries;
	}
	public void setAllowedCountries(List<String> allowedCountries) {
		this.allowedCountries = allowedCountries;
	}
	
}
