package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "systemNotification")
public class SystemNotification {

	@Id
	private String id;
	private String title;
	private String description;
	private String type;
	private String dateTime;
	private String url;
	private String valid_till;
	private String isArchive;
	private String isVendorOnly;
	private String vendorId;
	private String ownerEmail;
	
	
	
	
	
	public SystemNotification() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getValid_till() {
		return valid_till;
	}
	public void setValid_till(String valid_till) {
		this.valid_till = valid_till;
	}
	public String getIsArchive() {
		return isArchive;
	}
	public void setIsArchive(String isArchive) {
		this.isArchive = isArchive;
	}
	public String getIsVendorOnly() {
		return isVendorOnly;
	}
	public void setIsVendorOnly(String isVendorOnly) {
		this.isVendorOnly = isVendorOnly;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getOwnerEmail() {
		return ownerEmail;
	}
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
	
	
	
	
}
