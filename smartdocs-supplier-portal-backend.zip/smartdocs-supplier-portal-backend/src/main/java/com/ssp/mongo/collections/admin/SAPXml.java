package com.ssp.mongo.collections.admin;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "SAPXml")
public class SAPXml {
	public static final String STATUS_RECV="recv";
	public static final String STATUS_SENT="sent";

	public static final String INVALID_XML_FORMAT_ERROR="INVALID_XML_FORMAT_ERROR";
	public static final String INVALID_JSO_FORMAT_ERROR="INVALID_JSON_FORMAT_ERROR";
	public static final String OK="OK";


	private String xmlvalue;
	private String uuid;
	private String errorLog;
	private ZonedDateTime lastUpdated;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getXmlvalue() {
		return xmlvalue;
	}

	public void setXmlvalue(String xmlvalue) {
		this.xmlvalue = xmlvalue;
	}

	public SAPXml() {
		super();
		this.lastUpdated=ZonedDateTime.now();
	}

	public SAPXml(String xmlvalue , String uuid,String errorLog) {
		super();
		this.xmlvalue = xmlvalue;
		this.uuid=uuid;
		this.lastUpdated=ZonedDateTime.now();
		this.errorLog=errorLog;
	}

	public String getErrorLog() {
		return errorLog;
	}

	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}

	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
}
