package com.ssp.mongo.collections.config;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "ocrFieldMapping")
public class OCRFieldMapping {

	@Id
	private String id;
	
	private String name;
	
	private String language;
	
	private List<OCRField>  headerFields;
	
	private List<OCRField> lineItems;


	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<OCRField> getHeaderFields() {
		return headerFields;
	}

	public void setHeaderFields(List<OCRField> headerFields) {
		this.headerFields = headerFields;
	}

	public List<OCRField> getLineItems() {
		return lineItems;
	}

	public void setLineItems(List<OCRField> lineItems) {
		this.lineItems = lineItems;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
	 
	
}
