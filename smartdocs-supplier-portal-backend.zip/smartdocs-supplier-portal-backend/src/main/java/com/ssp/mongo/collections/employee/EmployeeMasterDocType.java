package com.ssp.mongo.collections.employee;

import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.ssp.mongo.collectionhelpers.CustomCountries;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.FormField;
import com.ssp.mongo.collections.workflow.config.BusinessRules;

@Document(collection = "employeeDocType")
public class EmployeeMasterDocType {
	
	@Id
	private String docTypeId;
	private String docTypeName;
	private String folder;
	private String docDesc;
	private boolean isRequired;
	private List<FormField> attributes;
	private List<BusinessRules> businessRules;
	private List<EBDPermissions> permissions;
	private CustomCountries criteria;
	
	private List<String> supportedFileTypes;
	private int maxFileSizeOfSignleDoc;
	private int maxAllowedDoc;
	
	private boolean retention;
	private int retentionPeriod;
	
	private DocumentHelper template;
	
	
	public String getDocTypeId() {
		return docTypeId;
	}
	public void setDocTypeId(String docTypeId) {
		this.docTypeId = docTypeId;
	}
	public String getDocTypeName() {
		return docTypeName;
	}
	public void setDocTypeName(String docTypeName) {
		this.docTypeName = docTypeName;
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = folder;
	}
	public String getDocDesc() {
		return docDesc;
	}
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	public boolean isRequired() {
		return isRequired;
	}
	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}
	public List<BusinessRules> getBusinessRules() {
		return businessRules;
	}
	public void setBusinessRules(List<BusinessRules> businessRules) {
		this.businessRules = businessRules;
	}
	public List<EBDPermissions> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<EBDPermissions> permissions) {
		this.permissions = permissions;
	}
	public CustomCountries getCriteria() {
		return criteria;
	}
	public void setCriteria(CustomCountries criteria) {
		this.criteria = criteria;
	}
	public List<FormField> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<FormField> attributes) {
		this.attributes = attributes;
	}
	public List<String> getSupportedFileTypes() {
		return supportedFileTypes;
	}
	public void setSupportedFileTypes(List<String> supportedFileTypes) {
		this.supportedFileTypes = supportedFileTypes;
	}
	public int getMaxFileSizeOfSignleDoc() {
		return maxFileSizeOfSignleDoc;
	}
	public void setMaxFileSizeOfSignleDoc(int maxFileSizeOfSignleDoc) {
		this.maxFileSizeOfSignleDoc = maxFileSizeOfSignleDoc;
	}
	public int getMaxAllowedDoc() {
		return maxAllowedDoc;
	}
	public void setMaxAllowedDoc(int maxAllowedDoc) {
		this.maxAllowedDoc = maxAllowedDoc;
	}
	public boolean isRetention() {
		return retention;
	}
	public void setRetention(boolean retention) {
		this.retention = retention;
	}
	public int getRetentionPeriod() {
		return retentionPeriod;
	}
	public void setRetentionPeriod(int retentionPeriod) {
		this.retentionPeriod = retentionPeriod;
	}
	public DocumentHelper getTemplate() {
		return template;
	}
	public void setTemplate(DocumentHelper template) {
		this.template = template;
	}
	
}
