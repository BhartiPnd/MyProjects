package com.ssp.mongo.collections.rfx;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.AwardedBidders;

@Document(collection = "award")
public class Award {
	
	@Id

	private String id;
	private String rfxNo;
	private List<AwardedBidders> awardedBidders;
	
	public Award() {
		super();
	}


	public List<AwardedBidders> getAwardedBidders() {
		return awardedBidders;
	}


	public void setAwardedBidders(List<AwardedBidders> awardedBidders) {
		this.awardedBidders = awardedBidders;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	
	
}
