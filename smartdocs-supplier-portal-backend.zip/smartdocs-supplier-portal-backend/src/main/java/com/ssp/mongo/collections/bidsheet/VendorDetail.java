package com.ssp.mongo.collections.bidsheet;

import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class VendorDetail {
	private String vendorId;
	private String vendorName;
	private List<String> vendorEmails;
	private DocumentHelper template;

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public List<String> getVendorEmails() {
		return vendorEmails;
	}

	public void setVendorEmails(List<String> vendorEmails) {
		this.vendorEmails = vendorEmails;
	}

	public DocumentHelper getTemplate() {
		return template;
	}

	public void setTemplate(DocumentHelper template) {
		this.template = template;
	}

	
}
