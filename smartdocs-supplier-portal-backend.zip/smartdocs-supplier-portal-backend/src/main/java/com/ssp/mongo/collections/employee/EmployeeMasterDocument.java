package com.ssp.mongo.collections.employee;

import java.time.ZonedDateTime;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.CreateEMDRequest;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.Agent;

@Document(collection = "EmployeeMasterDocument")
public class EmployeeMasterDocument {

	//FileDocument
	@Id
	private String id;
	//documentType_employeeId
	private String requestId;
	private String documentType;
	
	private String  employeeId;
	
	private String  status;
	
	private DocumentHelper attachment;
	private ZonedDateTime uploadedDate;
	private ZonedDateTime expirationDate;
	private String agentName;
	private Map<String, String> mataData;
	private GeneralState state;

	
	public EmployeeMasterDocument() {
		super();
		
	}
	public EmployeeMasterDocument(CreateEMDRequest emd) {
		super();
		this.documentType = emd.getDocumentType();
		this.employeeId = emd.getEmployeeId();
		//this.status = status;
		this.attachment = emd.getAttachment();
		this.uploadedDate = ZonedDateTime.now();
		this.expirationDate = emd.getExpirationDate();
		this.mataData = emd.getMataData();
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DocumentHelper getAttachment() {
		return attachment;
	}

	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}

	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}

	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Map<String, String> getMataData() {
		return mataData;
	}

	public void setMataData(Map<String, String> mataData) {
		this.mataData = mataData;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	 
	public void updateAgent(Agent agent) 
	{
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
		
	}
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}
	
}
