package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Channel;
import com.ssp.mongo.collectionhelpers.CustomRoles;
import com.ssp.mongo.collectionhelpers.CustomUserCompanies;

@Document(collection = "user")
public class User {

	// just for internal putpsoe not to set in db.
	public static final String ROLE_ANY = "ANY";
	public static final String ROLE_ADMIN = "Admin";
	public static final String ROLE_SYSTEMADMIN = "SystemAdmin";
	public static final String ROLE_SUPPLIER_LOGISTICS = "SupplierLogistics";
	public static final String ROLE_SUPPLIER_ADMIN = "SupplierAdmin";
	
	public static final String ROLE_SUPPLIER_USER = "SupplierUser";
	public static final String ROLE_COMPANY_USER = "CompanyUser";
	
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
	public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

	@Id
	private String id;
	private String email;
	private String name;
	private String password;
	private String firstname;
	private String lastname;
	private String mobile;
	private String location;
	private String language;
	private String timezone;
	private String dateformate;
	private String dateAndTimeFormate;
	private String decimalformate;
	private String currency;
	private CustomUserCompanies allowedCompanies;
	private String defaultSupplierId;
	private String defaultSupplier;
	private String supplier;
	private String supplierId;
	private String role;
	private String companycode;
	private String azureId;
	private String timeFormate;

	private String pic;

	private String dafaultPOInvoiceType;
	private String dafaultNPOInvoiceType;

	// private List<Notification> notifications;

	private Long createddatetime;
	private Long modifieddatetime;
	private List<Channel> channel;

	private int invalidPasswordAttempts;

	private String profileId;

	// this is for company users only. for RBAC model.
	private List<String> authPermissionGroups;
	// private List<Permission> permissions;

	private List<CustomRoles> userRoles;

	private ZonedDateTime passwordExpiry;
	private ZonedDateTime lastLogin;
	private ZonedDateTime lastActivity;
	private boolean isEmailEnabled;
	private boolean analyticsSyncStatus;

	private String mobileAccess;
	private String accessToken;
	private boolean isSAPSynchACK;

	public User() {
		super();
	}

	public List<Channel> getChannel() {
		return channel;
	}

	public void setChannel(List<Channel> channel) {
		this.channel = channel;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (StringUtils.isNotBlank(email)) {
			this.email = email.toLowerCase().trim();
		} else {
			this.email = email;
		}
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
		this.name = (this.firstname != null ? this.firstname + " " : "") + (this.lastname != null ? this.lastname : "");
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
		this.name = (this.firstname != null ? this.firstname + " " : "") + (this.lastname != null ? this.lastname : "");
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getDateformate() {
		return dateformate;
	}

	public void setDateformate(String dateformate) {
		this.dateformate = dateformate;
	}

	public String getDecimalformate() {
		return decimalformate;
	}

	public void setDecimalformate(String decimalformate) {
		this.decimalformate = decimalformate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public boolean isCompanyUser() {
		if (this.role == null)
			return false;
		return this.role.equals(ROLE_COMPANY_USER);
	}

	public boolean isAdmin() {
		if (this.role == null)
			return false;
		return this.role.equals(ROLE_ADMIN);
	}

	public boolean isSupplierUser() {
		if (this.role == null)
			return false;
		return this.role.equals(ROLE_SUPPLIER_USER);
	}

	public String getAzureId() {
		return azureId;
	}

	public void setAzureId(String azureId) {
		this.azureId = azureId;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", password=" + password + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", mobile=" + mobile + ", location=" + location + ", language=" + language
				+ ", timezone=" + timezone + ", dateformate=" + dateformate + ", decimalformate=" + decimalformate
				+ ", currency=" + currency + ", supplier=" + supplier + ", supplierId=" + supplierId + ", role=" + role
				+ ", companycode=" + companycode + ", azureId=" + azureId + ", createddatetime=" + createddatetime
				+ ", modifieddatetime=" + modifieddatetime + "]";
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public ZonedDateTime getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(ZonedDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public List<String> getAuthPermissionGroups() {
		return authPermissionGroups;
	}

	public void setAuthPermissionGroups(List<String> authPermissionGroups) {
		this.authPermissionGroups = authPermissionGroups;
	}

	public String getDefaultSupplierId() {
		return defaultSupplierId;
	}

	public String getDefaultSupplier() {
		return defaultSupplier;
	}

	public void setDefaultSupplierId(String defaultSupplierId) {
		this.defaultSupplierId = defaultSupplierId;
	}

	public void setDefaultSupplier(String defaultSupplier) {
		this.defaultSupplier = defaultSupplier;
	}

	public List<CustomRoles> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<CustomRoles> userRoles) {
		this.userRoles = userRoles;
	}

	public boolean isEmailEnabled() {
		return isEmailEnabled;
	}

	public void setEmailEnabled(boolean isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}

	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}

	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}

	public String getDafaultPOInvoiceType() {
		return dafaultPOInvoiceType;
	}

	public String getDafaultNPOInvoiceType() {
		return dafaultNPOInvoiceType;
	}

	public void setDafaultPOInvoiceType(String dafaultPOInvoiceType) {
		this.dafaultPOInvoiceType = dafaultPOInvoiceType;
	}

	public void setDafaultNPOInvoiceType(String dafaultNPOInvoiceType) {
		this.dafaultNPOInvoiceType = dafaultNPOInvoiceType;
	}

	public String getDateAndTimeFormate() {
		return dateAndTimeFormate;
	}

	public void setDateAndTimeFormate(String dateAndTimeFormate) {
		this.dateAndTimeFormate = dateAndTimeFormate;
	}

	public ZonedDateTime getPasswordExpiry() {
		return passwordExpiry;
	}

	public void setPasswordExpiry(ZonedDateTime passwordExpiry) {
		this.passwordExpiry = passwordExpiry;
	}

	public String getName() {
		return this.getFirstname() + " " + this.getLastname();
	}

	public int getInvalidPasswordAttempts() {
		return invalidPasswordAttempts;
	}

	public void setInvalidPasswordAttempts(int invalidPasswordAttempts) {
		this.invalidPasswordAttempts = invalidPasswordAttempts;
	}

	public void addInvalidPasswordAttempt() {
		invalidPasswordAttempts = invalidPasswordAttempts + 1;
	}

	public String getMobileAccess() {
		return mobileAccess;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setMobileAccess(String mobileAccess) {
		this.mobileAccess = mobileAccess;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public ZonedDateTime getLastActivity() {
		return lastActivity;
	}

	public void setLastActivity(ZonedDateTime lastActivity) {
		this.lastActivity = lastActivity;
	}

	public boolean isSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public void setName(String name) {
		this.name = name;
	}

	public CustomUserCompanies getAllowedCompanies() {
		return allowedCompanies;
	}

	public void setAllowedCompanies(CustomUserCompanies allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}

	public String getTimeFormate() {
		return timeFormate;
	}

	public void setTimeFormate(String timeFormate) {
		this.timeFormate = timeFormate;
	}

}