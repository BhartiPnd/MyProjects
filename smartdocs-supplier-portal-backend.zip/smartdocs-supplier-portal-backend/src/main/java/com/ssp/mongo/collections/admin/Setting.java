package com.ssp.mongo.collections.admin;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.BotSetting;
import com.ssp.mongo.collectionhelpers.InvoiceDelaySetting;
import com.ssp.mongo.collectionhelpers.SmartStoreConfigurator;

@Document(collection = "setting")
public class Setting {

	@Id
	private String id;
	private String email;
/*	private ImageHelper logo;
	private ImageHelper largeLogo;
	private ImageHelper backgroundimage;*/
	private String backgroundcolor;

	private String passwordpolicy;

	private SmartStoreConfigurator smartStoreConfigurator;

	private BotSetting botsetting;
	private String helpSettingTitle;
	private String helpSettingDesc;

	private Boolean isVendorMasterData;
	private Boolean isChatbot;
	private Boolean isRFx;
	private Boolean isPO;
	private Boolean isASN;
	private Boolean isOC;
	private Boolean isPayment;
	private Boolean isTikceting;
	private Boolean isAnnouncements;
	private Boolean isCAPA;
	private Boolean isReport;
	private Boolean isBidSheet;
	private String companyHelpLink;
	private String vendorHelpLink;


	 
	private InvoiceDelaySetting invoiceDelaySetting;

	public Setting() {
		super();
	}

	public Setting(String id, String email,  String backgroundcolor,
			  String passwordpolicy) {
		super();
		this.id = id;
		this.email = email;
		//this.logo = logo;
		////this.largeLogo = largeLogo;
		this.backgroundcolor = backgroundcolor;
		//this.backgroundimage = backgroundimage;
		this.passwordpolicy = passwordpolicy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public String getBackgroundcolor() {
		return backgroundcolor;
	}

	public void setBackgroundcolor(String backgroundcolor) {
		this.backgroundcolor = backgroundcolor;
	}

	 

	public String getPasswordpolicy() {
		return passwordpolicy;
	}

	public void setPasswordpolicy(String passwordpolicy) {
		this.passwordpolicy = passwordpolicy;
	}

	public SmartStoreConfigurator getSmartStoreConfigurator() {
		return smartStoreConfigurator;
	}

	public void setSmartStoreConfigurator(SmartStoreConfigurator smartStoreConfigurator) {
		this.smartStoreConfigurator = smartStoreConfigurator;
	}

	public BotSetting getBotsetting() {
		return botsetting;
	}

	public void setBotsetting(BotSetting botsetting) {
		this.botsetting = botsetting;
	}

	public String getHelpSettingTitle() {
		return helpSettingTitle;
	}

	public void setHelpSettingTitle(String helpSettingTitle) {
		this.helpSettingTitle = helpSettingTitle;
	}

	public String getHelpSettingDesc() {
		return helpSettingDesc;
	}

	public void setHelpSettingDesc(String helpSettingDesc) {
		this.helpSettingDesc = helpSettingDesc;
	}

	public Boolean getIsVendorMasterData() {
		return isVendorMasterData;
	}

	public void setIsVendorMasterData(Boolean isVendorMasterData) {
		this.isVendorMasterData = isVendorMasterData;
	}

	public Boolean getIsChatbot() {
		return isChatbot;
	}

	public void setIsChatbot(Boolean isChatbot) {
		this.isChatbot = isChatbot;
	}

	public Boolean getIsRFx() {
		return isRFx;
	}

	public void setIsRFx(Boolean isRFx) {
		this.isRFx = isRFx;
	}

	public Boolean getIsPO() {
		return isPO;
	}

	public void setIsPO(Boolean isPO) {
		this.isPO = isPO;
	}

	public Boolean getIsASN() {
		return isASN;
	}

	public void setIsASN(Boolean isASN) {
		this.isASN = isASN;
	}

	public Boolean getIsOC() {
		return isOC;
	}

	public void setIsOC(Boolean isOC) {
		this.isOC = isOC;
	}

	public Boolean getIsPayment() {
		return isPayment;
	}

	public void setIsPayment(Boolean isPayment) {
		this.isPayment = isPayment;
	}

	public Boolean getIsTikceting() {
		return isTikceting;
	}

	public void setIsTikceting(Boolean isTikceting) {
		this.isTikceting = isTikceting;
	}

	public Boolean getIsAnnouncements() {
		return isAnnouncements;
	}

	public void setIsAnnouncements(Boolean isAnnouncements) {
		this.isAnnouncements = isAnnouncements;
	}

	public Boolean getIsCAPA() {
		return isCAPA;
	}

	public void setIsCAPA(Boolean isCAPA) {
		this.isCAPA = isCAPA;
	}

	public Boolean getIsReport() {
		return isReport;
	}

	public void setIsReport(Boolean isReport) {
		this.isReport = isReport;
	}
 
	 

	 

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Setting [id=");
		builder.append(id);
		builder.append(", email=");
		builder.append(email);
		builder.append(", logo=");
		builder.append(", largeLogo=");
		
		builder.append(", backgroundcolor=");
		builder.append(backgroundcolor);
		builder.append(", backgroundimage=");
		 
		builder.append(", passwordpolicy=");
		builder.append(passwordpolicy);
		builder.append(", smartStoreConfigurator=");
		builder.append(smartStoreConfigurator);
		builder.append(", botsetting=");
		builder.append(botsetting);
		builder.append(", helpSettingTitle=");
		builder.append(helpSettingTitle);
		builder.append(", helpSettingDesc=");
		builder.append(helpSettingDesc);
		builder.append(", isVendorMasterData=");
		builder.append(isVendorMasterData);
		builder.append(", isChatbot=");
		builder.append(isChatbot);
		builder.append(", isRFx=");
		builder.append(isRFx);
		builder.append(", isBidSheet=");
		builder.append(isBidSheet);
		builder.append(", isPO=");
		builder.append(isPO);
		builder.append(", isASN=");
		builder.append(isASN);
		builder.append(", isOC=");
		builder.append(isOC);
		builder.append(", isPayment=");
		builder.append(isPayment);
		builder.append(", isTikceting=");
		builder.append(isTikceting);
		builder.append(", isAnnouncements=");
		builder.append(isAnnouncements);
		builder.append(", isCAPA=");
		builder.append(isCAPA);
		builder.append("]");
		return builder.toString();
	}

	 

	public InvoiceDelaySetting getInvoiceDelaySetting() {
		return invoiceDelaySetting;
	}

	public void setInvoiceDelaySetting(InvoiceDelaySetting invoiceDelaySetting) {
		this.invoiceDelaySetting = invoiceDelaySetting;
	}

	public String getCompanyHelpLink() {
		return companyHelpLink;
	}

	public void setCompanyHelpLink(String companyHelpLink) {
		this.companyHelpLink = companyHelpLink;
	}

	public String getVendorHelpLink() {
		return vendorHelpLink;
	}

	public void setVendorHelpLink(String vendorHelpLink) {
		this.vendorHelpLink = vendorHelpLink;
	}

	public Boolean getIsBidSheet() {
		return isBidSheet;
	}

	public void setIsBidSheet(Boolean isBidSheet) {
		this.isBidSheet = isBidSheet;
	}

	
}
