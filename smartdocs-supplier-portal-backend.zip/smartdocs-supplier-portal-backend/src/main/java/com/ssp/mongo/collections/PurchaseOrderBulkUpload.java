package com.ssp.mongo.collections;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.PoLineUploadData;

@Document(collection = "PurchaseOrderBulkUpload")
public class PurchaseOrderBulkUpload {
	
	@Id
	private String id;
	private String uuid;	
	private List<String> data;	
	private List<PoLineUploadData> lineItems;	
	public List<PoLineUploadData> getLineItems() {
		return lineItems;
	}
	public void setLineItems(List<PoLineUploadData> lineItems) {
		this.lineItems = lineItems;
	}
	private Date uploaded;	
	private String status;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	 

	public List<String> getData() {
		return data;
	}
	public void setData(List<String> data) {
		this.data = data;
	}
	public Date getUploaded() {
		return uploaded;
	}
	public void setUploaded(Date uploaded) {
		this.uploaded = uploaded;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
}
