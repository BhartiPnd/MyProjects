package com.ssp.mongo.collectionhelpers;

public class UomPriceFactor {
	
	private String uom;
	private String uomDesc;
	private Double cFactor;

	public UomPriceFactor() {
		super();
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	public Double getcFactor() {
		return cFactor;
	}

	public void setcFactor(Double cFactor) {
		this.cFactor = cFactor;
	}
}
