package com.ssp.mongo.collections.config;

public class OCRField {
	
	public static final String TYPE_STRING="String";
	public static final String TYPE_NUMBER="Number";
	public static final String TYPE_DATE="Date";
	
	public static final String DD_FIXED="Fixed";
	public static final String DD_OCR="OCR";

	private String  xmlField;
	private String  dataField;
	
	private String  type;
	
	// data determinationProcess
	private String  ddProcess;
	private String  dateFormat;
	
	public String getXmlField() {
		return xmlField;
	}
	public void setXmlField(String xmlField) {
		this.xmlField = xmlField;
	}
	public String getDataField() {
		return dataField;
	}
	public void setDataField(String dataField) {
		this.dataField = dataField;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDdProcess() {
		return ddProcess;
	}
	public void setDdProcess(String ddProcess) {
		this.ddProcess = ddProcess;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	
	
}
