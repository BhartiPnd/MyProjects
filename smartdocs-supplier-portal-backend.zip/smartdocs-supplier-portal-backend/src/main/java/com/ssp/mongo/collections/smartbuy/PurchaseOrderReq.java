package com.ssp.mongo.collections.smartbuy;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.smartbuy.CreatePurchaseOrderReqRequest;
import com.ssp.dto.smartbuy.CreatePurchaseOrderReqRequestLine;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.Agent;

@Document(collection = "PurchaseOrderReq")
public class PurchaseOrderReq {

	@Id
	private String id;
	private String requestId;
	private String prrRequestId;
	private String type;
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String requestor;
	private String requestorEmail;
	private Double amount;
	private String currency;
	private String supplierId;
	private String supplierName;
	private String status;
	private String createdBy;
	private String poNumber;
	private String fyYear;
	private String initator;
	
	private String plant;
	private String storageLocaion;
	private List<DocumentHelper> attachments;
	private List<PurchaseOrderRequestLine> requestItems;
	private String typeDesc;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	private String agentName;
	private Double totalAmount;
	 private ZonedDateTime createdDate;
	private GeneralState state;
	private String channel;
	private String buyer;
	private String notes;
	private ZonedDateTime deliveryDate;//newly added field
	private String headerText;//newly added field
	
	public PurchaseOrderReq() {
		super();
	}
	public PurchaseOrderReq(String clientTz,CreatePurchaseOrderReqRequest  createpurchaseOrderReq  ) {
		super();
	 
		this.title = createpurchaseOrderReq.getTitle();
		this.description = createpurchaseOrderReq.getDescription();
		this.companyCode = createpurchaseOrderReq.getCompanyCode();
		this.purchasingOrg = createpurchaseOrderReq.getPurchasingOrg();
		this.purchasingGroup = createpurchaseOrderReq.getPurchasingGroup();
		this.paymentTerms = createpurchaseOrderReq.getPaymentTerms();
		this.currency = createpurchaseOrderReq.getCurrency();
		this.supplierId = createpurchaseOrderReq.getSupplierId();
		this.createdDate = ZonedDateTime.now();
		this.plant = createpurchaseOrderReq.getPlant();
		this.storageLocaion = createpurchaseOrderReq.getStorageLocaion();
		this.attachments = createpurchaseOrderReq.getAttachments();
		this.isSAPSynch = false;
		this.syncToSAP = false;
		this.notes=createpurchaseOrderReq.getNotes();
		this.type=createpurchaseOrderReq.getType();
		this.requestorEmail=createpurchaseOrderReq.getRequestorEmail();
		this.totalAmount=createpurchaseOrderReq.getTotalAmount();
		this.channel="PORTAL";
		this.deliveryDate=createpurchaseOrderReq.getDeliveryDate();
		this.headerText=createpurchaseOrderReq.getHeaderText();
		int index=1; 
		List<PurchaseOrderRequestLine> lineitem=new ArrayList<>();
		if(createpurchaseOrderReq.getRequestItems()!=null) {
			for(CreatePurchaseOrderReqRequestLine line:createpurchaseOrderReq.getRequestItems()) 
			{
				PurchaseOrderRequestLine lne=new PurchaseOrderRequestLine(clientTz,line);
				lne.setLineNo(index);
				lne.setRequestId(String.valueOf(id));
				lne.setStatus(status);
				lineitem.add(lne);
				index++;
			}
		}
		this.setRequestItems(lineitem);
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStorageLocaion() {
		return storageLocaion;
	}
	public void setStorageLocaion(String storageLocaion) {
		this.storageLocaion = storageLocaion;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	 
	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}
	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}
	 
	public boolean isSAPSynch() {
		return isSAPSynch;
	}
	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	 
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public List<PurchaseOrderRequestLine> getRequestItems() {
		return requestItems;
	}
	public void setRequestItems(List<PurchaseOrderRequestLine> requestItems) {
		this.requestItems = requestItems;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public GeneralState getState() {
		return state;
	}
	public void setState(GeneralState state) {
		this.state = state;
	}
	public boolean isSyncToSAP() {
		return syncToSAP;
	}
	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public String getTypeDesc() {
		return typeDesc;
	}
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}
	public String getPrrRequestId() {
		return prrRequestId;
	}
	public void setPrrRequestId(String prrRequestId) {
		this.prrRequestId = prrRequestId;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public String getInitator() {
		return initator;
	}
	public void setInitator(String initator) {
		this.initator = initator;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getFyYear() {
		return fyYear;
	}
	public void setFyYear(String fyYear) {
		this.fyYear = fyYear;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getHeaderText() {
		return headerText;
	}
	public void setHeaderText(String headerText) {
		this.headerText = headerText;
	}
	
	 
}
