package com.ssp.mongo.collections.requests;

public class BankDetailChange {
	private  BankDetail bankDetail;
	private  BankDetail intermediaryBankDetail;
	public BankDetail getBankDetail() {
		return bankDetail;
	}
	public void setBankDetail(BankDetail bankDetail) {
		this.bankDetail = bankDetail;
	}
	public BankDetail getIntermediaryBankDetail() {
		return intermediaryBankDetail;
	}
	public void setIntermediaryBankDetail(BankDetail intermediaryBankDetail) {
		this.intermediaryBankDetail = intermediaryBankDetail;
	}
	
}
