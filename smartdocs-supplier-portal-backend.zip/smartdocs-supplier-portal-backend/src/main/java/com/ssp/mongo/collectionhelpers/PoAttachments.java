package com.ssp.mongo.collectionhelpers;

public class PoAttachments extends DocumentHelper {

}
