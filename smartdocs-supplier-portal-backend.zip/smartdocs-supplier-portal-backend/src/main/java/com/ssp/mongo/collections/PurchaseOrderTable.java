package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.Amount;

@Document(collection = "purchaseorder")
public class PurchaseOrderTable {

	public static final String STATUS_OPEN = "Open";
    public static final String STATUS_CLOSE = "Closed";
	
	@Id
	private String id;
	
	@Field("supplierId")
	private String supplierId;
	
	@Field("purchaseOrderNumber")
	private String purchaseOrderNumber;
	
	@Field("deliverydate")
	private ZonedDateTime deliveryDate;

	@Field("amount")
	private Amount amount;
	
	@Field("purchasingOrg")
	private String purchasingOrg;
	
	@Field("purchasingGroup")
	private String purchasingGroup;
	
	@Field("poDate")
	private ZonedDateTime poDate;
	
	@Field("contractNo")
	private String contractNo;
	
	@Field("requestor")
	private String requestor;
	
	@Field("status")
	private String status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public ZonedDateTime getPoDate() {
		return poDate;
	}

	public void setPoDate(ZonedDateTime poDate) {
		this.poDate = poDate;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static String getStatusOpen() {
		return STATUS_OPEN;
	}

	public static String getStatusClose() {
		return STATUS_CLOSE;
	}
	
	
}
