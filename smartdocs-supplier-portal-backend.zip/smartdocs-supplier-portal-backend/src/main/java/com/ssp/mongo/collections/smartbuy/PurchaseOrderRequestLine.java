package com.ssp.mongo.collections.smartbuy;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.TimeZone;

import com.ssp.dto.smartbuy.CreatePurchaseOrderReqRequestLine;
import com.ssp.mongo.collections.dataObject.MaterialMaster;

 
public class PurchaseOrderRequestLine {

	 
	private int lineNo;
	private String requestId;
	private double totalAmount;
	
	private String materialCode;
	private String materialDesc;
	private String materialGroup;
	private String materialGroupDesc;
	private boolean inventory;
	private String category;
	private String suppliedBy;
	private boolean isMaterialMaster;
	private double qty;
	private String uom;
	private double unitprice;
	private double taxAmount;
	private double frightAmount;
	private double discount;
	private String taxCode;
	private double taxPercent;
	private String currency;
	private String perUOM;
	private Long per;
	private String plant;
	private String storageLocation;
	private ZonedDateTime deliveryDate;
	
	private String accountAssignmentType;
	private String costCenter;
	private String wbsElementNo;
	private String glAccount;
	private String glAccountDesc;
	private String costCenterDesc;
 	private String status;
 	public List<PRLineItemUpdate> lineUpdate;
 	
 	
 	private String storageLocationDesc;
 	private String plantDesc;
 	private Double factor;
 	private Double perFactor;
 	private String internalOrder;
	private String project;
	private String networkNo;
	private String text;
	private MaterialMaster materialMasterObject;
 	
	public PurchaseOrderRequestLine() {
		super();
	}
	public PurchaseOrderRequestLine(String clientTz,CreatePurchaseOrderReqRequestLine line) {
		super();
		this.materialCode = line.getMaterialCode();
		this.materialDesc = line.getMaterialDesc();
		this.materialGroup = line.getMaterialGroup();
		this.category = line.getCategory();
		this.suppliedBy = line.getSuppliedBy();
		this.isMaterialMaster = line.isMaterialMaster();
		this.qty = line.getQty();
		this.uom = line.getUom();
		this.unitprice = line.getUnitprice();
		this.currency = line.getCurrency();
		this.perUOM = line.getPerUOM();
		this.per = line.getPer();
		this.factor = line.getFactor();
		this.perFactor = line.getPerFactor();
		this.plant = line.getPlant();
		this.inventory = line.isInventory();		
		this.accountAssignmentType=line.getAccountAssignmentType();
		this.costCenter=line.getCostCenter();
		this.wbsElementNo=line.getWbsElementNo();
		
		this.taxAmount=line.getTaxAmount();
		this.frightAmount=line.getFrightAmount();
		this.discount=line.getDiscount();
		this.taxCode=line.getTaxCode();
		this.storageLocation=line.getStorageLocation();
		//this.deliveryDate=line.getDeliveryDate();
		this.costCenter=line.getCostCenter();
		this.wbsElementNo=line.getWbsElementNo();
		this.glAccount=line.getGlAccount();
		this.materialGroupDesc=line.getMaterialGroupDesc();
		 this.project=line.getProject();
		 this.internalOrder=line.getInternalOrder();
		 this.networkNo=line.getNetworkNo();
		 this.text=line.getText();
		 this.taxPercent=line.getTaxPercent();
		 
		 if(line.getDeliveryDate()!=null)
		 {
				final ZoneId systemDefault = TimeZone.getTimeZone(clientTz).toZoneId();
				ZonedDateTime nyDateTime = line.getDeliveryDate().withZoneSameInstant(systemDefault);
				this.deliveryDate=( nyDateTime.withHour(8).withMinute(0));
		 }
	}
	 
	public int getLineNo() {
		return lineNo;
	}
	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	
	
	public MaterialMaster getMaterialMasterObject() {
		return materialMasterObject;
	}
	public void setMaterialMasterObject(MaterialMaster materialMasterObject) {
		this.materialMasterObject = materialMasterObject;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(double unitprice) {
		this.unitprice = unitprice;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPerUOM() {
		return perUOM;
	}
	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	public Long getPer() {
		return per;
	}
	public void setPer(Long per) {
		this.per = per;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSuppliedBy() {
		return suppliedBy;
	}
	public void setSuppliedBy(String suppliedBy) {
		this.suppliedBy = suppliedBy;
	}
	public boolean isMaterialMaster() {
		return isMaterialMaster;
	}
	public void setMaterialMaster(boolean isMaterialMaster) {
		this.isMaterialMaster = isMaterialMaster;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getAccountAssignmentType() {
		return accountAssignmentType;
	}
	public void setAccountAssignmentType(String accountAssignmentType) {
		this.accountAssignmentType = accountAssignmentType;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getWbsElementNo() {
		return wbsElementNo;
	}
	public void setWbsElementNo(String wbsElementNo) {
		this.wbsElementNo = wbsElementNo;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public double getFrightAmount() {
		return frightAmount;
	}
	public void setFrightAmount(double frightAmount) {
		this.frightAmount = frightAmount;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}
	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}
	public String getPlantDesc() {
		return plantDesc;
	}
	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}
	public String getCostCenterDesc() {
		return costCenterDesc;
	}
	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}
	public String getGlAccountDesc() {
		return glAccountDesc;
	}
	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}
	public String getMaterialGroupDesc() {
		return materialGroupDesc;
	}
	public void setMaterialGroupDesc(String materialGroupDesc) {
		this.materialGroupDesc = materialGroupDesc;
	}
	public String getInternalOrder() {
		return internalOrder;
	}
	public void setInternalOrder(String internalOrder) {
		this.internalOrder = internalOrder;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getNetworkNo() {
		return networkNo;
	}
	public void setNetworkNo(String networkNo) {
		this.networkNo = networkNo;
	}
	public double getTaxPercent() {
		return taxPercent;
	}
	public void setTaxPercent(double taxPercent) {
		this.taxPercent = taxPercent;
	}
	public List<PRLineItemUpdate> getLineUpdate() {
		return lineUpdate;
	}
	public boolean isInventory() {
		return inventory;
	}
	public void setInventory(boolean inventory) {
		this.inventory = inventory;
	}
	 
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Double getFactor() {
		return factor;
	}
	public void setFactor(Double factor) {
		this.factor = factor;
	}
	public Double getPerFactor() {
		return perFactor;
	}
	public void setPerFactor(Double perFactor) {
		this.perFactor = perFactor;
	}
	
}
