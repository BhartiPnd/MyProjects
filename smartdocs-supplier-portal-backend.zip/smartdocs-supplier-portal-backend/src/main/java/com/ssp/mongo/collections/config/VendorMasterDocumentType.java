package com.ssp.mongo.collections.config;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.VendorMasterDocumentTypeWorkFlowSteps;

@Document(collection = "VendorMasterDocumentType")
public class VendorMasterDocumentType {

	@Id
	private String identifier;

	private String id;
	private String documentFolderId;
	private String name;
	private String description;

	private boolean isRequired;
	private boolean hasExpiry;
	private boolean allowMultiple;
	
	// portalApprovalRequire
	private boolean approvalRequire;
	private boolean isEnabled;
	private int order;
	
	//private boolean portalWorkflow;
	
	private boolean sapWorkflow;
	
	private boolean accessRestricted;
	private List<String> allowedUsers;

	private List<Field> fields;
	
	private List<VendorMasterDocumentTypeWorkFlowSteps> workflowSteps;

	public String getIdentifier() {
		return identifier;
	}

	public String getId() {
		return id;
	}

	public String getDocumentFolderId() {
		return documentFolderId;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public boolean isRequired() {
		return isRequired;
	}

	public boolean isAllowMultiple() {
		return allowMultiple;
	}
 
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setDocumentFolderId(String documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}

	public void setAllowMultiple(boolean allowMultiple) {
		this.allowMultiple = allowMultiple;
	}

	public boolean isAccessRestricted() {
		return accessRestricted;
	}

	public List<String> getAllowedUsers() {
		return allowedUsers;
	}

	public void setAccessRestricted(boolean accessRestricted) {
		this.accessRestricted = accessRestricted;
	}

	public void setAllowedUsers(List<String> allowedUsers) {
		this.allowedUsers = allowedUsers;
	}

	public List<VendorMasterDocumentTypeWorkFlowSteps> getWorkflowSteps() {
		return workflowSteps;
	}
	
	public boolean isApprovalRequire() {
		return approvalRequire;
	}

	public void setApprovalRequire(boolean approvalRequire) {
		this.approvalRequire = approvalRequire;
	}

	public void setWorkflowSteps(List<VendorMasterDocumentTypeWorkFlowSteps> workflowSteps) {
		this.workflowSteps = workflowSteps;
	}

	public boolean isSapWorkflow() {
		return sapWorkflow;
	}

	public void setSapWorkflow(boolean sapWorkflow) {
		this.sapWorkflow = sapWorkflow;
	}
	public List<Field> getFields() {
		return fields;
	}

	public void setFields(List<Field> fields) {
		this.fields = fields;
	}

	public boolean isHasExpiry() {
		return hasExpiry;
	}

	public void setHasExpiry(boolean hasExpiry) {
		this.hasExpiry = hasExpiry;
	}

	public boolean isEnabled() {
		return isEnabled;
	}

	public int getOrder() {
		return order;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public void setOrder(int order) {
		this.order = order;
	}
	
	
}
