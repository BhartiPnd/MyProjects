package com.ssp.mongo.collections.smartbuy.workflow;

import java.util.List;

import com.ssp.mongo.collections.smartbuy.workflow.helper.WorkflowCriateria;

public class SmartBuyWorkflowConfig {

	
	private List<WorkflowCriateria> workflowCriateria;
	private int totalWeight;
	
	private List<String> level1approvers;
	private List<String> level2approvers;
	private List<String> level3approvers;
	public List<WorkflowCriateria> getWorkflowCriateria() {
		return workflowCriateria;
	}
	public void setWorkflowCriateria(List<WorkflowCriateria> workflowCriateria) {
		this.workflowCriateria = workflowCriateria;
	}
	public int getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(int totalWeight) {
		this.totalWeight = totalWeight;
	}
	public List<String> getLevel1approvers() {
		return level1approvers;
	}
	public void setLevel1approvers(List<String> level1approvers) {
		this.level1approvers = level1approvers;
	}
	public List<String> getLevel2approvers() {
		return level2approvers;
	}
	public void setLevel2approvers(List<String> level2approvers) {
		this.level2approvers = level2approvers;
	}
	public List<String> getLevel3approvers() {
		return level3approvers;
	}
	public void setLevel3approvers(List<String> level3approvers) {
		this.level3approvers = level3approvers;
	}
	
	
}
