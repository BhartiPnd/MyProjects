package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RFXNotificationLog {

	private String rfxNo;
	private String vendorId;
	private String vendorName;
	private String status;
	private ZonedDateTime dateTime;
	private String subject;
	private List<String> recipients;

	
	public RFXNotificationLog() {
		super();
	}

	public RFXNotificationLog(String rfxNo, ZonedDateTime dateTime, List<String> recipients, String vendorId,
			String vendorName, String status, String subject) {
		super();
		this.rfxNo = rfxNo;
		this.subject = subject;
		this.dateTime = dateTime;
		this.recipients = recipients;
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.status = status;
	}

	public String getRfxNo() {
		return rfxNo;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public ZonedDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public List<String> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<String> recipients) {
		this.recipients = recipients;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	
}
