package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.AgentCompanyConfig;


@Document(collection = "Agent")
public class Agent {

	public static  final String TYPE_APPROVAL_MATRIX="ApprovalMatrix";
	public static  final String TYPE_FIXED_USERS="FixesUsers";
	public static  final String TYPE_CC="CompanyCode";
	public static  final String TYPE_CCPO="CompanyCodePurchaseOrg";
	public static  final String TYPE_Requestor="Requestor";
	public static  final String TYPE_REQUESTORSMANAGER="RequestorsManager";
	public static  final String TYPE_POBUYER="POBuyer";
	public static  final String TYPE_Receiver="Receiver";
	public static  final String TYPE_CCBD="CCBD";
	public static  final String TYPE_Custom="Custom";
	public static final String TYPE_RECEIVER_AND_CC = "ReceiverAndCompanyCode";
	
	private String id;
	private String agentName;
	private String type;
	private String approvalMatrixID;
	private List<String> fixesUsers;
	private List<AgentCompanyConfig> agentCompanyConfig;
	
	private String accessType;
	private List<String> accessDataObject;
	
	private String sapAgentId;
	private ZonedDateTime lastModifiedDate;
	private String lastModifiedBy;
	private boolean agentonSAPSide;
	
	 
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	 
	public String getApprovalMatrixID() {
		return approvalMatrixID;
	}
	public void setApprovalMatrixID(String approvalMatrixID) {
		this.approvalMatrixID = approvalMatrixID;
	}
	public List<String> getFixesUsers() {
		return fixesUsers;
	}
	
	
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public void setFixesUsers(List<String> fixesUsers) {
		this.fixesUsers = fixesUsers;
	}
	public List<AgentCompanyConfig> getAgentCompanyConfig() {
		return agentCompanyConfig;
	}
	public void setAgentCompanyConfig(List<AgentCompanyConfig> agentCompanyConfig) {
		this.agentCompanyConfig = agentCompanyConfig;
	}
	public String getSapAgentId() {
		return sapAgentId;
	}
	public void setSapAgentId(String sapAgentId) {
		this.sapAgentId = sapAgentId;
	}
	public boolean isAgentonSAPSide() {
		return agentonSAPSide;
	}
	
	
	public ZonedDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(ZonedDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public void setAgentonSAPSide(boolean agentonSAPSide) {
		this.agentonSAPSide = agentonSAPSide;
	}
	public String getAccessType() {
		return accessType;
	}
	public List<String> getAccessDataObject() {
		return accessDataObject;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public void setAccessDataObject(List<String> accessDataObject) {
		this.accessDataObject = accessDataObject;
	}
 
	 
	
 
}
