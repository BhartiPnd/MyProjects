package com.ssp.mongo.collectionhelpers;



public class ContractLineItems {

	private String contractItem;
	private String itemCategory;
	private String productCode;
	private String productDesc;
	private String productCategory;
	private String productCategoryDesc;
	private Double targetQuantity;
	private Double targetValue;
	private String priceUnit; 
	private Double unitPrice;
	private String uom;
	
	private String perUOM;
	private Long per;
	private Double netValue;
	
 
	public String getContractItem() {
		return contractItem;
	}
	public String getItemCategory() {
		return itemCategory;
	}
	public String getProductCode() {
		return productCode;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public Double getTargetQuantity() {
		return targetQuantity;
	}
	public Double getTargetValue() {
		return targetValue;
	}
	public String getPriceUnit() {
		return priceUnit;
	}
	public Double getUnitPrice() {
		return unitPrice;
	}
	public String getUom() {
		return uom;
	}
	public void setContractItem(String contractItem) {
		this.contractItem = contractItem;
	}
	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public void setTargetQuantity(Double targetQuantity) {
		this.targetQuantity = targetQuantity;
	}
	public void setTargetValue(Double targetValue) {
		this.targetValue = targetValue;
	}
	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getProductCategoryDesc() {
		return productCategoryDesc;
	}

	public void setProductCategoryDesc(String productCategoryDesc) {
		this.productCategoryDesc = productCategoryDesc;
	}

	public Long getPer() {
		return per;
	}

	public void setPer(Long per) {
		this.per = per;
	}

	public Double getNetValue() {
		return netValue;
	}

	public void setNetValue(Double netValue) {
		this.netValue = netValue;
	}

	public String getPerUOM() {
		return perUOM;
	}

	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	
}

