package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.EmployeeMasterDto;
import com.ssp.mongo.collectionhelpers.CustomUserCompanies;

@Document(collection = "employeeMaster")
public class EmployeeMaster {

	@Id
	private String id;
	private String name;
	private String firstName;
	private String lastName;
	private String email;
	private String location;
	private String employeeId;
	// title is like designation
	private String title;
	private String phoneNumber;
	private String manager;
	private String status;
	private String erpId;
	private ZonedDateTime endDate;
	private String costCenter;

	private String gender;
	private ZonedDateTime dob;
	private String jobTitle;
	private String department;

	private Double approvalLimit;
	private String currency;
	private String companycode;
	private String image;
	private boolean isSAPSynchACK;
	private String businessUnit;
	private String division;
	private String country;
	private String personId;
	private String plant;
	private String plantDesc;
	private String deptText;
	private boolean primaryDocument;
	private String position;
	private String grade;
	private String headQutr;
	private ZonedDateTime doj;
	private String positionDesc;
	private String divisionDec;
	private String gradeDesc;
	private String headQutrDesc;
	private String businessArea;
	private CustomUserCompanies allowedCompanies;
	private List<String> authPermissionGroups;
	
	public EmployeeMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeMaster(EmployeeMasterDto emDTO) {
		super();
		this.firstName = emDTO.getFirstName();
		this.lastName = emDTO.getLastName();
		this.email = emDTO.getEmail();
		this.status = emDTO.getStatus();
		this.employeeId = emDTO.getEmployeeId();
		this.phoneNumber = emDTO.getPhoneNumber();
		this.manager = emDTO.getManager();
		this.gender = emDTO.getGender();
		this.approvalLimit = emDTO.getApprovalLimit();
		this.currency = emDTO.getCurrency();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public CustomUserCompanies getAllowedCompanies() {
		return allowedCompanies;
	}

	public void setAllowedCompanies(CustomUserCompanies allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}

	public List<String> getAuthPermissionGroups() {
		return authPermissionGroups;
	}

	public void setAuthPermissionGroups(List<String> authPermissionGroups) {
		this.authPermissionGroups = authPermissionGroups;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public Double getApprovalLimit() {
		return approvalLimit;
	}

	public void setApprovalLimit(Double approvalLimit) {
		this.approvalLimit = approvalLimit;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public ZonedDateTime getDob() {
		return dob;
	}

	public void setDob(ZonedDateTime dob) {
		this.dob = dob;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public boolean isSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public String getErpId() {
		return erpId;
	}

	public void setErpId(String erpId) {
		this.erpId = erpId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void resetName() {
		this.name = this.firstName + " "+ this.lastName;
	}

	public String getImage() {
		return image;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public String getDivision() {
		return division;
	}

	public String getCountry() {
		return country;
	}

	public String getPersonId() {
		return personId;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getDeptText() {
		return deptText;
	}

	public void setDeptText(String deptText) {
		this.deptText = deptText;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public boolean isPrimaryDocument() {
		return primaryDocument;
	}

	public void setPrimaryDocument(boolean primaryDocument) {
		this.primaryDocument = primaryDocument;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getHeadQutr() {
		return headQutr;
	}

	public void setHeadQutr(String headQutr) {
		this.headQutr = headQutr;
	}

	public ZonedDateTime getDoj() {
		return doj;
	}

	public void setDoj(ZonedDateTime doj) {
		this.doj = doj;
	}

	public String getPositionDesc() {
		return positionDesc;
	}

	public void setPositionDesc(String positionDesc) {
		this.positionDesc = positionDesc;
	}

	public String getDivisionDec() {
		return divisionDec;
	}

	public void setDivisionDec(String divisionDec) {
		this.divisionDec = divisionDec;
	}

	public String getGradeDesc() {
		return gradeDesc;
	}

	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}

	public String getHeadQutrDesc() {
		return headQutrDesc;
	}

	public void setHeadQutrDesc(String headQutrDesc) {
		this.headQutrDesc = headQutrDesc;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
}
