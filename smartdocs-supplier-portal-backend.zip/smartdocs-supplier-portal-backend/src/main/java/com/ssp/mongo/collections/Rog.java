package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.Item;

@Document(collection = "returnOfGoodReceipt")
public class Rog {
	@Id
	private String uuid;
	private Long ponumber;
	private String supplierId;
	private String rogreference;
	private String comment;
	private List<DocumentHelper> attachment;
	private List<Item> items;
	private ZonedDateTime createdDate;
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Long getPonumber() {
		return ponumber;
	}
	public void setPonumber(Long ponumber) {
		this.ponumber = ponumber;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	
	public String getRogreference() {
		return rogreference;
	}
	public void setRogreference(String rogreference) {
		this.rogreference = rogreference;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public List<DocumentHelper> getAttachment() {
		return attachment;
	}
	public void setAttachment(List<DocumentHelper> attachment) {
		this.attachment = attachment;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public Rog() {
		super();
	}
	public Rog(String uuid, Long ponumber, String supplierId, String rogreference, String comment,
			List<DocumentHelper> attachment, List<Item> items, ZonedDateTime createdDate) {
		super();
		this.uuid = uuid;
		this.ponumber = ponumber;
		this.supplierId = supplierId;
		this.rogreference = rogreference;
		this.comment = comment;
		this.attachment = attachment;
		this.items = items;
		this.createdDate = createdDate;
	}
	
	
	
	
}
