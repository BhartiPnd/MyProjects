package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "OCRFTPConfig")
public class OCRFTPConfig {
	
	public static final String DEFAULT_ID="FTPCnfg";

	@Id
	private String id;
	
	private String server;
	private int port;
	private String username;
	private String password;
	private String requestFolder;
	private String responseFolder;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequestFolder() {
		return requestFolder;
	}

	public void setRequestFolder(String requestFolder) {
		this.requestFolder = requestFolder;
	}

	public String getResponseFolder() {
		return responseFolder;
	}

	public void setResponseFolder(String responseFolder) {
		this.responseFolder = responseFolder;
	} 
	
	
}