package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "helpPageConfig")
public class HelpPageConfig {

	
	@Id
	private String id;
	
	private String pageId;
	
	 
	private String helpPageUrl;
	private String videoURL;
	
	private String state;
	
	public HelpPageConfig() {
		super();
		 
	}

	 

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getHelpPageUrl() {
		return helpPageUrl;
	}

	public void setHelpPageUrl(String helpPageUrl) {
		this.helpPageUrl = helpPageUrl;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVideoURL() {
		return videoURL;
	}

	public void setVideoURL(String videoURL) {
		this.videoURL = videoURL;
	}
	
}