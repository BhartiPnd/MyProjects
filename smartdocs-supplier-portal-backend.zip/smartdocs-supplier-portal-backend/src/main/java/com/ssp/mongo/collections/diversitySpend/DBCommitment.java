package com.ssp.mongo.collections.diversitySpend;

import java.util.List;

import com.ssp.dto.DBCommitedVendor;
import com.ssp.mongo.collectionhelpers.LogEntity;

public class DBCommitment {

	int version;
	private List<DBCommitedVendor> commitments;
	private LogEntity logs;
	
	public int getVersion() {
		return version;
	}
	public List<DBCommitedVendor> getCommitments() {
		return commitments;
	}
	public LogEntity getLogs() {
		return logs;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public void setCommitments(List<DBCommitedVendor> commitments) {
		this.commitments = commitments;
	}
	public void setLogs(LogEntity logs) {
		this.logs = logs;
	}
	
	
}
