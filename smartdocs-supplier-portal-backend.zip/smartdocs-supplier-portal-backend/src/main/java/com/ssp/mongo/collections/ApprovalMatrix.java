package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ApprovalMatrixDefination;


@Document(collection = "ApprovalMatrix")
public class ApprovalMatrix {
	
 
	
	@Id
	private String id;
	
	private String name;
	private String description;
	private String businessObject;
	private List<String> attributes;
	
	 
	
	private List<ApprovalMatrixCriateria> criateria;
	
	private List<ApprovalMatrixDefination> defination;
	
	private int totalLevel; 
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBusinessObject() {
		return businessObject;
	}
	public void setBusinessObject(String businessObject) {
		this.businessObject = businessObject;
	}
	public List<String> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<String> attributes) {
		this.attributes = attributes;
	}
	public List<ApprovalMatrixCriateria> getCriateria() {
		return criateria;
	}
	public void setCriateria(List<ApprovalMatrixCriateria> criateria) {
		this.criateria = criateria;
	}
	public int getTotalLevel() {
		return totalLevel;
	}
	public void setTotalLevel(int totalLevel) {
		this.totalLevel = totalLevel;
	}
	public List<ApprovalMatrixDefination> getDefination() {
		return defination;
	}
	public void setDefination(List<ApprovalMatrixDefination> defination) {
		this.defination = defination;
	}
	 
	 
	
	
	
	
	
}
