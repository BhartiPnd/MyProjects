package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "StatusConfig")
public class StatusConfig {

		
		@Id
		private String id;
		private String status;
		private String description;
		private String externalDescription;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public StatusConfig() {
			super();
		}
		public String getExternalDescription() {
			return externalDescription;
		}
		public void setExternalDescription(String externalDescription) {
			this.externalDescription = externalDescription;
		}
		
		
		
}
