package com.ssp.mongo.collectionhelpers;

public class FormField {

	private String fieldId;
	private String fieldTitle;
	private boolean isRequired;
	private String type;
	private boolean isEnabled;
	private boolean isConfigurable;
	private boolean editable;
	private boolean secured;
	private String format;
	private String responseMapper;
	private boolean lock;
	
	public FormField() {
		
	}
	public FormField(String fieldId, String fieldTitle, Boolean isEnabled,boolean isConfigurable, String type) {
		super();
		this.fieldId = fieldId;
		this.fieldTitle = fieldTitle;
		this.isEnabled = isEnabled;
		this.type = type;
		this.isConfigurable=isConfigurable;
	}
	public FormField(String fieldId, String fieldTitle, Boolean isEnabled, String type) {
		super();
		this.fieldId = fieldId;
		this.fieldTitle = fieldTitle;
		this.isEnabled = isEnabled;
		this.type = type;
		 
	}
	public String getFieldId() {
		return fieldId;
	}
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	public String getFieldTitle() {
		return fieldTitle;
	}
	public void setFieldTitle(String fieldTitle) {
		this.fieldTitle = fieldTitle;
	}
	 
	public boolean getIsEnabled() {
		return isEnabled;
	}
	public void setIsEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean getIsConfigurable() {
		return isConfigurable;
	}
	public void setIsConfigurable(boolean isConfigurable) {
		this.isConfigurable = isConfigurable;
	}
	public boolean getIsRequired() {
		return isRequired;
	}
	public void setIsRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}
	public boolean isEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
	public boolean isSecured() {
		return secured;
	}
	public void setSecured(boolean secured) {
		this.secured = secured;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getResponseMapper() {
		return responseMapper;
	}
	public void setResponseMapper(String responseMapper) {
		this.responseMapper = responseMapper;
	}
	public boolean isLock() {
		return lock;
	}
	public void setLock(boolean lock) {
		this.lock = lock;
	}
		
}
