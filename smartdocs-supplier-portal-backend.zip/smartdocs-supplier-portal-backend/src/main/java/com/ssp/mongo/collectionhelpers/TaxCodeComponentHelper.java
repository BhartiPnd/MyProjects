package com.ssp.mongo.collectionhelpers;

public class TaxCodeComponentHelper {
	private String tcomponent;
	private Double percentage;

	public TaxCodeComponentHelper() {
		super();
	}

	public String getTcomponent() {
		return tcomponent;
	}

	public void setTcomponent(String tcomponent) {
		this.tcomponent = tcomponent;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	@Override
	public String toString() {
		return "TaxCodeComponentHelper [tcomponent=" + tcomponent + ", percentage=" + percentage + "]";
	}

}
