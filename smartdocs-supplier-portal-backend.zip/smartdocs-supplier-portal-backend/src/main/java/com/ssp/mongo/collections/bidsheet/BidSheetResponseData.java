package com.ssp.mongo.collections.bidsheet;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "BidSheetResponseData")
public class BidSheetResponseData {
	
	@Id
	private String id;
	private String bidSheetTitle;
	private String bidSheetId;
	private String responseTxId;
	private String vendorId;
	private String itemNumber;
	private String itemName;
	private String packSize;
	private Double quantity;
	private Double ninetyDayVolumn;
	private String tiers;
	private Integer per;
	private String uom;
	private String uomDesc;
	private Integer deliveryDays;
	private Double previousBid;
	private Double bidPrice;
	private String currency;
	private ZonedDateTime effectiveDate;
	private ZonedDateTime expirationDate;
	private String supplierItem;
	private String notes;
	private String errors;
	private boolean ignore;
	
	public String getBidSheetTitle() {
		return bidSheetTitle;
	}
	public void setBidSheetTitle(String bidSheetTitle) {
		this.bidSheetTitle = bidSheetTitle;
	}
	public String getBidSheetId() {
		return bidSheetId;
	}
	public void setBidSheetId(String bidSheetId) {
		this.bidSheetId = bidSheetId;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getPackSize() {
		return packSize;
	}
	public void setPackSize(String packSize) {
		this.packSize = packSize;
	}
	
	public String getTiers() {
		return tiers;
	}
	public void setTiers(String tiers) {
		this.tiers = tiers;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public Double getPreviousBid() {
		return previousBid;
	}
	public void setPreviousBid(Double previousBid) {
		this.previousBid = previousBid;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public ZonedDateTime getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(ZonedDateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getSupplierItem() {
		return supplierItem;
	}
	public void setSupplierItem(String supplierItem) {
		this.supplierItem = supplierItem;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Double getNinetyDayVolumn() {
		return ninetyDayVolumn;
	}
	public void setNinetyDayVolumn(Double ninetyDayVolumn) {
		this.ninetyDayVolumn = ninetyDayVolumn;
	}
	public Double getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(Double bidPrice) {
		this.bidPrice = bidPrice;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getResponseTxId() {
		return responseTxId;
	}
	public void setResponseTxId(String responseTxId) {
		this.responseTxId = responseTxId;
	}
	public String getUomDesc() {
		return uomDesc;
	}
	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	public Integer getDeliveryDays() {
		return deliveryDays;
	}

	public void setDeliveryDays(Integer deliveryDays) {
		this.deliveryDays = deliveryDays;
	}
	public String getErrors() {
		return errors;
	}
	public void setErrors(String errors) {
		this.errors = errors;
	}
	public boolean isIgnore() {
		return ignore;
	}
	public void setIgnore(boolean ignore) {
		this.ignore = ignore;
	}
	public Integer getPer() {
		return per;
	}
	public void setPer(Integer per) {
		this.per = per;
	}
	
	
}
