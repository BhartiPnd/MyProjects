package com.ssp.mongo.collections.rfx;

import java.util.List;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class RfxTabulation {

	private String bidNo;
	private String supplierId;
	private String supplierName;
	private List<BidRequiredInfo> requiredInfo;
	private List<DocumentHelper> attachments;
	private List<RFXCollaborate> collaborate;
	private Address supplierAddress;
	private List<RFXItems> items;
	
	public RfxTabulation() {
		super();
	}
	
	public RfxTabulation(String  bidno, String supplierId, String supplierName,
			List<BidRequiredInfo> list, List<DocumentHelper> attachments, List<RFXCollaborate> collaborate,
			Address sup, List<RFXItems> items) {
		 this.bidNo=bidno;
		 this.supplierId=supplierId;
		 this.supplierName=supplierName;
		 this.requiredInfo=list;
		 this.attachments=attachments;
		 this.collaborate=collaborate;
		 this.supplierAddress=sup;
		 this.items=items;
	}

	public String getBidNo() {
		return bidNo;
	}
	public void setBidNo(String bidNo) {
		this.bidNo = bidNo;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public List<BidRequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}
	public void setRequiredInfo(List<BidRequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public List<RFXCollaborate> getCollaborate() {
		return collaborate;
	}
	public void setCollaborate(List<RFXCollaborate> collaborate) {
		this.collaborate = collaborate;
	}
	public Address getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(Address supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	
}
