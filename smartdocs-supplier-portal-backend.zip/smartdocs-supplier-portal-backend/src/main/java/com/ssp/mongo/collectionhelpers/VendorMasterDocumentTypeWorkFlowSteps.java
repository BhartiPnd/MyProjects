package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class VendorMasterDocumentTypeWorkFlowSteps {

	private int stepNo;
	private List<String> approvers;
	public int getStepNo() {
		return stepNo;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public void setStepNo(int stepNo) {
		this.stepNo = stepNo;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	
	
	
}
