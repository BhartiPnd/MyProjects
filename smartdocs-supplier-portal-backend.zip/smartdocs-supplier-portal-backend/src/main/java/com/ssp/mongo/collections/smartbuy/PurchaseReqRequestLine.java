package com.ssp.mongo.collections.smartbuy;

 
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import com.ssp.dto.smartbuy.CreatePurchaseReqRequestLine;
import com.ssp.mongo.collections.dataObject.MaterialMaster;
 
public class PurchaseReqRequestLine {

	@Id
	private String id;  
	private int lineNo;
	private String requestId;
	private String materialCode;
	private String materialDesc;
	private String materialGroup;
	private String materialGroupDesc;
	private String category;
	private String suppliedBy;
	private String supplierId;
	private boolean isMaterialMaster;
	private boolean inventory;
	private double qty;
	private double amount;
	private String uom;
	private double unitprice;
	private String currency;
	private String perUOM;
	private Long per;
	private String status;
	private String plant;
	private ZonedDateTime deliveryDate;
	private String storageLocation;
	private String accountAssignmentType;
	private String costCenter;
	private String costCenterDesc;
	private String wbsElementNo;
	public List<PRLineItemUpdate> lineUpdate;
	private String storageLocationDesc;
	private String glAccount;
	private String glAccountDesc;
 	private String plantDesc;
	private String internalOrder;
	private String project;
	private String networkNo;
	private String text;
	private MaterialMaster materialMasterObject;
 	private Double factor;
 	private Double perFactor;
	
	public PurchaseReqRequestLine() {
		super();
	}
	public PurchaseReqRequestLine(CreatePurchaseReqRequestLine line) {
		super();
		this.materialCode = line.getMaterialCode();
		this.materialDesc = line.getMaterialDesc();
		this.materialGroup = line.getMaterialGroup();
		this.category = line.getCategory();
		this.suppliedBy = line.getSuppliedBy();
		this.supplierId = line.getSupplierId();
		this.isMaterialMaster = line.isMaterialMaster();
		this.qty = line.getQty();
		this.uom = line.getUom();
		this.unitprice = line.getUnitprice();
		this.currency = line.getCurrency();
		this.perUOM = line.getPerUOM();
		this.per = line.getPer();
		this.storageLocation = line.getStorageLocation();
		this.plant = line.getPlant();
		this.deliveryDate = line.getDeliveryDate();
		this.glAccount = line.getGlAccount();
		this.accountAssignmentType=line.getAccountAssignmentType();
		this.costCenter=line.getCostCenter();
		this.wbsElementNo=line.getWbsElementNo();
		this.materialGroupDesc=line.getMaterialGroupDesc();
		 this.project=line.getProject();
		 this.internalOrder=line.getInternalOrder();
		 this.networkNo=line.getNetworkNo();
		 this.inventory = line.isInventory();
		 this.text = line.getText();
		 this.factor = line.getFactor();
		 this.perFactor = line.getPerFactor();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getLineNo() {
		return lineNo;
	}
	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	
	
	public MaterialMaster getMaterialMasterObject() {
		return materialMasterObject;
	}
	public void setMaterialMasterObject(MaterialMaster materialMasterObject) {
		this.materialMasterObject = materialMasterObject;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(double unitprice) {
		this.unitprice = unitprice;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPerUOM() {
		return perUOM;
	}
	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	public Long getPer() {
		return per;
	}
	public void setPer(Long per) {
		this.per = per;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSuppliedBy() {
		return suppliedBy;
	}
	public void setSuppliedBy(String suppliedBy) {
		this.suppliedBy = suppliedBy;
	}
	public boolean isMaterialMaster() {
		return isMaterialMaster;
	}
	public void setMaterialMaster(boolean isMaterialMaster) {
		this.isMaterialMaster = isMaterialMaster;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAccountAssignmentType() {
		return accountAssignmentType;
	}
	public void setAccountAssignmentType(String accountAssignmentType) {
		this.accountAssignmentType = accountAssignmentType;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getWbsElementNo() {
		return wbsElementNo;
	}
	public void setWbsElementNo(String wbsElementNo) {
		this.wbsElementNo = wbsElementNo;
	}
	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}
	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}
	public String getPlantDesc() {
		return plantDesc;
	}
	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public String getCostCenterDesc() {
		return costCenterDesc;
	}
	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public String getGlAccountDesc() {
		return glAccountDesc;
	}
	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}
	public String getMaterialGroupDesc() {
		return materialGroupDesc;
	}
	public void setMaterialGroupDesc(String materialGroupDesc) {
		this.materialGroupDesc = materialGroupDesc;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public List<PRLineItemUpdate> getLineUpdate() {
		return lineUpdate;
	}
	public void setLineUpdate(List<PRLineItemUpdate> lineUpdate) {
		this.lineUpdate = lineUpdate;
	}
	public String getInternalOrder() {
		return internalOrder;
	}
	public void setInternalOrder(String internalOrder) {
		this.internalOrder = internalOrder;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getNetworkNo() {
		return networkNo;
	}
	public void setNetworkNo(String networkNo) {
		this.networkNo = networkNo;
	}
	public boolean isInventory() {
		return inventory;
	}
	public void setInventory(boolean inventory) {
		this.inventory = inventory;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Double getFactor() {
		return factor;
	}
	public void setFactor(Double factor) {
		this.factor = factor;
	}
	public Double getPerFactor() {
		return perFactor;
	}
	public void setPerFactor(Double perFactor) {
		this.perFactor = perFactor;
	}
	
	
}
