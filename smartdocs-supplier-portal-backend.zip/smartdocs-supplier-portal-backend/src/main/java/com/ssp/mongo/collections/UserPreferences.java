package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "UserPreferences")
public class UserPreferences 
{
		@Id
		private String userID;
				
		private String companyCode;
		private String purchasingOrg;
		private String purchasingGrp;
		private String paymentTerms;
		private String currencyRate;
		private String accountAssignmentType;
		private String costCenter;
		private String wBS;
		private String internalOrder;
		private String projectNetwork;
		private String systemDefaultCurrency;
		
		private String plant;
		private String storageLocation;
		private String glAccount;
		
		private String defaultOAPODD;
		
		private String defaultNPOInvoiceType;
		
		public String getUserID() {
			return userID;
		}
		public void setUserID(String userID) {
			this.userID = userID;
		}
		
		public String getCompanyCode() {
			return companyCode;
		}
		public void setCompanyCode(String companyCode) {
			this.companyCode = companyCode;
		}
		public String getPurchasingOrg() {
			return purchasingOrg;
		}
		public void setPurchasingOrg(String purchasingOrg) {
			this.purchasingOrg = purchasingOrg;
		}
		public String getPurchasingGrp() {
			return purchasingGrp;
		}
		public void setPurchasingGrp(String purchasingGrp) {
			this.purchasingGrp = purchasingGrp;
		}
		public String getPaymentTerms() {
			return paymentTerms;
		}
		public void setPaymentTerms(String paymentTerms) {
			this.paymentTerms = paymentTerms;
		}
		public String getCurrencyRate() {
			return currencyRate;
		}
		public void setCurrencyRate(String currencyRate) {
			this.currencyRate = currencyRate;
		}
		public String getAccountAssignmentType() {
			return accountAssignmentType;
		}
		public void setAccountAssignmentType(String accountAssignmentType) {
			this.accountAssignmentType = accountAssignmentType;
		}
		public String getCostCenter() {
			return costCenter;
		}
		public void setCostCenter(String costCenter) {
			this.costCenter = costCenter;
		}
		public String getwBS() {
			return wBS;
		}
		public void setwBS(String wBS) {
			this.wBS = wBS;
		}
		public String getInternalOrder() {
			return internalOrder;
		}
		public void setInternalOrder(String internalOrder) {
			this.internalOrder = internalOrder;
		}
		public String getProjectNetwork() {
			return projectNetwork;
		}
		public void setProjectNetwork(String projectNetwork) {
			this.projectNetwork = projectNetwork;
		}
		public String getSystemDefaultCurrency() {
			return systemDefaultCurrency;
		}
		public void setSystemDefaultCurrency(String systemDefaultCurrency) {
			this.systemDefaultCurrency = systemDefaultCurrency;
		}
		public String getPlant() {
			return plant;
		}
		public String getStorageLocation() {
			return storageLocation;
		}
		public String getGlAccount() {
			return glAccount;
		}
		public void setPlant(String plant) {
			this.plant = plant;
		}
		public void setStorageLocation(String storageLocation) {
			this.storageLocation = storageLocation;
		}
		public void setGlAccount(String glAccount) {
			this.glAccount = glAccount;
		}
		public String getDefaultOAPODD() {
			return defaultOAPODD;
		}
		public void setDefaultOAPODD(String defaultOAPODD) {
			this.defaultOAPODD = defaultOAPODD;
		}
		public String getDefaultNPOInvoiceType() {
			return defaultNPOInvoiceType;
		}
		public void setDefaultNPOInvoiceType(String defaultNPOInvoiceType) {
			this.defaultNPOInvoiceType = defaultNPOInvoiceType;
		}
		 
}
