package com.ssp.mongo.collections.pir;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "PurchaseInfoRecord")
public class PurchaseInfoRecord {

	@Id
	private String id;
	private String materialCode;
	private String supplierId;
	private String plant;
	private String purchasingOrg;
	private String purchasingGroup;
	private String informationRecord;
	private double price;
	private double quantity;
	private String uom;
	private String deliveryDays;
	private ZonedDateTime validityFrom;
	private ZonedDateTime validityTo;
	
	

	public PurchaseInfoRecord() {
		
	}
	
	

	public String getPurchasingGroup() {
		return purchasingGroup;
	}



	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMaterialCode() {
		return materialCode;
	}
	

	public double getQuantity() {
		return quantity;
	}



	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}



	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getInformationRecord() {
		return informationRecord;
	}

	public void setInformationRecord(String informationRecord) {
		this.informationRecord = informationRecord;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getDeliveryDays() {
		return deliveryDays;
	}

	public void setDeliveryDays(String deliveryDays) {
		this.deliveryDays = deliveryDays;
	}

	public ZonedDateTime getValidityFrom() {
		return validityFrom;
	}

	public void setValidityFrom(ZonedDateTime validityFrom) {
		this.validityFrom = validityFrom;
	}

	public ZonedDateTime getValidityTo() {
		return validityTo;
	}

	public void setValidityTo(ZonedDateTime validityTo) {
		this.validityTo = validityTo;
	}

}
