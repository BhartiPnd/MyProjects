package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class PaymentRequest {

	private String type;
	private String emailAddress;
	private String accountType;
	private String bankRoutingNo;
	
	private String bankName;
	private String bankAccountNo;
	private String comment;
	private String achDec;
	private String other;
	private List<DocumentHelper> attachments;
	public String getType() {
		return type;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public String getAccountType() {
		return accountType;
	}
	public String getBankRoutingNo() {
		return bankRoutingNo;
	}
	public String getBankName() {
		return bankName;
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public String getComment() {
		return comment;
	}
	public String getAchDec() {
		return achDec;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public void setBankRoutingNo(String bankRoutingNo) {
		this.bankRoutingNo = bankRoutingNo;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public void setAchDec(String achDec) {
		this.achDec = achDec;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	
	
}
 