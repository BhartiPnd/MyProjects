package com.ssp.mongo.collections.diversitySpend;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.DBSubmissionLine;
import com.ssp.mongo.util.GeneralUtil;

@Document(collection = "DBCommitment")
public class DBCommitmentToVendor {

	@Id
	private String id;
	private String contractId;
	private String latestRequestId;
	private String contractTitle;
	private Double contractTargetValue;
	private String year;
	private String month;
	private String type;
	private String primeVendorId;
	private String primeVendorName;
	private String subcontractorId;
	private String subcontractorName;
	private boolean isSubContractorDBVendor;
	private boolean isSubContractorPortalVendor;
	private List<String> dbeTypes;
	private double commitedAmount;
	private double amountOfSubcontracts;
	private double amountEarnedToDate;
	private double amountPaidToDate;
	private ZonedDateTime lastUpdated ;
	
	private ZonedDateTime reportDate; 
	
	public DBCommitmentToVendor() {
		// TODO Auto-generated constructor stub
	}
	
	public DBCommitmentToVendor(Contract contract,String requestId,String type,DBSubmissionLine reportline,String year, String month,boolean isProfessional , String primeVendorName) {
		if(reportline.getSubcontractorId().equals("-1")) {
			//TODO: will handle this later.
			this.id=contract.getNumber()+"_"+reportline.getSubcontractorName();
			this.subcontractorId = reportline.getSubcontractorId();
			this.subcontractorName=reportline.getSubcontractorName();
			
		}
		else if(StringUtils.isNotEmpty(reportline.getSubcontractorId())) {
			this.id=contract.getNumber()+"_"+reportline.getSubcontractorId();
			this.subcontractorId = reportline.getSubcontractorId();
			this.subcontractorName=reportline.getSubcontractorName();
		}
		this.dbeTypes=reportline.getDbeTypes();
		this.isSubContractorDBVendor=reportline.isSubContractorDBVendor();
		this.isSubContractorPortalVendor=reportline.isSubContractorPortalVendor();
		this.contractId =  contract.getNumber();
		
		this.lastUpdated = ZonedDateTime.now();
		this.amountOfSubcontracts=reportline.getAmountOfSubcontracts();
		if(!isProfessional) {
			this.commitedAmount = reportline.getCommitedAmount();
			this.amountEarnedToDate = reportline.getAmountEarnedToDate();
			this.amountPaidToDate = reportline.getAmountPaidToDate();
		}
		this.primeVendorId=contract.getSupplierId();
		this.contractTitle=contract.getName();
		this.contractTargetValue=contract.getTargetValue();
		this.type=type;
		this.year=year;
		this.month=month;
		this.latestRequestId=requestId;
		this.primeVendorName=primeVendorName;
		this.reportDate=GeneralUtil.getMidDate(month, year);
		  
	}
	public DBCommitmentToVendor(Contract contract,String requestId,String type,DBSubmissionLine reportline,String year,String month) {
		if(reportline.getSubcontractorId().equals("-1")) {
			//TODO: will handle this later.
			this.id=contract.getNumber()+"_"+reportline.getSubcontractorName();
			this.subcontractorId = reportline.getSubcontractorId();
			this.subcontractorName=reportline.getSubcontractorName();
			
		}
		else if(StringUtils.isNotEmpty(reportline.getSubcontractorId())) {
			this.id=contract.getNumber()+"_"+reportline.getSubcontractorId();
			this.subcontractorId = reportline.getSubcontractorId();
			this.subcontractorName=reportline.getSubcontractorName();
		}
		this.dbeTypes=reportline.getDbeTypes();
		this.isSubContractorDBVendor=reportline.isSubContractorDBVendor();
		this.isSubContractorPortalVendor=reportline.isSubContractorPortalVendor();
		this.contractId = contract.getNumber();
		this.commitedAmount = reportline.getCommitedAmount();
		this.amountOfSubcontracts=reportline.getAmountOfSubcontracts();
		this.amountEarnedToDate = reportline.getAmountEarnedToDate();
		this.amountPaidToDate = reportline.getAmountPaidToDate();
		this.lastUpdated = ZonedDateTime.now();
		// TODO Auto-generated constructor stub
		
		this.primeVendorId=contract.getSupplierId();
		this.contractTitle=contract.getName();
		this.contractTargetValue=contract.getTargetValue();
		this.type=type;
		this.year=year;
		this.month=month;
		this.latestRequestId=requestId;
		this.reportDate=GeneralUtil.getMidDate(month, year);
	}
 
	public String getId() {
		return id;
	}

	public String getContractId() {
		return contractId;
	}
	 
	public double getCommitedAmount() {
		return commitedAmount;
	}

	 

	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	 

	public void setCommitedAmount(double commitedAmount) {
		this.commitedAmount = commitedAmount;
	}

	 

	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public double getAmountOfSubcontracts() {
		return amountOfSubcontracts;
	}
	public void setAmountOfSubcontracts(double amountOfSubcontracts) {
		this.amountOfSubcontracts = amountOfSubcontracts;
	}
	 
	public boolean isSubContractorDBVendor() {
		return isSubContractorDBVendor;
	}
	public List<String> getDbeTypes() {
		return dbeTypes;
	}
	 
	public void setSubContractorDBVendor(boolean isSubContractorDBVendor) {
		this.isSubContractorDBVendor = isSubContractorDBVendor;
	}
	public void setDbeTypes(List<String> dbeTypes) {
		this.dbeTypes = dbeTypes;
	}
	public boolean isSubContractorPortalVendor() {
		return isSubContractorPortalVendor;
	}
	public void setSubContractorPortalVendor(boolean isSubContractorPortalVendor) {
		this.isSubContractorPortalVendor = isSubContractorPortalVendor;
	}
	public double getAmountEarnedToDate() {
		return amountEarnedToDate;
	}
	public double getAmountPaidToDate() {
		return amountPaidToDate;
	}
	public void setAmountEarnedToDate(double amountEarnedToDate) {
		this.amountEarnedToDate = amountEarnedToDate;
	}
	public void setAmountPaidToDate(double amountPaidToDate) {
		this.amountPaidToDate = amountPaidToDate;
	}
	public String getSubcontractorId() {
		return subcontractorId;
	}
	public String getSubcontractorName() {
		return subcontractorName;
	}
	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}
	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}

	public String getContractTitle() {
		return contractTitle;
	}

	public Double getContractTargetValue() {
		return contractTargetValue;
	}

	public String getYear() {
		return year;
	}

	public String getMonth() {
		return month;
	}

	public String getType() {
		return type;
	}

	public void setContractTitle(String contractTitle) {
		this.contractTitle = contractTitle;
	}

	public void setContractTargetValue(Double contractTargetValue) {
		this.contractTargetValue = contractTargetValue;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPrimeVendorId() {
		return primeVendorId;
	}

	public void setPrimeVendorId(String primeVendorId) {
		this.primeVendorId = primeVendorId;
	}

	public String getLatestRequestId() {
		return latestRequestId;
	}

	public void setLatestRequestId(String latestRequestId) {
		this.latestRequestId = latestRequestId;
	}

	public String getPrimeVendorName() {
		return primeVendorName;
	}

	public void setPrimeVendorName(String primeVendorName) {
		this.primeVendorName = primeVendorName;
	}

	public ZonedDateTime getReportDate() {
		return reportDate;
	}

	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	
}
