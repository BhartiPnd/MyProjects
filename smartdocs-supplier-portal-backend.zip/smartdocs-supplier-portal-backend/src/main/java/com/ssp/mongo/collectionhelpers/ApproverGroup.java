package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class ApproverGroup {
	
	
	//private String invoiceType;
	private int level;
	private List<Approver> approvers;
	
	/*public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}*/
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public List<Approver> getApprovers() {
		return approvers;
	}
	public void setApprovers(List<Approver> approvers) {
		this.approvers = approvers;
	}
	

}
