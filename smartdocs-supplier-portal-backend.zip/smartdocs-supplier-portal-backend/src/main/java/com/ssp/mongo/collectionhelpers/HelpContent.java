package com.ssp.mongo.collectionhelpers;

public class HelpContent {

	private String fieldName;
	private String helpContent;
	
	private String description;
	
	public HelpContent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HelpContent(String fieldName, String helpContent) {
		super();
		this.fieldName = fieldName;
		this.helpContent = helpContent;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getHelpContent() {
		return helpContent;
	}

	public void setHelpContent(String helpContent) {
		this.helpContent = helpContent;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
