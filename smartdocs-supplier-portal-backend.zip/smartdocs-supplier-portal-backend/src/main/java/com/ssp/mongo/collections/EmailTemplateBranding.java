package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "EmailTemplateBranding")
public class EmailTemplateBranding {

	@Id
	private String id;
	
	private String mainTemplate;
	
	private String header;
	private String logo;
	private String signature;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getMainTemplate() {
		return mainTemplate;
	}
	public void setMainTemplate(String mainTemplate) {
		this.mainTemplate = mainTemplate;
	}
	
	
	
}
