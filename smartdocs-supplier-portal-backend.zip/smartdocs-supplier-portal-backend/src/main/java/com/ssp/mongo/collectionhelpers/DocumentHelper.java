package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class DocumentHelper {
	
	public static final int USR_UPLOADED_VENDOR=0;
	public static final int USR_UPLOADED_COMPANY=1;
	public static final int USR_UPLOADED_SAP=2;

	private String documentid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	private String upload;
	private String documentNo;
	
	// deprecated
	//public Long createdate;
	//deprecated
	//public Long createtime;

	//public String creator;
	
	private String uploadedBy;
	//private boolean uploadedByVendor;
	// -1 for non system user, 
	// 0 for vendor 
	// 1 for  company user 
	// 2 for sap
	private int usrUploaded;
	private ZonedDateTime uploadedDate;
	
	private String documentType;
	private ZonedDateTime validFromDate;
	private ZonedDateTime expiryDate;
	
	private Integer versionNo;
	private String versionType;
	private String fileSize;
	private boolean restricted;
	
	public DocumentHelper() {
		super();
	}

	public String getFilename() {
		return filename;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public String getDocumentid() {
		return documentid;
	}
	public void setDocumentid(String documentid) {
		this.documentid = documentid;
	}
	public String getArid() {
		return arid;
	}

	public void setArid(String arid) {
		this.arid = arid;
	}

	public String getAttid() {
		return attid;
	}

	public void setAttid(String attid) {
		this.attid = attid;
	}

//	public String getFilebase64() {
//		return filebase64;
//	}
//
//	public void setFilebase64(String filebase64) {
//		this.filebase64 = filebase64;
//	}

	public String getUpload() {
		return upload;
	}

	public void setUpload(String upload) {
		this.upload = upload;
	}


	/*public Long getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Long createdate) {
		this.createdate = createdate;
	}

	public Long getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Long createtime) {
		this.createtime = createtime;
	}

	private String getCreator() {
		return creator;
	}

	private void setCreator(String creator) {
		this.creator = creator;
	}
    */
 
	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public ZonedDateTime getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(ZonedDateTime expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}
	public void setVersionNo(String versionNo) {
		try {
			this.versionNo = Integer.valueOf(versionNo);
		}
		catch(Exception ex) {}
		
	}
	public String getVersionType() {
		return versionType;
	}

	public void setVersionType(String versionType) {
		this.versionType = versionType;
	}

	public boolean isRestricted() {
		return restricted;
	}

	public void setRestricted(boolean restricted) {
		this.restricted = restricted;
	}

	public ZonedDateTime getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(ZonedDateTime validFromDate) {
		this.validFromDate = validFromDate;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}

	/*public boolean isUploadedByVendor() {
		return uploadedByVendor;
	}

	public void setUploadedByVendor(boolean uploadedByVendor) {
		this.uploadedByVendor = uploadedByVendor;
	}*/

	public int getUsrUploaded() {
		return usrUploaded;
	}

	public void setUsrUploaded(int usrUploaded) {
		this.usrUploaded = usrUploaded;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	
	public DocumentHelper(String documentid, String filename, String filetype, String attid, String arid,
			String uploadedBy, String documentType, String fileSize) {
		super();
		this.documentid = documentid;
		this.filename = filename;
		this.filetype = filetype;
		this.attid = attid;
		this.arid = arid;
		this.uploadedBy = uploadedBy;
		this.uploadedDate = ZonedDateTime.now();
		this.documentType = documentType;
		this.fileSize = fileSize;	
	}
	
	
	
}
