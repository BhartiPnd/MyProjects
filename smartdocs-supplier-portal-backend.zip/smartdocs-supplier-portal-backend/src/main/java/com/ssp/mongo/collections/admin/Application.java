package com.ssp.mongo.collections.admin;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "application")
public class Application {
	
	
	@Id
    private String id;
	@Field("appId")
	private String appId;
	@Field("appName")
	private String appName;
	
	@Field("appSecret")
	private String appSecret;
	@Field("ipwhiteList")
	private String ipwhiteList;
	@Field("httpsonly")
	private boolean httpsOnly;
	
	@Field("ipWhiteListEnabled")
	private boolean ipWhiteListEnabled;
	
	
	@Field("encodingmethod")
	private String encodingMethod;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppSecret() {
		return appSecret;
	}
	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	public String getIpwhiteList() {
		return ipwhiteList;
	}
	public void setIpwhiteList(String ipwhiteList) {
		this.ipwhiteList = ipwhiteList;
	}

	public boolean isHttpsOnly() {
		return httpsOnly;
	}
	public void setHttpsOnly(boolean httpsOnly) {
		this.httpsOnly = httpsOnly;
	}
	public String getEncodingMethod() {
		return encodingMethod;
	}
	public void setEncodingMethod(String encodingMethod) {
		this.encodingMethod = encodingMethod;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public boolean isIpWhiteListEnabled() {
		return ipWhiteListEnabled;
	}
	public void setIpWhiteListEnabled(boolean ipWhiteListEnabled) {
		this.ipWhiteListEnabled = ipWhiteListEnabled;
	}

}