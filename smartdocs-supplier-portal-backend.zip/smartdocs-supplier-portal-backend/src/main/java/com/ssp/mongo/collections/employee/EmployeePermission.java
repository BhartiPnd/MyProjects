package com.ssp.mongo.collections.employee;

public class EmployeePermission {
	
	private String agent;
	private boolean view;
	public String getAgent() {
		return agent;
	}
	public boolean isView() {
		return view;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public void setView(boolean view) {
		this.view = view;
	}
	
	

}
