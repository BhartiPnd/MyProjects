package com.ssp.mongo.collectionhelpers;

public class OtherChangeRequest {
	
	private String comment;

	public OtherChangeRequest() {
		super();
	}
	public OtherChangeRequest(String comment) {
		super();
		this.comment = comment;
	}
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
