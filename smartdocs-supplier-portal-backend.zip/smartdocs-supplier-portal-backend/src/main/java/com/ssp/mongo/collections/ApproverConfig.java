package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ApprovalConfigStep;

@Document(collection = "approverConfig")
public class ApproverConfig {

	@Id
	private String id;
	private String requestType;
	private String companyCode;
	private boolean approvalRequere;
	private boolean qtyChangeBuyerNotification;
	private boolean sapApprovalReq;
	private int totalSteps;
	List<ApprovalConfigStep> approvalConfigStep;
	private List<String> synchNotifiers;
	
	public ApproverConfig() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApproverConfig(String id, String requestType, boolean approvalRequere,boolean qtyChangeBuyerNotification,boolean sapApprovalReq,
			List<ApprovalConfigStep> approvalConfigStep) {
		super();
		this.id = id;
		this.requestType = requestType;
		this.approvalRequere = approvalRequere;
		this.qtyChangeBuyerNotification = qtyChangeBuyerNotification;
		this.sapApprovalReq = sapApprovalReq;
		this.approvalConfigStep = approvalConfigStep;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public boolean isApprovalRequere() {
		return approvalRequere;
	}

	public void setApprovalRequere(boolean approvalRequere) {
		this.approvalRequere = approvalRequere;
	}

	public List<ApprovalConfigStep> getApprovalConfigStep() {
		return approvalConfigStep;
	}

	public void setApprovalConfigStep(List<ApprovalConfigStep> approvalConfigStep) {
		this.approvalConfigStep = approvalConfigStep;
	}

	public int getTotalSteps() {
		return totalSteps;
	}

	public void setTotalSteps(int totalSteps) {
		this.totalSteps = totalSteps;
	}

	public List<String> getSynchNotifiers() {
		return synchNotifiers;
	}

	public void setSynchNotifiers(List<String> synchNotifiers) {
		this.synchNotifiers = synchNotifiers;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public boolean isQtyChangeBuyerNotification() {
		return qtyChangeBuyerNotification;
	}

	public void setQtyChangeBuyerNotification(boolean qtyChangeBuyerNotification) {
		this.qtyChangeBuyerNotification = qtyChangeBuyerNotification;
	}

	public boolean isSapApprovalReq() {
		return sapApprovalReq;
	}

	public void setSapApprovalReq(boolean sapApprovalReq) {
		this.sapApprovalReq = sapApprovalReq;
	}
	
}
