package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.ssp.mongo.collectionhelpers.PurchaseReqRequestTemplateLineItems;

@Document(collection = "PurchaseReqRequestTemplate")
public class PurchaseReqRequestTemplate {

	@Id
	private String id;
	private String companyCode;
	private String title;
	private String owner;
	private String global;
	private String prrType;
	private String notes;
	private ZonedDateTime createdDateTime;
	private List<PurchaseReqRequestTemplateLineItems> items;

	public PurchaseReqRequestTemplate() {
		super();
		this.createdDateTime = ZonedDateTime.now();

	}

	public PurchaseReqRequestTemplate(String title, String owner, String global, String prrType,
			List<PurchaseReqRequestTemplateLineItems> items) {
		super();
		this.title = title;
		this.owner = owner;
		this.global = global;
		this.prrType = prrType;
		this.createdDateTime = ZonedDateTime.now();
		this.items = items;
	}

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getOwner() {
		return owner;
	}

	public String getGlobal() {
		return global;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void setGlobal(String global) {
		this.global = global;
	}

	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getPrrType() {
		return prrType;
	}

	public void setPrrType(String prrType) {
		this.prrType = prrType;
	}

	public List<PurchaseReqRequestTemplateLineItems> getItems() {
		return items;
	}

	public void setItems(List<PurchaseReqRequestTemplateLineItems> items) {
		this.items = items;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
	
}
