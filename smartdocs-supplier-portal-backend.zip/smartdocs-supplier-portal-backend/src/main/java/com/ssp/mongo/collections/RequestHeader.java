package com.ssp.mongo.collections;

import java.util.List;

public class RequestHeader {

	private int filedSequence;
	private String filedName;
	private String filedLabel;
	private String filedValue;
	private String filedType;
	private String filedLength;
	private List<String> possibleValues;
	private String listScreenPosition;
	private Boolean barCodeSupported;
	private Boolean showOnMobile;

	public RequestHeader() {

	}

	public RequestHeader(int filedSequence, String filedName, String filedLabel,String filedValue, String filedType, String filedLength,
			List<String> possibleValues, String listScreenPosition, Boolean barCodeSupported, Boolean showOnMobile) {
		super();
		this.filedSequence = filedSequence;
		this.filedName = filedName;
		this.filedLabel = filedLabel;
		this.filedValue = filedValue;
		this.filedType = filedType;
		this.filedLength = filedLength;
		this.possibleValues = possibleValues;
		this.listScreenPosition = listScreenPosition;
		this.barCodeSupported = barCodeSupported;
		this.showOnMobile = showOnMobile;
	}

	public int getFiledSequence() {
		return filedSequence;
	}

	public void setFiledSequence(int filedSequence) {
		this.filedSequence = filedSequence;
	}

	public String getFiledName() {
		return filedName;
	}

	public void setFiledName(String filedName) {
		this.filedName = filedName;
	}

	public String getFiledValue() {
		return filedValue;
	}

	public void setFiledValue(String filedValue) {
		this.filedValue = filedValue;
	}

	public String getFiledLabel() {
		return filedLabel;
	}

	public void setFiledLabel(String filedLabel) {
		this.filedLabel = filedLabel;
	}

	public String getFiledType() {
		return filedType;
	}

	public void setFiledType(String filedType) {
		this.filedType = filedType;
	}

	public String getFiledLength() {
		return filedLength;
	}

	public void setFiledLength(String filedLength) {
		this.filedLength = filedLength;
	}

	public List<String> getPossibleValues() {
		return possibleValues;
	}

	public void setPossibleValues(List<String> possibleValues) {
		this.possibleValues = possibleValues;
	}

	public String getListScreenPosition() {
		return listScreenPosition;
	}

	public void setListScreenPosition(String listScreenPosition) {
		this.listScreenPosition = listScreenPosition;
	}

	public Boolean getBarCodeSupported() {
		return barCodeSupported;
	}

	public void setBarCodeSupported(Boolean barCodeSupported) {
		this.barCodeSupported = barCodeSupported;
	}

	public Boolean getShowOnMobile() {
		return showOnMobile;
	}

	public void setShowOnMobile(Boolean showOnMobile) {
		this.showOnMobile = showOnMobile;
	}

	@Override
	public String toString() {
		return "RequestHeader [filedSequence=" + filedSequence + ", filedName=" + filedName + ", filedLabel="
				+ filedLabel + ", filedType=" + filedType + ", filedLength=" + filedLength + ", possibleValues="
				+ possibleValues + ", listScreenPosition=" + listScreenPosition + ", barCodeSupported="
				+ barCodeSupported + ", showOnMobile=" + showOnMobile + "]";
	}

}
