package com.ssp.mongo.collections.smartbuy.workflow.helper;

public class WorkflowCriateria {

	private String field;
	private String operation;
	private double min;
	private double max;
	private String value;
	private int weight;
	private boolean requird;
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public boolean isRequird() {
		return requird;
	}
	public void setRequird(boolean requird) {
		this.requird = requird;
	}
	
	
}
