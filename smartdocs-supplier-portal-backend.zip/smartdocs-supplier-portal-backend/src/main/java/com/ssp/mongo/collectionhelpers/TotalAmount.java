package com.ssp.mongo.collectionhelpers;

public class TotalAmount {

	private Double amount;

	public TotalAmount() {
		super();
	}

	public TotalAmount(Double amount) {
		super();
		this.amount = amount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
}
