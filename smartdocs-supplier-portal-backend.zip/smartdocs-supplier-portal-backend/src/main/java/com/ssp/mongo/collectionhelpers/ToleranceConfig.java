package com.ssp.mongo.collectionhelpers;

public class ToleranceConfig {

	private boolean isEnabled;
	private float tolerance;
	private String companyCode;
	//allow more then tolerance value
	private boolean allowMore;

	public boolean isEnabled() {
		return isEnabled;
	}

	public float getTolerance() {
		return tolerance;
	}

	public boolean isAllowMore() {
		return allowMore;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public void setTolerance(float tolerance) {
		this.tolerance = tolerance;
	}

	public void setAllowMore(boolean allowMore) {
		this.allowMore = allowMore;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	
	
}
