package com.ssp.mongo.collections;

public class MealsDetails {

	
	private String zip;
	private String county;
	private int meals;
	private String city;
	private String state;
	private int value;
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public int getMeals() {
		return meals;
	}
	public void setMeals(int meals) {
		this.meals = meals;
	}
	
	
	
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public MealsDetails() {
		super();
	}
	
	
	
	
}
