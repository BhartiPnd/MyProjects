package com.ssp.mongo.collections.requests;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.dto.InterCompanyDetails;
import com.ssp.dto.OrganisationalDetails;
import com.ssp.dto.ProcessingData;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.Contact;
import com.ssp.mongo.collectionhelpers.DBESelectedStatus;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.PaymentRequest;
import com.ssp.mongo.collectionhelpers.Phone;
import com.ssp.mongo.collections.Agent;

@Document(collection = "VendorRegistrationRequest")
public class VendorRegistrationRequest {
	
	
	public static final String REF_ID_PREFIX="VRR";
	
	
	@Id
	private String id;
	private String prefix;
	private long registrationRequestId;
	
	// just for form. 
	private String captchaCode;
	private String createdBy;
	private ZonedDateTime createdDate;
	private String status;
	private String statusDesc;
	private String notes;
	private String taxId;
	private String taxIdType;
	private Address companyAddress;
	private Phone phone;
	private Phone fax;
	private Phone mobile;
	private String primarEmailAddreess;
	private String  incoterms;
	
	private String tandcversion;
	
	private String payeeName;
	private String paymentRemittanceEmail;
	private Address permanentRemitanceAddress;
	private String dbaName;
	private String function;
	
	private String socialSecurityNo;
	private String employeeIdNo;
	private String employeeLicense;
	
	private String companyName;
	
	private List<Contact> contactPersons;
	private Map<String,String> attributes;
	private  PaymentRequest payment;
	private  BankDetail bankDetail;
	private  BankDetail intermediaryBankDetail;
	private  TaxDetail taxDetail;

	private String supplierId;
	private String companyCode;
	private List<DocumentHelper> attachments;
	
	
	private ZonedDateTime w9SignatureDate;
	private String dbSelected;
	private List<DBESelectedStatus> dbeSelectedStatus;
	private List<String> productCategories;
		
	private List<ActivityLog> activityLogs;
	
	private boolean isSAPSynch;
	private Long sapSynchDate;
	private boolean isSAPSynchACK;
	
	private boolean isCollaborated;
	
	private String collaboratedUser;
	
	// this is used in case of company user want to colloborate with vendor. 
	private String  notesForVendor;
	
	private boolean noAlternatePayment;
	private boolean analyticsSyncStatus;
	
	
	private boolean syncToSAP;
	private GeneralState state;
	private String agentName;
	
	private String requestorEmail;
	
	private InterCompanyDetails interCompanyDetails;
	private OrganisationalDetails organisationalDetails;
	private ProcessingData processingData;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public long getRegistrationRequestId() {
		return registrationRequestId;
	}
	public void setRegistrationRequestId(long registrationRequestId) {
		this.registrationRequestId = registrationRequestId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	 
	public Address getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(Address companyAddress) {
		this.companyAddress = companyAddress;
	}
	public Phone getPhone() {
		return phone;
	}
	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	public Phone getFax() {
		return fax;
	}
	public void setFax(Phone fax) {
		this.fax = fax;
	}
	public String getPrimarEmailAddreess() {
		return primarEmailAddreess;
	}
	public void setPrimarEmailAddreess(String primarEmailAddreess) {
		this.primarEmailAddreess = primarEmailAddreess;
		
		
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public Address getPermanentRemitanceAddress() {
		return permanentRemitanceAddress;
	}
	public void setPermanentRemitanceAddress(Address permanentRemitanceAddress) {
		this.permanentRemitanceAddress = permanentRemitanceAddress;
	}
	 
	public String getEmployeeIdNo() {
		return employeeIdNo;
	}
	public void setEmployeeIdNo(String employeeIdNo) {
		this.employeeIdNo = employeeIdNo;
	}
	public String getEmployeeLicense() {
		return employeeLicense;
	}
	public void setEmployeeLicense(String employeeLicense) {
		this.employeeLicense = employeeLicense;
	}
	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public String getNotes() {
		return notes;
	}
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getTaxIdType() {
		return taxIdType;
	}
	public void setTaxIdType(String taxIdType) {
		this.taxIdType = taxIdType;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public Long getSapSynchDate() {
		return sapSynchDate;
	}
	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Map<String, String> getAttributes() {
		return attributes;
	}
	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}
	public List<DBESelectedStatus> getDbeSelectedStatus() {
		return dbeSelectedStatus;
	}
	public void setDbeSelectedStatus(List<DBESelectedStatus> dbeSelectedStatus) {
		this.dbeSelectedStatus = dbeSelectedStatus;
	}
	public List<String> getProductCategories() {
		return productCategories;
	}
	public void setProductCategories(List<String> productCategories) {
		this.productCategories = productCategories;
	}
	public List<Contact> getContactPersons() {
		return contactPersons;
	}
	public void setContactPersons(List<Contact> contactPersons) {
		this.contactPersons = contactPersons;
	}
	public ZonedDateTime getW9SignatureDate() {
		return w9SignatureDate;
	}
	public void setW9SignatureDate(ZonedDateTime w9SignatureDate) {
		this.w9SignatureDate = w9SignatureDate;
	}
	public String getSocialSecurityNo() {
		return socialSecurityNo;
	}
	public void setSocialSecurityNo(String socialSecurityNo) {
		this.socialSecurityNo = socialSecurityNo;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public Phone getMobile() {
		return mobile;
	}
	public void setMobile(Phone mobile) {
		this.mobile = mobile;
	}
	
	public boolean isCollaborated() {
		return isCollaborated;
	}
	public void setCollaborated(boolean isCollaborated) {
		this.isCollaborated = isCollaborated;
	}
	
	 
	public String getCaptchaCode() {
		return captchaCode;
	}
	public void setCaptchaCode(String captchaCode) {
		this.captchaCode = captchaCode;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public String getDbaName() {
		return dbaName;
	}
	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}
	public PaymentRequest getPayment() {
		return payment;
	}
	public void setPayment(PaymentRequest payment) {
		this.payment = payment;
	}
	public String getDbSelected() {
		return dbSelected;
	}
	public void setDbSelected(String dbSelected) {
		this.dbSelected = dbSelected;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	
	 public String getNotesForVendor() {
		return notesForVendor;
	}
	public void setNotesForVendor(String notesForVendor) {
		this.notesForVendor = notesForVendor;
	}
	
	public boolean isNoAlternatePayment() {
		return noAlternatePayment;
	}
	public void setNoAlternatePayment(boolean noAlternatePayment) {
		this.noAlternatePayment = noAlternatePayment;
	}
	public void addAttachments(List<DocumentHelper>  attachments,String uploadedBy,int usrUploaded) {
		 resetAttachmentUploadeByInfo(attachments,uploadedBy, usrUploaded);
		if(attachments!=null && attachments.size()>0) {
			if(this.getAttachments()==null){
				this.setAttachments(new ArrayList<>());
			}
			for(DocumentHelper docHelper:attachments) {
				this.getAttachments().add(docHelper);
			}
		}
		else {
			
		}
	}
	
	public BankDetail getBankDetail() {
		return bankDetail;
	}
	public void setBankDetail(BankDetail bankDetail) {
		this.bankDetail = bankDetail;
	}
	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}
	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	
	public String getIncoterms() {
		return incoterms;
	}
	public void setIncoterms(String incoterms) {
		this.incoterms = incoterms;
	}
	 
	public String getPaymentRemittanceEmail() {
		return paymentRemittanceEmail;
	}
	public void setPaymentRemittanceEmail(String paymentRemittanceEmail) {
		this.paymentRemittanceEmail = paymentRemittanceEmail;
	}
	public BankDetail getIntermediaryBankDetail() {
		return intermediaryBankDetail;
	}
	public void setIntermediaryBankDetail(BankDetail intermediaryBankDetail) {
		this.intermediaryBankDetail = intermediaryBankDetail;
	}
	public TaxDetail getTaxDetail() {
		return taxDetail;
	}
	public void setTaxDetail(TaxDetail taxDetail) {
		this.taxDetail = taxDetail;
	}
	public List<DocumentHelper> resetAttachmentUploadeByInfo(List<DocumentHelper> attachments,String uploadedBy,int usrUploaded) {
		if(attachments!=null && attachments.size()>0)
		{
			for(DocumentHelper attachment:attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
			}
		}
		return attachments;
	}
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		if(this.attachments!=null && this.attachments.size()>0)
		{
			for(DocumentHelper attachment:this.attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
				
			}
			
		}
	}
	public boolean isSyncToSAP() {
		return syncToSAP;
	}
	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}
	public GeneralState getState() {
		return state;
	}
	public void setState(GeneralState state) {
		this.state = state;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getTandcversion() {
		return tandcversion;
	}
	public void setTandcversion(String tandcversion) {
		this.tandcversion = tandcversion;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public InterCompanyDetails getInterCompanyDetails() {
		return interCompanyDetails;
	}
	public void setInterCompanyDetails(InterCompanyDetails interCompanyDetails) {
		this.interCompanyDetails = interCompanyDetails;
	}
	public OrganisationalDetails getOrganisationalDetails() {
		return organisationalDetails;
	}
	public void setOrganisationalDetails(OrganisationalDetails organisationalDetails) {
		this.organisationalDetails = organisationalDetails;
	}
	public ProcessingData getProcessingData() {
		return processingData;
	}
	public void setProcessingData(ProcessingData processingData) {
		this.processingData = processingData;
	}
	
	
}
