package com.ssp.mongo.collections.rfx;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

@Document(collection = "bidRFx")
public class BidRFx {
	
	public static final String STATUS_DRAFT="DRAFT";
	public static final String STATUS_SUBMITTED="SUBMITTED";
	
	public static final String BID_TYPE_BID="BID";
	
	@Id
	private String id; 
	private String bidNo;
	private String rfxNo;
	private boolean isSubmitted;
	private String status;
	private String supplierId;
	private String supplierName;
	private List<RFXItems> items;
	private List<BidRequiredInfo> requiredInfo;
	private Double totalAmount;
	private String currency;
	private String comments;
	private ZonedDateTime createdDateTime;
	private List<DocumentHelper> attachments;
	private String title;
	private String bidType;
	private boolean isAwarded;
	private String bidSubmittedBy;
	private Boolean isErpSynch;
	private Long erpSynchDate;
	private Boolean isErpSynchACK;
	private ZonedDateTime lastUpdatedDate;
	private String lastUpdatedBy;
	private String bidSubmittedByName;
	private boolean isOwner;
	
	private boolean isSurrogateBid;
	private String surragoteBidBy;
	private String surragoteBidByName;
	
	private boolean noBid;
	private Boolean isLastTab;
	private String awardStatus;
	private boolean portalAward;
	
	public boolean isNoBid() {
		return noBid;
	}


	public void setNoBid(boolean noBid) {
		this.noBid = noBid;
	}


	public boolean isSurrogateBid() {
		return isSurrogateBid;
	}


	public void setSurrogateBid(boolean isSurrogateBid) {
		this.isSurrogateBid = isSurrogateBid;
	}


	public String getSurragoteBidBy() {
		return surragoteBidBy;
	}


	public void setSurragoteBidBy(String surragoteBidBy) {
		this.surragoteBidBy = surragoteBidBy;
	}


	public String getSurragoteBidByName() {
		return surragoteBidByName;
	}


	public void setSurragoteBidByName(String surragoteBidByName) {
		this.surragoteBidByName = surragoteBidByName;
	}


	public BidRFx() {
		super();
		this.isErpSynch=false;
		this.isErpSynchACK=false;
	}

	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getBidNo() {
		return bidNo;
	}
	public void setBidNo(String bidNo) {
		this.bidNo = bidNo;
	}
	
	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	
	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public List<BidRequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}
	public void setRequiredInfo(List<BidRequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	
	 
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	 
	public boolean isAwarded() {
		return isAwarded;
	}
	public void setAwarded(boolean isAwarded) {
		this.isAwarded = isAwarded;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public boolean isSubmitted() {
		return isSubmitted;
	}
	public void setSubmitted(boolean isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
 
	public String getBidSubmittedBy() {
		return bidSubmittedBy;
	}
	public void setBidSubmittedBy(String bidSubmittedBy) {
		this.bidSubmittedBy = bidSubmittedBy;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	
	public void resetAttachmentUploadeByInfo(String uploadedBy) {
			if(this.attachments!=null && !this.attachments.isEmpty())
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
					} 
				}
			}
	}
	public boolean isOwner() {
		return isOwner;
	}
	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}
	
	public String getBidSubmittedByName() {
		return bidSubmittedByName;
	}
	
	public void setBidSubmittedByName(String bidSubmittedByName) {
		this.bidSubmittedByName = bidSubmittedByName;
	}
	public String getBidType() {
		return bidType;
	}
	public void setBidType(String bidType) {
		this.bidType = bidType;
	}


	public Boolean getIsErpSynch() {
		return isErpSynch;
	}


	public void setIsErpSynch(Boolean isErpSynch) {
		this.isErpSynch = isErpSynch;
	}



	public Long getErpSynchDate() {
		return erpSynchDate;
	}


	public void setErpSynchDate(Long erpSynchDate) {
		this.erpSynchDate = erpSynchDate;
	}


	public Boolean getIsErpSynchACK() {
		return isErpSynchACK;
	}


	public void setIsErpSynchACK(Boolean isErpSynchACK) {
		this.isErpSynchACK = isErpSynchACK;
	}


	public ZonedDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}


	public void setLastUpdatedDate(ZonedDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}


	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


	public Boolean getIsLastTab() {
		return isLastTab;
	}


	public void setIsLastTab(Boolean isLastTab) {
		this.isLastTab = isLastTab;
	}


	public String getAwardStatus() {
		return awardStatus;
	}

	public void setAwardStatus(String awardStatus) {
		this.awardStatus = awardStatus;
	}


	public boolean isPortalAward() {
		return portalAward;
	}


	public void setPortalAward(boolean portalAward) {
		this.portalAward = portalAward;
	}

	
}	
