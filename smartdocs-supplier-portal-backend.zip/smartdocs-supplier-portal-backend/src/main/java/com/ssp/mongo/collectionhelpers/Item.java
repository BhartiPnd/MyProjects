package com.ssp.mongo.collectionhelpers;

public class Item {

	private Long itemno;
	private String itemdescription;
	private Double quantity;
	private String uom;
	private String plant;
	private String storageLocation;
	private Double discount;
	private String storageLocationDesc;
	private String plantDesc;
	private String mat_CODE;
    private String unitprice;
    private String uomDesc;
	
	private String perUOM;
	private Long per;
	private Double netValue;
	private boolean deliveryCompleted;
	private boolean catchWeight;
	private Double deliveredQty;
	private String deliveredUom;
	
	
	public Item() {
		super();
	}

	public Long getItemno() {
		return itemno;
	}

	public void setItemno(Long itemno) {
		this.itemno = itemno;
	}

	public String getItemdescription() {
		return itemdescription;
	}

	public void setItemdescription(String itemdescription) {
		this.itemdescription = itemdescription;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Item [itemno=" + itemno + ", itemdescription="
				+ itemdescription + ", quantity=" + quantity + ", uom=" + uom
				+ "]";
	}

	public String getPlant() {
		return plant;
	}

	public String getStorageLocation() {
		return storageLocation;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}

	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}

	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public String getMat_CODE() {
		return mat_CODE;
	}

	public void setMat_CODE(String mat_CODE) {
		this.mat_CODE = mat_CODE;
	}

	public String getUnitprice() {
		return unitprice;
	}

	public void setUnitprice(String unitprice) {
		this.unitprice = unitprice;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	public String getPerUOM() {
		return perUOM;
	}

	public Long getPer() {
		return per;
	}

	public Double getNetValue() {
		return netValue;
	}

	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}

	public void setPer(Long per) {
		this.per = per;
	}

	public void setNetValue(Double netValue) {
		this.netValue = netValue;
	}

	public boolean isDeliveryCompleted() {
		return deliveryCompleted;
	}

	public void setDeliveryCompleted(boolean deliveryCompleted) {
		this.deliveryCompleted = deliveryCompleted;
	}

	public boolean isCatchWeight() {
		return catchWeight;
	}

	public void setCatchWeight(boolean catchWeight) {
		this.catchWeight = catchWeight;
	}

	public Double getDeliveredQty() {
		return deliveredQty;
	}

	public void setDeliveredQty(Double deliveredQty) {
		this.deliveredQty = deliveredQty;
	}

	public String getDeliveredUom() {
		return deliveredUom;
	}

	public void setDeliveredUom(String deliveredUom) {
		this.deliveredUom = deliveredUom;
	}

	
}
