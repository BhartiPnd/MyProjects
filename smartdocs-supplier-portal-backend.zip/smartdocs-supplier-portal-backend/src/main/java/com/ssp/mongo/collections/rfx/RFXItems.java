package com.ssp.mongo.collections.rfx;

import java.time.ZonedDateTime;

public class RFXItems {
	private String lineNo;
	private String itemNumber;
	private String itemName;
	private String uom;
	private String uomDesc;
	private ZonedDateTime deliveryDate;
	private double quantity;
	private String materialGroup;
	private String itemCategory;
	private String plant;
	private String plantDesc;
	private String storageLoc;
	private String storageLocDesc;
	private String vendorId;
	private String vendorName;
	private String glAccount;
	private String glAccountDesc;
	private double unitPrice;
	private String currency;
	private String per;
	private String perUom;
	private double totalPrice;
	private String accountAssignmentCategory;
	private String costCenter;
	private String costCenterDesc;
	private String category;
	private double vendorUnitPrice;
	private String vendorPartNo;
	private boolean isSelected;
	private String comment;
	private String awardStatus;
	private String error;

	public String getLineNo() {
		return lineNo;
	}

	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public String getPerUom() {
		return perUom;
	}

	public void setPerUom(String perUom) {
		this.perUom = perUom;
	}

	public String getVendorPartNo() {
		return vendorPartNo;
	}

	public void setVendorPartNo(String vendorPartNo) {
		this.vendorPartNo = vendorPartNo;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}



	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getMaterialGroup() {
		return materialGroup;
	}

	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public String getStorageLoc() {
		return storageLoc;
	}

	public void setStorageLoc(String storageLoc) {
		this.storageLoc = storageLoc;
	}

	public String getStorageLocDesc() {
		return storageLocDesc;
	}

	public void setStorageLocDesc(String storageLocDesc) {
		this.storageLocDesc = storageLocDesc;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getGlAccount() {
		return glAccount;
	}

	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}

	public String getGlAccountDesc() {
		return glAccountDesc;
	}

	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPer() {
		return per;
	}

	public void setPer(String per) {
		this.per = per;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getAccountAssignmentCategory() {
		return accountAssignmentCategory;
	}

	public void setAccountAssignmentCategory(String accountAssignmentCategory) {
		this.accountAssignmentCategory = accountAssignmentCategory;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getCostCenterDesc() {
		return costCenterDesc;
	}

	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getVendorUnitPrice() {
		return vendorUnitPrice;
	}

	public void setVendorUnitPrice(double vendorUnitPrice) {
		this.vendorUnitPrice = vendorUnitPrice;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAwardStatus() {
		return awardStatus;
	}

	public void setAwardStatus(String awardStatus) {
		this.awardStatus = awardStatus;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	
}
