package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class InvoiceTemplateLineItems {
	
	
	private String materialCode;
	private String materialGroup;
	private String materialDescription;
	private String unitofmeasure;
	private String supplierPartNo;
	private String plant;
	private String plantDesc;
	private String storageLocation;
	private String storageLocationDesc;
	private String tradingPartner;
	private String tradingPartnerDesc;
	private String glAccountCode;
	private String glAccountDesc;
	private String costCenter;
	private String costCenterDesc;
	private String wbsElement;
	private String wbsElementDesc;
	private String datesOfService;
	private String itemText;
	private String fundNumber;
	
	private String assetCode;
	private String companyCode;
	private String companyCodeDesc;
	private String orderNumber;
	
	private String lineNumber;
	private String assignmentNumber;
	private String taxJurisdiction;
	private String segment;
	private String salesOrder;
	private String materialNumber;
	private String profitCenter;
	private double unitPrice;
	private double invUnitPrice;
	private double discountamount;
	private double netAmount;
	private double tax;
	private double taxPercent;
	private double subTotal;
	private double total;
	
	public String getGlAccountCode() {
		return glAccountCode;
	}
	public String getGlAccountDesc() {
		return glAccountDesc;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public String getCostCenterDesc() {
		return costCenterDesc;
	}
	public String getWbsElement() {
		return wbsElement;
	}
	public String getWbsElementDesc() {
		return wbsElementDesc;
	}
	public void setGlAccountCode(String glAccountCode) {
		this.glAccountCode = glAccountCode;
	}
	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}
	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}
	public void setWbsElementDesc(String wbsElementDesc) {
		this.wbsElementDesc = wbsElementDesc;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public String getMaterialDescription() {
		return materialDescription;
	}
	public String getUnitofmeasure() {
		return unitofmeasure;
	}
	public String getSupplierPartNo() {
		return supplierPartNo;
	}
	public String getPlant() {
		return plant;
	}
	public String getPlantDesc() {
		return plantDesc;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}
	public String getDatesOfService() {
		return datesOfService;
	}
	public String getItemText() {
		return itemText;
	}
	public String getFundNumber() {
		return fundNumber;
	}
	public String getAssetCode() {
		return assetCode;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public String getCompanyCodeDesc() {
		return companyCodeDesc;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public String getLineNumber() {
		return lineNumber;
	}
	public String getAssignmentNumber() {
		return assignmentNumber;
	}
	public String getTaxJurisdiction() {
		return taxJurisdiction;
	}
	public String getSegment() {
		return segment;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public String getMaterialNumber() {
		return materialNumber;
	}
	public String getProfitCenter() {
		return profitCenter;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}
	public void setUnitofmeasure(String unitofmeasure) {
		this.unitofmeasure = unitofmeasure;
	}
	public void setSupplierPartNo(String supplierPartNo) {
		this.supplierPartNo = supplierPartNo;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}
	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}
	public void setItemText(String itemText) {
		this.itemText = itemText;
	}
	public void setFundNumber(String fundNumber) {
		this.fundNumber = fundNumber;
	}
	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public void setCompanyCodeDesc(String companyCodeDesc) {
		this.companyCodeDesc = companyCodeDesc;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public void setAssignmentNumber(String assignmentNumber) {
		this.assignmentNumber = assignmentNumber;
	}
	public void setTaxJurisdiction(String taxJurisdiction) {
		this.taxJurisdiction = taxJurisdiction;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public void setMaterialNumber(String materialNumber) {
		this.materialNumber = materialNumber;
	}
	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public double getInvUnitPrice() {
		return invUnitPrice;
	}
	public void setInvUnitPrice(double invUnitPrice) {
		this.invUnitPrice = invUnitPrice;
	}
	public double getDiscountamount() {
		return discountamount;
	}
	public void setDiscountamount(double discountamount) {
		this.discountamount = discountamount;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	public double getTaxPercent() {
		return taxPercent;
	}
	public void setTaxPercent(double taxPercent) {
		this.taxPercent = taxPercent;
	}
	public double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getTradingPartner() {
		return tradingPartner;
	}
	public void setTradingPartner(String tradingPartner) {
		this.tradingPartner = tradingPartner;
	}
	public String getTradingPartnerDesc() {
		return tradingPartnerDesc;
	}
	public void setTradingPartnerDesc(String tradingPartnerDesc) {
		this.tradingPartnerDesc = tradingPartnerDesc;
	}
	
}
