package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.EmailChannelField;

@Document(collection = "emailChannel")
public class EmailChannels {
	
	public static final String REQTYPESUBJECT="subject"; 
	public static final String AUTH_TYPE_OAUTH="oauth";
	public static final String AUTH_TYPE_BASIC="basic";
	public static final String DATA_OBJECT_BIDSHEET = "BidSHEET";

	@Id
	private String id;
	
	private String imapHost;
	private int imapPort;
	private String username;
	private String password;
	private String mailStoreProtocol;
	private String securedConnection;
	
	private String smtpPort;
	private String auth;
	private boolean starttls;
	private String smtpHost;
	
	private boolean enabled;
	
	private boolean ocrEnabled;
	private String ocrProfile;
	
	private List<String> supportedFileTypes;
	
	// max file size in MB
	private int maxFileSize;
	
	private boolean autoReply;
	private boolean npoLines;
	private String accessToken;
	private String refreshToken;
	private long expiresIn;
	private ZonedDateTime lastUpdated;
	private String authType;
	private String dataObject;
	
	/*
	 * private String companyCode; private String requestorType; private String
	 * requestorTypeRegex;
	 */
	
	
	private String npoInvoiceType;
	private String poInvoiceType;
	private List<EmailChannelField> fieldsConfig;
	
	
	public EmailChannels() {
		
	}
	
	public EmailChannels(String username,String accessToken, String refreshToken, long expiresIn,
			ZonedDateTime lastUpdated, String authType,String imapHost,int imapPort,String mailStoreProtocol,String securedConnection,boolean starttls,String smtpHost,String smtpPort) {
		super();
		this.username = username;
		this.accessToken = accessToken;
		this.refreshToken = refreshToken;
		this.expiresIn = expiresIn;
		this.lastUpdated = lastUpdated;
		this.authType = authType;
		this.imapHost = imapHost;
		this.imapPort = imapPort;
		this.mailStoreProtocol = mailStoreProtocol;
		this.securedConnection = securedConnection;
		this.starttls = starttls;
		this.smtpHost = smtpHost;
		this.smtpPort = smtpPort;
	}
	public String getImapHost() {
		return imapHost;
	}
	public void setImapHost(String imapHost) {
		this.imapHost = imapHost;
	}
	
	public int getImapPort() {
		return imapPort;
	}

	public void setImapPort(int imapPort) {
		this.imapPort = imapPort;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMailStoreProtocol() {
		return mailStoreProtocol;
	}
	public void setMailStoreProtocol(String mailStoreProtocol) {
		this.mailStoreProtocol = mailStoreProtocol;
	}
	public String getSecuredConnection() {
		return securedConnection;
	}
	public void setSecuredConnection(String securedConnection) {
		this.securedConnection = securedConnection;
	}
	public String getSmtpPort() {
		return smtpPort;
	}
	public void setSmtpPort(String smtpPort) {
		this.smtpPort = smtpPort;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public boolean isStarttls() {
		return starttls;
	}
	
	
	

	

	public String getDataObject() {
		return dataObject;
	}

	public void setDataObject(String dataObject) {
		this.dataObject = dataObject;
	}

	public void setStarttls(boolean starttls) {
		this.starttls = starttls;
	}
	public String getSmtpHost() {
		return smtpHost;
	}
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public boolean isOcrEnabled() {
		return ocrEnabled;
	}
	public void setOcrEnabled(boolean ocrEnabled) {
		this.ocrEnabled = ocrEnabled;
	}
	 
	public List<EmailChannelField> getFieldsConfig() {
		return fieldsConfig;
	}
	public void setFieldsConfig(List<EmailChannelField> fieldsConfig) {
		this.fieldsConfig = fieldsConfig;
	}
	public List<String> getSupportedFileTypes() {
		return supportedFileTypes;
	}
	public void setSupportedFileTypes(List<String> supportedFileTypes) {
		this.supportedFileTypes = supportedFileTypes;
	}
	public int getMaxFileSize() {
		return maxFileSize;
	}
	public void setMaxFileSize(int maxFileSize) {
		this.maxFileSize = maxFileSize;
	}
	public boolean isAutoReply() {
		return autoReply;
	}
	public void setAutoReply(boolean autoReply) {
		this.autoReply = autoReply;
	}
	public boolean isNpoLines() {
		return npoLines;
	}
	public void setNpoLines(boolean npoLines) {
		this.npoLines = npoLines;
	}
	public String getNpoInvoiceType() {
		return npoInvoiceType;
	}
	public void setNpoInvoiceType(String npoInvoiceType) {
		this.npoInvoiceType = npoInvoiceType;
	}
	public String getPoInvoiceType() {
		return poInvoiceType;
	}
	public void setPoInvoiceType(String poInvoiceType) {
		this.poInvoiceType = poInvoiceType;
	}
	public String getOcrProfile() {
		return ocrProfile;
	}
	public void setOcrProfile(String ocrProfile) {
		this.ocrProfile = ocrProfile;
	}
	
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public long getExpiresIn() {
		return expiresIn;
	}
	public void setExpiresIn(long expiresIn) {
		this.expiresIn = expiresIn;
	}
	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	
	public String getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	public static String getReqtypesubject() {
		return REQTYPESUBJECT;
	}
	
	
}
