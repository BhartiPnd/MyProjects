package com.ssp.mongo.collections.admin;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ExportProfileCriateria;
import com.ssp.mongo.collectionhelpers.ExportProfileFtpConfig;

@Document(collection = "ExportProfile")
public class ExportProfile {

	@Id
    private String id;
	
    private String name;
    private String dataObject;
    
    private boolean status;
    private List<ExportProfileCriateria> criateria;
    private  ExportProfileFtpConfig targetConfig;
    private  boolean includeAttachments;
    private  boolean includeLogs;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDataObject() {
		return dataObject;
	}
	public void setDataObject(String dataObject) {
		this.dataObject = dataObject;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public List<ExportProfileCriateria> getCriateria() {
		return criateria;
	}
	public void setCriateria(List<ExportProfileCriateria> criateria) {
		this.criateria = criateria;
	}
	public ExportProfileFtpConfig getTargetConfig() {
		return targetConfig;
	}
	public void setTargetConfig(ExportProfileFtpConfig targetConfig) {
		this.targetConfig = targetConfig;
	}
	public boolean isIncludeAttachments() {
		return includeAttachments;
	}
	public void setIncludeAttachments(boolean includeAttachments) {
		this.includeAttachments = includeAttachments;
	}
	public boolean isIncludeLogs() {
		return includeLogs;
	}
	public void setIncludeLogs(boolean includeLogs) {
		this.includeLogs = includeLogs;
	}
    
    
    
}
