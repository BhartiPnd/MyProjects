package com.ssp.mongo.collectionhelpers;

public class EmailAccountConfiguration {

}
