package com.ssp.mongo.collections;

public class RFxQandA {

	private Integer sequence;
	private String question;
	private String answer;
	
	public RFxQandA() {
		super();
	}
	public RFxQandA(Integer sequence, String question, String answer) {
		super();
		this.sequence = sequence;
		this.question = question;
		this.answer = answer;
	}
	
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	@Override
	public String toString() {
		return "RFxQandA [sequence=" + sequence + ", question=" + question + ", answer=" + answer + "]";
	}
}
