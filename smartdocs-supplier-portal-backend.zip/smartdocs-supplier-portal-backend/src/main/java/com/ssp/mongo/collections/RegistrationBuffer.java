//package com.ssp.mongo.collections;
//
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
//@Document(collection = "registration_buffer")
//public class RegistrationBuffer {
//
//	@Id
//	private String uuid;
//	private String channelid;
//	private String channel;
//	
//	public String getUuid() {
//		return uuid;
//	}
//	public void setUuid(String uuid) {
//		this.uuid = uuid;
//	}
//	
//	public String getChannel() {
//		return channel;
//	}
//	public void setChannel(String channel) {
//		this.channel = channel;
//	}
//	public String getChannelid() {
//		return channelid;
//	}
//	public void setChannelid(String channelid) {
//		this.channelid = channelid;
//	}
//	public RegistrationBuffer(String uuid, String channelid, String channel) {
//		super();
//		this.uuid = uuid;
//		this.channelid = channelid;
//		this.channel = channel;
//	}
//	public RegistrationBuffer() {
//		super();
//	}
//	public RegistrationBuffer(String externalId, String generateResetKey) {
//	}
//}
