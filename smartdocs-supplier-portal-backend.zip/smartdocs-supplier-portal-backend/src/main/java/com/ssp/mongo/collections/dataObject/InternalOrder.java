package com.ssp.mongo.collections.dataObject;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "InternalOrder")
public class InternalOrder {

	
	@Id
	private String ioNumber;
	private String description;
	private String date;
	private String ccode;
	private String plant;
	private String barea;
	private String carea;
	private String status;
	
	public InternalOrder() {
		
	}
	 

	public String getIoNumber() {
		return ioNumber;
	}

	public void setIoNumber(String ioNumber) {
		this.ioNumber = ioNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCcode() {
		return ccode;
	}

	public void setCcode(String ccode) {
		this.ccode = ccode;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getBarea() {
		return barea;
	}

	public void setBarea(String barea) {
		this.barea = barea;
	}

	public String getCarea() {
		return carea;
	}

	public void setCarea(String carea) {
		this.carea = carea;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	 
	
}

 