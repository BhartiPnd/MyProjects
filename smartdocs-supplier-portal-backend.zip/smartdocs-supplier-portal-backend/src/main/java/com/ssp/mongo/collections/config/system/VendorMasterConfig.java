package com.ssp.mongo.collections.config.system;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "SystemConfiguration")
public class VendorMasterConfig {
	public static final String VENDOR_CONFIG = "vendor_config";
	
	@Id
	private String id;

	private boolean website;
	
	private boolean ecom;
	
	private boolean rating;
	
	private boolean vendorMasterDocument;
	private boolean uploadVendorMasterDocument;
	
	private boolean products;
	private boolean businessEntities;
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isWebsite() {
		return website;
	}

	public boolean isEcom() {
		return ecom;
	}

	public boolean isRating() {
		return rating;
	}

	public boolean isVendorMasterDocument() {
		return vendorMasterDocument;
	}

	public boolean isProducts() {
		return products;
	}

	public void setWebsite(boolean website) {
		this.website = website;
	}

	public void setEcom(boolean ecom) {
		this.ecom = ecom;
	}

	public void setRating(boolean rating) {
		this.rating = rating;
	}

	public void setVendorMasterDocument(boolean vendorMasterDocument) {
		this.vendorMasterDocument = vendorMasterDocument;
	}

	public void setProducts(boolean products) {
		this.products = products;
	}

	public boolean isUploadVendorMasterDocument() {
		return uploadVendorMasterDocument;
	}

	public void setUploadVendorMasterDocument(boolean uploadVendorMasterDocument) {
		this.uploadVendorMasterDocument = uploadVendorMasterDocument;
	}

	public boolean isBusinessEntities() {
		return businessEntities;
	}

	public void setBusinessEntities(boolean businessEntities) {
		this.businessEntities = businessEntities;
	}
	
	
}
