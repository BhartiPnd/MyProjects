package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;


public class PRItemHelper {

	private Integer line;
	private String materialCode;
	private String materialDesc;
	private Double qty;
	private Double unitPrice;
	private Double netValue;
	private String perUOM;
	private Long per;
	
	private String uom;
	private String plant;
	private String plantDesc;
	private String storageLocation;
	private String storageLocationDesc;
	private String supplierPartNumber;
	private String supplierId;
	private String supplierName;
	private String requestor;
	private ZonedDateTime deliveryDate;
	private Address shipToAddress;
	
	
	public Integer getLine() {
		return line;
	}
	public void setLine(Integer line) {
		this.line = line;
	}
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public Double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Double getNetValue() {
		return netValue;
	}
	public void setNetValue(Double netValue) {
		this.netValue = netValue;
	}
	public String getPerUOM() {
		return perUOM;
	}
	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	public Long getPer() {
		return per;
	}
	public void setPer(Long per) {
		this.per = per;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public String getSupplierPartNumber() {
		return supplierPartNumber;
	}
	public void setSupplierPartNumber(String supplierPartNumber) {
		this.supplierPartNumber = supplierPartNumber;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public Address getShipToAddress() {
		return shipToAddress;
	}
	public void setShipToAddress(Address shipToAddress) {
		this.shipToAddress = shipToAddress;
	}
	public String getPlantDesc() {
		return plantDesc;
	}
	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}
	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}
	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	
}
