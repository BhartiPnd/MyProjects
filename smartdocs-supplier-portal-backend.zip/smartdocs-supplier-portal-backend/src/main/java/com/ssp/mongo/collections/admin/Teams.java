package com.ssp.mongo.collections.admin;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.CustomSelector;

@Document(collection = "Teams")
public class Teams {

	@Id
    private String id;
	
    private String teamName;
    private CustomSelector companyCode;
    private CustomSelector plant;
    private CustomSelector grade;
    private CustomSelector department;
    
    private String role;
    
	public String getId() {
		return id;
	}
	public String getTeamName() {
		return teamName;
	}
	public CustomSelector getCompanyCode() {
		return companyCode;
	}
	public CustomSelector getPlant() {
		return plant;
	}
	public CustomSelector getGrade() {
		return grade;
	}
	public CustomSelector getDepartment() {
		return department;
	}
	public String getRole() {
		return role;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public void setCompanyCode(CustomSelector companyCode) {
		this.companyCode = companyCode;
	}
	public void setPlant(CustomSelector plant) {
		this.plant = plant;
	}
	public void setGrade(CustomSelector grade) {
		this.grade = grade;
	}
	public void setDepartment(CustomSelector department) {
		this.department = department;
	}
	public void setRole(String role) {
		this.role = role;
	}
    
    
	
	
	
}
