package com.ssp.mongo.collections.smartbuy;

import com.ssp.dto.rfx.RfxView;
import com.ssp.mongo.collections.workflow.WorkItem;
import com.ssp.mongo.util.JsonResponse;

public class RfxRequestInboxDetail {
	
	private RfxView rfx;
	private WorkItem workItem;
	private String status;
	private String error;
	
	public RfxRequestInboxDetail() {
		super();
		this.status = JsonResponse.RESULT_SUCCESS;
	}

	public RfxView getRfx() {
		return rfx;
	}

	public void setRfx(RfxView rfx) {
		this.rfx = rfx;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
	
	
}
