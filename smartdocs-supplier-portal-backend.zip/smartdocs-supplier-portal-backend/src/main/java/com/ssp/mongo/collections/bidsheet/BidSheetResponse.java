package com.ssp.mongo.collections.bidsheet;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.AuditTrackingLog;

@Document(collection = "BidSheetResponse")
public class BidSheetResponse {

	public static final String STATUS_REVIEWED = "REVIEWED";
	public static final String STATUS_INPROCESS = "INPROCESS";
	public static final String STATUS_OBSOLETE = "OBSOLETE";
	public static final String STATUS_ERROR = "ERROR";
	
	@Id
	private String txId;
	private String bidSheetId;
	private String pirNo;
	private String requestorName;
	private String requestorEmail;
	private String vendorId;
	private String vendorName;
	private String companyCode;
	private String companyName;
	private String purchasingOrg;
	private String purchasingOrgDesc;
	private String fromEmail;
	private String status;
	private String subject;
	private String plant;
	private String purchasingGrp;
	private String purchasingGrpDesc;
	//private long erpSyncedDate;
	
	private ZonedDateTime receivedDate;
	
	private List<AuditTrackingLog> logs;
	private List<DocumentHelper> attachment;
	private int noOfErrors;
	private List<String> errors;
	
	private boolean syncToErp;
	private boolean erpSynced;
	
	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getBidSheetId() {
		return bidSheetId;
	}

	public void setBidSheetId(String bidSheetId) {
		this.bidSheetId = bidSheetId;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

//	public long getErpSyncedDate() {
//		return erpSyncedDate;
//	}
//
//	public void setErpSyncedDate(long erpSyncedDate) {
//		this.erpSyncedDate = erpSyncedDate;
//	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public List<DocumentHelper> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<DocumentHelper> attachment) {
		this.attachment = attachment;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public ZonedDateTime getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(ZonedDateTime receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<AuditTrackingLog> getLogs() {
		return logs;
	}

	public void setLogs(List<AuditTrackingLog> logs) {
		this.logs = logs;
	}

	public String getPirNo() {
		return pirNo;
	}

	public void setPirNo(String pirNo) {
		this.pirNo = pirNo;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public boolean isSyncToErp() {
		return syncToErp;
	}

	public void setSyncToErp(boolean syncToErp) {
		this.syncToErp = syncToErp;
	}

	public boolean isErpSynced() {
		return erpSynced;
	}

	public void setErpSynced(boolean erpSynced) {
		this.erpSynced = erpSynced;
	}	 
	
	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPurchasingGrp() {
		return purchasingGrp;
	}

	public void setPurchasingGrp(String purchasingGrp) {
		this.purchasingGrp = purchasingGrp;
	}

	public String getPurchasingGrpDesc() {
		return purchasingGrpDesc;
	}

	public void setPurchasingGrpDesc(String purchasingGrpDesc) {
		this.purchasingGrpDesc = purchasingGrpDesc;
	}

	public int getNoOfErrors() {
		return noOfErrors;
	}

	public void setNoOfErrors(int noOfErrors) {
		this.noOfErrors = noOfErrors;
	}
	
	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
	

}
