package com.ssp.mongo.collections.diversitySpend;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "DBCommitmentSheet")
public class DBCommitmentSheet {

	@Id
	private String id;
	
	private String contractId;
	private DBCommitment commitment;
	private List<DBCommitment> commitmentChangeHistory;
	
	
	
	public DBCommitment getCommitment() {
		return commitment;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<DBCommitment> getCommitmentChangeHistory() {
		return commitmentChangeHistory;
	}

	public void setCommitment(DBCommitment commitment) {
		this.commitment = commitment;
	}

	public void setCommitmentChangeHistory(List<DBCommitment> commitmentChangeHistory) {
		this.commitmentChangeHistory = commitmentChangeHistory;
	}

	public String getContractId() {
		return contractId;
	}
	
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	 
	
}
