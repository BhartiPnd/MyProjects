package com.ssp.mongo.collectionhelpers;

public class AgentCompanyConfig {

	private String user;
	private String companyCode;
	private String purchasingOrg;
	
	private String country;
	private String department;
	private String businessUnit;
	
	private String plant;
	private String division;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getCountry() {
		return country;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public String getDepartment() {
		return department;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPlant() {
		return plant;
	}
	public String getDivision() {
		return division;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
	
	
	
}
