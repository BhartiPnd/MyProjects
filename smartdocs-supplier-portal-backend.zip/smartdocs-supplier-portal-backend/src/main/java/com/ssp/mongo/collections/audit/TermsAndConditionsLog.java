package com.ssp.mongo.collections.audit;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "TermsAndConditionsLog")
public class TermsAndConditionsLog {

	
	@Id
	private String id;
	
	private String user;
	
	private String version;
	
	private String ip;
	
	private String supplierId;
	
	private ZonedDateTime zonedDateTime;
	
	private boolean currentVersion;
	
	public TermsAndConditionsLog() {
		super();
	}
	public TermsAndConditionsLog(String user, String version, String ip,String supplierId) {
		super();
		this.id = user+version+supplierId;
		this.user = user;
		this.version = version;
		this.ip = ip;
		this.zonedDateTime = ZonedDateTime.now();
		this.supplierId=supplierId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public ZonedDateTime getZonedDateTime() {
		return zonedDateTime;
	}
	public void setZonedDateTime(ZonedDateTime zonedDateTime) {
		this.zonedDateTime = zonedDateTime;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public boolean isCurrentVersion() {
		return currentVersion;
	}
	public void setCurrentVersion(boolean currentVersion) {
		this.currentVersion = currentVersion;
	}
	
	
	
}
