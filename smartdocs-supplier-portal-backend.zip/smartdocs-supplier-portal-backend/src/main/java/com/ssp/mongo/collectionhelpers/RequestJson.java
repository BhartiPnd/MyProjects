package com.ssp.mongo.collectionhelpers;

import java.util.List;
import java.util.Map;

import com.ssp.mongo.collections.RequestAttachment;



public class RequestJson {
	private String docType;
	private String description;
	private Map<String,String> header;
	private Map<Integer,Map<String,String>> lineItems;
	private List<RequestAttachment> attachments;
	
	
	
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, String> getHeader() {
		return header;
	}
	public void setHeader(Map<String, String> header) {
		this.header = header;
	}
	public Map<Integer, Map<String, String>> getLineItems() {
		return lineItems;
	}
	public void setLineItems(Map<Integer, Map<String, String>> lineItems) {
		this.lineItems = lineItems;
	}
	public List<RequestAttachment> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<RequestAttachment> attachments) {
		this.attachments = attachments;
	}
	

}
