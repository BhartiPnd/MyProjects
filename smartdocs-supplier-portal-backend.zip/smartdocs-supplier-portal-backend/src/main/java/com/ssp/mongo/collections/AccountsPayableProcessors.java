package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "APProcessors")
public class AccountsPayableProcessors {
	
	@Id
	public String id;
	public String user;
	public String companyCode;
	
	public AccountsPayableProcessors() {
		super();
	}
	public AccountsPayableProcessors(String user, String companyCode) {
		super();
		this.id=companyCode+"_"+user;
		this.user = user;
		this.companyCode = companyCode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	
	
}
