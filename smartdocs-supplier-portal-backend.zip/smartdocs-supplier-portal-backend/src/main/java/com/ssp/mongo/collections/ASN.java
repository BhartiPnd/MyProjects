package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.CommentLog;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.Item;
import com.ssp.mongo.collectionhelpers.ProofOfDocument;

@Document(collection = "asn")
public class ASN {

	public static final String CUSTOMER_ACTION_STATUS_NEW="NEW";
	public static final String CUSTOMER_ACTION_STATUS_APPROVED="APPROVED";
	public static final String CUSTOMER_ACTION_STATUS_REJECTED="REJECTED";
	
	@Id
	private String id;
	private String asnreference;
	private long refId;
	private Long systemid;
	private String ponumber;
	private Double amount;
	private String currency;
	private String companycode;
	private ZonedDateTime shipmentdate;
	private Address  remittoaddress;
	private  Address  shiptoaddress;
	
	private String status;
	private String notes;
	private List<Item> items;

	private String requestId;
	private List<DocumentHelper> attachments;

	private ZonedDateTime createddatetime;
	private ZonedDateTime modifieddatetime;

	private String creator;
    private ZonedDateTime date;

	private Boolean isSAPSynch;
	private ZonedDateTime sapSynchDate;
	private Boolean isSAPSynchACK;

	private String supplierId;
	private String channel;
	private String customerActionStatus;
	private String customerActionUser;
	private Long customerActionDate;	

	
	private Boolean isPOD;
	private List<ProofOfDocument> proofOfDocuments;
	 
	private List<CommentLog> commentLog;
	private String statusDesc;
	private List<ActivityLog> activityLogs;
	private boolean deleted;
	
	private String containerNumber;

	public ASN() {
		super();
	}	
	public ASN(ZonedDateTime shipmentdate,String companycode,String headerText, Address remittoaddress, Address shiptoaddress,String id, String asnreference, Long systemid, String ponumber,
			Double amount, String currency, String notes, List<Item> items, String creator, ZonedDateTime date, List<DocumentHelper> attachments, List<ProofOfDocument> proofOfDocuments) {
		super();
		this.shipmentdate = shipmentdate;
		this.companycode = companycode;
		this.remittoaddress = remittoaddress;
		this.shiptoaddress = shiptoaddress;
		this.id = id;
		this.asnreference = asnreference;
		this.systemid = systemid;
		this.ponumber = ponumber;
		this.amount = amount;
		this.currency = currency;
		this.notes = notes;
		this.items = items;
		this.creator = creator;
		this.date = date;
		this.attachments = attachments;
		this.proofOfDocuments = proofOfDocuments;
		
	}
	
	public ZonedDateTime getShipmentdate() {
		return shipmentdate;
	}

	public void setShipmentdate(ZonedDateTime shipmentdate) {
		this.shipmentdate = shipmentdate;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	
	public Address getRemittoaddress() {
		return remittoaddress;
	}

	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}

	public Address getShiptoaddress() {
		return shiptoaddress;
	}

	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAsnreference() {
		return asnreference;
	}

	public void setAsnreference(String asnreference) {
		this.asnreference = asnreference;
	}

	public Long getSystemid() {
		return systemid;
	}

	public void setSystemid(Long systemid) {
		this.systemid = systemid;
	}

	public String getPonumber() {
		return ponumber;
	}

	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public ZonedDateTime getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(ZonedDateTime createddatetime) {
		this.createddatetime = createddatetime;
	}

	public ZonedDateTime getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(ZonedDateTime modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public ZonedDateTime getDate() {
		return date;
	}

	public void setDate(ZonedDateTime date) {
		this.date = date;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public ZonedDateTime getSapSynchDate() {
		return sapSynchDate;
	}

	public void setSapSynchDate(ZonedDateTime sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getCustomerActionStatus() {
		return customerActionStatus;
	}
	
	public void setCustomerActionStatus(String customerActionStatus) {
		this.customerActionStatus = customerActionStatus;
	}
	public String getCustomerActionUser() {
		return customerActionUser;
	}
	
	public void setCustomerActionUser(String customerActionUser) {
		this.customerActionUser = customerActionUser;
	}
	public Long getCustomerActionDate() {
		return customerActionDate;
	}
	public void setCustomerActionDate(Long customerActionDate) {
		this.customerActionDate = customerActionDate;
	}
	
	public List<ProofOfDocument> getProofOfDocuments() {
		return proofOfDocuments;
	}
	public void setProofOfDocuments(List<ProofOfDocument> proofOfDocuments) {
		this.proofOfDocuments = proofOfDocuments;
	}
	public Boolean getIsPOD() {
		return isPOD;
	}
	public void setIsPOD(Boolean isPOD) {
		this.isPOD = isPOD;
	}
	public void addCommentLogs(String commentLogs,String userId) {
		if((commentLogs!=null && !commentLogs.trim().equals(""))) {
			if(this.getCommentLog()==null){
				this.setCommentLog(new ArrayList<>());
			}
			this.getCommentLog().add(new CommentLog(false,commentLogs,userId));
		}
	
	}
	public void addCommentLogs(boolean workFlow,String commentLogs,String userId,String oldStatus,String newStatus) {
		if(workFlow || (commentLogs!=null && !commentLogs.trim().equals(""))) {
			if(this.getCommentLog()==null){
				this.setCommentLog(new ArrayList<>());
			}
			this.getCommentLog().add(new CommentLog(workFlow,commentLogs,userId,oldStatus,newStatus));
		}
	}
	 
	public List<CommentLog> getCommentLog() {
		return commentLog;
	}
	public void setCommentLog(List<CommentLog> commentLog) {
		this.commentLog = commentLog;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}	
	
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	public void addActivityLogs(ActivityLog activityLog) {
		if (this.getActivityLogs() == null) {
			this.setActivityLogs(new ArrayList<>());
		}
		if (this.getActivityLogs().size() > 1) {
			ActivityLog activityLog2 = this.activityLogs.get(this.getActivityLogs().size() - 1);
			if (activityLog.getStep() == activityLog2.getStep()) {
				activityLog.setSeq(activityLog2.getSeq() + 1);
			}
		}

		this.getActivityLogs().add(activityLog);
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getContainerNumber() {
		return containerNumber;
	}
	public void setContainerNumber(String containerNumber) {
		this.containerNumber = containerNumber;
	}
	
	
	
}
