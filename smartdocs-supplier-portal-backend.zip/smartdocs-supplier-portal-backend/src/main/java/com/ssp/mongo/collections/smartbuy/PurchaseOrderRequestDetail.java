package com.ssp.mongo.collections.smartbuy;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.Agent;
import com.ssp.mongo.collections.ticket.Ticket;
import com.ssp.mongo.collections.workflow.WorkItem;

@Document(collection = "PurchaseOrderReq")
public class PurchaseOrderRequestDetail {

	@Id
	private String id;
	private String requestId;
	private String type;
	private String typeDesc;
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	
	private String requestorEmail;
	private Double amount;
	private String currency;
	private String supplierId;
	private ZonedDateTime createdDate;
	private String status;
	private String createdBy;
	private String plant;
	private String storageLocaion;
	private List<DocumentHelper> attachments;
	private List<PurchaseOrderRequestLine> requestItems;
	
	private Boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private Boolean isSAPSynchACK;
	private String agentName;
	private Double totalAmount;
	
	private String poNumber;
	private String company;
	private String purchasingGroupDesc;
	private String purchasingOrgDesc;
	private String paymentTermsDesc;
	private String requestor;
	private String supplier;
	private Address supplierAddress;
	private String prrRequestId;
	private WorkItem workItem;
	private List<Ticket> tickets;
	private String headerText;//newly added field 
	public PurchaseOrderRequestDetail() {
		super();
	}
	 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStorageLocaion() {
		return storageLocaion;
	}
	public void setStorageLocaion(String storageLocaion) {
		this.storageLocaion = storageLocaion;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}
	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public List<PurchaseOrderRequestLine> getRequestItems() {
		return requestItems;
	}
	public void setRequestItems(List<PurchaseOrderRequestLine> requestItems) {
		this.requestItems = requestItems;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getPaymentTermsDesc() {
		return paymentTermsDesc;
	}

	public void setPaymentTermsDesc(String paymentTermsDesc) {
		this.paymentTermsDesc = paymentTermsDesc;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public Address getSupplierAddress() {
		return supplierAddress;
	}

	public void setSupplierAddress(Address supplierAddress) {
		this.supplierAddress = supplierAddress;
	}

	public String getPrrRequestId() {
		return prrRequestId;
	}

	public void setPrrRequestId(String prrRequestId) {
		this.prrRequestId = prrRequestId;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getHeaderText() {
		return headerText;
	}

	public void setHeaderText(String headerText) {
		this.headerText = headerText;
	}
	
}
