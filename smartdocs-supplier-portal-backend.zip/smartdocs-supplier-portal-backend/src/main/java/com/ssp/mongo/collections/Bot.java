package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "bot")
public class Bot {
	
	@Id
	private String id;
	private String name;
	private String botId;
	private String synapseUrl;
	 
	
	public Bot() {
		super();
	}
	 
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getBotId() {
		return botId;
	}


	public void setBotId(String botId) {
		this.botId = botId;
	}


	public String getSynapseUrl() {
		return synapseUrl;
	}


	public void setSynapseUrl(String synapseUrl) {
		this.synapseUrl = synapseUrl;
	}


	 
	 
	 
	 
 
}
