package com.ssp.mongo.collectionhelpers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

public class LineItems {

	private String ponumber;

	private String poLineNumber;
	private String materialCode;
	private String materialGroup;
	private String materialDescription;
	private Double quantity;
	private String unitofmeasure;
	private String supplierPartNo;
	private String plant;
	private String plantDesc;
	private String storageLocation;
	private String storageLocationDesc;

	private double unitPrice;
	private double invUnitPrice;
	private double discountamount;
	private double netAmount;
	private double tax;
	private double taxPercent;
	private double subTotal;
	private double total;

	private ZonedDateTime deliveryDate;

	private Address shipToAddress;

	private String glAccountCode;
	private String glAccountDesc;
	private String costCenter;
	private String costCenterDesc;
	private String wbsElement;
	private String wbsElementDesc;
	private String datesOfService;
	private String itemText;
	private String fundNumber;
	
	private String assetCode;
	private String companyCode;
	private String companyCodeDesc;
	private String orderNumber;
	
	private Long per;
	private String perUOM;
	private String ioOrder;
	private Double grQuantity;
	private String unitOfMeasureDesc;
	
	
	private String lineNumber;
	private String debitOrCreditIndicator;
	private String assignmentNumber;
	private String text;
	private String taxCode;
	private String taxJurisdiction;
	private String segment;
	private String salesOrder;
	private String materialNumber;
	private String profitCenter;
	private boolean matched;
	
	private String tradingPartner;
	private String tradingPartnerDesc;
	
	public String getPonumber() {
		return ponumber;
	}

	public String getPoLineNumber() {
		return poLineNumber;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public String getMaterialGroup() {
		return materialGroup;
	}

	public String getMaterialDescription() {
		return materialDescription;
	}

	public Double getQuantity() {
		return quantity;
	}

	public String getUnitofmeasure() {
		return unitofmeasure;
	}

	public String getSupplierPartNo() {
		return supplierPartNo;
	}

	public String getPlant() {
		return plant;
	}

	public String getStorageLocation() {
		return storageLocation;
	}

	 

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public Address getShipToAddress() {
		return shipToAddress;
	}

	public String getGlAccountCode() {
		return glAccountCode;
	}

	public String getGlAccountDesc() {
		return glAccountDesc;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public String getCostCenterDesc() {
		return costCenterDesc;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public String getWbsElementDesc() {
		return wbsElementDesc;
	}

	public String getIoOrder() {
		return ioOrder;
	}

	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}

	public void setPoLineNumber(String poLineNumber) {
		this.poLineNumber = poLineNumber;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}

	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public void setUnitofmeasure(String unitofmeasure) {
		this.unitofmeasure = unitofmeasure;
	}

	public void setSupplierPartNo(String supplierPartNo) {
		this.supplierPartNo = supplierPartNo;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}

	 

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public void setShipToAddress(Address shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public void setGlAccountCode(String glAccountCode) {
		this.glAccountCode = glAccountCode;
	}

	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public void setWbsElementDesc(String wbsElementDesc) {
		this.wbsElementDesc = wbsElementDesc;
	}

	public void setIoOrder(String ioOrder) {
		this.ioOrder = ioOrder;
	}

	 
	public String getDatesOfService() {
		return datesOfService;
	}

	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}

	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}

	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}

	public String getItemText() {
		return itemText;
	}

	public void setItemText(String itemText) {
		this.itemText = itemText;
	}

	public Double getGrQuantity() {
		return grQuantity;
	}

	public void setGrQuantity(Double grQuantity) {
		this.grQuantity = grQuantity;
	}

	public String getUnitOfMeasureDesc() {
		return unitOfMeasureDesc;
	}

	public void setUnitOfMeasureDesc(String unitOfMeasureDesc) {
		this.unitOfMeasureDesc = unitOfMeasureDesc;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

 

	public String getFundNumber() {
		return fundNumber;
	}

	public void setFundNumber(String fundNumber) {
		this.fundNumber = fundNumber;
	}

	public Long getPer() {
		return per;
	}

	public void setPer(Long per) {
		this.per = per;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getInvUnitPrice() {
		return invUnitPrice;
	}

	public void setInvUnitPrice(double invUnitPrice) {
		this.invUnitPrice = invUnitPrice;
	}

	public double getDiscountamount() {
		return discountamount;
	}

	public void setDiscountamount(double discountamount) {
		this.discountamount = discountamount;
	}



	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public double getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(double taxPercent) {
		this.taxPercent = taxPercent;
	}
 
	
	public double getNetAmount() {
		return netAmount;
	}

	private void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public double getSubTotal() {
		return subTotal;
	}

	private void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public void reCalculate(boolean isPO, List<UomPriceFactor> factors, String perUom) {
		this.setPer((this.getPer()==null ||this.getPer()<0) ?1:this.getPer());
		if(isPO) {
			if (perUom != null && StringUtils.isBlank(this.getPerUOM())) {
				this.perUOM = perUom;
			}
			if (StringUtils.isNotBlank(this.getPerUOM())) {
				Double selectedUomPF = getPriceFactor(factors, this.getUnitofmeasure());
				Double perUomPF = getPriceFactor(factors, this.getPerUOM());
				this.subTotal = BigDecimal.valueOf(((this.getQuantity()==null?0:this.getQuantity()) * (this.getInvUnitPrice()) * (selectedUomPF == null ? 1 : selectedUomPF))/(this.getPer() * (perUomPF == null ? 1 : perUomPF))).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
			}
			
			if (StringUtils.isBlank(this.getPerUOM())) {
				this.subTotal = BigDecimal.valueOf((this.getQuantity()==null?0:this.getQuantity())*(this.getInvUnitPrice())/this.getPer()).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
			}
			
		}
		else {
			this.subTotal = BigDecimal.valueOf((this.getQuantity()==null?0:this.getQuantity())*(this.getUnitPrice()==null?0:this.getUnitPrice())/this.getPer()).setScale(2, RoundingMode.HALF_EVEN).doubleValue();
		}
		//this.subTotal   = new BigDecimal((this.getQuantity()==null?0:this.getQuantity())*(this.getUnitPrice()==null?0:this.getUnitPrice())).setScale(2, BigDecimal.ROUND_HALF_EVEN).doubleValue();
		//this.subTotal=(this.getQuantity()==null?0:this.getQuantity())*(this.getUnitPrice()==null?0:this.getUnitPrice());
		this.total=this.getSubTotal()-this.getDiscountamount();
		this.netAmount=this.getTotal()+this.getTax();
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getDebitOrCreditIndicator() {
		return debitOrCreditIndicator;
	}

	public void setDebitOrCreditIndicator(String debitOrCreditIndicator) {
		this.debitOrCreditIndicator = debitOrCreditIndicator;
	}

	public String getAssignmentNumber() {
		return assignmentNumber;
	}

	public void setAssignmentNumber(String assignmentNumber) {
		this.assignmentNumber = assignmentNumber;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getTaxJurisdiction() {
		return taxJurisdiction;
	}

	public void setTaxJurisdiction(String taxJurisdiction) {
		this.taxJurisdiction = taxJurisdiction;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getSalesOrder() {
		return salesOrder;
	}

	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	public String getMaterialNumber() {
		return materialNumber;
	}

	public void setMaterialNumber(String materialNumber) {
		this.materialNumber = materialNumber;
	}

	public String getProfitCenter() {
		return profitCenter;
	}

	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getCompanyCodeDesc() {
		return companyCodeDesc;
	}

	public void setCompanyCodeDesc(String companyCodeDesc) {
		this.companyCodeDesc = companyCodeDesc;
	}

	public boolean isMatched() {
		return matched;
	}

	public void setMatched(boolean matched) {
		this.matched = matched;
	}

	public String getTradingPartner() {
		return tradingPartner;
	}

	public void setTradingPartner(String tradingPartner) {
		this.tradingPartner = tradingPartner;
	}

	public String getTradingPartnerDesc() {
		return tradingPartnerDesc;
	}

	public void setTradingPartnerDesc(String tradingPartnerDesc) {
		this.tradingPartnerDesc = tradingPartnerDesc;
	}

	public String getPerUOM() {
		return perUOM;
	}

	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	
	private Double getPriceFactor(List<UomPriceFactor> factors, String uom) {
		if (factors != null && !factors.isEmpty()) {
			for (UomPriceFactor uomPFactor : factors) {
				if (uom.equals(uomPFactor.getUom())) {
					return uomPFactor.getcFactor();
				}
			}
		}
		return null;
	}
}
