package com.ssp.mongo.collections.admin;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "SAPSynchStatus")
public class SAPSynchStatus {
	
	public static final String VENDOR_MASTER_ACTIVITY="VENDOR_MASTER";
	public static final String VRR="VRR";
	public static final String VCR="VCR";
	public static final String VMDCR="VMDCR";
	public static final String OA="OA";
	public static final String PO="PO";
	public static final String POR="POR";
	public static final String PRR="PRR";
	public static final String PR="PR";
	public static final String PPO="PPO";
	public static final String COLLABORATE="COLLABORATE";
	public static final String RFX="RFX";
	public static final String BID="BID";
	public static final String INVOICE="INVOICE";
	public static final String CONTRACT="CONTRACT";
	public static final String PAYMENT="PAYMENT";
	public static final String EXPENSE="EXPENSE";
	
	public static final String EMPLOYEE="Employee";
	
	public static final String VENDOR_MASTER_ACTIVITY_SYNCVM="VENDOR_MASTER_SYNCVM";
	public static final String VENDOR_MASTER_INVITE_CONTACT="VENDOR_MASTER_INVITE_CONTACT";
	
	public static final String ACTION="STATUS_ACTION";
	public static final String CHECK_RULE="CHECK_RULE";
	public static final String STATUS_UPDATE="STATUS_UPDATE";
	public static final String SYNC="SYNC";
	public static final String ACK="ACK";

	
	

	
	
	
	
	
	
	
	public static final String STATUS_RECV="recv";
	public static final String STATUS_SENT="sent";

	public static final String INVALID_XML_FORMAT_ERROR="INVALID_XML_FORMAT_ERROR";
	public static final String OK="OK";

	private String type;
	private String subType;
	private String uuid;
	private String status;
	private String activity;
	private String response;
	private Long createdatetime;
	private String error;
	private ZonedDateTime lastUpdated;

	public SAPSynchStatus() {
		super();
		this.lastUpdated=ZonedDateTime.now();
	}

	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(Long createdatetime) {
		this.createdatetime = createdatetime;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	


}
