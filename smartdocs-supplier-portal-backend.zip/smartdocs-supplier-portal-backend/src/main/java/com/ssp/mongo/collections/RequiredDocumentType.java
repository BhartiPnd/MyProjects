package com.ssp.mongo.collections;

import java.util.List;

public class RequiredDocumentType {

	private String id;
	private String type;
	private String description;
	private List<String> supportedFileFormates;
	
	public RequiredDocumentType() {
		super();
	}
	public RequiredDocumentType(String id, String type, String description, List<String> supportedFileFormates) {
		super();
		this.id = id;
		this.type = type;
		this.description = description;
		this.supportedFileFormates = supportedFileFormates;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	 
	@Override
	public String toString() {
		return "RequiredDocumentType [id=" + id + ", type=" + type + ", description=" + description + ", supportedFileFormates=" + supportedFileFormates
				+ "]";
	}
}
