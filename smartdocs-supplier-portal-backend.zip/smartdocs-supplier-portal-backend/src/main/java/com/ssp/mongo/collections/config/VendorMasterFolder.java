package com.ssp.mongo.collections.config;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "VendorMasterFolder")
public class VendorMasterFolder {

	@Id
	private String identifier;

	private String id;
	private String icon;
	private String name;
	private String description;
	private boolean isEnabled;
	private int order;
	
	public String getIdentifier() {
		return identifier;
	}
	public String getId() {
		return id;
	}
	public String getIcon() {
		return icon;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public boolean isEnabled() {
		return isEnabled;
	}
	public int isOrder() {
		return order;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
	
}
