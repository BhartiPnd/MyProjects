package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class ProductCategoriesChangeRequest {
	
	private List<String> deSelectProductCatagories;
	private List<String> newProductCategories;
	public List<String> getDeSelectProductCatagories() {
		return deSelectProductCatagories;
	}
	public void setDeSelectProductCatagories(List<String> deSelectProductCatagories) {
		this.deSelectProductCatagories = deSelectProductCatagories;
	}
	public List<String> getNewProductCategories() {
		return newProductCategories;
	}
	public void setNewProductCategories(List<String> newProductCategories) {
		this.newProductCategories = newProductCategories;
	}
	
	
}
