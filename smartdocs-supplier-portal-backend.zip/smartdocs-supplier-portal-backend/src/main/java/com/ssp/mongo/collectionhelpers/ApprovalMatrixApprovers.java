package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class ApprovalMatrixApprovers {

	private int level;
	private List<String> approvers;
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	
	
	
	
	
	
	
}
