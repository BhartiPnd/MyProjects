package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.Amount;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.ItemUpdate;
import com.ssp.mongo.collectionhelpers.NotificationLog;
import com.ssp.mongo.collectionhelpers.POitmHelper;

@Document(collection = "purchaseorder")
public class PurchaseOrder {

	public static final String STATUS_OPEN = "Open";
	public static final String STATUS_CLOSE = "Closed";

	@Id
	private String id;

	@Field("purchaseOrderNumber")
	private String purchaseOrderNumber;
	@Field("PODesc")
	private String PODesc;

	@Field("companycode")
	private String companyCode;

	@Field("deliverydate")
	private ZonedDateTime deliveryDate;

	@Field("amount")
	private Amount amount;

	@Field("purchasingOrg")
	private String purchasingOrg;

	@Field("purchasingGroup")
	private String purchasingGroup;

	@Field("poType")
	private String poType;

	@Field("poDate")
	private ZonedDateTime poDate;

	@Field("paymentTerms")
	private String paymentTerms;

	@Field("contractNo")
	private String contractNo;

	@Field("buyer")
	private String buyer;

	@Field("status")
	private String status;

	@Field("requestor")
	private String requestor;

	@Field("remittoaddress")
	private List<Address> remitToAddress = null;

	@Field("shiptoaddress")
	private List<Address> shipToAddress = null;

	@Field("supplierId")
	private String supplierId;

	// display only field.
	private String supplierName;

	@Field("notes")
	private String notes;
	
	@Field("headerText")
	private String headerText;

	private List<DocumentHelper> attachments = null;
	private List<DocumentHelper> originalDocuments = null;
	private List<POitmHelper> poitms = null;
	private List<ItemUpdate> itemUpdate = null;

	@Field("isupdate")
	private boolean isUpdate;

	@Field("isUpdateSynchWithSAP")
	private boolean isUpdateSynchWithSAP;

	private String shipmentType;

	private boolean orderAcknowledged;
	private ZonedDateTime orderAcknowledgedDate;
	
	private boolean sapOrderAcknowledged;
	private ZonedDateTime sapOrderAcknowledgedDate;

	private String purchasingOrgDesc;

	private String purchasingGroupDesc;
    
	private String paymentTermsDesc;
	
	private String statusDesc;
	
	private boolean notified;
	
	private String logicalSystem;
	private String taxCode;
	private double taxAmount;
	private boolean syncToAbby;
	private List<NotificationLog> notificationLogs;
	
	
	private ZonedDateTime lastOrderAckDate;
	private ZonedDateTime lastASNDate;
	
	private boolean oaCompleted;
	private boolean asnCompleted;
	private String porRequestId;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPoType() {
		return poType;
	}

	public void setPoType(String poType) {
		this.poType = poType;
	}

	public ZonedDateTime getPoDate() {
		return poDate;
	}

	public void setPoDate(ZonedDateTime poDate) {
		this.poDate = poDate;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public List<Address> getRemitToAddress() {
		return remitToAddress;
	}

	public void setRemitToAddress(List<Address> remitToAddress) {
		this.remitToAddress = remitToAddress;
	}

	public List<Address> getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(List<Address> shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public List<POitmHelper> getPoitms() {
		return poitms;
	}

	public void setPoitms(List<POitmHelper> poitms) {
		this.poitms = poitms;
	}

	public boolean isUpdate() {
		return isUpdate;
	}

	public void setUpdate(boolean isUpdate) {
		this.isUpdate = isUpdate;
	}

	public boolean isUpdateSynchWithSAP() {
		return isUpdateSynchWithSAP;
	}

	public void setUpdateSynchWithSAP(boolean isUpdateSynchWithSAP) {
		this.isUpdateSynchWithSAP = isUpdateSynchWithSAP;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public List<ItemUpdate> getItemUpdate() {
		return itemUpdate;
	}

	public void setItemUpdate(List<ItemUpdate> itemUpdate) {
		this.itemUpdate = itemUpdate;
	}

	public List<DocumentHelper> getOriginalDocuments() {
		return originalDocuments;
	}

	public void setOriginalDocuments(List<DocumentHelper> originalDocuments) {
		this.originalDocuments = originalDocuments;
	}

	public String getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(String shipmentType) {
		this.shipmentType = shipmentType;
	}

	public String getPODesc() {
		return PODesc;
	}

	public void setPODesc(String pODesc) {
		PODesc = pODesc;
	}

	public boolean isOrderAcknowledged() {
		return orderAcknowledged;
	}

	public void setOrderAcknowledged(boolean orderAcknowledged) {
		this.orderAcknowledged = orderAcknowledged;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public ZonedDateTime getOrderAcknowledgedDate() {
		return orderAcknowledgedDate;
	}

	public void setOrderAcknowledgedDate(ZonedDateTime orderAcknowledgedDate) {
		this.orderAcknowledgedDate = orderAcknowledgedDate;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public boolean isSapOrderAcknowledged() {
		return sapOrderAcknowledged;
	}

	public ZonedDateTime getSapOrderAcknowledgedDate() {
		return sapOrderAcknowledgedDate;
	}

	public void setSapOrderAcknowledged(boolean sapOrderAcknowledged) {
		this.sapOrderAcknowledged = sapOrderAcknowledged;
	}

	public void setSapOrderAcknowledgedDate(ZonedDateTime sapOrderAcknowledgedDate) {
		this.sapOrderAcknowledgedDate = sapOrderAcknowledgedDate;
	}

	public boolean isNotified() {
		return notified;
	}

	public void setNotified(boolean notified) {
		this.notified = notified;
	}

	public List<NotificationLog> getNotificationLogs() {
		return notificationLogs;
	}

	public void setNotificationLogs(List<NotificationLog> notificationLogs) {
		this.notificationLogs = notificationLogs;
	}

	public String getLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getPaymentTermsDesc() {
		return paymentTermsDesc;
	}

	public void setPaymentTermsDesc(String paymentTermsDesc) {
		this.paymentTermsDesc = paymentTermsDesc;
	}

	public boolean isSyncToAbby() {
		return syncToAbby;
	}

	public void setSyncToAbby(boolean syncToAbby) {
		this.syncToAbby = syncToAbby;
	}

	public String getHeaderText() {
		return headerText;
	}

	public void setHeaderText(String headerText) {
		this.headerText = headerText;
	}

	public ZonedDateTime getLastOrderAckDate() {
		return lastOrderAckDate;
	}

	public ZonedDateTime getLastASNDate() {
		return lastASNDate;
	}

	public boolean isOaCompleted() {
		return oaCompleted;
	}

	public boolean isAsnCompleted() {
		return asnCompleted;
	}

	public void setLastOrderAckDate(ZonedDateTime lastOrderAckDate) {
		this.lastOrderAckDate = lastOrderAckDate;
	}

	public void setLastASNDate(ZonedDateTime lastASNDate) {
		this.lastASNDate = lastASNDate;
	}

	public void setOaCompleted(boolean oaCompleted) {
		this.oaCompleted = oaCompleted;
	}

	public void setAsnCompleted(boolean asnCompleted) {
		this.asnCompleted = asnCompleted;
	}

	public String getPorRequestId() {
		return porRequestId;
	}

	public void setPorRequestId(String porRequestId) {
		this.porRequestId = porRequestId;
	}
	
}
