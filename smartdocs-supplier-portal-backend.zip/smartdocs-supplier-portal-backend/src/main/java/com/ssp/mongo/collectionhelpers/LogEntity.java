package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class LogEntity {
	
	public static final String LOG_TYPE_USER="USER";
	public static final String LOG_TYPE_SYSTEM="SYSTEM";
	
	public static final int LOG_LEVEl_INFO=0;
	public static final int LOG_LEVEl_WARNING=1;
	public static final int LOG_LEVEl_ERROR=2;
	
	private String comment;
	private String logType;
	private ZonedDateTime dateTime; 
	private String userEmail;
	private Integer level;
	private String ip;
	
	public LogEntity() {
		super();
	}
	public LogEntity(String comment,  String userEmail) {
		super();
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.userEmail = userEmail;
	 
	}
	public LogEntity(String comment, String logType,  String userEmail, String ip,int logLevel) {
		super();
		this.comment = comment;
		this.logType = logType;
		this.dateTime = ZonedDateTime.now();
		this.userEmail = userEmail;
		this.ip = ip;
		this.level=logLevel;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getLogType() {
		return logType;
	}
	public void setLogType(String logType) {
		this.logType = logType;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	
	
	
	
}
