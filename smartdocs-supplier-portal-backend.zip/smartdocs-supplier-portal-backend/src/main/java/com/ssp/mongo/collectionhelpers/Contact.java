package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ssp.dto.ContactDto;
import com.ssp.mongo.collections.requests.VendorUserRegistrarionRequest;

public class Contact {
	
	public static final String ACTION_ADD = "Add";
	public static final String ACTION_UPDATE = "Update";
	public static final String ACTION_DELETE = "Delete";

	private String contactId;
	private String firstname;
	private String lastname;
	private String email;
	private Phone  phonenumber;
	private Phone  fax;
	private Phone  mobile;
	private String  functionName;
	private boolean admin;
	
	private boolean isPortalAccount;
	private boolean asPrimaryEmail;
	private boolean addedFromPortal;
	
	private List<String> roles;
	
	private ZonedDateTime date;
	
	public Contact() {
		super();
	}

	public Contact(ContactDto contact) {
		this.contactId = contact.getContactId();
		this.firstname = contact.getFirstname();
		this.lastname = contact.getLastname();
		this.email = contact.getEmail();
		this.phonenumber = contact.getPhonenumber();
		this.fax = contact.getFax();
		this.mobile = contact.getMobile();
		this.functionName = contact.getFunctionName();
		this.date = contact.getDate();
		this.admin = contact.isAdmin();
		this.isPortalAccount = contact.isPortalAccount();
		this.asPrimaryEmail = contact.isAsPrimaryEmail();
		this.roles = new ArrayList<String>();
		if(contact.getRoles()!=null && contact.getRoles().size() > 0) {
			for(String role : contact.getRoles()) {
				roles.add(role);
			}
		}
	    this.addedFromPortal = true;
	}
	
	public Contact(VendorUserRegistrarionRequest contact) {
		//this.contactId = contact.getContactId();
		this.firstname = contact.getFirstName();
		this.lastname = contact.getLastName();
		this.email = contact.getEmail();
		this.phonenumber = contact.getPhone();
		this.mobile = contact.getPhone();
		 
	}
	
	/*public Contact(String firstname, String lastname,String email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	 
	}*/

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if(StringUtils.isNotBlank(email)) {
			this.email=email.toLowerCase().trim();
		}
		else{
			this.email = email;
		}
	}

	public Phone getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Phone phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Phone getFax() {
		return fax;
	}

	public void setFax(Phone fax) {
		this.fax = fax;
	}

	public Phone getMobile() {
		return mobile;
	}

	public void setMobile(Phone mobile) {
		this.mobile = mobile;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean isPortalAccount() {
		return isPortalAccount;
	}

	public void setPortalAccount(boolean isPortalAccount) {
		this.isPortalAccount = isPortalAccount;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public boolean isAsPrimaryEmail() {
		return asPrimaryEmail;
	}

	public void setAsPrimaryEmail(boolean asPrimaryEmail) {
		this.asPrimaryEmail = asPrimaryEmail;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public ZonedDateTime getDate() {
		return date;
	}

	public void setDate(ZonedDateTime date) {
		this.date = date;
	}

	public boolean isAddedFromPortal() {
		return addedFromPortal;
	}

	public void setAddedFromPortal(boolean addedFromPortal) {
		this.addedFromPortal = addedFromPortal;
	}
	
}
