package com.ssp.mongo.collections.employee;

import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.ssp.mongo.collectionhelpers.CustomCountries;
import com.ssp.mongo.collectionhelpers.FormField;
import com.ssp.mongo.collections.workflow.config.BusinessRules;

@Document(collection = "employeeMasterFolder")
public class EmployeeMasterFolder {
	
	@Id
	private String id;
	private String icon;
	private String name;
	private String description;
	private boolean isEnabled;
	private int order;

	public String getId() {
		return id;
	}
	public String getIcon() {
		return icon;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public boolean isEnabled() {
		return isEnabled;
	}
	public int isOrder() {
		return order;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
}
