package com.ssp.mongo.collections;


import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.Amount;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.PRItemHelper;



@Document(collection = "PurchaseRequisition")
public class PurchaseRequisition {

	
	@Id
	private String id;
	
	private String purchaseRequisitionNumber;
	
	private String prDesc;
	
	private String companyCode;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	private String prType;
	
	private ZonedDateTime prDate;
	
	private Amount amount;
	
	private String buyer;
	
	private String status;
	
	private List<Address> remitToAddress = null;
	
	private List<Address> shipToAddress  = null;
	
	private List<DocumentHelper> attachments = null;
	private List<DocumentHelper> originalDocuments = null;
	
	private List<PRItemHelper> lineItems = null;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseRequisitionNumber() {
		return purchaseRequisitionNumber;
	}

	public void setPurchaseRequisitionNumber(String purchaseRequisitionNumber) {
		this.purchaseRequisitionNumber = purchaseRequisitionNumber;
	}

	public String getPrDesc() {
		return prDesc;
	}

	public void setPrDesc(String prDesc) {
		this.prDesc = prDesc;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPrType() {
		return prType;
	}

	public void setPrType(String prType) {
		this.prType = prType;
	}

	public ZonedDateTime getPrDate() {
		return prDate;
	}

	public void setPrDate(ZonedDateTime prDate) {
		this.prDate = prDate;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Address> getRemitToAddress() {
		return remitToAddress;
	}

	public void setRemitToAddress(List<Address> remitToAddress) {
		this.remitToAddress = remitToAddress;
	}

	public List<Address> getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(List<Address> shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public List<DocumentHelper> getOriginalDocuments() {
		return originalDocuments;
	}

	public void setOriginalDocuments(List<DocumentHelper> originalDocuments) {
		this.originalDocuments = originalDocuments;
	}

	public List<PRItemHelper> getLineItems() {
		return lineItems;
	}

	public void setLineItems(List<PRItemHelper> lineItems) {
		this.lineItems = lineItems;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}
	
	
}
