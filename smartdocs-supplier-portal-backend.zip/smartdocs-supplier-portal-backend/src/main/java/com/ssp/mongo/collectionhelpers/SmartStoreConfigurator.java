package com.ssp.mongo.collectionhelpers;

public class SmartStoreConfigurator {

	private String serverURL;
	private String system;
	private String pVersion;
	private String contRep;
	private String compId;
	private String authId;
	private String expiration;
	private String secKey;

	public String getServerURL() {
		return serverURL;
	}
	public void setServerURL(String serverURL) {
		this.serverURL = serverURL;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getpVersion() {
		return pVersion;
	}
	public void setpVersion(String pVersion) {
		this.pVersion = pVersion;
	}
	public String getContRep() {
		return contRep;
	}
	public void setContRep(String contRep) {
		this.contRep = contRep;
	}
	public String getCompId() {
		return compId;
	}
	public void setCompId(String compId) {
		this.compId = compId;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getExpiration() {
		return expiration;
	}
	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}
	public String getSecKey() {
		return secKey;
	}
	public void setSecKey(String secKey) {
		this.secKey = secKey;
	}
	@Override
	public String toString() {
		return "SmartStoreConfigurator [serverURL=" + serverURL + ", system="
				+ system + ", pVersion=" + pVersion + ", contRep=" + contRep
				+ ", compId=" + compId + ", authId=" + authId + ", expiration="
				+ expiration + ", secKey=" + secKey + "]";
	}


}

