package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "EmailNotificationSystemConfig")
public class EmailNotificationSystemConfig {

		@Id
		private String identifier;
		
		private String notification_type;
		private String notificationTypeLable;
		private boolean enabled;
		private boolean vendorUser;
		private boolean companyUser;
		
		private boolean vendorUserConfig;
		private boolean companyUserConfig;
		// UI point of view to group.
		private String group;
		
		
		public EmailNotificationSystemConfig() {
			super();
		}
		public EmailNotificationSystemConfig(String notification_type,
				String notificationTypeLable,String groupBy, boolean isEnabled) {
			super();
			this.identifier=notification_type;
			this.notification_type = notification_type;
			this.notificationTypeLable = notificationTypeLable;
			this.enabled = isEnabled;
			this.group=groupBy;
		}
		public String getNotification_type() {
			return notification_type;
		}
		public String getNotificationTypeLable() {
			return notificationTypeLable;
		}
		public String getGroup() {
			return group;
		}
		public void setGroup(String group) {
			this.group = group;
		}
	 
		public String getIdentifier() {
			return identifier;
		}

		public void setIdentifier(String identifier) {
			this.identifier = identifier;
		}

		public void setNotification_type(String notification_type) {
			this.notification_type = notification_type;
		}
		public void setNotificationTypeLable(String notificationTypeLable) {
			this.notificationTypeLable = notificationTypeLable;
		}
		 
		public boolean isEnabled() {
			return enabled;
		}
		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}
		public boolean isVendorUser() {
			return vendorUser;
		}
		public boolean isCompanyUser() {
			return companyUser;
		}
		public void setVendorUser(boolean vendorUser) {
			this.vendorUser = vendorUser;
		}
		public void setCompanyUser(boolean companyUser) {
			this.companyUser = companyUser;
		}
		public boolean isVendorUserConfig() {
			return vendorUserConfig;
		}
		public boolean isCompanyUserConfig() {
			return companyUserConfig;
		}
		public void setVendorUserConfig(boolean vendorUserConfig) {
			this.vendorUserConfig = vendorUserConfig;
		}
		public void setCompanyUserConfig(boolean companyUserConfig) {
			this.companyUserConfig = companyUserConfig;
		}
		
		
	}
