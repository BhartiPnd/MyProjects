package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "AuditTrackingLog")
public class AuditTrackingLog {

	private String id;
	private String itemType;
	private String itemId;
	private String tag;
	private String refId;
	private String comment;
	private String activity;
	private String activityByUser;
	private boolean internal;
	private ZonedDateTime createDate;
	
	public AuditTrackingLog() {
		super();
	}
	
	public AuditTrackingLog(String itemType, String itemId,
			String tag, String refId, String comment,
			String activity, String activityByUser, boolean internal) {
		super();
		this.itemType = itemType;
		this.itemId = itemId;
		this.tag = tag;
		this.refId = refId;
		this.comment = comment;
		this.activity = activity;
		this.activityByUser = activityByUser;
		this.internal = internal;
		this.createDate = ZonedDateTime.now();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getActivityByUser() {
		return activityByUser;
	}
	public void setActivityByUser(String activityByUser) {
		this.activityByUser = activityByUser;
	}
	public boolean isInternal() {
		return internal;
	}
	public void setInternal(boolean internal) {
		this.internal = internal;
	}
	public ZonedDateTime getCreateDate() {
		return createDate;
	}
	public void setCreateDate(ZonedDateTime createDate) {
		this.createDate = createDate;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	
	
}
