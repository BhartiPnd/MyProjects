package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

import com.ssp.mongo.collections.requests.TaxDetail;


public class TaxAndW9Change {

	private String taxIdType;
	private String socialSecurityNo;
	private String employeeIdNo;
	private ZonedDateTime w9SignatureDate;
	private DocumentHelper attachment;
	
	private TaxDetail taxDetail;
	
	 String getTaxIdType() {
		return taxIdType;
	}
	public ZonedDateTime getW9SignatureDate() {
		return w9SignatureDate;
	}
	public DocumentHelper getAttachment() {
		return attachment;
	}
	 
	public void setTaxIdType(String taxIdType) {
		this.taxIdType = taxIdType;
	}
	public void setW9SignatureDate(ZonedDateTime w9SignatureDate) {
		this.w9SignatureDate = w9SignatureDate;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public String getSocialSecurityNo() {
		return socialSecurityNo;
	}
	public String getEmployeeIdNo() {
		return employeeIdNo;
	}
	public void setSocialSecurityNo(String socialSecurityNo) {
		this.socialSecurityNo = socialSecurityNo;
	}
	public void setEmployeeIdNo(String employeeIdNo) {
		this.employeeIdNo = employeeIdNo;
	}
	public TaxDetail getTaxDetail() {
		return taxDetail;
	}
	public void setTaxDetail(TaxDetail taxDetail) {
		this.taxDetail = taxDetail;
	} 
	
	
}
