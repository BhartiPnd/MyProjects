package com.ssp.mongo.collectionhelpers;

public class ApprovalConfigCondition {

	
	public static final String EQUALS="eq";
	public static final String NOT_EQUALS="ne";
	public static final String GRATERTEHN="gt";
	public static final String LESSTHEN="lt";
	
	
	
	private String attributeName;
	private String attributeType;
	private String condition;
	private String attributeValue;
	
	public ApprovalConfigCondition() {
		super();
	}
	public ApprovalConfigCondition(String attributeName, String attributeType, String condition,
			String attributeValue) {
		super();
		this.attributeName = attributeName;
		this.attributeType = attributeType;
		this.condition = condition;
		this.attributeValue = attributeValue;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getAttributeType() {
		return attributeType;
	}
	public void setAttributeType(String attributeType) {
		this.attributeType = attributeType;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getAttributeValue() {
		return attributeValue;
	}
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	
	
}
