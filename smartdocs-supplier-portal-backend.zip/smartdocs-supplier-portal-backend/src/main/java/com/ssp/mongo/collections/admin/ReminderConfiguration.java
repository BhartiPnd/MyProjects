package com.ssp.mongo.collections.admin;

public class ReminderConfiguration {

}
