package com.ssp.mongo.collections.smartbuy;

import com.ssp.mongo.collections.workflow.WorkItem;

public class PurchaseReqRequestInboxDetail {

	private PurchaseReqRequestDetail purchaseReqRequest;
	private WorkItem workItem;
	private String status;
	private String error;
	
	public PurchaseReqRequestDetail getPurchaseReqRequest() {
		return purchaseReqRequest;
	}
	public void setPurchaseReqRequest(PurchaseReqRequestDetail purchaseReqRequest) {
		this.purchaseReqRequest = purchaseReqRequest;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getStatus() {
		return status;
	}
	public String getError() {
		return error;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setError(String error) {
		this.error = error;
	}
	 
	
}
