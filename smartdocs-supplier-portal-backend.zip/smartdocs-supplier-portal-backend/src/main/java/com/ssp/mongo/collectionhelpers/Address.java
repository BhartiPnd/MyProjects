package com.ssp.mongo.collectionhelpers;

import com.ssp.mongo.collections.RemitToAddress;

public class Address {
	
	private String name;
	private String address1;
	private String address2;
	private String address3;
	private String city;
	private String country;
	private String zip;
	private String location;
	private String state;

	
	public Address() {
		super();
	}
	
	
	public Address(String name,RemitToAddress address) {
		super();
		this.name=name;
		this.address1 = address.getAddress1();
		this.address2 = address.getAddress2();
		this.address3 = address.getAddress3();
		this.city = address.getCity();
		this.zip = address.getZip();
		this.country = address.getCountry();
		this.location = address.getLocation();
	}
	public Address(String name,String address1, String address2, String address3,
			String city, String country, String zip,String location) {
		super();
		this.name=name;
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.city = city;
		this.zip = zip;
		this.country = country;
		this.location = location;
	}

	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Address [address1=" + address1 + ", address2=" + address2
				+ ", address3=" + address3 + ", city=" + city + ", zip=" + zip
				+ ", country=" + country + "]";
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
