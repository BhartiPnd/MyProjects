package com.ssp.mongo.collectionhelpers;

public class BotSetting {

	private Boolean isenabled;
	private String botname;
	private String botid;
	private String privatekey;
	private String bothandlerurl;
	
	public BotSetting() {
		super();
	}

	public BotSetting(Boolean isenabled, String botname, String botid,
			String privatekey, String bothandlerurl) {
		super();
		this.isenabled = isenabled;
		this.botname = botname;
		this.botid = botid;
		this.privatekey = privatekey;
		this.bothandlerurl = bothandlerurl;
	}

	public Boolean getIsenabled() {
		return isenabled;
	}

	public void setIsenabled(Boolean isenabled) {
		this.isenabled = isenabled;
	}

	public String getBotname() {
		return botname;
	}

	public void setBotname(String botname) {
		this.botname = botname;
	}

	public String getBotid() {
		return botid;
	}

	public void setBotid(String botid) {
		this.botid = botid;
	}

	public String getPrivatekey() {
		return privatekey;
	}

	public void setPrivatekey(String privatekey) {
		this.privatekey = privatekey;
	}

	public String getBothandlerurl() {
		return bothandlerurl;
	}

	public void setBothandlerurl(String bothandlerurl) {
		this.bothandlerurl = bothandlerurl;
	}

	@Override
	public String toString() {
		return "BotSetting [isenabled=" + isenabled + ", botname=" + botname
				+ ", botid=" + botid + ", privatekey=" + privatekey
				+ ", bothandlerurl=" + bothandlerurl + "]";
	}
	
	
	
}
