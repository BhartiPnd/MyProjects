package com.ssp.mongo.collections.config;

public class Field {

	private String identifier;
	private String name;
	private String title;
	private String fieldType;
	private boolean required;
	private boolean hidden;
	private String defaultValue;
	private boolean readOnly;
	private String formElementHint;
	private boolean isSystemDefined;
	private String description; 
	private String regexPattern;
	private String group;
	
	
	public String getIdentifier() {
		return identifier;
	}
	public String getName() {
		return name;
	}
	public String getTitle() {
		return title;
	}
	public String getFieldType() {
		return fieldType;
	}
	public boolean isRequired() {
		return required;
	}
	public boolean isHidden() {
		return hidden;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public boolean isReadOnly() {
		return readOnly;
	}
	public String getFormElementHint() {
		return formElementHint;
	}
	public boolean isSystemDefined() {
		return isSystemDefined;
	}
	public String getDescription() {
		return description;
	}
	public String getRegexPattern() {
		return regexPattern;
	}
	public String getGroup() {
		return group;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	public void setFormElementHint(String formElementHint) {
		this.formElementHint = formElementHint;
	}
	public void setSystemDefined(boolean isSystemDefined) {
		this.isSystemDefined = isSystemDefined;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setRegexPattern(String regexPattern) {
		this.regexPattern = regexPattern;
	}
	public void setGroup(String group) {
		this.group = group;
	} 
	
	
	//private fieldChoices:[]
//	fieldPermissions:[]isDeleted:false
}
