package com.ssp.mongo.collections.requests;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.Phone;

@Document(collection = "VendorUserRegistrationRequest")
public class VendorUserRegistrarionRequest {

	public static final String STATUS_OPEN="Open";
	public static final String STATUS_COMPLETED="Completed";
	public static final String STATUS_DELETED="Deleted";
	
	@Id
	private String id;
	private String supplierId;
	private String email;
	private String firstName;
	private String lastName;
	private String companyName;
	private Phone phone;
	private String status;
	private List<DocumentHelper> attachment;
	private ZonedDateTime createdDate;
	
	private String notes;
	
	private List<ActivityLog> activityLogs;
	
	
	
	// just for form. 
	private String captcha;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getEmail() {
		if(email!=null) {
			return email.toLowerCase();
		}
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Phone getPhone() {
		return phone;
	}
	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
 
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public List<DocumentHelper> getAttachment() {
		return attachment;
	}
	public void setAttachment(List<DocumentHelper> attachment) {
		this.attachment = attachment;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCaptcha() {
		return captcha;
	}
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public void addActivityLogs(ActivityLog activityLog) {
		if (this.getActivityLogs() == null) {
			this.setActivityLogs(new ArrayList<>());
		}
		if (this.getActivityLogs().size() > 1) {
			ActivityLog activityLog2 = this.activityLogs.get(this.getActivityLogs().size() - 1);
			if (activityLog.getStep() == activityLog2.getStep()) {
				activityLog.setSeq(activityLog2.getSeq() + 1);
			}
			
		}

		this.getActivityLogs().add(activityLog);
	}
	
	
	
	
}
