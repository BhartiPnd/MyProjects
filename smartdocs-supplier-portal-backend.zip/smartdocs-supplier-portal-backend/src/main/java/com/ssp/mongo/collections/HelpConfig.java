package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.HelpContent;

@Document(collection = "helpConfig")
public class HelpConfig {

	@Id
	private String id;
	private String type;
	private List<HelpContent> fieldHelp;
	
	public HelpConfig() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HelpConfig(String id, String type, List<HelpContent> fieldHelp) {
		super();
		this.id = id;
		this.type = type;
		this.fieldHelp = fieldHelp;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<HelpContent> getFieldHelp() {
		return fieldHelp;
	}

	public void setFieldHelp(List<HelpContent> fieldHelp) {
		this.fieldHelp = fieldHelp;
	}

	
}
