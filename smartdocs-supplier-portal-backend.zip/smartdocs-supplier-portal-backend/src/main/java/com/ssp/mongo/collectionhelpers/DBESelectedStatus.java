package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;



public class DBESelectedStatus {

	private String dbe;
	private boolean selected;
	private ZonedDateTime certificationExpiryDate;
	private DocumentHelper attachment; 

	public String getDbe() {
		return dbe;
	}

	public void setDbe(String dbe) {
		this.dbe = dbe;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public ZonedDateTime getCertificationExpiryDate() {
		return certificationExpiryDate;
	}


	public void setCertificationExpiryDate(ZonedDateTime certificationExpiryDate) {
		this.certificationExpiryDate = certificationExpiryDate;
	}


	public DocumentHelper getAttachment() {
		return attachment;
	}


	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}


	 
    

	 
	

}
