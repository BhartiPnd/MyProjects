package com.ssp.mongo.collections.rfx;

import java.util.List;

public class RFXBidder {
	private String vendorId;
	private String vendorName;
	private List<String> contactPersonEmails;

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public List<String> getContactPersonEmails() {
		return contactPersonEmails;
	}

	public void setContactPersonEmails(List<String> contactPersonEmails) {
		this.contactPersonEmails = contactPersonEmails;
	}

}
