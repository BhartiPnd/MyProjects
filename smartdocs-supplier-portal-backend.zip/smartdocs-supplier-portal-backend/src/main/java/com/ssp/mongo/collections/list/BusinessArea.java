package com.ssp.mongo.collections.list;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "BusinessArea")
public class BusinessArea {

	@Id
	private String id;
	private String businessArea;
	private String description;
	
	public BusinessArea() {
		super();
	}

	public BusinessArea(String id, String businessArea, String description) {
		super();
		this.id = id;
		this.businessArea = businessArea;
		this.description = description;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
