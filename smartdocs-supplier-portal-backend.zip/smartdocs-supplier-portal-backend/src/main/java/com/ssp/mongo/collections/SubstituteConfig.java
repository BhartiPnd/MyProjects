package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.CreateSubstituteConfig;
import com.ssp.mongo.util.GeneralUtil;

@Document(collection = "SubstituteConfig")
public class SubstituteConfig {
	
	@Id
	private String id;
	private String user;
	private ZonedDateTime fromDate;
	private ZonedDateTime toDate;
	private String substituteUser;
	private boolean isActive;
	
	public SubstituteConfig() {
		super();
	}
	public SubstituteConfig(CreateSubstituteConfig  substituteConfig,String clientTz) {
		super();
		this.id=substituteConfig.getId();
		this.user = substituteConfig.getUser();
		this.fromDate = GeneralUtil.getFromDate(substituteConfig.getFromDate(), clientTz);
		this.toDate = GeneralUtil.getEndime(substituteConfig.getToDate(), clientTz);
		this.substituteUser = substituteConfig.getSubstituteUser();
		this.isActive = substituteConfig.isActive();
	}
	public String getId() {
		return id;
	}
	public String getUser() {
		return user;
	}
	public ZonedDateTime getFromDate() {
		return fromDate;
	}
	public ZonedDateTime getToDate() {
		return toDate;
	}
	public String getSubstituteUser() {
		return substituteUser;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setFromDate(ZonedDateTime fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(ZonedDateTime toDate) {
		this.toDate = toDate;
	}
	public void setSubstituteUser(String substituteUser) {
		this.substituteUser = substituteUser;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
	
}
