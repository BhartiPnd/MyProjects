package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "GoodsIssueTemplate")
public class GoodsIssueTemplate {
	
	@Id
	private String id;
	private String companyCode;
	private String title;
	private String owner;
	private String global;
	private String type;
	private String notes;
	private ZonedDateTime createdDateTime;
	private List<GoodsIssueTemplateLineItems> items;
	
	public GoodsIssueTemplate() {
		super();
		this.createdDateTime = ZonedDateTime.now();
	}
//	public GoodsIssueTemplate(List<GoodsIssueTemplateLineItems> items ) {
//		super();
//		this.items = items;
//	}

	public GoodsIssueTemplate(String title, String owner, String global, String type,
			List<GoodsIssueTemplateLineItems> items) {
		super();
		this.title = title;
		this.owner = owner;
		this.global = global;
		this.type = type;
		this.createdDateTime = ZonedDateTime.now();
		this.items = items;
	}
	
	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getOwner() {
		return owner;
	}

	public String getGlobal() {
		return global;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void setGlobal(String global) {
		this.global = global;
	}

	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<GoodsIssueTemplateLineItems> getItems() {
		return items;
	}

	public void setItems(List<GoodsIssueTemplateLineItems> items) {
		this.items = items;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
	
}
