package com.ssp.mongo.collectionhelpers;

public class StorageLoc {

	private String storageLocId;
	private String storageLocDesc;
	
	public String getStorageLocDesc() {
		return storageLocDesc;
	}
	public void setStorageLocDesc(String storageLocDesc) {
		this.storageLocDesc = storageLocDesc;
	}
	public String getStorageLocId() {
		return storageLocId;
	}
	public void setStorageLocId(String storageLocId) {
		this.storageLocId = storageLocId;
	}
	
	
}
