package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.EDIOrderConfirmationDTO;
import com.ssp.dto.EDIPOitmHelperDTO;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.POitmHelper;

@Document(collection = "orderconfirmation")
public class OrderConfirmation {

	public static final String CHANNEL_EDI = "EDI";
	public static final String CHANNEL_PORTAL = "PORTAL";

	public static final String EDI_STATUS_IC = "IC";
	public static final String EDI_STATUS_IR = "IR";
	public static final String EDI_STATUS_ID = "ID";
	public static final String EDI_STATUS_IA = "IA";

	@Id
	private String id;
	private String purchaseOrderNumber;
	private String companyCode;
	private long refId;

	private String orderconfreference;
	private String supplierId;
	private String createdBy;

	private List<POitmHelper> items;

	private ZonedDateTime createdDateTime;
	private List<DocumentHelper> attachments;

	private String status;
	private String statusDesc;
	private String channel;
	private String comment;

	private Boolean isSAPSynch;
	private Long sapSynchDate;
	private Boolean isSAPSynchACK;
	private boolean deleted;

	private ZonedDateTime poAcknowledgedDate;
	private ZonedDateTime acknowledgedDeliveryDate;
	private String oaJson;

	public OrderConfirmation() {
		super();
	}

	public List<POitmHelper> getItems() {
		return items;
	}

	public void setItems(List<POitmHelper> items) {
		this.items = items;
	}

	public OrderConfirmation(PurchaseOrder po, String creator) {
		this.purchaseOrderNumber = po.getPurchaseOrderNumber();
		if (po.getPoitms() != null && po.getPoitms().size() > 0) {
			this.items = po.getPoitms();
		}
		// this.creator = creator;
	}

	public OrderConfirmation(EDIOrderConfirmationDTO ediOrderConfirmationDTO) {
		this.purchaseOrderNumber = ediOrderConfirmationDTO.getPurchaseOrderNumber();
		if (!ediOrderConfirmationDTO.getItems().isEmpty()) {
			List<POitmHelper> helpers = new ArrayList<>();
			for (EDIPOitmHelperDTO edipOitmHelperDTO : ediOrderConfirmationDTO.getItems()) {
				helpers.add(new POitmHelper(edipOitmHelperDTO));
			}
			this.items = helpers;
		}
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getOrderconfreference() {
		return orderconfreference;
	}

	public void setOrderconfreference(String orderconfreference) {
		this.orderconfreference = orderconfreference;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public Long getSapSynchDate() {
		return sapSynchDate;
	}

	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public long getRefId() {
		return refId;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	public ZonedDateTime getAcknowledgedDeliveryDate() {
		return acknowledgedDeliveryDate;
	}

	public void setAcknowledgedDeliveryDate(ZonedDateTime acknowledgedDeliveryDate) {
		this.acknowledgedDeliveryDate = acknowledgedDeliveryDate;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public ZonedDateTime getPoAcknowledgedDate() {
		return poAcknowledgedDate;
	}

	public void setPoAcknowledgedDate(ZonedDateTime poAcknowledgedDate) {
		this.poAcknowledgedDate = poAcknowledgedDate;
	}

	public void addAttachments(List<DocumentHelper> attachments) {

		if (attachments != null && attachments.size() > 0) {
			if (this.getAttachments() == null) {
				this.setAttachments(new ArrayList<>());
			}
			for (DocumentHelper docHelper : attachments) {
				this.getAttachments().add(docHelper);
			}
		} else {

		}
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<DocumentHelper> resetAttachmentUploadeByInfo(List<DocumentHelper> attachments, String uploadedBy,
			int usrUploaded) {
		if (attachments != null && attachments.size() > 0) {
			for (DocumentHelper attachment : attachments) {
				if (attachment.getUploadedDate() == null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if (attachment.getUploadedBy() == null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
			}
		}
		return attachments;
	}

	public void resetAttachmentUploadeByInfo(String uploadedBy, int usrUploaded) {

		if (this.attachments != null && this.attachments.size() > 0) {
			for (DocumentHelper attachment : this.attachments) {
				if (attachment.getUploadedDate() == null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if (attachment.getUploadedBy() == null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
			}
		}

	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getOaJson() {
		return oaJson;
	}

	public void setOaJson(String oaJson) {
		this.oaJson = oaJson;
	}

}
