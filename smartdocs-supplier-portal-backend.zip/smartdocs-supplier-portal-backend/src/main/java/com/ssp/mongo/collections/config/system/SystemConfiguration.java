package com.ssp.mongo.collections.config.system;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "SystemConfiguration")
public class SystemConfiguration {

		public static final String DEFAULT_SYSTEM_CONFIG = "system_config";
		
		@Id
		private String id;
		private boolean rfx;
		
		
		private boolean vrr;
		private boolean vcr;
		
		
		private boolean contract;
		private boolean purchaseOrder ;
		private boolean asn;
		private boolean oa;
		private boolean gr;
		private boolean plannedPO;
		
		private boolean smartBuying;
		private boolean purchaseRequisitionRequest;
		private boolean purchaseOrderRequest ;
		private boolean goodsIssue;
		private boolean vendorSearch;
		private boolean materialSearch;
		
		private boolean invoice;
		private boolean submitPoInvoice;
		private boolean submitNonPoInvoice;
		private boolean expenses;
		
		
		private boolean analytics;
		
		private boolean payment;
		private boolean announcement;
		private boolean payments;
		private boolean ticket;
		private boolean employeeDocuments;
		
		
		private boolean inbox;
		private boolean logicalSystem;
		
		private boolean smartTask;
		private boolean termsAndCondition;
		private boolean report;
		private boolean bidSheet;
		private boolean rfq;
		
		public boolean isInbox() {
			return inbox;
		}
		public void setInbox(boolean inbox) {
			this.inbox = inbox;
		}
		public boolean isVrr() {
			return vrr;
		}
		public void setVrr(boolean vrr) {
			this.vrr = vrr;
		}
		public boolean isReport() {
			return report;
		}
		public void setReport(boolean report) {
			this.report = report;
		}
		public boolean isPurchaseOrder() {
			return purchaseOrder;
		}
		public void setPurchaseOrder(boolean purchaseOrder) {
			this.purchaseOrder = purchaseOrder;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public boolean isSmartTask() {
			return smartTask;
		}
		public void setSmartTask(boolean smartTask) {
			this.smartTask = smartTask;
		}
		public boolean isContract() {
			return contract;
		}
		public void setContract(boolean contract) {
			this.contract = contract;
		}
		public boolean isRfx() {
			return rfx;
		}
		public void setRfx(boolean rfx) {
			this.rfx = rfx;
		}
		public boolean isAsn() {
			return asn;
		}
		public void setAsn(boolean asn) {
			this.asn = asn;
		}
		public boolean isGr() {
			return gr;
		}
		public void setGr(boolean gr) {
			this.gr = gr;
		}
		public boolean isOa() {
			return oa;
		}
		public void setOa(boolean oa) {
			this.oa = oa;
		}
		public boolean isInvoice() {
			return invoice;
		}
		public void setInvoice(boolean invoice) {
			this.invoice = invoice;
		}
		public boolean isSubmitPoInvoice() {
			return submitPoInvoice;
		}
		public void setSubmitPoInvoice(boolean submitPoInvoice) {
			this.submitPoInvoice = submitPoInvoice;
		}
		public boolean isSubmitNonPoInvoice() {
			return submitNonPoInvoice;
		}
		public void setSubmitNonPoInvoice(boolean submitNonPoInvoice) {
			this.submitNonPoInvoice = submitNonPoInvoice;
		}
		public boolean isExpenses() {
			return expenses;
		}
		public void setExpenses(boolean expenses) {
			this.expenses = expenses;
		}
		public boolean isSmartBuying() {
			return smartBuying;
		}
		public void setSmartBuying(boolean smartBuying) {
			this.smartBuying = smartBuying;
		}
		public boolean isPurchaseRequisitionRequest() {
			return purchaseRequisitionRequest;
		}
		public void setPurchaseRequisitionRequest(boolean purchaseRequisitionRequest) {
			this.purchaseRequisitionRequest = purchaseRequisitionRequest;
		}
		public boolean isPurchaseOrderRequest() {
			return purchaseOrderRequest;
		}
		public void setPurchaseOrderRequest(boolean purchaseOrderRequest) {
			this.purchaseOrderRequest = purchaseOrderRequest;
		}
		public boolean isAnalytics() {
			return analytics;
		}
		public void setAnalytics(boolean analytics) {
			this.analytics = analytics;
		}
		public boolean isPayments() {
			return payments;
		}
		public void setPayments(boolean payments) {
			this.payments = payments;
		}
		public boolean isVcr() {
			return vcr;
		}
		public void setVcr(boolean vcr) {
			this.vcr = vcr;
		}
		public boolean isTicket() {
			return ticket;
		}
		public void setTicket(boolean ticket) {
			this.ticket = ticket;
		}
		public boolean isAnnouncement() {
			return announcement;
		}
		public void setAnnouncement(boolean announcement) {
			this.announcement = announcement;
		}
		public boolean isPayment() {
			return payment;
		}
		public void setPayment(boolean payment) {
			this.payment = payment;
		}
		public boolean isPlannedPO() {
			return plannedPO;
		}
		public void setPlannedPO(boolean plannedPO) {
			this.plannedPO = plannedPO;
		}
		public boolean isEmployeeDocuments() {
			return employeeDocuments;
		}
		public void setEmployeeDocuments(boolean employeeDocuments) {
			this.employeeDocuments = employeeDocuments;
		}
		public boolean isTermsAndCondition() {
			return termsAndCondition;
		}
		public void setTermsAndCondition(boolean termsAndCondition) {
			this.termsAndCondition = termsAndCondition;
		}
		public boolean isGoodsIssue() {
			return goodsIssue;
		}
		public void setGoodsIssue(boolean goodsIssue) {
			this.goodsIssue = goodsIssue;
		}
		public boolean isLogicalSystem() {
			return logicalSystem;
		}
		public void setLogicalSystem(boolean logicalSystem) {
			this.logicalSystem = logicalSystem;
		}
		public boolean isVendorSearch() {
			return vendorSearch;
		}
		public boolean isMaterialSearch() {
			return materialSearch;
		}
		public void setVendorSearch(boolean vendorSearch) {
			this.vendorSearch = vendorSearch;
		}
		public void setMaterialSearch(boolean materialSearch) {
			this.materialSearch = materialSearch;
		}
		public boolean isBidSheet() {
			return bidSheet;
		}
		public void setBidSheet(boolean bidSheet) {
			this.bidSheet = bidSheet;
		}
		public boolean isRfq() {
			return rfq;
		}
		public void setRfq(boolean rfq) {
			this.rfq = rfq;
		}
		
		
		
}
