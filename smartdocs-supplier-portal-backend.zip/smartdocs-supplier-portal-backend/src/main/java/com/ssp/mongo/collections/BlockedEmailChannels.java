package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "blockedEmailChannel")
public class BlockedEmailChannels {
	

	@Id
	private String email;
	private ZonedDateTime blockDate;
	private String blockBy;
	
	public BlockedEmailChannels() {
		super();
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ZonedDateTime getBlockDate() {
		return blockDate;
	}
	public void setBlockDate(ZonedDateTime blockDate) {
		this.blockDate = blockDate;
	}
	public String getBlockBy() {
		return blockBy;
	}
	public void setBlockBy(String blockBy) {
		this.blockBy = blockBy;
	}
	
}
