package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "sendGridEmailConfig")
public class SendGridEmailConfig {

	
	@Id
	private String id;
	private String fromEmailAddress;
	private String sendGridName;
	private String description;
	private String apiKey;
	private String vendorRegistrationEmailToCompany;
	private String vendorRegistrationEmailToVendor;
	private String vendorRegistrationCompleted;
	private String vendorRegistrationRejected;
	private String ach;
	private String vendorChangeRequest;
	private String orderChangeRequest;
	private String rfxRequest;
	private String rfxAwarded;
	private String invoiceApprovalNotification;
	
	
	
	
	public SendGridEmailConfig() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFromEmailAddress() {
		return fromEmailAddress;
	}
	public void setFromEmailAddress(String fromEmailAddress) {
		this.fromEmailAddress = fromEmailAddress;
	}
	public String getSendGridName() {
		return sendGridName;
	}
	public void setSendGridName(String sendGridName) {
		this.sendGridName = sendGridName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getVendorRegistrationEmailToCompany() {
		return vendorRegistrationEmailToCompany;
	}
	public void setVendorRegistrationEmailToCompany(String vendorRegistrationEmailToCompany) {
		this.vendorRegistrationEmailToCompany = vendorRegistrationEmailToCompany;
	}
	public String getVendorRegistrationEmailToVendor() {
		return vendorRegistrationEmailToVendor;
	}
	public void setVendorRegistrationEmailToVendor(String vendorRegistrationEmailToVendor) {
		this.vendorRegistrationEmailToVendor = vendorRegistrationEmailToVendor;
	}
	public String getVendorRegistrationCompleted() {
		return vendorRegistrationCompleted;
	}
	public void setVendorRegistrationCompleted(String vendorRegistrationCompleted) {
		this.vendorRegistrationCompleted = vendorRegistrationCompleted;
	}
	public String getVendorRegistrationRejected() {
		return vendorRegistrationRejected;
	}
	public void setVendorRegistrationRejected(String vendorRegistrationRejected) {
		this.vendorRegistrationRejected = vendorRegistrationRejected;
	}
	public String getAch() {
		return ach;
	}
	public void setAch(String ach) {
		this.ach = ach;
	}
	public String getVendorChangeRequest() {
		return vendorChangeRequest;
	}
	public void setVendorChangeRequest(String vendorChangeRequest) {
		this.vendorChangeRequest = vendorChangeRequest;
	}
	public String getOrderChangeRequest() {
		return orderChangeRequest;
	}
	public void setOrderChangeRequest(String orderChangeRequest) {
		this.orderChangeRequest = orderChangeRequest;
	}
	public String getRfxRequest() {
		return rfxRequest;
	}
	public void setRfxRequest(String rfxRequest) {
		this.rfxRequest = rfxRequest;
	}
	public String getRfxAwarded() {
		return rfxAwarded;
	}
	public void setRfxAwarded(String rfxAwarded) {
		this.rfxAwarded = rfxAwarded;
	}
	public String getInvoiceApprovalNotification() {
		return invoiceApprovalNotification;
	}
	public void setInvoiceApprovalNotification(String invoiceApprovalNotification) {
		this.invoiceApprovalNotification = invoiceApprovalNotification;
	}
	
	
	
	
}
