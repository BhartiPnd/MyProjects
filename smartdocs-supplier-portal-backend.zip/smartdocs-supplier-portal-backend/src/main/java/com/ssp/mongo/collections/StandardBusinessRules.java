package com.ssp.mongo.collections;

 
public class StandardBusinessRules {
 
	 public static final String RULE_MISSING_MANDATORY_DATA="MissingMandatoryData";
	 public static final String RULE_DUPLICATECHECK="DuplicateCheck";
	 public static final String RULE_LINEITEM_MISMATCH="LineItemMismatch";
	 public static final String RULE_UOM_MISMATCH="UOMMismatch";
	 
	 public static final String RULE_UNABLE_TO_DETERMINE_APPROVER="UnableToDetermineApprovers";
	 
	 
	 public static final String RULE_AMOUNT_NOT_BALANCED="AmountNotBalanced";
	 public static final String RULE_VEBDOR_BLOCKED="VendorBlocked";
	 public static final String RULE_PRICEVARIANCE="PriceVariance";
	 public static final String RULE_HOLD_QUANTITYVARIANCE="HoldQuantityVariance";
	 public static final String RULE_QUANTITYVARIANCE="QuantityVariance";
	 public static final String RULE_APPROVALREQUIRED1="ApprovalsRequired";
	 public static final String RULE_APPROVALREQUIRED2="ApprovalsRequired2";
	 public static final String RULE_APPROVALREQUIRED3="ApprovalsRequired3";
	 public static final String RULE_APPROVALREQUIRED4="ApprovalsRequired4";
	 public static final String RULE_APPROVALREQUIRED5="ApprovalsRequired5";
	 
	 
	 
	 public static final String RULE_PARKINVOICE="ParkInvoice";
	 public static final String RULE_POSTINVOICE="PostInvoice";
	 
	 public static final String RULE_CREATEPO_OR_PR="CreatePO/PR";
	 
	 public static final String RULE_CUSTOM_ERP="CustomErp";
	public static final String RULE_CUSTOM_ERP2 = "CustomErp2";
  
    private String ruleId;
	private String title;
	
	private String ponpoType;
	private String exception;
	
	public StandardBusinessRules(String ruleId,String title,String ponpoType) {
		super();
		this.ruleId=ruleId;
		this.title=title;
		this.ponpoType=ponpoType;
		this.exception=title+" Exception";
	}
	public StandardBusinessRules(String ruleId,String title) {
		super();
		this.ruleId=ruleId;
		this.title=title;
		this.exception=title+" Exception";
	}
	public StandardBusinessRules() {
		super();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getPonpoType() {
		return ponpoType;
	}
	public void setPonpoType(String ponpoType) {
		this.ponpoType = ponpoType;
	}
	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}
	  	
}
