package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;

import com.ssp.dto.AllowedCompanyCodes;

public class EmailTemplates {

	@Id
	private String id;
	private String subject;
	private String category;
	private String description;
	// in case of send grid 
	private String templateId;
	private String templateBody;
	private List<String> variables;
	
	/// view only field
	private boolean configured;
	private String header;
	private String logo;
	private String signature;
	
	private String mainTemplate;
	private boolean enabled;
	private List<AllowedCompanyCodes> allowedCompanies;
	
	public EmailTemplates() {
		super();
	}
	public EmailTemplates(String id,String category,String description) {
			super();
			this.id=id;
				this.category=category;
				this.description=description;
				this.configured=false;
	}
	
	public List<AllowedCompanyCodes> getAllowedCompanies() {
		return allowedCompanies;
	}
	public void setAllowedCompanies(List<AllowedCompanyCodes> allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	  
	public String getTemplateBody() {
		return templateBody;
	}
	public void setTemplateBody(String templateBody) {
		this.templateBody = templateBody;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	
	
	public String getMainTemplate() {
		return mainTemplate;
	}
	public void setMainTemplate(String mainTemplate) {
		this.mainTemplate = mainTemplate;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getVariables() {
		return variables;
	}
	public boolean isConfigured() {
		return configured;
	}
	public void setVariables(List<String> variables) {
		this.variables = variables;
	}
	public void setConfigured(boolean configured) {
		this.configured = configured;
	}
	  
	

 
	
	
	
}
