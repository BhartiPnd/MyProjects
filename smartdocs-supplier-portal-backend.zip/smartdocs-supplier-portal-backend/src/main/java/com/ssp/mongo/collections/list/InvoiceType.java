package com.ssp.mongo.collections.list;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.DocumentTypeDTO;
import com.ssp.mongo.collectionhelpers.FormField;
import com.ssp.mongo.collections.workflow.config.BusinessRules;

@Document(collection = "invoiceType")
public class InvoiceType {

	public static final String WORKFLOW_TYPE_SEQ = "Sequential";
	
	//public static final String WORKFLOW_ENGINE_PORTAL = "PORTAL";
	//public static final String WORKFLOW_ENGINE_SPAY = "SPAY";
	
	@Id
	private String id;
	private String name;
	private String desc;
	private List<String> tags; // PUR//CON // etc...
	private boolean defaultSelected;
	private boolean isSupplier;
	
	//private boolean isExpenseReport;

	private boolean isRemitToAddress;
	private boolean isShipToAddress;

	private String[] requiredDocTypes;
	private String dynamicHeaderFields;
	private String dynamicLineFields;

	private List<FormField> headerFields;
	private List<FormField> lineFields;

	private List<FormField> customHeaderFields;
	
	private List<BusinessRules> businessRules;
	private String category;

	private String workflowEngine;
	private boolean addressEditable;
	private boolean portalApproval;
	private boolean pdfCreate;
	private boolean adhoc;
	private String pdfCreateDocType;
	private boolean oneTime;
	private String defaultVendor;
	private boolean retention;
	private int retentionPeriod;
	private String apAgent;
	private List<DocumentTypeDTO> documentTypes;
	
	private boolean requestorCreatorValidation;
	
//	In %
	private double tolerance;
	
	public String getApAgent() {
		return apAgent;
	}

	public void setApAgent(String apAgent) {
		this.apAgent = apAgent;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public boolean isSupplier() {
		return isSupplier;
	}

	public void setSupplier(boolean isSupplier) {
		this.isSupplier = isSupplier;
	}

	public String[] getRequiredDocTypes() {
		return requiredDocTypes;
	}

	public void setRequiredDocTypes(String[] requiredDocTypes) {
		this.requiredDocTypes = requiredDocTypes;
	}

	 

	public List<BusinessRules> getBusinessRules() {
		return businessRules;
	}

	public void setBusinessRules(List<BusinessRules> businessRules) {
		this.businessRules = businessRules;
	}

	public List<FormField> getHeaderFields() {
		return headerFields;
	}

	public void setHeaderFields(List<FormField> headerFields) {
		this.headerFields = headerFields;
	}

	public List<FormField> getLineFields() {
		return lineFields;
	}

	public void setLineFields(List<FormField> lineFields) {
		this.lineFields = lineFields;
	}

	public String getDynamicHeaderFields() {
		return dynamicHeaderFields;
	}

	public void setDynamicHeaderFields(String dynamicHeaderFields) {
		this.dynamicHeaderFields = dynamicHeaderFields;
	}

	public String getDynamicLineFields() {
		return dynamicLineFields;
	}

	public void setDynamicLineFields(String dynamicLineFields) {
		this.dynamicLineFields = dynamicLineFields;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

//	public boolean isExpenseReport() {
//		return isExpenseReport;
//	}
//
//	public void setExpenseReport(boolean isExpenseReport) {
//		this.isExpenseReport = isExpenseReport;
//	}

	public boolean isRemitToAddress() {
		return isRemitToAddress;
	}

	public void setRemitToAddress(boolean isRemitToAddress) {
		this.isRemitToAddress = isRemitToAddress;
	}

	public boolean isShipToAddress() {
		return isShipToAddress;
	}

	public void setShipToAddress(boolean isShipToAddress) {
		this.isShipToAddress = isShipToAddress;
	}

	public boolean isDefaultSelected() {
		return defaultSelected;
	}

	public void setDefaultSelected(boolean defaultSelected) {
		this.defaultSelected = defaultSelected;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public boolean isPortalApproval() {
		return portalApproval;
	}

	public void setPortalApproval(boolean portalApproval) {
		this.portalApproval = portalApproval;
	}

	public boolean isPdfCreate() {
		return pdfCreate;
	}

	public void setPdfCreate(boolean pdfCreate) {
		this.pdfCreate = pdfCreate;
	}

	public boolean isAdhoc() {
		return adhoc;
	}

	public void setAdhoc(boolean adhoc) {
		this.adhoc = adhoc;
	}

	public String getPdfCreateDocType() {
		return pdfCreateDocType;
	}

	public void setPdfCreateDocType(String pdfCreateDocType) {
		this.pdfCreateDocType = pdfCreateDocType;
	}

	public String getWorkflowEngine() {
		return workflowEngine;
	}

	public void setWorkflowEngine(String workflowEngine) {
		this.workflowEngine = workflowEngine;
	}

	public boolean isAddressEditable() {
		return addressEditable;
	}

	public void setAddressEditable(boolean addressEditable) {
		this.addressEditable = addressEditable;
	}

	public boolean isRetention() {
		return retention;
	}

	public void setRetention(boolean retention) {
		this.retention = retention;
	}

	public int getRetentionPeriod() {
		return retentionPeriod;
	}

	public void setRetentionPeriod(int retentionPeriod) {
		this.retentionPeriod = retentionPeriod;
	}

	public List<FormField> getCustomHeaderFields() {
		return customHeaderFields;
	}

	public void setCustomHeaderFields(List<FormField> customHeaderFields) {
		this.customHeaderFields = customHeaderFields;
	}

	public boolean isRequestorCreatorValidation() {
		return requestorCreatorValidation;
	}

	public void setRequestorCreatorValidation(boolean requestorCreatorValidation) {
		this.requestorCreatorValidation = requestorCreatorValidation;
	}

	public boolean isOneTime() {
		return oneTime;
	}

	public void setOneTime(boolean oneTime) {
		this.oneTime = oneTime;
	}

	public String getDefaultVendor() {
		return defaultVendor;
	}

	public void setDefaultVendor(String defaultVendor) {
		this.defaultVendor = defaultVendor;
	}

	public List<DocumentTypeDTO> getDocumentTypes() {
		return documentTypes;
	}

	public void setDocumentTypes(List<DocumentTypeDTO> documentTypes) {
		this.documentTypes = documentTypes;
	}

	public double getTolerance() {
		return tolerance;
	}

	public void setTolerance(double tolerance) {
		this.tolerance = tolerance;
	}
	
	
	
}
