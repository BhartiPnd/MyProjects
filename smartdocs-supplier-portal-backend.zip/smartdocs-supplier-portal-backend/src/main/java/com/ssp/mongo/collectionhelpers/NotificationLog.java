package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;
import java.util.List;

public class NotificationLog {
	private long id;
	private ZonedDateTime dateTime;
	private List<String> recipients;
	private String status;
	
	
	public NotificationLog(long id, ZonedDateTime dateTime, List<String> recipients, String status) {
		super();
		this.id = id;
		this.dateTime = dateTime;
		this.recipients = recipients;
		this.status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public List<String> getRecipients() {
		return recipients;
	}
	public void setRecipients(List<String> recipients) {
		this.recipients = recipients;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
