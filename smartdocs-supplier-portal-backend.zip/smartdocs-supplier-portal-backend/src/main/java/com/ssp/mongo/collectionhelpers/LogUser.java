package com.ssp.mongo.collectionhelpers;

import com.ssp.security.services.UserPrinciple;

public class LogUser {
	
	private String email;
	private String firstname;
	private String lastname;
	private String supplier;
	private String supplierId;
	private String role;
	private String companycode;
	
	public LogUser(){
		
	}
 
	public LogUser(UserPrinciple user){
		this.email=user.getEmail();
		this.firstname=user.getName();
		this.supplier=user.getSupplier();
		this.supplierId=user.getSupplierId();
		this.role=user.getRole();
		
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
 
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	 
    
}
