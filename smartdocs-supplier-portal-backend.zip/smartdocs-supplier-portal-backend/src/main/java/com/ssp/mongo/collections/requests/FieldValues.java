package com.ssp.mongo.collections.requests;

public class FieldValues {
	private String identifier;
	private String name;
	private String title;
	private String fieldType;
	private String value;
	
	public String getIdentifier() {
		return identifier;
	}
	public String getName() {
		return name;
	}
	public String getTitle() {
		return title;
	}
	public String getFieldType() {
		return fieldType;
	}
	public String getValue() {
		return value;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
