package com.ssp.mongo.collections;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="urlbuffer")
public class UrlBuffer {

	private String id;
	private String docCreatekey;
	private String companyId;
	private String systemId;
	private String clientId;
	private String archiveDocId;
	private String url;
	private String expiryTimeStamp;
	private boolean takenFlag;

	private String filename;
	private String filetype;
	private String uploadstatus;
	private String attachmentfor;

	public UrlBuffer(String url) {
		super();
		this.url = url;
	}

	public UrlBuffer(String id, String url, boolean takenFlag) {
		super();
		this.id = id;
		this.url = url;
		this.takenFlag = takenFlag;
	}

	public UrlBuffer(String id, String docCreatekey, String companyId,
			String systemId, String clientId, String archiveDocId, String url,
			String expiryTimeStamp, boolean takenFlag, String attachmentfor) {
		super();
		this.id = id;
		this.docCreatekey = docCreatekey;
		this.companyId = companyId;
		this.systemId = systemId;
		this.clientId = clientId;
		this.archiveDocId = archiveDocId;
		this.url = url;
		this.expiryTimeStamp = expiryTimeStamp;
		this.takenFlag = takenFlag;
		this.attachmentfor = attachmentfor;
	}

	public UrlBuffer() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocCreatekey() {
		return docCreatekey;
	}
	public void setDocCreatekey(String docCreatekey) {
		this.docCreatekey = docCreatekey;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getArchiveDocId() {
		return archiveDocId;
	}
	public void setArchiveDocId(String archiveDocId) {
		this.archiveDocId = archiveDocId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getExpiryTimeStamp() {
		return expiryTimeStamp;
	}
	public void setExpiryTimeStamp(String expiryTimeStamp) {
		this.expiryTimeStamp = expiryTimeStamp;
	}
	public boolean isTakenFlag() {
		return takenFlag;
	}
	public void setTakenFlag(boolean takenFlag) {
		this.takenFlag = takenFlag;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFiletype() {
		return filetype;
	}

	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}

	public String getUploadstatus() {
		return uploadstatus;
	}

	public void setUploadstatus(String uploadstatus) {
		this.uploadstatus = uploadstatus;
	}

	public String getAttachmentfor() {
		return attachmentfor;
	}

	public void setAttachmentfor(String attachmentfor) {
		this.attachmentfor = attachmentfor;
	}

	@Override
	public String toString() {
		return "UrlBuffer [id=" + id + ", docCreatekey=" + docCreatekey
				+ ", companyId=" + companyId + ", systemId=" + systemId
				+ ", clientId=" + clientId + ", archiveDocId=" + archiveDocId
				+ ", url=" + url + ", expiryTimeStamp=" + expiryTimeStamp
				+ ", takenFlag=" + takenFlag + "]";
	}

}
