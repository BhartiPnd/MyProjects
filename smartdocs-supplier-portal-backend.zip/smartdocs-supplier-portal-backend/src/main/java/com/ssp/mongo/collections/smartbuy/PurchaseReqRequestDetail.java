package com.ssp.mongo.collections.smartbuy;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.ticket.Ticket;
import com.ssp.mongo.collections.workflow.WorkItem;

@Document(collection = "PurchaseReqRequest")
public class PurchaseReqRequestDetail {
	
	@Id
	private String id;
	private String requestId;
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private Double amount;
	private String currency;
	private ZonedDateTime createdDate;
	private String status;
	private String createdBy;
	private String plant;
	private String storageLocation;
	private List<DocumentHelper> attachments;
	private Double totalAmount;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private String receiverEmail;
	private String receiverName;
	private List<GIReceiver> receivers;
	private boolean syncToSAP;
	//newly added
	private String type;
	private String typeDesc;
	private String agentName;
	private String requestorEmail;
	private GeneralState state;
	private WorkItem workItem;
	private String company;
	private String purchasingGroupDesc;
	private String purchasingOrgDesc;
	private String paymentTermsDesc;
	private String requestor;
	private List<PurchaseReqRequestLine> requestItems;
	private List<Ticket> tickets;
	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getPaymentTermsDesc() {
		return paymentTermsDesc;
	}

	public void setPaymentTermsDesc(String paymentTermsDesc) {
		this.paymentTermsDesc = paymentTermsDesc;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getStorageLocation() {
		return storageLocation;
	}

	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public boolean isSAPSynch() {
		return isSAPSynch;
	}

	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}

	public List<PurchaseReqRequestLine> getRequestItems() {
		return requestItems;
	}

	public void setRequestItems(List<PurchaseReqRequestLine> requestItems) {
		this.requestItems = requestItems;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public List<GIReceiver> getReceivers() {
		return receivers;
	}

	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}
	
	
	
}
