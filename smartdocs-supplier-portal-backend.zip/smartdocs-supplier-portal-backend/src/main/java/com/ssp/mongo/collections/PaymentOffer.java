package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

@Document(collection = "paymentoffer")
public class PaymentOffer {

	@Id
	private String id;
	private String invoicenumber;
	private String systemid;
	private String companycode;
	private String creator;
	private String status;
	private Double discountamount;
	private Double amount;
	private String currency;
	private Double taxamount;
	private String paymentterms;
	private Integer createdate;
	private Integer createtime;
	private List<DocumentHelper> attachments;

	private Long modifieddatetime;

	public PaymentOffer() {
		super();
	}

	public PaymentOffer(String id, String invoicenumber, String systemid,
			String companycode, String creator, String status,
			Double discountamount, Double amount, String currency,
			Double taxamount, String paymentterms, Integer createdate,
			Integer createtime, List<DocumentHelper> attachments) {
		super();
		this.id = id;
		this.invoicenumber = invoicenumber;
		this.systemid = systemid;
		this.companycode = companycode;
		this.creator = creator;
		this.status = status;
		this.discountamount = discountamount;
		this.amount = amount;
		this.currency = currency;
		this.taxamount = taxamount;
		this.paymentterms = paymentterms;
		this.createdate = createdate;
		this.createtime = createtime;
		this.attachments = attachments;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInvoicenumber() {
		return invoicenumber;
	}

	public void setInvoicenumber(String invoicenumber) {
		this.invoicenumber = invoicenumber;
	}

	public String getSystemid() {
		return systemid;
	}

	public void setSystemid(String systemid) {
		this.systemid = systemid;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getDiscountamount() {
		return discountamount;
	}

	public void setDiscountamount(Double discountamount) {
		this.discountamount = discountamount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getTaxamount() {
		return taxamount;
	}

	public void setTaxamount(Double taxamount) {
		this.taxamount = taxamount;
	}

	public String getPaymentterms() {
		return paymentterms;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public Integer getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Integer createdate) {
		this.createdate = createdate;
	}

	public Integer getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Integer createtime) {
		this.createtime = createtime;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	@Override
	public String toString() {
		return "PaymentOffer [id=" + id + ", invoicenumber=" + invoicenumber
				+ ", systemid=" + systemid + ", companycode=" + companycode
				+ ", creator=" + creator + ", status=" + status
				+ ", discountamount=" + discountamount + ", amount=" + amount
				+ ", currency=" + currency + ", taxamount=" + taxamount
				+ ", paymentterms=" + paymentterms + ", createdate="
				+ createdate + ", createtime=" + createtime + ", attachments="
				+ attachments
				+ ", modifieddatetime=" + modifieddatetime + "]";
	}

}
