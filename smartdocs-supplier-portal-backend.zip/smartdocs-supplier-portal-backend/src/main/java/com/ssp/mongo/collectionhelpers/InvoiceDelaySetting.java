package com.ssp.mongo.collectionhelpers;

public class InvoiceDelaySetting {
	public static String DAYS = "DAYS";
	public static String HOURS = "HOURS";
	public static String MINUTS = "MINUTS";

	private String type;
	private int count;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	

}
