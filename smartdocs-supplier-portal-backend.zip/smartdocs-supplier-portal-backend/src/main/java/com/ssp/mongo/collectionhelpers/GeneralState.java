package com.ssp.mongo.collectionhelpers;

import com.ssp.mongo.collections.workflow.WorkFlowState;

public class GeneralState {
	
	private String status;
	private String stlStatus;
	private	WorkFlowState wfState;
	public GeneralState() {
		super();
	}
	public GeneralState(String status, String stlStatus, WorkFlowState wfState) {
		super();
		this.status = status;
		this.stlStatus = stlStatus;
		this.wfState = wfState;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStlStatus() {
		return stlStatus;
	}
	public void setStlStatus(String stlStatus) {
		this.stlStatus = stlStatus;
	}
	public WorkFlowState getWfState() {
		return wfState;
	}
	public void setWfState(WorkFlowState wfState) {
		this.wfState = wfState;
	}
	
	
}
