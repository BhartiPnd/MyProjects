package com.ssp.mongo.collections.dataObject;

import java.util.List;

import org.springframework.data.annotation.Id;

import com.ssp.mongo.collections.Supplier;
import com.ssp.mongo.collections.VendorCatalog;

public class MaterialMasterDetail {

	
	@Id
	private String code;
	private String desc;
	
	private String uom;
	private String uomDesc;
	private String grp;
	private String grpDesc;
	
	private String matType;
	private String hsnCode;
	
	private Supplier suggestedVendor;
	
	private List<Supplier> suppliers;
	
	private List<VendorCatalog> catalog;
	
	public MaterialMasterDetail(MaterialMaster materialMaster) {
		super();
		this.code = materialMaster.getCode();
		this.desc = materialMaster.getDesc();
		this.uom = materialMaster.getUom();
		this.grp = materialMaster.getGrp();
		this.grpDesc = materialMaster.getGrpDesc();
		this.matType = materialMaster.getMatType();
		this.uomDesc = materialMaster.getUomDesc();
	 
	}

	public MaterialMasterDetail() {
		super();
		
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getGrp() {
		return grp;
	}

	public void setGrp(String grp) {
		this.grp = grp;
	}

	public String getGrpDesc() {
		return grpDesc;
	}

	public void setGrpDesc(String grpDesc) {
		this.grpDesc = grpDesc;
	}

	public String getMatType() {
		return matType;
	}

	public void setMatType(String matType) {
		this.matType = matType;
	}

	public String getHsnCode() {
		return hsnCode;
	}

	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}

	public List<Supplier> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<Supplier> suppliers) {
		this.suppliers = suppliers;
	}

	public Supplier getSuggestedVendor() {
		return suggestedVendor;
	}

	public void setSuggestedVendor(Supplier suggestedVendor) {
		this.suggestedVendor = suggestedVendor;
	}

	public List<VendorCatalog> getCatalog() {
		return catalog;
	}

	public void setCatalog(List<VendorCatalog> catalog) {
		this.catalog = catalog;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}
	
	
	
}
