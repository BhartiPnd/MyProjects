package com.ssp.mongo.collections;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Buyers")
public class Buyers {

	@Id
	public String id;
	public String user;
	public String companyCode;
	public String purchasingOrg;
	
	public Buyers( ) {
		super();
	}
	public Buyers(String id, String user, String companyCode, String purchasingOrg) {
		super();
		
		if(StringUtils.isEmpty(purchasingOrg)) 
		{
			this.id = companyCode+"_"+user+"_*";
			
		}else {
			this.id = companyCode+"_"+user+"_"+purchasingOrg;
		}
		
		this.user = user;
		this.companyCode = companyCode;
		this.purchasingOrg = purchasingOrg;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	
	
}
