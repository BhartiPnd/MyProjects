package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class VendorData {

	private String vendorId;
	private String vendorName;
	private ZonedDateTime validFrom;
	private ZonedDateTime validTo;
	private Boolean fixSupply;

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public ZonedDateTime getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(ZonedDateTime validFrom) {
		this.validFrom = validFrom;
	}

	public ZonedDateTime getValidTo() {
		return validTo;
	}

	public void setValidTo(ZonedDateTime validTo) {
		this.validTo = validTo;
	}

	public Boolean getFixSupply() {
		return fixSupply;
	}

	public void setFixSupply(Boolean fixSupply) {
		this.fixSupply = fixSupply;
	}

	

}
