package com.ssp.mongo.collectionhelpers;

public class ImageHelper {

	private String base64;
	private String filetype;
	
	public ImageHelper(String base64, String filetype) {
		super();
		this.base64 = base64;
		this.filetype = filetype;
	}
	public ImageHelper() {
		super();
	}
	public String getBase64() {
		return base64;
	}
	public void setBase64(String base64) {
		this.base64 = base64;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	@Override
	public String toString() {
		return "ImageHelper [base64=" + base64 + ", filetype=" + filetype + "]";
	}
	
}
