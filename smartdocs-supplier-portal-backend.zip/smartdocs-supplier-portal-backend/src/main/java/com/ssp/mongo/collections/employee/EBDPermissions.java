package com.ssp.mongo.collections.employee;

public class EBDPermissions {
	
	private String agent;
	private boolean view;
	private boolean add;
	private boolean edit;
	private boolean delete;
	private boolean download;
	private boolean plh;
	private boolean rhl;
	private boolean version;
	
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public boolean isAdd() {
		return add;
	}
	public void setAdd(boolean add) {
		this.add = add;
	}
	public boolean isEdit() {
		return edit;
	}
	public void setEdit(boolean edit) {
		this.edit = edit;
	}
	public boolean isDelete() {
		return delete;
	}
	public void setDelete(boolean delete) {
		this.delete = delete;
	}
	
	public boolean isDownload() {
		return download;
	}
	public void setDownload(boolean download) {
		this.download = download;
	}
	public boolean isPlh() {
		return plh;
	}
	public void setPlh(boolean plh) {
		this.plh = plh;
	}
	public boolean isRhl() {
		return rhl;
	}
	public void setRhl(boolean rhl) {
		this.rhl = rhl;
	}
	public boolean isVersion() {
		return version;
	}
	public void setVersion(boolean version) {
		this.version = version;
	}
	public boolean isView() {
		return view;
	}
	public void setView(boolean view) {
		this.view = view;
	}

	
}
