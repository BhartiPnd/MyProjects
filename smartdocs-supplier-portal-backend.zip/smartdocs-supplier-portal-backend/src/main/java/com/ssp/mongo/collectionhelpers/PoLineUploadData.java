package com.ssp.mongo.collectionhelpers;

public class PoLineUploadData {

	private String invoice;
	private String carton;
	private String ucc;
	private String  po;
	private String sku;
	private String quantity;
	private String  line;
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getCarton() {
		return carton;
	}
	public void setCarton(String carton) {
		this.carton = carton;
	}
	public String getUcc() {
		return ucc;
	}
	public void setUcc(String ucc) {
		this.ucc = ucc;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public PoLineUploadData() {}
	public PoLineUploadData(String invoice, String carton, String ucc, String po, String sku, String quantity,
			String line) {
		super();
		this.invoice = invoice;
		this.carton = carton;
		this.ucc = ucc;
		this.po = po;
		this.sku = sku;
		this.quantity = quantity;
		this.line = line;
	}
	
	@Override
	public String toString() {
		return "PoLineUploadData [invoice=" + invoice + ", carton=" + carton + ", ucc=" + ucc + ", po=" + po + ", sku="
				+ sku + ", quantity=" + quantity + ", line=" + line + "]";
	}	
}
