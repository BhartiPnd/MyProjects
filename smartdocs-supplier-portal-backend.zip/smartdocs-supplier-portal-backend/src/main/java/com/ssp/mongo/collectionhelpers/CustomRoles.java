package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class CustomRoles {

	private String supplierId;
	private List<String> roles;
	public CustomRoles() {
		super();
	}
	public CustomRoles(String supplierId, List<String> roles) {
		super();
		this.supplierId = supplierId;
		this.roles = roles;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	 
	
}
