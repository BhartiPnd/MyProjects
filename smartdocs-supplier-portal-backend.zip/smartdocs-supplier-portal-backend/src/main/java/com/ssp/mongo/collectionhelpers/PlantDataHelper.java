package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;
import java.util.List;

public class PlantDataHelper 
{
	private String plant;
	private String hsnCode;
	private String plantDesc;
	private String priceCntrl;
	private Double stndPrice;
	private Double movPrice;
	private Double priceCFactor;
	private String poNumber;
	private Double poUnitPrice;
	private ZonedDateTime poSyncDate;
	private String inventoryGl;
	private String invoiceGl;
	private String fixedStorageLoc;
	private List<StorageLoc> storageLocs;
	private List<VendorData> fixedVendors;
	private List<UomPriceFactor> factors;
	
	public PlantDataHelper() {
		super();
	}
	
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getHsnCode() {
		return hsnCode;
	}
	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}
	public String getPlantDesc() {
		return plantDesc;
	}
	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}
	public String getPriceCntrl() {
		return priceCntrl;
	}
	public void setPriceCntrl(String priceCntrl) {
		this.priceCntrl = priceCntrl;
	}
	public Double getStndPrice() {
		return stndPrice;
	}
	public void setStndPrice(Double stndPrice) {
		this.stndPrice = stndPrice;
	}
	public Double getMovPrice() {
		return movPrice;
	}
	public void setMovPrice(Double movPrice) {
		this.movPrice = movPrice;
	}
	public Double getPriceCFactor() {
		return priceCFactor;
	}

	public void setPriceCFactor(Double priceCFactor) {
		this.priceCFactor = priceCFactor;
	}

	public Double getPoUnitPrice() {
		return poUnitPrice;
	}

	public void setPoUnitPrice(Double poUnitPrice) {
		this.poUnitPrice = poUnitPrice;
	}

	public ZonedDateTime getPoSyncDate() {
		return poSyncDate;
	}

	public void setPoSyncDate(ZonedDateTime poSyncDate) {
		this.poSyncDate = poSyncDate;
	}
	
	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	public String getInventoryGl() {
		return inventoryGl;
	}

	public void setInventoryGl(String inventoryGl) {
		this.inventoryGl = inventoryGl;
	}

	public String getInvoiceGl() {
		return invoiceGl;
	}

	public void setInvoiceGl(String invoiceGl) {
		this.invoiceGl = invoiceGl;
	}

	public String getFixedStorageLoc() {
		return fixedStorageLoc;
	}

	public void setFixedStorageLoc(String fixedStorageLoc) {
		this.fixedStorageLoc = fixedStorageLoc;
	}

	public List<StorageLoc> getStorageLocs() {
		return storageLocs;
	}

	public void setStorageLocs(List<StorageLoc> storageLocs) {
		this.storageLocs = storageLocs;
	}

	public List<VendorData> getFixedVendors() {
		return fixedVendors;
	}

	public void setFixedVendors(List<VendorData> fixedVendors) {
		this.fixedVendors = fixedVendors;
	}

	@Override
	public String toString() {
		return "PlantDataHelper [plant=" + plant + ", hsnCode=" + hsnCode + ", plantDesc=" + plantDesc + ", priceCntrl="
				+ priceCntrl + ", stndPrice=" + stndPrice + ", movPrice=" + movPrice + ", priceCFactor=" + priceCFactor
				+ ", poUnitPrice=" + poUnitPrice + ", poSyncDate=" + poSyncDate + "]";
	}

	public List<UomPriceFactor> getFactors() {
		return factors;
	}

	public void setFactors(List<UomPriceFactor> factors) {
		this.factors = factors;
	}

	
}
