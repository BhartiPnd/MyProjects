package com.ssp.mongo.collectionhelpers;


public class GRItm {
	
	//private Integer PO_LNE;
	/*private String MAT_CODE;
	private String MAT_DES;
	private Double QTY;
	private String UOM;
	private String PLANT;
	private String SPARTNO;
	private String SLOCATION;
	private ZonedDateTime GR_DATE;*/
	private String MAT_CODE;
	private String MAT_DES;
	private Double QTY;
	private String UOM;
	private String PLANT;
	private String SPARTNO;
	private String SLOCATION;
	private String GR_DATE;
	private String PO_NO;
	private String PO_ITEM;
	private String STATUS;
	private String AMNT;
	private String CURRENCY;
	private String GR_ITEM_NO;
	private String GR_ITEM_DES;
	private boolean CATCH_WEIGHT;
	private double DELIVERED_QTY;
	private String DELIVERED_UOM;
	public Long PER;
	public String PER_UOM;
	public String UNIT_PRICE;
	
	private String plantDesc;
	private  String storageLocationDesc;
	private String uomDesc;
	
	public GRItm() {
		super();
	}
	//private Address shipToAddress;
 
	 
	public String getMAT_CODE() {
		return MAT_CODE;
	}

	public String getMAT_DES() {
		return MAT_DES;
	}

	public Double getQTY() {
		return QTY;
	}

	public String getUOM() {
		return UOM;
	}

	public String getPLANT() {
		return PLANT;
	}

	public String getSPARTNO() {
		return SPARTNO;
	}

	public String getSLOCATION() {
		return SLOCATION;
	}

	public void setMAT_CODE(String mAT_CODE) {
		MAT_CODE = mAT_CODE;
	}

	public void setMAT_DES(String mAT_DES) {
		MAT_DES = mAT_DES;
	}

	public void setQTY(Double qTY) {
		QTY = qTY;
	}

	public void setUOM(String uOM) {
		UOM = uOM;
	}

	public void setPLANT(String pLANT) {
		PLANT = pLANT;
	}

	public void setSPARTNO(String sPARTNO) {
		SPARTNO = sPARTNO;
	}

	public void setSLOCATION(String sLOCATION) {
		SLOCATION = sLOCATION;
	}


	public String getGR_DATE() {
		return GR_DATE;
	}


	public String getPO_NO() {
		return PO_NO;
	}


	public String getPO_ITEM() {
		return PO_ITEM;
	}


	public String getSTATUS() {
		return STATUS;
	}


	public String getAMNT() {
		return AMNT;
	}


	public String getCURRENCY() {
		return CURRENCY;
	}


	public String getGR_ITEM_NO() {
		return GR_ITEM_NO;
	}


	public String getGR_ITEM_DES() {
		return GR_ITEM_DES;
	}


	public void setGR_DATE(String gR_DATE) {
		GR_DATE = gR_DATE;
	}


	public void setPO_NO(String pO_NO) {
		PO_NO = pO_NO;
	}


	public void setPO_ITEM(String pO_ITEM) {
		PO_ITEM = pO_ITEM;
	}


	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}


	public void setAMNT(String aMNT) {
		AMNT = aMNT;
	}


	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}


	public void setGR_ITEM_NO(String gR_ITEM_NO) {
		GR_ITEM_NO = gR_ITEM_NO;
	}


	public void setGR_ITEM_DES(String gR_ITEM_DES) {
		GR_ITEM_DES = gR_ITEM_DES;
	}


	public String getPlantDesc() {
		return plantDesc;
	}


	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}


	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}


	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}


	public String getUomDesc() {
		return uomDesc;
	}


	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}


	public boolean isCATCH_WEIGHT() {
		return CATCH_WEIGHT;
	}


	public void setCATCH_WEIGHT(boolean cATCH_WEIGHT) {
		CATCH_WEIGHT = cATCH_WEIGHT;
	}


	public double getDELIVERED_QTY() {
		return DELIVERED_QTY;
	}


	public void setDELIVERED_QTY(double dELIVERED_QTY) {
		DELIVERED_QTY = dELIVERED_QTY;
	}


	public String getDELIVERED_UOM() {
		return DELIVERED_UOM;
	}


	public void setDELIVERED_UOM(String dELIVERED_UOM) {
		DELIVERED_UOM = dELIVERED_UOM;
	}
 
}
