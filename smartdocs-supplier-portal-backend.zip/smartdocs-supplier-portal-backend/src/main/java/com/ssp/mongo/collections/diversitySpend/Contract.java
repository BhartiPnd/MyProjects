package com.ssp.mongo.collections.diversitySpend;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.ContractLineItems;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.NotificationLog;


@Document(collection = "Contract")
public class Contract {
	
	@Id
	private String id;

	private String number;
	private String name;
	
	// central or parent
	private String type;
	
	private String contractType;
	private String owner;
	
	private String supplierId;
	private String supplierName;
	private Address supplierAddress;
	
	private String description;
	private String status;
	
	@Field("startDate")
	private ZonedDateTime startDate;
	@Field("endDate")
	private ZonedDateTime endDate;
	
	
	@Field("createdDate")
	private ZonedDateTime createdDate;
	
	private String createdBy;
	
	private String purchasingOrganization;
	private String purchasingGroup;
	private String paymentTerms;
	@Field("buyer")
	private String buyer;
	
	private Address remitToAddress ;

	// Portal only field will use for construction DB report submission. 
	private boolean commitmentSheetUploaded;
	
	private List<ContractLineItems> contractLineItems;
	private List<DocumentHelper> attachments;
	private List<DocumentHelper> originalDocuments;
	//Contract Amount
	private Double targetValue;
	
	// Contract Amount Paid Till Date 
	private Double amountPaidTillDate;
	
	//Released Value
	private Double relValue;
	private String currency;

		
	private Float dbGoalPercent;
	private Double dbGoalAmount;

	
	private String purchasingOrgDesc;
	private String purchasingGroupDesc;
    
	private String statusDesc;
	private boolean notified=true;
	
	private LatestDBSubmission dbSubmission;
	
	private List<NotificationLog> notificationLogs;
 

	public String getId() {
		return id;
	}


	public String getNumber() {
		return number;
	}


	public String getName() {
		return name;
	}


	public String getType() {
		return type;
	}


	public String getOwner() {
		return owner;
	}


	public String getSupplierId() {
		return supplierId;
	}


	public String getDescription() {
		return description;
	}


	public String getStatus() {
		return status;
	}


	public ZonedDateTime getStartDate() {
		return startDate;
	}


	public ZonedDateTime getEndDate() {
		return endDate;
	}


	public Double getTargetValue() {
		return targetValue;
	}


	public Double getRelValue() {
		return relValue;
	}


	public String getCurrency() {
		return currency;
	}


	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public String getPurchasingOrganization() {
		return purchasingOrganization;
	}


	public String getPurchasingGroup() {
		return purchasingGroup;
	}


	public String getPaymentTerms() {
		return paymentTerms;
	}


	public List<ContractLineItems> getContractLineItems() {
		return contractLineItems;
	}


	public List<DocumentHelper> getAttachments() {
		return attachments;
	}


	public void setId(String id) {
		this.id = id;
	}


	public void setNumber(String number) {
		this.number = number;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setType(String type) {
		this.type = type;
	}


	public void setOwner(String owner) {
		this.owner = owner;
	}


	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}


	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}


	public void setTargetValue(Double targetValue) {
		this.targetValue = targetValue;
	}


	public void setRelValue(Double relValue) {
		this.relValue = relValue;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public void setPurchasingOrganization(String purchasingOrganization) {
		this.purchasingOrganization = purchasingOrganization;
	}


	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}


	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}


	public void setContractLineItems(List<ContractLineItems> contractLineItems) {
		this.contractLineItems = contractLineItems;
	}


	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}


	public Float getDbGoalPercent() {
		return dbGoalPercent;
	}


	public Double getDbGoalAmount() {
		return dbGoalAmount;
	}


	public Double getAmountPaidTillDate() {
		return amountPaidTillDate;
	}


	public void setDbGoalPercent(Float dbGoalPercent) {
		this.dbGoalPercent = dbGoalPercent;
	}


	public void setDbGoalAmount(Double dbGoalAmount) {
		this.dbGoalAmount = dbGoalAmount;
	}


	public void setAmountPaidTillDate(Double amountPaidTillDate) {
		this.amountPaidTillDate = amountPaidTillDate;
	}


	public String getContractType() {
		return contractType;
	}


	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

/*	public double getDbPercentOfAmountPaidtoPrimeVendor() {
		return dbPercentOfAmountPaidtoPrimeVendor;
	}


	public void setDbPercentOfAmountPaidtoPrimeVendor(double dbPercentOfAmountPaidtoPrimeVendor) {
		this.dbPercentOfAmountPaidtoPrimeVendor = dbPercentOfAmountPaidtoPrimeVendor;
	}


	public double getTotalDBAmountPaidtillDate() {
		return totalDBAmountPaidtillDate;
	}


	public double getDbGoalAchivedPercent() {
		return dbGoalAchivedPercent;
	}


	public void setTotalDBAmountPaidtillDate(double totalDBAmountPaidtillDate) {
		this.totalDBAmountPaidtillDate = totalDBAmountPaidtillDate;
	}


	public void setDbGoalAchivedPercent(double dbGoalAchivedPercent) {
		this.dbGoalAchivedPercent = dbGoalAchivedPercent;
	}


	public double getTotalCommitedAmount() {
		return totalCommitedAmount;
	}


	public double getTotalEarnedTillDate() {
		return totalEarnedTillDate;
	}


	public double getTotalPaidTillDate() {
		return totalPaidTillDate;
	}


	public void setTotalCommitedAmount(double totalCommitedAmount) {
		this.totalCommitedAmount = totalCommitedAmount;
	}


	public void setTotalEarnedTillDate(double totalEarnedTillDate) {
		this.totalEarnedTillDate = totalEarnedTillDate;
	}


	public void setTotalPaidTillDate(double totalPaidTillDate) {
		this.totalPaidTillDate = totalPaidTillDate;
	}


	public boolean isFinalReport() {
		return finalReport;
	}


	public void setFinalReport(boolean finalReport) {
		this.finalReport = finalReport;
	}
*/

	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public Address getSupplierAddress() {
		return supplierAddress;
	}


	public void setSupplierAddress(Address supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	public List<DocumentHelper> getOriginalDocuments() {
		return originalDocuments;
	}
	public void setOriginalDocuments(List<DocumentHelper> originalDocuments) {
		this.originalDocuments = originalDocuments;
	}


	public String getBuyer() {
		return buyer;
	}


	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}


	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}


	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}


	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}


	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}


	public String getStatusDesc() {
		return statusDesc;
	}


	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}


	public boolean isCommitmentSheetUploaded() {
		return commitmentSheetUploaded;
	}

	public void setCommitmentSheetUploaded(boolean commitmentSheetUploaded) {
		this.commitmentSheetUploaded = commitmentSheetUploaded;
	}

	public boolean isNotified() {
		return notified;
	}
	public void setNotified(boolean notified) {
		this.notified = notified;
	}

	public LatestDBSubmission getDbSubmission() {
		return dbSubmission;
	}

	public void setDbSubmission(LatestDBSubmission dbSubmission) {
		this.dbSubmission = dbSubmission;
	}


	public List<NotificationLog> getNotificationLogs() {
		return notificationLogs;
	}


	public void setNotificationLogs(List<NotificationLog> notificationLogs) {
		this.notificationLogs = notificationLogs;
	}


	public Address getRemitToAddress() {
		return remitToAddress;
	}


	public void setRemitToAddress(Address remitToAddress) {
		this.remitToAddress = remitToAddress;
	}
	
	
	
}
