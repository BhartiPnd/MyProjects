package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.RfxPermission;

@Document(collection = "RfxTeamMember")
public class RfxTeamMember {
	
	@Id
	private String id;
	private String rfxNo;
	private String name;
	private String email;
	private RfxPermission permission;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public RfxPermission getPermission() {
		return permission;
	}
	public void setPermission(RfxPermission permission) {
		this.permission = permission;
	}
	
	
	
}
