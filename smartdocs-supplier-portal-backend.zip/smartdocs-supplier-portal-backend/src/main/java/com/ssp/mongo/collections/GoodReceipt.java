package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.CommentLog;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GRItm;

@Document(collection = "goodsReceipt")
public class GoodReceipt {

	@Id
	private String id;
	private String ponumber;
	private String supplierId;
	private String grreference;
	private String createdBy;
	private String notes;
	private String grrId;
	
	private String grNo;
	private String fYear;
	private String creator;
	private String grRefNo;
	
	private String sapInvoiceNo;
	//	
	//	private long sspGRNumber;
	//	private Integer FYEAR;
	private ZonedDateTime grDate;
	
	//private Long GR_REF;
	private List<GRItm> items;
	private List<DocumentHelper> attachments;

	private List<CommentLog> commentLogs;
	
	
	private ZonedDateTime createdDate;

	private Boolean isSAPSynch;
	private ZonedDateTime sapSynchDate;
	private Boolean isSAPSynchACK;
	
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPonumber() {
		return ponumber;
	}
	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getGrreference() {
		return grreference;
	}
	public void setGrreference(String grreference) {
		this.grreference = grreference;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public ZonedDateTime getGrDate() {
		return grDate;
	}
	public List<GRItm> getItems() {
		return items;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public ZonedDateTime getSapSynchDate() {
		return sapSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setGrDate(ZonedDateTime grDate) {
		this.grDate = grDate;
	}
	public void setItems(List<GRItm> items) {
		this.items = items;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSapSynchDate(ZonedDateTime sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	 
	public List<CommentLog> getCommentLogs() {
		return commentLogs;
	}
	 
	public void setCommentLogs(List<CommentLog> commentLogs) {
		this.commentLogs = commentLogs;
	}
	 
     
    public void addCommentLogs(String commentLogs,String userId) {
		if((commentLogs!=null && !commentLogs.trim().equals(""))) {
			if(this.getCommentLogs()==null){
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(false,commentLogs,userId));
		}
	
	}
	public void addCommentLogs(boolean workFlow,String commentLogs,String userId,String oldStatus,String newStatus) {
		if(workFlow || (commentLogs!=null && !commentLogs.trim().equals(""))) {
			if(this.getCommentLogs()==null){
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(workFlow,commentLogs,userId,oldStatus,newStatus));
		}
	}
	public String getGrNo() {
		return grNo;
	}
	public String getfYear() {
		return fYear;
	}
	public String getCreator() {
		return creator;
	}
	public String getGrRefNo() {
		return grRefNo;
	}
	public void setGrNo(String grNo) {
		this.grNo = grNo;
	}
	public void setfYear(String fYear) {
		this.fYear = fYear;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public void setGrRefNo(String grRefNo) {
		this.grRefNo = grRefNo;
	}
	public String getSapInvoiceNo() {
		return sapInvoiceNo;
	}
	public void setSapInvoiceNo(String sapInvoiceNo) {
		this.sapInvoiceNo = sapInvoiceNo;
	}
	public String getGrrId() {
		return grrId;
	}
	public void setGrrId(String grrId) {
		this.grrId = grrId;
	}
	
}
