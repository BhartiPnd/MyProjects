package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "currencyconvert")
public class CurrencyConverter 
{
	@Id
	private String id;
	
	private String from;
	private String to;
	private String extraType;
	private Double extraValue;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getExtraType() {
		return extraType;
	}

	public void setExtraType(String extraType) {
		this.extraType = extraType;
	}

	public Double getExtraValue() {
		return extraValue;
	}

	public void setExtraValue(Double extraValue) {
		this.extraValue = extraValue;
	}
	
	 
}
