package com.ssp.mongo.collections.list;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "capaRequestType")
public class CapaRequestType {
	
	@Id
	private String id;
	private String key;
	private String desc;
	
	public CapaRequestType() {
		super();
	}
	public CapaRequestType(String key, String desc) {
		super();
		this.key = key;
		this.desc = desc;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}	
}
