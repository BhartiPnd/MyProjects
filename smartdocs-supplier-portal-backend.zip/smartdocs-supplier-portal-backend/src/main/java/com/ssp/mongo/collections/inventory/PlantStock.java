package com.ssp.mongo.collections.inventory;

import java.util.List;

public class PlantStock {

	private String companyCode;
	private String plantCode;
	private String plantDesc;
	
	private Double unresStock;
	private Double qainsStock;
	
	private Double reservedStock;
	private Double onRoadStock;
	private Double slocTransderStock;
	private Double grBlockedStock;
	private Double breturnedStock;
	private Double blockedStock;
	
	
	private List<StorageLocationStock> slocStock;
	
//	Extra field for tolerance
	private Double pendingTolerance;
	private Double pendingQuantity;
	private Double usedQuantity;
	
	

	public PlantStock() {
		super();
	}
	



	public String getPlantCode() {
		return plantCode;
	}


	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}


	public String getPlantDesc() {
		return plantDesc;
	}


	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}


	public Double getUnresStock() {
		return unresStock;
	}


	public void setUnresStock(Double unresStock) {
		this.unresStock = unresStock;
	}


	public Double getQainsStock() {
		return qainsStock;
	}


	public void setQainsStock(Double qainsStock) {
		this.qainsStock = qainsStock;
	}


	public Double getReservedStock() {
		return reservedStock;
	}


	public void setReservedStock(Double reservedStock) {
		this.reservedStock = reservedStock;
	}


	public Double getOnRoadStock() {
		return onRoadStock;
	}


	public void setOnRoadStock(Double onRoadStock) {
		this.onRoadStock = onRoadStock;
	}


	public Double getSlocTransderStock() {
		return slocTransderStock;
	}


	public void setSlocTransderStock(Double slocTransderStock) {
		this.slocTransderStock = slocTransderStock;
	}


	public Double getGrBlockedStock() {
		return grBlockedStock;
	}


	public void setGrBlockedStock(Double grBlockedStock) {
		this.grBlockedStock = grBlockedStock;
	}


	public Double getBreturnedStock() {
		return breturnedStock;
	}


	public void setBreturnedStock(Double breturnedStock) {
		this.breturnedStock = breturnedStock;
	}


	public Double getBlockedStock() {
		return blockedStock;
	}


	public void setBlockedStock(Double blockedStock) {
		this.blockedStock = blockedStock;
	}


	public List<StorageLocationStock> getSlocStock() {
		return slocStock;
	}


	public void setSlocStock(List<StorageLocationStock> slocStock) {
		this.slocStock = slocStock;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public Double getPendingTolerance() {
		return pendingTolerance;
	}

	public void setPendingTolerance(Double pendingTolerance) {
		this.pendingTolerance = pendingTolerance;
	}

	public Double getPendingQuantity() {
		return pendingQuantity;
	}

	public void setPendingQuantity(Double pendingQuantity) {
		this.pendingQuantity = pendingQuantity;
	}

	public Double getUsedQuantity() {
		return usedQuantity;
	}

	public void setUsedQuantity(Double usedQuantity) {
		this.usedQuantity = usedQuantity;
	}	
	
	
	
}
