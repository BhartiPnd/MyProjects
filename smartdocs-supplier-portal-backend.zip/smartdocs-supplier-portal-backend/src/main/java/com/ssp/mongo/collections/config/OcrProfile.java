package com.ssp.mongo.collections.config;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "OcrProfile")
public class OcrProfile {

	@Id
	private String id;
	
	private String name;
	
	private String host;
	private String url;
	private String auth;
	
	private String projectId;
	private String roleType;
	private String stationType;
	
	private String batchName;
	private String projectNameOrGuid;
	private String ownerId;
	
	private String errorStatus;
	
	private String lastUpdatedBy;
	private ZonedDateTime lastupdated;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getStationType() {
		return stationType;
	}

	public void setStationType(String stationType) {
		this.stationType = stationType;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public String getProjectNameOrGuid() {
		return projectNameOrGuid;
	}

	public void setProjectNameOrGuid(String projectNameOrGuid) {
		this.projectNameOrGuid = projectNameOrGuid;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public ZonedDateTime getLastupdated() {
		return lastupdated;
	}

	public void setLastupdated(ZonedDateTime lastupdated) {
		this.lastupdated = lastupdated;
	}
	 
	
}
