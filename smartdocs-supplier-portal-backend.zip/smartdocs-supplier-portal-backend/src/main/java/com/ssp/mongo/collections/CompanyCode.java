package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.ToleranceConfig;

@Document(collection = "companycode")
public class CompanyCode {

	@Id
	private String id;
	private String companycode;
	private String name;
	
	// this means this is head office or main organization.
	private boolean isMain;
	
	private Address primaryAddress;
	private List<Address> address;
	//private List<Address> shiptoaddress;

	private Long createddatetime;
	private Long modifieddatetime;
	
	private ToleranceConfig toleranceConfig;
	private EsclationConfig esclationConfig;

	public CompanyCode() {
		super();
	}

	public CompanyCode(String id, String companycode, String name,List<Address> address) {
		super();
		this.id = id;
		this.companycode = companycode;
		this.name = name;
		this.address = address;
		//this.shiptoaddress = shiptoaddress;
	}
	public CompanyCode(  String companycode, String name,List<Address> address) {
		super();
		this.companycode = companycode;
		this.name = name;
		this.address = address;
		//this.shiptoaddress = shiptoaddress;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

 
	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	@Override
	public String toString() {
		return "CompanyCode [id=" + id + ", companycode=" + companycode
				+ ", name=" + name + ", address="
				+ address  
				+ ", createddatetime=" + createddatetime
				+ ", modifieddatetime=" + modifieddatetime + "]";
	}

	public void copy(CompanyCode cc){
		this.companycode = cc.getCompanycode();
		this.name = cc.getName();
		this.address = cc.getAddress();
		//this.shiptoaddress = cc.getShiptoaddress();
	}

	public Address getPrimaryAddress() {
		return primaryAddress;
	}

	public void setPrimaryAddress(Address primaryAddress) {
		this.primaryAddress = primaryAddress;
	}

	public boolean isMain() {
		return isMain;
	}

	public void setMain(boolean isMain) {
		this.isMain = isMain;
	}

	public ToleranceConfig getToleranceConfig() {
		return toleranceConfig;
	}

	public void setToleranceConfig(ToleranceConfig toleranceConfig) {
		this.toleranceConfig = toleranceConfig;
	}

	public EsclationConfig getEsclationConfig() {
		return esclationConfig;
	}

	public void setEsclationConfig(EsclationConfig esclationConfig) {
		this.esclationConfig = esclationConfig;
	}
	
}
