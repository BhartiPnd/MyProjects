package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class AdhocApprover {
	
	private int step;
	private List<String> approvers;
	
	public int getStep() {
		return step;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	
}
