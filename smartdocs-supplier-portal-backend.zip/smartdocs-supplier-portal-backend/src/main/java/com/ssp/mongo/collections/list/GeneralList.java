package com.ssp.mongo.collections.list;

import org.springframework.data.annotation.Id;

public class GeneralList {

	@Id
	private String id;
	private String title;
	private String desc;
	private String documentType;
	private String verificationSource;
	private boolean certificationDateRequire;
	private boolean attachmentRequire;
	private int order;
	//private String type;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
 
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
 
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public boolean isCertificationDateRequire() {
		return certificationDateRequire;
	}
	public boolean isAttachmentRequire() {
		return attachmentRequire;
	}
	public void setCertificationDateRequire(boolean certificationDateRequire) {
		this.certificationDateRequire = certificationDateRequire;
	}
	public void setAttachmentRequire(boolean attachmentRequire) {
		this.attachmentRequire = attachmentRequire;
	}
	 
/*	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}*/
	
}
