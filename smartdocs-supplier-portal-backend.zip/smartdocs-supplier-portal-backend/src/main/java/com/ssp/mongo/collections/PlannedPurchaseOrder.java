package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "PlannedPurchaseOrder")
public class PlannedPurchaseOrder {

	@Id
	private String id;
	
	private String orderNo;
	
	private String materialDescription;
	
	private String material;
	
	private ZonedDateTime openDate;
	  
	private ZonedDateTime startDate;
	 
	private ZonedDateTime finishDate;
	
	private int weekNo;
	private int year;
	
	private Double qty;
	
	private ZonedDateTime availableDate;
	 
	private String grProcessingTime;
 
	private String productionPlant;
	
	private String storageLocation;
	
	private String bombExplosion;
	
	private String purchasingOrg;
	
	private String fixVendor;
	  
	private String outlineAgreement;
	
	private String centralContact;
	
	private String quoteAgreement;
	
	private String mrpController;
	
	private String purhcasingGroup;
	 
	private String accAssignmentCategory;
	
	private String specialStock;
	
	private String consumption;
	
	private String saleOrder;
	
	private String wbsElement;
	
	private String plannedDeliveryTime;
	
	private String lotSize;
	
	private String fixedLotSize;

	private String minLotSize;
	 
	private String maxLotSize;
	 
	private String roundingValue;
	 
	private String totalReplyLeadTime;
	 
	private String maxStockLevel;
	
	private String roundingProfile;
	
	private String supplierId;
	
	private String companyCode;

	private String unitOfMeasure;
	
	private boolean ploExists;
	
	public PlannedPurchaseOrder() {
		super();
	}
	 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getMaterialDescription() {
		return materialDescription;
	}

	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public ZonedDateTime getOpenDate() {
		return openDate;
	}

	public void setOpenDate(ZonedDateTime openDate) {
		this.openDate = openDate;
	}

	public ZonedDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}

	public ZonedDateTime getFinishDate() {
		return finishDate;
	}

	public void setFinishDate(ZonedDateTime finishDate) {
		this.finishDate = finishDate;
	}

	public Double getQty() {
		return qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	public ZonedDateTime getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(ZonedDateTime availableDate) {
		this.availableDate = availableDate;
	}

	public String getGrProcessingTime() {
		return grProcessingTime;
	}

	public void setGrProcessingTime(String grProcessingTime) {
		this.grProcessingTime = grProcessingTime;
	}

	public String getProductionPlant() {
		return productionPlant;
	}

	public void setProductionPlant(String productionPlant) {
		this.productionPlant = productionPlant;
	}

	public String getStorageLocation() {
		return storageLocation;
	}

	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}

	public String getBombExplosion() {
		return bombExplosion;
	}

	public void setBombExplosion(String bombExplosion) {
		this.bombExplosion = bombExplosion;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getFixVendor() {
		return fixVendor;
	}

	public void setFixVendor(String fixVendor) {
		this.fixVendor = fixVendor;
	}

	public String getOutlineAgreement() {
		return outlineAgreement;
	}

	public void setOutlineAgreement(String outlineAgreement) {
		this.outlineAgreement = outlineAgreement;
	}

	public String getCentralContact() {
		return centralContact;
	}

	public void setCentralContact(String centralContact) {
		this.centralContact = centralContact;
	}

	public String getQuoteAgreement() {
		return quoteAgreement;
	}

	public void setQuoteAgreement(String quoteAgreement) {
		this.quoteAgreement = quoteAgreement;
	}

	public String getMrpController() {
		return mrpController;
	}

	public void setMrpController(String mrpController) {
		this.mrpController = mrpController;
	}

	public String getPurhcasingGroup() {
		return purhcasingGroup;
	}

	public void setPurhcasingGroup(String purhcasingGroup) {
		this.purhcasingGroup = purhcasingGroup;
	}

	public String getAccAssignmentCategory() {
		return accAssignmentCategory;
	}

	public void setAccAssignmentCategory(String accAssignmentCategory) {
		this.accAssignmentCategory = accAssignmentCategory;
	}

	public String getSpecialStock() {
		return specialStock;
	}

	public void setSpecialStock(String specialStock) {
		this.specialStock = specialStock;
	}

	public String getConsumption() {
		return consumption;
	}

	public void setConsumption(String consumption) {
		this.consumption = consumption;
	}

	public String getSaleOrder() {
		return saleOrder;
	}

	public void setSaleOrder(String saleOrder) {
		this.saleOrder = saleOrder;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public String getPlannedDeliveryTime() {
		return plannedDeliveryTime;
	}

	public void setPlannedDeliveryTime(String plannedDeliveryTime) {
		this.plannedDeliveryTime = plannedDeliveryTime;
	}

	public String getLotSize() {
		return lotSize;
	}

	public void setLotSize(String lotSize) {
		this.lotSize = lotSize;
	}

	public String getFixedLotSize() {
		return fixedLotSize;
	}

	public void setFixedLotSize(String fixedLotSize) {
		this.fixedLotSize = fixedLotSize;
	}

	public String getMinLotSize() {
		return minLotSize;
	}

	public void setMinLotSize(String minLotSize) {
		this.minLotSize = minLotSize;
	}

	public String getMaxLotSize() {
		return maxLotSize;
	}

	public void setMaxLotSize(String maxLotSize) {
		this.maxLotSize = maxLotSize;
	}

	public String getRoundingValue() {
		return roundingValue;
	}

	public void setRoundingValue(String roundingValue) {
		this.roundingValue = roundingValue;
	}

	public String getTotalReplyLeadTime() {
		return totalReplyLeadTime;
	}

	public void setTotalReplyLeadTime(String totalReplyLeadTime) {
		this.totalReplyLeadTime = totalReplyLeadTime;
	}

	public String getMaxStockLevel() {
		return maxStockLevel;
	}

	public void setMaxStockLevel(String maxStockLevel) {
		this.maxStockLevel = maxStockLevel;
	}

	public String getRoundingProfile() {
		return roundingProfile;
	}

	public void setRoundingProfile(String roundingProfile) {
		this.roundingProfile = roundingProfile;
	}

	public int getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(int weekNo) {
		this.weekNo = weekNo;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public boolean isPloExists() {
		return ploExists;
	}

	public void setPloExists(boolean ploExists) {
		this.ploExists = ploExists;
	}
	
	
}

