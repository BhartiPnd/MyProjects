package com.ssp.mongo.collections.inventory;

import java.util.List;


public class InventoryUom {

	private String uom;
	private List<PlantStock> plantStock;
	
	public InventoryUom() {
		super();
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public List<PlantStock> getPlantStock() {
		return plantStock;
	}

	public void setPlantStock(List<PlantStock> plantStock) {
		this.plantStock = plantStock;
	}
	
	
	
}
