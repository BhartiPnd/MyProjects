package com.ssp.mongo.collectionhelpers;

public class BankAccount {
	
	private String bnk_name;
	private String bnk_address;
	private String bnk_acc_no;
	private String bnk_cntry_key;
	private String bnk_routing_no;

	public BankAccount() {
		super();
	}

	public BankAccount(String bnk_name, String bnk_address, String bnk_cntry_key, String bnk_acc_no,String bnk_routing_no) {
		super();		
		this.bnk_name = bnk_name;
		this.bnk_address = bnk_address;
		this.bnk_acc_no = bnk_acc_no;
		this.bnk_cntry_key = bnk_cntry_key;
		this.bnk_routing_no = bnk_routing_no;
	}	

	public String getBnk_cntry_key() {
		return bnk_cntry_key;
	}
	public void setBnk_cntry_key(String bnk_cntry_key) {
		this.bnk_cntry_key = bnk_cntry_key;
	}

	public String getBnk_name() {
		return bnk_name;
	}
	public void setBnk_name(String bnk_name) {
		this.bnk_name = bnk_name;
	}
	
	public String getBnk_acc_no() {
		return bnk_acc_no;
	}
	public void setBnk_acc_no(String bnk_acc_no) {
		this.bnk_acc_no = bnk_acc_no;
	}

	public String getBnk_address() {
		return bnk_address;
	}
	public void setBnk_address(String bnk_address) {
		this.bnk_address = bnk_address;
	}

	public String getBnk_routing_no() {
		return bnk_routing_no;
	}

	public void setBnk_routing_no(String bnk_routing_no) {
		this.bnk_routing_no = bnk_routing_no;
	}
	
}
