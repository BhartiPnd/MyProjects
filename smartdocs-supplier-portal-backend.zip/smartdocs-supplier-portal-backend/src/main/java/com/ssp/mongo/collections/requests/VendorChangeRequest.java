package com.ssp.mongo.collections.requests;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.AchRequest;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.Contact;
import com.ssp.mongo.collectionhelpers.DBChangeRequest;
import com.ssp.mongo.collectionhelpers.DBESelectedStatus;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.OtherChangeRequest;
import com.ssp.mongo.collectionhelpers.ProductCategoriesChangeRequest;
import com.ssp.mongo.collectionhelpers.TaxAndW9Change;
import com.ssp.mongo.collections.Agent;

@Document(collection = "VendorChangeRequest")
public class VendorChangeRequest {
 
    public static final String CHANGE_ADDRESS = "AddressChange";
 	public static final String CHANGE_PRODUCT_CATEGORY = "ProductCategoryChange";
 	public static final String CHANGE_ACH = "ACHChange";
 	public static final String CHANGE_DBE ="DiverseBusinessUpdate";
 	public static final String CONTACT ="Contact";
 	public static final String BANK_DETAIl_CHANGE = "BankDetailChange";
 	
 	public static final String PAYMENT_TERMS_CHANGE = "PaymentsTermsChange";
 //	public static final String CHANGE_TAXANDW9 ="TaxAndW9Change";
 	public static final String OTHER ="Other";
 	public static final String CHANGE_TAXANDW9 ="TaxAndW9Change";
 	
 
	public static final String ACTION_ADD="Add";
	public static final String ACTION_UPDATE="Update";
	public static final String ACTION_DELETE="Delete";
	
	@Id
	private String id;
	private String prefix; 
	private long refId;
	
	private String type; 
	private String companyCode;
	private String supplierId;
	private String status;
	 
	private String createdUserId;
	private String createdUserName;
	
	private ZonedDateTime createdDate;
	
	//TODO : to be changed with zonedate time.
	private Long createddatetime;
	private Long modifieddatetime;
	private Long lastUpdated;

	private List<DocumentHelper> attachments;
	
	// action approve reject. 	
	//private String notes;
	
	// submit + resubmit 
	private String comment;
	
	// if address Change Request.

	private String action;
	// Leagal Status changes
//	private String legalStatus;
	//private String orgSME;
	private Address address;
	private Contact contact;
	private AchRequest achRequest;
	private DBChangeRequest dbeChangeRequest; 
	private ProductCategoriesChangeRequest pccr; 
	private OtherChangeRequest other;
	private TaxAndW9Change taxAndW9;
	private String paymentsTerms;
	
	private BankDetailChange bankDetailChange;
	
	private Boolean isSAPSynch;
	private Long sapSynchDate;
	private Boolean isSAPSynchACK;
	
	//private boolean isCollaborated;
	//private String collaboratedUser;
	private List<ActivityLog> activityLogs;
	private String statusDesc;
	private boolean syncToSAP;
	private String agentName;
	private GeneralState state;
	
	private String requestorEmail;
	
	private String activityCode;
	
	public VendorChangeRequest() {
		super();
		this.createdDate=ZonedDateTime.now();
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	 
	public String getSupplierId() {
		return supplierId;
	}
	
	 

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	
	public void setSAPSynch(boolean syncSAP) {
		this.isSAPSynch = syncSAP;
	}
	public Long getSapSynchDate() {
		return sapSynchDate;
	}

	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}


	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public Long getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Long lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	public AchRequest getAchRequest() {
		return achRequest;
	}

	public void setAchRequest(AchRequest achRequest) {
		this.achRequest = achRequest;
	}

	 


	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public long getRefId() {
		return refId;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	 
	 

	public DBChangeRequest getDbeChangeRequest() {
		return dbeChangeRequest;
	}

	public void setDbeChangeRequest(DBChangeRequest dbeChangeRequest) {
		this.dbeChangeRequest = dbeChangeRequest;
	}

	public ProductCategoriesChangeRequest getPccr() {
		return pccr;
	}

	public void setPccr(ProductCategoriesChangeRequest pccr) {
		this.pccr = pccr;
	}

	/*public boolean isCollaborated() {
		return isCollaborated;
	}

	public void setCollaborated(boolean isCollaborated) {
		this.isCollaborated = isCollaborated;
	}

	public String getCollaboratedUser() {
		return collaboratedUser;
	}

	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}*/

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	public void addAttachments(List<DocumentHelper>  attachments,String uploadedBy,int usrUploaded) {
		resetAttachmentUploadeByInfo( attachments, uploadedBy, usrUploaded);
		if(attachments!=null && attachments.size()>0) {
			if(this.getAttachments()==null){
				this.setAttachments(new ArrayList<>());
			}
			for(DocumentHelper docHelper:attachments) {
				this.getAttachments().add(docHelper);
			}
		}
		else {
			
		}
	}
	
	public OtherChangeRequest getOther() {
		return other;
	}

	public void setOther(OtherChangeRequest other) {
		this.other = other;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public List<DocumentHelper> resetAttachmentUploadeByInfo(List<DocumentHelper> attachments,String uploadedBy,int usrUploaded) {
		if(attachments!=null && attachments.size()>0)
		{
			for(DocumentHelper attachment:attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
				
			}
			
		}
		return attachments;
	}
	
	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public TaxAndW9Change getTaxAndW9() {
		return taxAndW9;
	}

	public BankDetailChange getBankDetailChange() {
		return bankDetailChange;
	}

	public void setBankDetailChange(BankDetailChange bankDetailChange) {
		this.bankDetailChange = bankDetailChange;
	}

	public void setTaxAndW9(TaxAndW9Change taxAndW9) {
		this.taxAndW9 = taxAndW9;
	}

	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		 
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					} 
				}
			}
			if(this.dbeChangeRequest!=null && dbeChangeRequest.getDbeSelectedStatus()!=null && dbeChangeRequest.getDbeSelectedStatus().size()>0) {
				for(DBESelectedStatus dbs:dbeChangeRequest.getDbeSelectedStatus()) 
				{
					if(dbs.getAttachment()!=null) {
						if(dbs.getAttachment().getUploadedDate()==null) {
							dbs.getAttachment().setUploadedDate(ZonedDateTime.now());
						}
						if(dbs.getAttachment().getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
							dbs.getAttachment().setUploadedBy(uploadedBy);
							dbs.getAttachment().setUsrUploaded(usrUploaded);
						}
					}
				}
			}
			if(this.taxAndW9!=null &&   this.taxAndW9.getAttachment()!=null)  {
				if(this.taxAndW9.getAttachment().getUploadedDate()==null) {
					this.taxAndW9.getAttachment().setUploadedDate(ZonedDateTime.now());
				}
				if(this.taxAndW9.getAttachment().getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					this.taxAndW9.getAttachment().setUploadedBy(uploadedBy);
					this.taxAndW9.getAttachment().setUsrUploaded(usrUploaded);
				}
			}
		
	}
	public String getRequestId() {
		return String.valueOf(this.refId);
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}

	
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getPaymentsTerms() {
		return paymentsTerms;
	}
	public void setPaymentsTerms(String paymentsTerms) {
		this.paymentsTerms = paymentsTerms;
	}
	
}
