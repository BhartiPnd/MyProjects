package com.ssp.mongo.collections.config.system;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collections.employee.EmployeePermission;

@Document(collection = "SystemConfiguration")
public class EmployeeMasterConfig {

	public static final String EMPLOYEE_CONFIG = "employee_config";
	
	@Id
	private String id;
	
	private String primaryDocType;
	
	private List<EmployeePermission> permissions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPrimaryDocType() {
		return primaryDocType;
	}

	public void setPrimaryDocType(String primaryDocType) {
		this.primaryDocType = primaryDocType;
	}

	public List<EmployeePermission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<EmployeePermission> permissions) {
		this.permissions = permissions;
	}
	
	
	
}
