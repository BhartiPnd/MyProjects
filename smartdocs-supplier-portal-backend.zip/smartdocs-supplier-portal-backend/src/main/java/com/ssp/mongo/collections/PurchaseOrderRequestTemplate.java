package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.ssp.mongo.collectionhelpers.PurchaseOrderReqTemplateLineItems;
 
@Document(collection = "PurchaseOrderRequestTemplate")
public class PurchaseOrderRequestTemplate {
	
	@Id
	private String id;
	private String companyCode;
	private String title;
	private String owner;
	private String global;
	private String porType;
	private String notes;
	private ZonedDateTime createdDateTime;
	private List<PurchaseOrderReqTemplateLineItems> items;
	
	public PurchaseOrderRequestTemplate() {
		super();
		this.createdDateTime = ZonedDateTime.now();
		 
	}
	public PurchaseOrderRequestTemplate(String title, String owner, String global, String porType ,
			List<PurchaseOrderReqTemplateLineItems> items) {
		super();
		this.title = title;
		this.owner = owner;
		this.global = global;
		this.porType = porType;
		this.createdDateTime = ZonedDateTime.now();
		this.items = items;
	}
	

	
	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getOwner() {
		return owner;
	}

	public String getGlobal() {
		return global;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void setGlobal(String global) {
		this.global = global;
	}
	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getPorType() {
		return porType;
	}
	public void setPorType(String porType) {
		this.porType = porType;
	}
	public List<PurchaseOrderReqTemplateLineItems> getItems() {
		return items;
	}
	public void setItems(List<PurchaseOrderReqTemplateLineItems> items) {
		this.items = items;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
}
