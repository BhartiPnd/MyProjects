package com.ssp.mongo.collectionhelpers;

public class DiverseBusinessStatus {

	private Boolean isMinorityBusinessEnterprise;
	private Long minorityBusinessEnterpriseDate;
	
	private Boolean isWomenBusinessEnterprise;
	private Long womenBusinessEnterpriseDate;
	
	private Boolean isSmallBusinessEnterprise;
	private Long smallBusinessEnterpriseDate;
	
	private Boolean isVeteranBusinessEnterprise;
	private Long veteranBusinessEnterpriseDate;
	
	private Boolean isServiceBusinessEnterprise;
	private Long serviceBusinessEnterpriseDate;
	
	public DiverseBusinessStatus() {
		super();
	}
	
	public DiverseBusinessStatus(Boolean isMinorityBusinessEnterprise, Long minorityBusinessEnterpriseDate,
			Boolean isWomenBusinessEnterprise, Long womenBusinessEnterpriseDate, Boolean isSmallBusinessEnterprise,
			Long smallBusinessEnterpriseDate, Boolean isVeteranBusinessEnterprise, Long veteranBusinessEnterpriseDate,
			Boolean isServiceBusinessEnterprise, Long serviceBusinessEnterpriseDate) {
		super();
		this.isMinorityBusinessEnterprise = isMinorityBusinessEnterprise;
		this.minorityBusinessEnterpriseDate = minorityBusinessEnterpriseDate;
		this.isWomenBusinessEnterprise = isWomenBusinessEnterprise;
		this.womenBusinessEnterpriseDate = womenBusinessEnterpriseDate;
		this.isSmallBusinessEnterprise = isSmallBusinessEnterprise;
		this.smallBusinessEnterpriseDate = smallBusinessEnterpriseDate;
		this.isVeteranBusinessEnterprise = isVeteranBusinessEnterprise;
		this.veteranBusinessEnterpriseDate = veteranBusinessEnterpriseDate;
		this.isServiceBusinessEnterprise = isServiceBusinessEnterprise;
		this.serviceBusinessEnterpriseDate = serviceBusinessEnterpriseDate;
	}

	public Boolean getIsMinorityBusinessEnterprise() {
		return isMinorityBusinessEnterprise;
	}
	public void setIsMinorityBusinessEnterprise(Boolean isMinorityBusinessEnterprise) {
		this.isMinorityBusinessEnterprise = isMinorityBusinessEnterprise;
	}

	public Long getMinorityBusinessEnterpriseDate() {
		return minorityBusinessEnterpriseDate;
	}
	public void setMinorityBusinessEnterpriseDate(Long minorityBusinessEnterpriseDate) {
		this.minorityBusinessEnterpriseDate = minorityBusinessEnterpriseDate;
	}

	public Boolean getIsWomenBusinessEnterprise() {
		return isWomenBusinessEnterprise;
	}
	public void setIsWomenBusinessEnterprise(Boolean isWomenBusinessEnterprise) {
		this.isWomenBusinessEnterprise = isWomenBusinessEnterprise;
	}

	public Long getWomenBusinessEnterpriseDate() {
		return womenBusinessEnterpriseDate;
	}
	public void setWomenBusinessEnterpriseDate(Long womenBusinessEnterpriseDate) {
		this.womenBusinessEnterpriseDate = womenBusinessEnterpriseDate;
	}

	public Boolean getIsSmallBusinessEnterprise() {
		return isSmallBusinessEnterprise;
	}
	public void setIsSmallBusinessEnterprise(Boolean isSmallBusinessEnterprise) {
		this.isSmallBusinessEnterprise = isSmallBusinessEnterprise;
	}

	public Long getSmallBusinessEnterpriseDate() {
		return smallBusinessEnterpriseDate;
	}
	public void setSmallBusinessEnterpriseDate(Long smallBusinessEnterpriseDate) {
		this.smallBusinessEnterpriseDate = smallBusinessEnterpriseDate;
	}

	public Boolean getIsVeteranBusinessEnterprise() {
		return isVeteranBusinessEnterprise;
	}
	public void setIsVeteranBusinessEnterprise(Boolean isVeteranBusinessEnterprise) {
		this.isVeteranBusinessEnterprise = isVeteranBusinessEnterprise;
	}

	public Long getVeteranBusinessEnterpriseDate() {
		return veteranBusinessEnterpriseDate;
	}
	public void setVeteranBusinessEnterpriseDate(Long veteranBusinessEnterpriseDate) {
		this.veteranBusinessEnterpriseDate = veteranBusinessEnterpriseDate;
	}

	public Boolean getIsServiceBusinessEnterprise() {
		return isServiceBusinessEnterprise;
	}
	public void setIsServiceBusinessEnterprise(Boolean isServiceBusinessEnterprise) {
		this.isServiceBusinessEnterprise = isServiceBusinessEnterprise;
	}

	public Long getServiceBusinessEnterpriseDate() {
		return serviceBusinessEnterpriseDate;
	}
	public void setServiceBusinessEnterpriseDate(Long serviceBusinessEnterpriseDate) {
		this.serviceBusinessEnterpriseDate = serviceBusinessEnterpriseDate;
	}

	@Override
	public String toString() {
		return "DiverseBusinessStatus [isMinorityBusinessEnterprise=" + isMinorityBusinessEnterprise
				+ ", minorityBusinessEnterpriseDate=" + minorityBusinessEnterpriseDate + ", isWomenBusinessEnterprise="
				+ isWomenBusinessEnterprise + ", womenBusinessEnterpriseDate=" + womenBusinessEnterpriseDate
				+ ", isSmallBusinessEnterprise=" + isSmallBusinessEnterprise + ", smallBusinessEnterpriseDate="
				+ smallBusinessEnterpriseDate + ", isVeteranBusinessEnterprise=" + isVeteranBusinessEnterprise
				+ ", veteranBusinessEnterpriseDate=" + veteranBusinessEnterpriseDate + ", isServiceBusinessEnterprise="
				+ isServiceBusinessEnterprise + ", serviceBusinessEnterpriseDate=" + serviceBusinessEnterpriseDate
				+ "]";
	}
}
