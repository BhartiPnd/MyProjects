package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class ApprovalConfigStep {

	public static final String STEP_TYPE_CONDITIONAL="Conditional";
	public static final String STEP_TYPE_SEQUENCIAL="Sequencial";
			
	private int stepNo;
	private String stepType;
	private List<String> approvers;
	private List<ApprovalConfigCondition> configCondition;

	public int getStepNo() {
		return stepNo;
	}

	public void setStepNo(int stepNo) {
		this.stepNo = stepNo;
	}

	public String getStepType() {
		return stepType;
	}

	public void setStepType(String stepType) {
		this.stepType = stepType;
	}

	 
	public List<ApprovalConfigCondition> getConfigCondition() {
		return configCondition;
	}

	public void setConfigCondition(List<ApprovalConfigCondition> configCondition) {
		this.configCondition = configCondition;
	}

	public List<String> getApprovers() {
		return approvers;
	}

	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	
}
