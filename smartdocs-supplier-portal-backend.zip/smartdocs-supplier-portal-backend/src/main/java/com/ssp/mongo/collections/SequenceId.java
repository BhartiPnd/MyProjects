package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "sequence")
public class SequenceId {
	
	public static final String VENDOR_REGISTRATION_REQ="VendorRegistrationRequest";
	public static final String VENDOR_CHANGE_REQ="VendorChangeRequest";
	public static final String INVOICE="Invoice";
	public static final String EXPENSE="Expense";
	public static final String RFXBid="RFXBid";
	public static final String GRR_ACK="GoodReceiptRequest";
	public static final String ORDER_ACK="OrderConfirmation";
	public static final String ASN_ACK="AdvanceShippingNotice";
	public static final String PURCORDERREQ="PurchaseOrderReq";
	public static final String EmployeeMasterDoc="EmployeeMasterDoc";
	public static final String PURCREQREQ="PurchaseReqRequest";
	public static final String RFX="Rfx";
	public static final String BIDSHEET="BidSheet";
	public static final String GOODS_ISSUE="GoodsIssue";
	
	public static final String DB_SUBMISSION_REPORT="DBReport";
	//public static final String GOODS_RECEIPTS="GoodsReceipt";
	//public static final String ORDER_CONFIRMATION="OrderConfirmation";
	public static final String TICKETS="Tickets";
	public static final String WORKITEM="WorkItem";
	
	public static final String OCRINVOICEBATCH="OCIncoiceBatch";
	public static final String VENDOR_CONTACT_CHANGE_REQUEST = "VCCR";

	
    @Id
    private String id;

    private long seq;
    
    private long seqStart;
    
    private long seqEnd;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getSeq() {
        return seq;
    }

	public long getSeqStart() {
		return seqStart;
	}

	public void setSeqStart(long seqStart) {
		this.seqStart = seqStart;
	}

	public long getSeqEnd() {
		return seqEnd;
	}

	public void setSeqEnd(long seqEnd) {
		this.seqEnd = seqEnd;
	}
    
  
    
    
}