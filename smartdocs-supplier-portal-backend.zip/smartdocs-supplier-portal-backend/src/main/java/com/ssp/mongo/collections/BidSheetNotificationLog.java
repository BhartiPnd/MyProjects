package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "bidSheetNotificationLog")
public class BidSheetNotificationLog {
	
	@Id
	private String id;
	private String bidSheetId;
	private String from;
	private ZonedDateTime date;
	private String channel;
	private String emailSubject;
	private List<String> emailTo;
	private String vendorId;
	private String vendorName;
	private String status;

	
	public BidSheetNotificationLog() {
	}

	
	public BidSheetNotificationLog(String from, String channel, String emailSubject, List<String> emailTo) {
		super();
		this.from = from;
		this.channel = channel;
		this.emailSubject = emailSubject;
		this.emailTo = emailTo;
		this.date = ZonedDateTime.now();
	}
	
	public BidSheetNotificationLog(String bidSheetId, String from, String channel, String emailSubject, List<String> emailTo, String vendorId, 
			String vendorName, String status) {
		super();
		this.bidSheetId = bidSheetId;
		this.from = from;
		this.channel = channel;
		this.emailSubject = emailSubject;
		this.emailTo = emailTo;
		this.date = ZonedDateTime.now();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.status = status;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public List<String> getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(List<String> emailTo) {
		this.emailTo = emailTo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getFrom() {
		return from;
	}


	public void setFrom(String from) {
		this.from = from;
	}


	public String getVendorId() {
		return vendorId;
	}


	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}


	public String getVendorName() {
		return vendorName;
	}


	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getBidSheetId() {
		return bidSheetId;
	}


	public void setBidSheetId(String bidSheetId) {
		this.bidSheetId = bidSheetId;
	}
	
	
}
