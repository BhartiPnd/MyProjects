package com.ssp.mongo.collections.list;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "paymentterms")
public class PaymentTerms {
	
	@Id
	private String terms;
	private String description;
	private String companyCode;
	private int days;
	
	public PaymentTerms() {
		super();
	}
	public PaymentTerms(String terms, String description,String companyCode) {
		super();
		this.terms = terms;
		this.description = description;
		this.companyCode = companyCode;
	}
	public String getTerms() {
		return terms;
	}
	public void setTerms(String terms) {
		this.terms = terms;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	
}
