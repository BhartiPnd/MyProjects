package com.ssp.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "BidSheetSchedulerLog")
public class BidSheetSchedulerLog {
	
	@Id
	private String jobId;
	private String bidSheetNo;
	private String status;
	private ZonedDateTime triggeredDate;
	
	public BidSheetSchedulerLog() {
		super();
	}
	
	public BidSheetSchedulerLog(BidSheetSchedulerLog bid) {
		super();
		this.jobId = bid.jobId;
		this.bidSheetNo = bid.bidSheetNo;
		this.status = bid.status;
		this.triggeredDate = bid.triggeredDate;
	}
	
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getBidSheetNo() {
		return bidSheetNo;
	}
	public void setBidSheetNo(String bidSheetNo) {
		this.bidSheetNo = bidSheetNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ZonedDateTime getTriggeredDate() {
		return triggeredDate;
	}
	public void setTriggeredDate(ZonedDateTime triggeredDate) {
		this.triggeredDate = triggeredDate;
	}
	
	
	
}
