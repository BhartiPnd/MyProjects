package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class GRN {

	private Long GRNNO;
	private Integer FYEAR;
	private String GR_DATE;
	private Long GR_REF;
	private List<GRItm> GR_ITMS;

	public GRN() {
		super();
	}

	public GRN(Long gRNO, Integer fYEAR, String gR_DATE, Long gR_REF,
			List<GRItm> gR_ITMS) {
		super();
		GRNNO = gRNO;
		FYEAR = fYEAR;
		GR_DATE = gR_DATE;
		GR_REF = gR_REF;
		GR_ITMS = gR_ITMS;
	}

	public Long getGRNO() {
		return GRNNO;
	}

	public void setGRNO(Long gRNO) {
		GRNNO = gRNO;
	}

	public Integer getFYEAR() {
		return FYEAR;
	}

	public void setFYEAR(Integer fYEAR) {
		FYEAR = fYEAR;
	}

	public String getGR_DATE() {
		return GR_DATE;
	}

	public void setGR_DATE(String gR_DATE) {
		GR_DATE = gR_DATE;
	}

	public Long getGR_REF() {
		return GR_REF;
	}

	public void setGR_REF(Long gR_REF) {
		GR_REF = gR_REF;
	}

	public List<GRItm> getGR_ITMS() {
		return GR_ITMS;
	}

	public void setGR_ITMS(List<GRItm> gR_ITMS) {
		GR_ITMS = gR_ITMS;
	}

	@Override
	public String toString() {
		return "GRNHelper [GRNO=" + GRNNO + ", FYEAR=" + FYEAR + ", GR_DATE="
				+ GR_DATE + ", GR_REF=" + GR_REF + ", GR_ITMS=" + GR_ITMS + "]";
	}

}
