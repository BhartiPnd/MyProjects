package com.ssp.mongo.collections.requests;

public class TaxDetail {

	private String vatId;
	private String taxId;
	private String hst;
	private String gst;
	private String pst;
	
	
	public String getVatId() {
		return vatId;
	}
	public void setVatId(String vatId) {
		this.vatId = vatId;
	}
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public String getHst() {
		return hst;
	}
	public void setHst(String hst) {
		this.hst = hst;
	}
	public String getGst() {
		return gst;
	}
	public void setGst(String gst) {
		this.gst = gst;
	}
	public String getPst() {
		return pst;
	}
	public void setPst(String pst) {
		this.pst = pst;
	}
	
	
	
}
