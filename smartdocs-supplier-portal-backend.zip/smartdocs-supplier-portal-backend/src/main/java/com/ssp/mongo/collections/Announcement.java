package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;

/**
 * A Anouncements.
 */

@Document(collection = "announcement")
public class Announcement implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("title")
    private String title;

    @Field("description")
    private String description;

    

    @Field("duration_from")
    private ZonedDateTime durationFrom;

    @Field("duration_to")
    private ZonedDateTime durationTo;
 

    @Field("createddatetime")
    private Long createddatetime;
    
    @Field("modifieddatetime")
	private Long modifieddatetime;
    
    private List<DocumentHelper> attachments = null;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
    public String getTitle() {
        return title;
    }

    public Announcement title(String title) {
        this.title = title;
        return this;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public Announcement description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

   /* public String getAudience() {
        return audience;
    }

    public Anouncements audience(String audience) {
        this.audience = audience;
        return this;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }*/

    public ZonedDateTime getDurationFrom() {
        return durationFrom;
    }

    public Announcement durationFrom(ZonedDateTime durationFrom) {
        this.durationFrom = durationFrom;
        return this;
    }

    public void setDurationFrom(ZonedDateTime durationFrom) {
        this.durationFrom = durationFrom;
    }

    public ZonedDateTime getDurationTo() {
        return durationTo;
    }

    public Announcement durationTo(ZonedDateTime durationTo) {
        this.durationTo = durationTo;
        return this;
    }

    public void setDurationTo(ZonedDateTime durationTo) {
        this.durationTo = durationTo;
    }

   /* public String getAria() {
        return aria;
    }

    public Anouncements aria(String aria) {
        this.aria = aria;
        return this;
    }

    public void setAria(String aria) {
        this.aria = aria;
    }
*/
    public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Announcement anouncements = (Announcement) o;
        if (anouncements.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, anouncements.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Anouncements [id=");
		builder.append(id);
		builder.append(", title=");
		builder.append(title);
		builder.append(", description=");
		builder.append(description);
		builder.append(", durationFrom=");
		builder.append(durationFrom);
		builder.append(", durationTo=");
		builder.append(durationTo);
		builder.append(", createddatetime=");
		builder.append(createddatetime);
		builder.append(", modifieddatetime=");
		builder.append(modifieddatetime);
		builder.append(", attachments=");
		builder.append(attachments);
		builder.append("]");
		return builder.toString();
	}
}
