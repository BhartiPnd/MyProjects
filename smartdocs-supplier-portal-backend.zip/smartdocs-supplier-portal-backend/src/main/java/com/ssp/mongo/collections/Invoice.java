package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.config.GlobalConfig;
import com.ssp.dto.CreateInvoiceRequest;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.CommentLog;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.LineItems;
import com.ssp.mongo.collectionhelpers.POitmHelper;
import com.ssp.mongo.collectionhelpers.PlantDataHelper;
import com.ssp.mongo.collectionhelpers.UomPriceFactor;
import com.ssp.mongo.collections.dataObject.MaterialMaster;
import com.ssp.mongo.collections.requests.BankDetail;
import com.ssp.travler.InvoieValidationResult;

@Document(collection = "invoice")
public class Invoice extends AbstractAuditingEntity {

	public static final String CHANNAL_SSP = "PORTAL";
	public static final String CHANNAL_OCR = "OCR";
	public static final String CHANNAL_EMAIL = "EMAIL";
	public static final String CHANNAL_LAWTRACK = "LAWTRACK";

	public static final String STATUS_PARKED= "Parked";
	public static final String STATUS_POSTED = "Posted";
	
	@Id
	private String id;
	private long sspInvoiceReferenceNo;
	private String invoiceNumber;
	private String sapInvoiceNo;
	private String companyCode;
	private String supplierId;
	private String supplier;
	private BankDetail bankDetails;
	private boolean oneTime;
	// Invoice bufferId;
	private String tempBufferId;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime supplyDate;
	private ZonedDateTime postedDate;
	
	
	private String docheaderText;

	private Address remittoaddress;
	private Address shiptoaddress;

	private String currency;

	// input field.
	private float taxPercent; 
	//calculated
	private double subTotal;
	// editable.
	private double discount;
	// calculated
	private double netAmount;
	// editable
	private double taxAmount;
	// editable
	private double freightAmount;
	// calculated
	private double totalAmount;
	// input
	private double totalInvoiceAmount;
	 

	private String paymentterms;
	private String freightCarrier;
	private String poNumber;
	private String poDescription;

	// PO// NOnPo// Expense
	private String invoiceCategory;

	private String status;
	private String statusDesc;

	private Map<String, String> headerAttributes;
	private String invoiceType;
	private String creator;
	
	private boolean isCreatedByVendor;

	// Supplier portal or SAP.
	private String channel;

	private String requestId;

	// private String cadsNo;
	private DocumentHelper email;
	private String invoiceDocId;
	private List<DocumentHelper> attachments;
	private String notes;
	// private String comments;
	private List<LineItems> invoiceitems;

	private String buyer;
	private String requestor;

	private List<CommentLog> commentLogs;

	private boolean creditMemo;

	private String cadsNumber;
	private String billAccNumber;
	private String billAccName;

	private List<AdhocApprover> adhocApprovers;
	private List<ActivityLog> activityLogs;

//	private Boolean isSAPSynch;
//	private Long SAPSynchDate;
 	private boolean isSAPSynchACK;
	
	//private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	
	
	private String requestorEmail;
	private String shoppingCartNo;
	private String shipmentType;
	private boolean confidential;
	private boolean asset;
	private boolean afterFactPO;
	private List<InvoieValidationResult> validationResut;
	private String eventNumber;
	private String eventDescription;
	private boolean analyticsSyncStatus;
	private String bankAccountNumber;
	 
	
	
	private String costCenter;
	private String wbsElement;
    private String glAccount;
	private String accountNumber;
	private String approver;
	private ZonedDateTime invoiceDocumentDate;
	private String datesOfService;
	private String invoiceTypeCategory;
	private ZonedDateTime paidDate;
	private boolean visibleToVendor;
	
	private String agentName;
	private String sapAgentId;
	private boolean agentonSAPSide;
	private boolean exported;
	
	private String vatNumber;
	private boolean duplicate;
	private String logicalSystem;
	private String year;
	
	private String abaNo;
	private GeneralState state;
	private InvoieValidationResult exceptions;
	
	private String paymentMethod;
	private ActivityLog recentActivity;
	private List<String> approvers;
	private String businessArea;
	
	private ZonedDateTime holdDate;
	public Invoice() {
		super();
		this.state=new GeneralState();
	}
	
	public Invoice(InvoiceBuffer invoiceRequest, PurchaseOrder purchaseOrder, List<MaterialMaster> materials) {
		super();
		this.createdDate = ZonedDateTime.now();
		this.currency =StringUtils.isEmpty(invoiceRequest.getCurrency())? GlobalConfig.DEFAULT_CURRENCY:invoiceRequest.getCurrency();
		this.channel =StringUtils.isEmpty(invoiceRequest.getChannel())?  Invoice.CHANNAL_SSP:invoiceRequest.getChannel(); 
		//this.isSAPSynch = false;
		this.SAPSynchDate = null;
	//	this.syncToSAP = false;
		this.setTaxAmount(invoiceRequest.getTaxAmount());
		this.invoiceNumber = invoiceRequest.getInvoiceNumber();
		this.poNumber = invoiceRequest.getPoNumber();
		this.email = invoiceRequest.getEmail();
		this.supplierId = invoiceRequest.getSupplierId();
		this.companyCode = invoiceRequest.getCompanyCode();
		this.dueDate = invoiceRequest.getDueDate();
		this.supplyDate = invoiceRequest.getSupplyDate();
		this.invoiceDocId=invoiceRequest.getInvoiceDocId();
		this.remittoaddress = invoiceRequest.getRemitToAddress();
		this.shiptoaddress = invoiceRequest.getShipToAddress();
		this.creditMemo = invoiceRequest.isCreditMemo();
		this.subTotal = invoiceRequest.getSubTotal();  
														 
		//this.totalDiscount = invoiceRequest.getTotalDiscount(); 
		//this.additionalDiscount = invoiceRequest.getAdditionalDiscount(); 
		this.freightAmount = invoiceRequest.getFreightAmount(); 
		this.taxPercent = invoiceRequest.getTaxPercent();

		this.paymentterms = invoiceRequest.getPaymentterms();
		this.freightCarrier = invoiceRequest.getFreightCarrier();

		this.invoiceCategory = invoiceRequest.getInvoiceCategory();

		//this.headerAttributes = invoiceRequest.getHeaderAttributes();
		this.invoiceType = invoiceRequest.getInvoiceType();
		this.requestor=invoiceRequest.getRequestor();
		if(invoiceRequest.getRequestorEmail()!=null)
		{
			this.requestorEmail=invoiceRequest.getRequestorEmail().toLowerCase();
		}
		this.attachments = invoiceRequest.getAttachments();
		//this.notes = invoiceRequest.getNotes();
		this.invoiceitems = invoiceRequest.getInvoiceitems();
		this.tempBufferId=invoiceRequest.getId();
		this.invoiceDate = invoiceRequest.getInvoiceDate();
		this.state=new GeneralState();
        this.setVisibleToVendor(true);
        
        this.taxPercent=invoiceRequest.getTaxPercent();
        this.discount=invoiceRequest.getDiscount();
        this.taxAmount=invoiceRequest.getTaxAmount();
    	this.freightAmount = invoiceRequest.getFreightAmount(); 
        this.discount=invoiceRequest.getDiscount();
        this.totalInvoiceAmount=invoiceRequest.getTotalInvoiceAmount();
        this.asset=false;
        reCalculate(purchaseOrder, materials);
	}
	
	
	public Invoice(CreateInvoiceRequest invoiceRequest, PurchaseOrder purchaseOrder, List<MaterialMaster> materials) {
		super();
		this.createdDate = ZonedDateTime.now();
		
		if(StringUtils.isNotBlank(invoiceRequest.getCurrency()))
		{
			this.currency =invoiceRequest.getCurrency();
		}
		else {
			this.currency = GlobalConfig.DEFAULT_CURRENCY;
		}
		
		this.asset=invoiceRequest.isAsset();
		this.channel = Invoice.CHANNAL_SSP;
		//this.isSAPSynch = false;
		this.SAPSynchDate = null;
		//this.syncToSAP = false;
		
		this.invoiceNumber = invoiceRequest.getInvoiceNumber();
		this.poNumber = invoiceRequest.getPoNumber();

		this.supplierId = invoiceRequest.getSupplierId();

		this.dueDate = invoiceRequest.getDueDate();
		this.supplyDate = invoiceRequest.getSupplyDate();

		this.remittoaddress = invoiceRequest.getRemittoaddress();
		this.shiptoaddress = invoiceRequest.getShiptoaddress();

		//this.subTotal = invoiceRequest.getSubTotal();  
														 
		//this.totalDiscount = invoiceRequest.getTotalDiscount(); 
		//this.additionalDiscount = invoiceRequest.getAdditionalDiscount(); 

		this.paymentterms = invoiceRequest.getPaymentterms();
		this.freightCarrier = invoiceRequest.getFreightCarrier();

		this.invoiceCategory = invoiceRequest.getInvoiceCategory();

		this.headerAttributes = invoiceRequest.getHeaderAttributes();
		this.invoiceType = invoiceRequest.getInvoiceType();

		this.attachments = invoiceRequest.getAttachments();
		this.notes = invoiceRequest.getNotes();
		this.invoiceitems = invoiceRequest.getInvoiceitems();

		this.creditMemo = invoiceRequest.isCreditMemo();
		this.requestor = invoiceRequest.getRequestor();

		this.cadsNumber = invoiceRequest.getCadsNumber();
		this.billAccName = invoiceRequest.getBillAccName();
		this.billAccNumber = invoiceRequest.getBillAccNumber();
		this.invoiceDate = invoiceRequest.getInvoiceDate();
		this.shoppingCartNo = invoiceRequest.getShoppingCartNo();
		this.shipmentType = invoiceRequest.getShipmentType();
		this.confidential = invoiceRequest.isConfidential();
		this.poDescription = invoiceRequest.getPoDescription();
		this.afterFactPO = invoiceRequest.isAfterFactPO();
		this.eventNumber = invoiceRequest.getEventNumber();
		this.eventDescription = invoiceRequest.getEventDescription();
		if (invoiceRequest != null) {
			this.adhocApprovers = invoiceRequest.getAdhocApprovers();
		}
 		this.bankAccountNumber=invoiceRequest.getBankAccountNumber();
        this.requestorEmail=invoiceRequest.getRequestorEmail();
        this.abaNo=invoiceRequest.getAbaNo();
        this.datesOfService=invoiceRequest.getDatesOfService();
        this.invoiceTypeCategory=invoiceRequest.getInvoiceTypeCategory();
        this.setVisibleToVendor(true);
        this.state=new GeneralState();
        
        //     Amount Start 
        this.taxPercent=invoiceRequest.getTaxPercent();
        this.discount=invoiceRequest.getDiscount();
        this.taxAmount=invoiceRequest.getTaxAmount();
    	this.freightAmount = invoiceRequest.getFreightAmount(); 
        this.discount=invoiceRequest.getDiscount();
        this.totalInvoiceAmount=invoiceRequest.getTotalInvoiceAmount();
        this.bankDetails=invoiceRequest.getBankDetails();
        this.oneTime=invoiceRequest.isOneTime();
        this.setBusinessArea(invoiceRequest.getBusinessArea());
        
       reCalculate(purchaseOrder, materials);
	}

	public String getId() {
		return id;
	}

	public long getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}

	public ZonedDateTime getDueDate() {
		return dueDate;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}

	public Address getRemittoaddress() {
		return remittoaddress;
	}

	public Address getShiptoaddress() {
		return shiptoaddress;
	}

	public String getPaymentterms() {
		return paymentterms;
	}

	public String getFreightCarrier() {
		return freightCarrier;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public String getInvoiceCategory() {
		return invoiceCategory;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public String getSupplier() {
		return supplier;
	}

	public String getStatus() {
		return status;
	}

	public Map<String, String> getHeaderAttributes() {
		return headerAttributes;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	 
	public String getCreator() {
		return creator;
	}

	public String getChannel() {
		return channel;
	}

	public String getRequestId() {
		return requestId;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public String getNotes() {
		return notes;
	}
	//
	// public String getComments() {
	// return comments;
	// }

	public List<LineItems> getInvoiceitems() {
		return invoiceitems;
	}

	/*
	 * public String getRequestorEmailAddress() { return requestorEmailAddress;
	 * }
	 */

	 
	public List<CommentLog> getCommentLogs() {
		return commentLogs;
	}

//	public Boolean getIsSAPSynch() {
//		return isSAPSynch;
//	}

	 

	public boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setSspInvoiceReferenceNo(long sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}

	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}

	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setHeaderAttributes(Map<String, String> headerAttributes) {
		this.headerAttributes = headerAttributes;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	 

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	// public void setComments(String comments) {
	// this.comments = comments;
	// }

	/*
	 * public String getCadsNo() { return cadsNo; }
	 * 
	 * public void setCadsNo(String cadsNo) { this.cadsNo = cadsNo; }
	 */

	public void setInvoiceitems(List<LineItems> invoiceitems) {
		this.invoiceitems = invoiceitems;
	}

	/*
	 * public void setRequestorEmailAddress(String requestorEmailAddress) {
	 * this.requestorEmailAddress = requestorEmailAddress; }
	 */
	 

	public void setCommentLogs(List<CommentLog> commentLogs) {
		this.commentLogs = commentLogs;
	}

//	public void setIsSAPSynch(Boolean isSAPSynch) {
//		this.isSAPSynch = isSAPSynch;
//	}

	 

	public void setIsSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public String getCurrency() {
		return currency;
	}


	public Double getFreightAmount() {
		return freightAmount;
	}

	public Float getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(Float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

 
//	public Double getTotalDiscount() {
//		return totalDiscount;
//	}
//	public void setTotalDiscount(Double totalDiscount) {
//		this.totalDiscount = totalDiscount;
//	}
//	public Double getAdditionalDiscount() {
//		return additionalDiscount;
//	}
//	public void setAdditionalDiscount(Double additionalDiscount) {
//		this.additionalDiscount = additionalDiscount;
//	}

	public void setFreightAmount(Double freightAmount) {
		this.freightAmount = freightAmount;
	}

	public String getSapInvoiceNo() {
		return sapInvoiceNo;
	}

	public void setSapInvoiceNo(String sapInvoiceNo) {
		this.sapInvoiceNo = sapInvoiceNo;
	}

	public boolean isCreditMemo() {
		return creditMemo;
	}

	public String getRequestor() {
		return requestor;
	}

	public String getCadsNumber() {
		return cadsNumber;
	}

	public String getBillAccNumber() {
		return billAccNumber;
	}

	public String getBillAccName() {
		return billAccName;
	}

	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public void setCadsNumber(String cadsNumber) {
		this.cadsNumber = cadsNumber;
	}

	public void setBillAccNumber(String billAccNumber) {
		this.billAccNumber = billAccNumber;
	}

	public void setBillAccName(String billAccName) {
		this.billAccName = billAccName;
	}

//	public Double getTotalNetAmount() {
//		return (this.getSubTotal() == null ? 0 : this.getSubTotal())
//				- (this.getAdditionalDiscount() == null ? 0 : this.getAdditionalDiscount());
//	}
//
//	public Double getTotalAmount() {
//		return (getTotalNetAmount()) + (this.getFreightAmount() == null ? 0 : this.getFreightAmount());
//	}
//
//	public Double getTotalTaxAmount() {
//		
//		 if(this.getTaxAmount()!=null && this.getTaxAmount()>0) {
//			return this.getTaxAmount();
//		}
//		else return 0.0;
//	}
//
//	public Double getTotalGrossAmount() {
//		return this.getTotalTaxAmount() + this.getTotalAmount();
//	}

	 

	public void addCommentLogs(String commentLogs, String userId) {
		if ((commentLogs != null && !commentLogs.trim().equals(""))) {
			if (this.getCommentLogs() == null) {
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(false, commentLogs, userId));
		}

	}

	public void addCommentLogs(boolean workFlow, String commentLogs, String userId, String oldStatus,
			String newStatus) {
		if (workFlow || (commentLogs != null && !commentLogs.trim().equals(""))) {
			if (this.getCommentLogs() == null) {
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(workFlow, commentLogs, userId, oldStatus, newStatus));
		}
	}

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public void addActivityLogs(ActivityLog activityLog) {
		if (this.getActivityLogs() == null) {
			this.setActivityLogs(new ArrayList<>());
		}
		if (this.getActivityLogs().size() > 1) {
			ActivityLog activityLog2 = this.activityLogs.get(this.getActivityLogs().size() - 1);
			if (activityLog.getStep() == activityLog2.getStep()) {
				activityLog.setSeq(activityLog2.getSeq() + 1);
			}
		}

		this.getActivityLogs().add(activityLog);
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}

	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}

	public String getShoppingCartNo() {
		return shoppingCartNo;
	}

	public void setShoppingCartNo(String shoppingCartNo) {
		this.shoppingCartNo = shoppingCartNo;
	}

	public String getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(String shipmentType) {
		this.shipmentType = shipmentType;
	}

	public boolean isConfidential() {
		return confidential;
	}

	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}

	public String getPoDescription() {
		return poDescription;
	}

	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}

	public boolean isAfterFactPO() {
		return afterFactPO;
	}

	public void setAfterFactPO(boolean afterFactPO) {
		this.afterFactPO = afterFactPO;
	}

	public List<InvoieValidationResult> getValidationResut() {
		return validationResut;
	}

	public void setValidationResut(List<InvoieValidationResult> validationResut) {
		this.validationResut = validationResut;
	}

	public String getEventNumber() {
		return eventNumber;
	}

	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}

	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getAbaNo() {
		return abaNo;
	}

	public void setAbaNo(String abaNo) {
		this.abaNo = abaNo;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public String getGlAccount() {
		return glAccount;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getApprover() {
		return approver;
	}

	public ZonedDateTime getInvoiceDocumentDate() {
		return invoiceDocumentDate;
	}

	 

	public ZonedDateTime getPaidDate() {
		return paidDate;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public void setInvoiceDocumentDate(ZonedDateTime invoiceDocumentDate) {
		this.invoiceDocumentDate = invoiceDocumentDate;
	}
	public void setPaidDate(ZonedDateTime paidDate) {
		this.paidDate = paidDate;
	}
	public String getDatesOfService() {
		return datesOfService;
	}
	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}

	public boolean isCreatedByVendor() {
		return isCreatedByVendor;
	}

	public void setCreatedByVendor(boolean isCreatedByVendor) {
		this.isCreatedByVendor = isCreatedByVendor;
	}

	public String getInvoiceTypeCategory() {
		return invoiceTypeCategory;
	}

	public void setInvoiceTypeCategory(String invoiceTypeCategory) {
		this.invoiceTypeCategory = invoiceTypeCategory;
	}
	
	public boolean isVisibleToVendor() {
		return visibleToVendor;
	}

	public void setVisibleToVendor(boolean visibleToVendor) {
		this.visibleToVendor = visibleToVendor;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		 
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					}
				}
			}
	}

	public Double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
			this.sapAgentId=agent.getSapAgentId();
			this.agentonSAPSide=agent.isAgentonSAPSide();
		}else {
			this.agentName=null;
			this.sapAgentId=null;
			this.agentonSAPSide=false;
		}
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getSapAgentId() {
		return sapAgentId;
	}

	public void setSapAgentId(String sapAgentId) {
		this.sapAgentId = sapAgentId;
	}

	public boolean isAgentonSAPSide() {
		return agentonSAPSide;
	}

	public void setAgentonSAPSide(boolean agentonSAPSide) {
		this.agentonSAPSide = agentonSAPSide;
	}

	public boolean isDuplicate() {
		return duplicate;
	}

	public void setDuplicate(boolean duplicate) {
		this.duplicate = duplicate;
	}

	public DocumentHelper getEmail() {
		return email;
	}

	public void setEmail(DocumentHelper email) {
		this.email = email;
	}

	public String getInvoiceDocId() {
		return invoiceDocId;
	}

	public void setInvoiceDocId(String invoiceDocId) {
		this.invoiceDocId = invoiceDocId;
	}

	public String getLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public ZonedDateTime getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(ZonedDateTime postedDate) {
		this.postedDate = postedDate;
	}

	public boolean isExported() {
		return exported;
	}

	public void setExported(boolean exported) {
		this.exported = exported;
	}

	public String getTempBufferId() {
		return tempBufferId;
	}

	public void setTempBufferId(String tempBufferId) {
		this.tempBufferId = tempBufferId;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	 
	
	
//	public void recalculateAmount() {
//		if (this.getInvoiceitems() == null || this.getInvoiceitems().size() == 0) {
//			 
//		} else {
//			double subTotal=0.0d;
//			double totalDiscount=0.0d;
//			for (LineItems lineItem : this.getInvoiceitems()) {
//				try {
//					double qty = (lineItem.getQuantity() == null) ? 1 : lineItem.getQuantity();
//					double unitPrice = (lineItem.getUnitPrice() == null) ? 0 : lineItem.getUnitPrice();
//					double disc = ((lineItem.getDiscountamount() == null) ? 0 : lineItem.getDiscountamount());
//					double netAmount = qty * unitPrice - disc;
//					lineItem.setNetAmount(netAmount);
//					subTotal = subTotal + netAmount;
//					System.out.println("qty:" + qty + ", unit price:" + unitPrice + ", discount:" + disc
//							+ ", subtotal :" + subTotal);
//
//					totalDiscount = totalDiscount + disc;
//				} catch (Exception numbe) {
//					numbe.printStackTrace();
//				}
//
//			}
//			System.out.println("subTotal:" + subTotal);
//			this.setSubTotal(subTotal);
//			//this.setTotalDiscount(totalDiscount);
//		}
//	}

	public double getDiscount() {
		return discount;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getNetAmount() {
		return netAmount;
	}


	public double getTotalAmount() {
		return totalAmount;
	}
	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	private void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	private void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public void setFreightAmount(double freightAmount) {
		this.freightAmount = freightAmount;
	}
	
	public String getVatNumber() {
		return vatNumber;
	}

	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}

	public void setTaxPercent(float taxPercent) {
		this.taxPercent = taxPercent;
	}
	
	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}
	
	

	public InvoieValidationResult getExceptions() {
		return exceptions;
	}

	public void setExceptions(InvoieValidationResult exceptions) {
		this.exceptions = exceptions;
	}

	public void reCalculate(PurchaseOrder purchaseOrder, List<MaterialMaster> materials) {
		double subtotal=0;
		if(invoiceitems!=null) {
			for(LineItems lineItem:invoiceitems) {
				List<UomPriceFactor> factors = null;
				String perUom = null;
				if (this.getInvoiceCategory().equalsIgnoreCase("PO")) {
					factors = getPriceFactorsForMaterial(materials, lineItem);
					perUom = getPerUomFromPurchaseOrder(purchaseOrder, lineItem.getMaterialCode(), lineItem.getPoLineNumber());
				}
				lineItem.reCalculate("PO".equalsIgnoreCase(this.getInvoiceCategory()), factors, perUom);
				if(creditMemo) {
				
					subtotal=subtotal+lineItem.getSubTotal();
				}
				else {
					if(lineItem.getDebitOrCreditIndicator()!=null && lineItem.getDebitOrCreditIndicator().equalsIgnoreCase("C")) 
					{
						subtotal=subtotal-lineItem.getSubTotal();
					}
					else {
						subtotal=subtotal+lineItem.getSubTotal();
					}
				}
				//subtotal=subtotal+lineItem.getSubTotal();
			}
		}
		this.subTotal=subtotal;
		this.netAmount=subtotal-discount;
		this.totalAmount=this.getNetAmount()+this.getTaxAmount()+this.getFreightAmount();
		//this.netAmount=this.getTotal()+this.getTax();
	}

	private String getPerUomFromPurchaseOrder(PurchaseOrder purchaseOrder, String materialCode, String poLineNumber) {
		if (purchaseOrder != null && purchaseOrder.getPoitms() != null && !purchaseOrder.getPoitms().isEmpty()) {
			if (StringUtils.isNotBlank(materialCode)) {
				for (POitmHelper poItem : purchaseOrder.getPoitms()) {
					if (poItem.getMAT_CODE().equals(materialCode)) {
						return poItem.getPerUOM();
					}
				}
			} else if (StringUtils.isNotBlank(poLineNumber)) {
				for (POitmHelper poItem : purchaseOrder.getPoitms()) {
					if (poItem.getPO_LNE() != null && poItem.getPO_LNE().toString().equals(poLineNumber)) {
						return poItem.getPerUOM();
					}
				}
			}
			
		}
		return null;
	}

	private List<UomPriceFactor> getPriceFactorsForMaterial(List<MaterialMaster> materials, LineItems lineItem) {
		List<UomPriceFactor> factors = null;
		if (materials != null && !materials.isEmpty() && lineItem.getMaterialCode() != null) {
			for (MaterialMaster material : materials) {
				if (material.getCode().equals(lineItem.getMaterialCode())
						&& (material.getpLantDataHelper() != null && !material.getpLantDataHelper().isEmpty())) {
					for (PlantDataHelper plant : material.getpLantDataHelper()) {
						if (plant.getPlant().equals(lineItem.getPlant())) {
							return plant.getFactors();
						}
					}

				}
			}
			
			
		}
		return factors;
	}

	public String getDocheaderText() {
		return docheaderText;
	}

	public void setDocheaderText(String docheaderText) {
		this.docheaderText = docheaderText;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public List<String> getApprovers() {
		return approvers;
	}

	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	public void setApproversSet(Set<String> approvers) {
	if(approvers!=null)
	{
		this.approvers = new ArrayList<>(approvers);
	}
	else this.approvers=null;
	}

	public ActivityLog getRecentActivity() {
		return recentActivity;
	}

	public void setRecentActivity(ActivityLog recentActivity) {
		this.recentActivity = recentActivity;
	}

	public boolean isAsset() {
		return asset;
	}

	public void setAsset(boolean asset) {
		this.asset = asset;
	}

	public BankDetail getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(BankDetail bankDetails) {
		this.bankDetails = bankDetails;
	}

	public boolean isOneTime() {
		return oneTime;
	}

	public void setOneTime(boolean oneTime) {
		this.oneTime = oneTime;
	}

	public ZonedDateTime getHoldDate() {
		return holdDate;
	}

	public void setHoldDate(ZonedDateTime holdDate) {
		this.holdDate = holdDate;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
}
