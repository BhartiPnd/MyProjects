package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.RfxUpdateDto;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXBidder;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.RequiredDocumentType;
import com.ssp.mongo.collections.rfx.RequiredInfo;

@Document(value = "rfxUpdateLog")
public class RfxUpdateLog {
	
	@Id
	private String id;
	private String rfxNo;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	private List<RFXItems> items;
	private List<RFXBidder> bidders;
	private List<RequiredDocumentType> requiredDocuments;
	private List<RequiredInfo> requiredInfo;
	private List<DocumentHelper> attachments;
	private String updatedBy;
	private String updatedByName;
	private ZonedDateTime updatedDate;
	
	
	
	public RfxUpdateLog(RfxUpdateDto rfxUpdateDto, String updatedBy, String updatedByName) {
		super();
		this.rfxNo = rfxUpdateDto.getRfxNo();
		this.submissionEndDate = rfxUpdateDto.getSubmissionEndDate();
		this.qAndADeadline = rfxUpdateDto.getqAndADeadline();
		this.items = rfxUpdateDto.getItems();
		this.bidders = rfxUpdateDto.getBidders();
		this.requiredDocuments = rfxUpdateDto.getRequiredDocuments();
		this.requiredInfo = rfxUpdateDto.getRequiredInfo();
		this.attachments = rfxUpdateDto.getAttachments();
		this.updatedBy = updatedBy;
		this.updatedByName = updatedByName;
		this.updatedDate = ZonedDateTime.now();
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}
	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}
	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}
	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	public List<RFXBidder> getBidders() {
		return bidders;
	}
	public void setBidders(List<RFXBidder> bidders) {
		this.bidders = bidders;
	}
	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}
	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}
	public List<RequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}
	public void setRequiredInfo(List<RequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedByName() {
		return updatedByName;
	}
	public void setUpdatedByName(String updatedByName) {
		this.updatedByName = updatedByName;
	}
	public ZonedDateTime getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(ZonedDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
