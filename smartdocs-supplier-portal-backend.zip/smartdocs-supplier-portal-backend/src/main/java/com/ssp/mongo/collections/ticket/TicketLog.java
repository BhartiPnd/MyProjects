package com.ssp.mongo.collections.ticket;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class TicketLog {

	private String activityCode;
	private String activity;
	private String userName;
	private String userEmail;
	
	private String actualUser;

	private String comment;
	private ZonedDateTime dateTime;
	private List<DocumentHelper> attachments;
	
	public TicketLog(
			 
			String activityCode,
			String activity,
			String userEmail, 
			String comment,List<DocumentHelper> attachments) {
		super();
		 
		this.activityCode = activityCode;
		this.activity = activity;
		this.userEmail = userEmail;
		this.comment = comment;
		this.dateTime = ZonedDateTime.now();
		this.attachments=attachments;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getActualUser() {
		return actualUser;
	}
	public void setActualUser(String actualUser) {
		this.actualUser = actualUser;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	
	
	
}
