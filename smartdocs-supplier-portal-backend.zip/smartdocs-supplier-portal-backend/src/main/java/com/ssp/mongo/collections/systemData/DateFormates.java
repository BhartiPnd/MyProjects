package com.ssp.mongo.collections.systemData;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "DateFormates")
public class DateFormates {

	public static final String TYPE_DATE="D";
	public static final String TYPE_DATE_AND_TIME="DT";
	@Id
	private String id;
	
	private String format;
	private String type;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
