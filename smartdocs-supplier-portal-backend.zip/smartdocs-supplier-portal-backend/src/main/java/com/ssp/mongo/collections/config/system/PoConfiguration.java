package com.ssp.mongo.collections.config.system;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "SystemConfiguration")
public class PoConfiguration {

		public static final String DEFAULT_PO_CONFIG = "po_config";
		
		@Id
		private String id;
		
		private boolean poLineItems;
		private boolean asn;
		private boolean goodsReceipt;
		private boolean poDocument;
		private boolean orderAcknowledgment;
		private boolean invoices;
		private boolean attachments;
		private boolean showLogo;
		private boolean auditLog;
		private boolean showDescription;
		private boolean emailHistory;
		private boolean orderAckNotification;
		private String oaNotifyTo;
		private boolean logicalSystem;
		
		private boolean purchasingOrg;
		
		private boolean line_itemText;
		
		private boolean deleteOA;
		private boolean deleteASN;
		
		private boolean poSearchPurchasingOrg;
		private boolean poSearchPurchasingGroup;
		private boolean poSearchOACompleted;
		private boolean poSearchASNCompleted;
		
		
		private boolean lastOrderAckDate;
		private boolean lastASNDate;
		
		private boolean poDownload;
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public boolean isPoLineItems() {
			return poLineItems;
		}
		public void setPoLineItems(boolean poLineItems) {
			this.poLineItems = poLineItems;
		}
		public boolean isAsn() {
			return asn;
		}
		public void setAsn(boolean asn) {
			this.asn = asn;
		}
		public boolean isGoodsReceipt() {
			return goodsReceipt;
		}
		public void setGoodsReceipt(boolean goodsReceipt) {
			this.goodsReceipt = goodsReceipt;
		}
		public boolean isPoDocument() {
			return poDocument;
		}
		public void setPoDocument(boolean poDocument) {
			this.poDocument = poDocument;
		}
		public boolean isOrderAcknowledgment() {
			return orderAcknowledgment;
		}
		public void setOrderAcknowledgment(boolean orderAcknowledgment) {
			this.orderAcknowledgment = orderAcknowledgment;
		}
		public boolean isInvoices() {
			return invoices;
		}
		public void setInvoices(boolean invoices) {
			this.invoices = invoices;
		}
		public boolean isAttachments() {
			return attachments;
		}
		public void setAttachments(boolean attachments) {
			this.attachments = attachments;
		}
		public boolean isShowLogo() {
			return showLogo;
		}
		public void setShowLogo(boolean showLogo) {
			this.showLogo = showLogo;
		}
		public static String getDefaultPoConfig() {
			return DEFAULT_PO_CONFIG;
		}
		public boolean isShowDescription() {
			return showDescription;
		}
		public void setShowDescription(boolean showDescription) {
			this.showDescription = showDescription;
		}
		public boolean isEmailHistory() {
			return emailHistory;
		}
		public void setEmailHistory(boolean emailHistory) {
			this.emailHistory = emailHistory;
		}
		public boolean isLogicalSystem() {
			return logicalSystem;
		}
		public void setLogicalSystem(boolean logicalSystem) {
			this.logicalSystem = logicalSystem;
		}
		public boolean isOrderAckNotification() {
			return orderAckNotification;
		}
		public void setOrderAckNotification(boolean orderAckNotification) {
			this.orderAckNotification = orderAckNotification;
		}
		public String getOaNotifyTo() {
			return oaNotifyTo;
		}
		public void setOaNotifyTo(String oaNotifyTo) {
			this.oaNotifyTo = oaNotifyTo;
		}
		public boolean isAuditLog() {
			return auditLog;
		}
		public void setAuditLog(boolean auditLog) {
			this.auditLog = auditLog;
		}
		public boolean isDeleteOA() {
			return deleteOA;
		}
		public boolean isDeleteASN() {
			return deleteASN;
		}
		public void setDeleteOA(boolean deleteOA) {
			this.deleteOA = deleteOA;
		}
		public void setDeleteASN(boolean deleteASN) {
			this.deleteASN = deleteASN;
		}
		public boolean isLine_itemText() {
			return line_itemText;
		}
		public void setLine_itemText(boolean line_itemText) {
			this.line_itemText = line_itemText;
		}
		public boolean isPurchasingOrg() {
			return purchasingOrg;
		}
		public void setPurchasingOrg(boolean purchasingOrg) {
			this.purchasingOrg = purchasingOrg;
		}
		public boolean isPoSearchPurchasingOrg() {
			return poSearchPurchasingOrg;
		}
		public boolean isPoSearchPurchasingGroup() {
			return poSearchPurchasingGroup;
		}
		public void setPoSearchPurchasingOrg(boolean poSearchPurchasingOrg) {
			this.poSearchPurchasingOrg = poSearchPurchasingOrg;
		}
		public void setPoSearchPurchasingGroup(boolean poSearchPurchasingGroup) {
			this.poSearchPurchasingGroup = poSearchPurchasingGroup;
		}
		public boolean isLastOrderAckDate() {
			return lastOrderAckDate;
		}
		public boolean isLastASNDate() {
			return lastASNDate;
		}
		public void setLastOrderAckDate(boolean lastOrderAckDate) {
			this.lastOrderAckDate = lastOrderAckDate;
		}
		public void setLastASNDate(boolean lastASNDate) {
			this.lastASNDate = lastASNDate;
		}
		public boolean isPoSearchOACompleted() {
			return poSearchOACompleted;
		}
		public boolean isPoSearchASNCompleted() {
			return poSearchASNCompleted;
		}
		public void setPoSearchOACompleted(boolean poSearchOACompleted) {
			this.poSearchOACompleted = poSearchOACompleted;
		}
		public void setPoSearchASNCompleted(boolean poSearchASNCompleted) {
			this.poSearchASNCompleted = poSearchASNCompleted;
		}
		public boolean isPoDownload() {
			return poDownload;
		}
		public void setPoDownload(boolean poDownload) {
			this.poDownload = poDownload;
		}
		
		
		
}
