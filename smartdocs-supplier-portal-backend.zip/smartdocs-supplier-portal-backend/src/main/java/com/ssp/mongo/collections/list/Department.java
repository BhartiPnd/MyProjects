package com.ssp.mongo.collections.list;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "dept")
public class Department {
	
	@Id
	private String id;
	private String depName;
	private String desc;
	
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Department(String id, String depName, String desc) {
		super();
		this.id = id;
		this.depName = depName;
		this.desc = desc;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}
 


	public String getDepName() {
		return depName;
	}


	public void setDepName(String depName) {
		this.depName = depName;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}

	
	
	
	
}
