package com.ssp.mongo.collections.list;


public class ProductCategoriesClassification {
	private String id;
	private String title;
	public ProductCategoriesClassification() {}

    public ProductCategoriesClassification(String id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	public String getId() {
		return id;
	}
	public String getTitle() {
		return title;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
