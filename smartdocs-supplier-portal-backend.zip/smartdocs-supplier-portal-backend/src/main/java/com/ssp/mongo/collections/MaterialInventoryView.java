package com.ssp.mongo.collections;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.MaterialMasterInv;
import com.ssp.mongo.collections.inventory.InventoryUom;

@Document(collection = "MaterialInventory")
public class MaterialInventoryView {

	@Id
	private String id;
	private String materialCode;
	private String materialDesc;
	private String status;
	private String category;
	private List<InventoryUom> uoms;
	
	private MaterialMasterInv materialMaster;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public MaterialMasterInv getMaterialMaster() {
		return materialMaster;
	}

	public void setMaterialMaster(MaterialMasterInv materialMaster) {
		this.materialMaster = materialMaster;
	}

	public List<InventoryUom> getUoms() {
		return uoms;
	}

	public void setUoms(List<InventoryUom> uoms) {
		this.uoms = uoms;
	}
	
	
}
