package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class OcrProcessLog {
	public static final String STATUS_SENT_TO_FTTP="SentToFTP";
	public static final String STATUS_ERROR_SENT_TO_FTTP="ErrorSentToFTP";
	public static final String STATUS_RECEIVED_FROM_FTP="ReceiveFromFTP";
	public static final String STATUS_NOOCR="NoOCR";
	
	private String id;
	private String fileName;
	private String status;
	private ZonedDateTime sentToFTP;
	private String ftpServer;
	private ZonedDateTime receivedFromFTP;
	
	public OcrProcessLog() {
		
	}
	
	public OcrProcessLog(String id, String fileName, String status,  String ftpServer) {
		super();
		this.id = id;
		this.fileName = fileName;
		this.status = status;
		this.sentToFTP = ZonedDateTime.now();
		this.ftpServer = ftpServer;
		 
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ZonedDateTime getSentToFTP() {
		return sentToFTP;
	}
	public void setSentToFTP(ZonedDateTime sentToFTP) {
		this.sentToFTP = sentToFTP;
	}
	public String getFtpServer() {
		return ftpServer;
	}
	public void setFtpServer(String ftpServer) {
		this.ftpServer = ftpServer;
	}
	public ZonedDateTime getReceivedFromFTP() {
		return receivedFromFTP;
	}
	public void setReceivedFromFTP(ZonedDateTime receivedFromFTP) {
		this.receivedFromFTP = receivedFromFTP;
	}
	
}
