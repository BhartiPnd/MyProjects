package com.ssp.mongo.collections.config;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "TicketWorkFlowConfig")
public class TicketWorkFlowConfig {

	@Id
	private String type;
	
	private List<String> approvers;
	
	private List<String> escalateTo ;
	private int escalateDays ;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getApprovers() {
		return approvers;
	}

	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}

	 

	public List<String> getEscalateTo() {
		return escalateTo;
	}

	public void setEscalateTo(List<String> escalateTo) {
		this.escalateTo = escalateTo;
	}

	public int getEscalateDays() {
		return escalateDays;
	}

	public void setEscalateDays(int escalateDays) {
		this.escalateDays = escalateDays;
	}

	 
	
	
}
