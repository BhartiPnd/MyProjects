package com.ssp.mongo.collections.dataObject;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CADS")
public class CadsModel {

	@Id
	private String id;
	private String incidentNumber;
	private String eventType ;
	private String location;
	private String eventDescription;
	private ZonedDateTime incidentDateTime;
	private String createDate;
	private String createTime;
 
	private String status;

	public String getId() {
		return id;
	}

	public String getIncidentNumber() {
		return incidentNumber;
	}

	public String getEventType() {
		return eventType;
	}

	public String getLocation() {
		return location;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public String getCreateDate() {
		return createDate;
	}

	public String getCreateTime() {
		return createTime;
	}

	public String getStatus() {
		return status;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setIncidentNumber(String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getIncidentDateTime() {
		return incidentDateTime;
	}

	public void setIncidentDateTime(ZonedDateTime incidentDateTime) {
		this.incidentDateTime = incidentDateTime;
	}
	
	
}
