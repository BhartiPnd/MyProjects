package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "SMTPOauthToken")
public class SMTPOauthToken {
	
	@Id
	private String id;
	private String email;
	private long expires_in;
	private String access_token;
	private String refresh_token;
	private String redirectURI;
	private ZonedDateTime lastUpdated;
	public SMTPOauthToken() {
		
	}
	public SMTPOauthToken(String email, long expires_in, String access_token, String refresh_token,String redirectURI) {
		super();
		this.id=email;
		this.email = email;
		this.expires_in = expires_in;
		this.access_token = access_token;
		this.refresh_token = refresh_token;
		this.lastUpdated=ZonedDateTime.now();
		this.redirectURI=redirectURI;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getExpires_in() {
		return expires_in;
	}
	public void setExpires_in(long expires_in) {
		this.expires_in = expires_in;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getRefresh_token() {
		return refresh_token;
	}
	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}
	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getRedirectURI() {
		return redirectURI;
	}
	public void setRedirectURI(String redirectURI) {
		this.redirectURI = redirectURI;
	}
	
	
}

