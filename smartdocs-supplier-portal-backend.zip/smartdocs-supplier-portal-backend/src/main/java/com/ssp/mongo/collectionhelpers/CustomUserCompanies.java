package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class CustomUserCompanies {
	
	public static final String TYPE_ALL="*";
	public static final String TYPE_CUSTOM="custom";
	
	private String type;
	private List<String> allowedCompanies;
	
	public CustomUserCompanies() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public CustomUserCompanies(String type, List<String> allowedCompanies) {
		super();
		this.type = type;
		this.allowedCompanies = allowedCompanies;
	}




	public String getType() {
		return type;
	}
	
	
	
	
	public void setType(String type) {
		this.type = type;
	}
	public List<String> getAllowedCompanies() {
		return allowedCompanies;
	}
	public void setAllowedCompanies(List<String> allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}
	
}
