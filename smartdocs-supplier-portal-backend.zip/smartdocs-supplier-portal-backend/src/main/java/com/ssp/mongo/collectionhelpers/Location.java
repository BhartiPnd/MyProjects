package com.ssp.mongo.collectionhelpers;

public class Location {

	private String country;
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
}
