package com.ssp.mongo.collectionhelpers;

import java.time.ZonedDateTime;

public class NewExpenseItems {

	
	private String expenseType;
	private ZonedDateTime date;
	private ZonedDateTime throughDate;
	private String mileageRate;
	private String miles;
	private String zipCode;
	
	
	private Double amount;
	private String currency;
	private ZonedDateTime departTime;
	private ZonedDateTime returnTime;
	private String glAccount;
	private String wbsElementNo;
	private String costCenter;
	
	// view only field.
	private String glAccountDesc;
	private String wbsElementNoDesc;
	private String costCenterDesc;
	
	
	private String description;
	private String type;
	
	private String city;
    private String county;
    private String state;
    private String mealsRate;
    private String hotelRate;
    
	public String getExpenseType() {
		return expenseType;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public ZonedDateTime getThroughDate() {
		return throughDate;
	}
	public String getMileageRate() {
		return mileageRate;
	}
	public String getMiles() {
		return miles;
	}
	public String getZipCode() {
		return zipCode;
	}
	public String getWbsElementNo() {
		return wbsElementNo;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public Double getAmount() {
		return amount;
	}
	public String getCurrency() {
		return currency;
	}
	public ZonedDateTime getDepartTime() {
		return departTime;
	}
	public ZonedDateTime getReturnTime() {
		return returnTime;
	}
	public String getDescription() {
		return description;
	}
	public String getType() {
		return type;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	public void setThroughDate(ZonedDateTime throughDate) {
		this.throughDate = throughDate;
	}
	public void setMileageRate(String mileageRate) {
		this.mileageRate = mileageRate;
	}
	public void setMiles(String miles) {
		this.miles = miles;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public void setWbsElementNo(String wbsElementNo) {
		this.wbsElementNo = wbsElementNo;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setDepartTime(ZonedDateTime departTime) {
		this.departTime = departTime;
	}
	public void setReturnTime(ZonedDateTime returnTime) {
		this.returnTime = returnTime;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public String getGlAccountDesc() {
		return glAccountDesc;
	}
	public String getWbsElementNoDesc() {
		return wbsElementNoDesc;
	}
	public String getCostCenterDesc() {
		return costCenterDesc;
	}
	public void setGlAccountDesc(String glAccountDesc) {
		this.glAccountDesc = glAccountDesc;
	}
	public void setWbsElementNoDesc(String wbsElementNoDesc) {
		this.wbsElementNoDesc = wbsElementNoDesc;
	}
	public void setCostCenterDesc(String costCenterDesc) {
		this.costCenterDesc = costCenterDesc;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMealsRate() {
		return mealsRate;
	}
	public void setMealsRate(String mealsRate) {
		this.mealsRate = mealsRate;
	}
	public String getHotelRate() {
		return hotelRate;
	}
	public void setHotelRate(String hotelRate) {
		this.hotelRate = hotelRate;
	}
	
	
	//private String location;

	
	
	//private Double quantity;
	//private String  unitofmeasure;
	//private Double unitprice;
	 
	//private Double discountamount;
	
	//private Double tax;
	 
 
}
