package com.ssp.mongo.collections;

public class RequestAttachment {
	
	public int counter;

	public int lineNumber;
	
	private String archiveId;

	private String archiveDocId;

	private String creator;

	private String fileName;

	private String fileType;

	private String createDate;

	private String createTime;

	private String isNewDocuemnt;
	
	private String mimeType;
	
	private Long fileSize;
	
	private String url;

	public RequestAttachment() {
		super();
		// TODO Auto-generated constructor stub
	}


	public RequestAttachment(int counter, String archiveId, String archiveDocId, String creator, String fileName,
			String fileType, String createDate, String createTime, String isNewDocuemnt,Long fileSize) {
		super();
		this.counter = counter;
		this.archiveId = archiveId;
		this.archiveDocId = archiveDocId;
		this.creator = creator;
		this.fileName = fileName;
		this.fileType = fileType;
		this.createDate = createDate;
		this.createTime = createTime;
		this.isNewDocuemnt = isNewDocuemnt;
		this.fileSize = fileSize;
	}

	

	public RequestAttachment(int counter,int lineNumber ,String archiveId, String archiveDocId, String creator, String fileName,
			String fileType, String createDate, String createTime, String isNewDocuemnt, String mimeType,
			Long fileSize) {
		super();
		this.counter = counter;
		this.lineNumber = lineNumber;
		this.archiveId = archiveId;
		this.archiveDocId = archiveDocId;
		this.creator = creator;
		this.fileName = fileName;
		this.fileType = fileType;
		this.createDate = createDate;
		this.createTime = createTime;
		this.isNewDocuemnt = isNewDocuemnt;
		this.mimeType = mimeType;
		this.fileSize = fileSize;
	}


	public int getCounter() {
		return counter;
	}


	public void setCounter(int counter) {
		this.counter = counter;
	}


	public int getLineNumber() {
		return lineNumber;
	}


	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}


	public String getArchiveId() {
		return archiveId;
	}


	public void setArchiveId(String archiveId) {
		this.archiveId = archiveId;
	}


	public String getArchiveDocId() {
		return archiveDocId;
	}


	public void setArchiveDocId(String archiveDocId) {
		this.archiveDocId = archiveDocId;
	}


	public String getCreator() {
		return creator;
	}


	public void setCreator(String creator) {
		this.creator = creator;
	}


	public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	public String getFileType() {
		return fileType;
	}


	public void setFileType(String fileType) {
		this.fileType = fileType;
	}


	public String getCreateDate() {
		return createDate;
	}


	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}


	public String getCreateTime() {
		return createTime;
	}


	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}


	public String getIsNewDocuemnt() {
		return isNewDocuemnt;
	}


	public void setIsNewDocuemnt(String isNewDocuemnt) {
		this.isNewDocuemnt = isNewDocuemnt;
	}


	public String getMimeType() {
		return mimeType;
	}


	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}


	public Long getFileSize() {
		return fileSize;
	}


	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}
	

}
