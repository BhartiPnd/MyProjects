package com.ssp.mongo.collections;

public class EmailTemplatesConstants {
	
	public static final String EMIAL_TYPE_APPROVAL="approval";
	public static final String EMIAL_TYPE_CONFIRM="Confirm";
	public static final String EMIAL_TYPE_COLLAB="collaborate";
	public static final String EMIAL_TYPE_INIT="initator";
	public static final String EMIAL_TYPE_RETURN="return";
	public static final String EMIAL_TYPE_CANCEL="cancel";
	public static final String EMIAL_TYPE_SUBMIT="submit";
	public static final String EMIAL_TYPE_COMPLETE="Completed";
	public static final String SEND_EMP_ROSTER_DATA="SEND_EMP_ROSTER_DATA";
	public static final String EMAIL_CHANNEL_CAT_INVOICE = "Invoice";
	public static final String EMAIL_CHANNEL_CAT_PRR = "PRR";
	public static final String EMAIL_CHANNEL_CAT_POR = "POR";
	public static final String EMAIL_CHANNEL_CAT_TICKET = "TICKET";
	public static final String EMAIL_CHANNEL_CAT_OCR = "OCR";
	public static final String EMAIL_CHANNEL_CAT_RFX = "RFX";
	public static final String EMAIL_CHANNEL_CAT_OA = "OA";
	public static final String EMAIL_CHANNEL_CAT_ASN = "ASN";
	public static final String EMAIL_CHANNEL_CAT_GRR = "GRR";
	public static final String EMAIL_CHANNEL_CAT_GoodsIssueRequest = "GoodsIssueRequest";
	public static final String EMAIL_CHANNEL_CAT_PO = "PO";
	public static final String EMAIL_CHANNEL_CAT_DiverseBusiness = "DiverseBusiness";
	public static final String EMAIL_CHANNEL_CAT_EXPENSE = "EXPENSE";
	public static final String EMAIL_CHANNEL_CAT_GENERAL = "GENERAL";
	public static final String EMAIL_CHANNEL_CAT_VRR_VCR = "VRR_VCR";
	public static final String EMAIL_CHANNEL_CAT_VendorContact = "VendorContact";
	public static final String EMAIL_CHANNEL_CAT_CONTRACT="Contract";
	public static final String EMAIL_CHANNEL_CAT_EMP_MASTER="EmployeeMaster";
	public static final String EMAIL_CHANNEL_CAT_BIDSHEET="BidSheet";
	public static final String EMAIL_CHANNEL_CAT_BIDSHEET_RESPONSE="BidSheetResponse";
 
	
	//Invoice
	public static final String Approver_for_Invoice_Approval = "Approver_for_Invoice_Approval";
	public static final String Invoice_Notification_After_Submission_To_Initator = "Invoice_Notification_After_Submission_To_Initator";
	public static final String Invoice_collaboration = "Invoice_collaboration";
	public static final String Invoice_returnToInitator = "Invoice_returnToInitator";
	public static final String Invoice_Cancel = "Invoice_Cancel";
	public static final String Invoice_Completion = "Invoice_Completion";
	
	//PRR
	public static final String PRR_SUBMIT_TO_INITATOR = "PRR_SUBMIT_TO_INITATOR";
	public static final String PRR_RETURN_TO_INITATOR = "PRR_RETURN_TO_INITATOR";
	public static final String PRR_COMPLETE_TO_INITATOR = "PRR_COMPLETE_TO_INITATOR";
	public static final String PRR_COLLABORATE = "PRR_COLLABORATE";
	public static final String PRR_CANCEL_TO_INITATOR = "PRR_CANCEL_TO_INITATOR";
	public static final String PRR_APPROVAL = "PRR_APPROVAL";
	
	// POR
	public static final String POR_SUBMIT_TO_INITATOR = "POR_SUBMIT_TO_INITATOR";
	public static final String POR_CANCEL_TO_INITATOR = "POR_CANCEL_TO_INITATOR";
	public static final String POR_RETURN_TO_INITATOR = "POR_RETURN_TO_INITATOR";
	public static final String POR_COMPLETE_TO_INITATOR = "POR_COMPLETE_TO_INITATOR";
	public static final String POR_COLLABORATE = "POR_COLLABORATE";
	public static final String POR_APPROVAL = "POR_APPROVAL";
	
	// Ticket
	public static final String TICKET_SUBMISSION_NOTIFICATION_TO_INITIOR = "TICKET_SUBMISSION_NOTIFICATION_TO_INITIOR";
	public static final String TICKET_SUBMISSION_NOTIFICATION_TO_COMPANY = "TICKET_SUBMISSION_NOTIFICATION_TO_COMPANY";
	public static final String TICKET_STATUS_UPDATE_NOTIFICATION_TO_INITIOR = "TICKET_STATUS_UPDATE_NOTIFICATION_TO_INITIOR";
	public static final String TICKET_STATUS_UPDATE_NOTIFICATION_TO_COMPANY = "TICKET_STATUS_UPDATE_NOTIFICATION_TO_COMPANY";
	public static final String TICKET_ESCALATION_NOTIFICATION = "TICKET_ESCALATION_NOTIFICATION";
	
	//OCR
	public static final String OCR_SUCCESS = "OCR_SUCCESS";
	public static final String OCR_NO_ATTACHMENT = "OCR_NO_ATTACHMENT";
	public static final String OCR_NON_SUPPORTED_FILE = "OCR_NON_SUPPORTED_FILE";
	public static final String OCR_FILE_SIZE_EXCEEDED = "OCR_FILE_SIZE_EXCEEDED";
	public static final String OCR_SINGLE_ATTACHMENT_ALLOWED = "OCR SINGLE ATTACHMENT ALLOWED";
	
	
	//RFX
	public static final String RFX_NOTIFICATION = "RFX_NOTIFICATION";
	public static final String RFX_UPDATE_NOTIFICATION = "RFX_UPDATE_NOTIFICATION";
	public static final String VENDOR_RFX_REVERSE_ACTION = "VENDOR_RFX_REVERSE_ACTION";
	public static final String RFx_bid_submission_by_a_vendor = "RFx bid submission by a vendor";
	public static final String RFx_questions = "RFx questions";
	
	public static final String Vendor_notification_after_Bid_Submission = "Vendor notification after Bid Submission";
	public static final String BID_INVITATION_UPDATE = "BID_INVITATION_UPDATE";
	public static final String RFX_BID_SUBMISSION_NOTIFICATION_TO_VENDOR= "RFx_Bid_Submission_notification_to_Vendor";
	public static final String RFX_BID_SUBMISSION_NOTIFICATION_TO_COMPANY= "RFx_Bid Submission_notification_to_Company";
	public static final String RFX_PUBLISH_NOTIFICATION_TO_VENDOR = "RFx_Publish_Notification_to_Vendor";
	public static final String RFX_UPDATE_NOTIFICATION_TO_VENDOR = "RFx_Update_Notification_to_Vendor";
	public static final String RFX_REVOKE_NOTIFICATION_TO_VENDOR = "RFx_Revoke_Notification_to_Vendor";
	public static final String RFX_ANS_BY_BUYER_TO_VENDOR= "RFx_Answers_by_Buyers_to_Vendors";
	public static final String RFX_QUESTION_BY_VENDOR_TO_BUYER = "RFx_Questions_by_Vendor_to_Buyers";
	public static final String RFX_APPROVAL = "RFX_APPROVAL";
	public static final String RFX_SUBMIT_TO_INITATOR = "RFX_SUBMIT_TO_INITATOR";
	public static final String RFX_RETURN_TO_INITATOR = "RFX_RETURN_TO_INITATOR";
	public static final String RFX_COLLABORATE = "RFX_COLLABORATE";
	public static final String RFX_CANCEL_TO_INITATOR = "RFX_CANCEL_TO_INITATOR";
	public static final String RFX_AWARD_NOTIFICATION_TO_VENDOR = "RFx_Award_Notification_to_Vendor";
	
	
	
	//OA
	public static final String OA_Rejection = "OA_Rejection";
	public static final String OA_Submit_Notification_to_Buyer = "OA_Submit_Notification_to_Buyer";
	public static final String OA_Submit_Notification_to_Initator = "OA_Submit_Notification_to_Initator";
	public static final String OA_Approval = "OA_Approval";
 	public static final String OA_COMPLETE_TO_INITATOR = "OA_COMPLETE_TO_INITATOR";
	
	//ASN
	public static final String ASN_Submit_Notification_to_Buyer = "ASN_Submit_Notification_to_Buyer";
	public static final String ASN_Submit_Notification_to_Initator = "ASN_Submit_Notification_to_Initator";
	public static final String ASN_COMPLETE_TO_INITATOR = "ASN_COMPLETE_TO_INITATOR";
	
	//GRR
	public static final String GRR_SUBMIT_TO_BUYER = "GRR_SUBMIT_TO_BUYER";
	public static final String GRR_COMPLETE_TO_INITATOR = "GRR_COMPLETE_TO_INITATOR";
	
	//Goods Issue Request
	public static final String GIR_RETURN_TO_INITATOR = "GIR_RETURN_TO_INITATOR";
	public static final String GIR_COLLABORATE = "GIR_COLLABORATE";
	public static final String GIR_APPROVAL = "GIR_APPROVAL";
	public static final String GIR_CANCEL_TO_INITATOR = "GIR_CANCEL_TO_INITATOR";
	public static final String GIR_SUBMIT_TO_INITATOR = "GIR_SUBMIT_TO_INITATOR";
	public static final String GIR_COMPLETE_TO_INITATOR = "GIR_COMPLETE_TO_INITATOR";
	
	//Contract
	public static final String CONTRACT = "CONTRACT";
	public static final String CONTRACT_UPDATE = "CONTRACT_UPDATE";
	
	//PO
//	public static final String PO_UPDATE = "PO_UPDATE";
//	public static final String PO_DISPATCH = "PO_DISPATCH";
	public static final String PO_DISPATCH_FOR_VENDOR = "PO_DISPATCH_FOR_VENDOR";
	public static final String PO_DISPATCH_FOR_BUYER = "PO_DISPATCH_FOR_BUYER";
	public static final String PO_UPDATE_FOR_VENDOR = "PO_UPDATE_FOR_VENDOR";
	public static final String PO_UPDATE_FOR_BUYER = "PO_UPDATE_FOR_BUYER";
	public static final String PO_DELETE_FOR_VENDOR = "PO_DELETE_FOR_VENDOR";
	public static final String PO_DELETE_FOR_BUYER = "PO_DELETE_FOR_BUYER";
	
	//DiverseBusiness
	public static final String E0_402_SUBMISSION = "E0_402_SUBMISSION";
	
	
	//Expense
	public static final String EXPENSE_SUBMISSION = "EXPENSE_SUBMISSION";
	public static final String Approver_for_Expense_Report = "Approver for Expense Report";
	
	//General
	public static final String NOTIFY = "NOTIFY";
	public static final String RESET_PASSWORD = "RESET_PASSWORD";
	public static final String User_Substitution_Notification = "User_Substitution_Notification";
	public static final String DOCUMEN_SHARING_TO_EXTERNAL_USER = "DOCUMEN_SHARING_TO_EXTERNAL_USER";
	public static final String SEND_EMP_MASTER_DATA = "SEND_EMP_MASTER_DATA";
	
	//Employee Master Document
	public static final String SEND_EMP_MASTER_DOCUMENT = "SEND_EMP_MASTER_DOCUMENT";
	
	//================================
	
	//VRR_VCR
	public static final String VRR_Invitation = "VRR_Invitation";
	public static final String VRR_Submit_to_Initator = "VRR_Submit_to_Initator";
	public static final String VRR_Return_To_Initator = "VRR_Return_To_Initator";
	
	public static final String VCR_Submit_to_Initator = "VCR_Submit_to_Initator";
	public static final String VCR_Return_To_Initator = "VCR_Return_To_Initator";
	public static final String VCR_Cancel_to_Initator = "VCR_Cancel_to_Initator";
	public static final String VCR_Complete_to_Initator = "VCR_Complete_to_Initator";
	
	//VendorContact
	public static final String VENDOR_CONTACT_PORTAL_INVITATION = "VENDOR_CONTACT_PORTAL_INVITATION"; // company user send invitation 
	public static final String VENDOR_ADMIN_CONTACT_PORTAL_INVITATION = "VENDOR_ADMIN_CONTACT_PORTAL_INVITATION"; // vendor admin
	/////////////////////////////////
//	public static final String VCR_COLLABORATION_TO_VENDOR = "VCR_COLLABORATION_TO_VENDOR";	
//	public static final String APPROVAL_NOTIFICATION = "APPROVAL_NOTIFICATION";
//	public static final String REQUEST_CANCELLED = "REQUEST_CANCELLED";
//	public static final String VENDOR_REGISTRATION_REJECTED = "VENDOR_REGISTRATION_REJECTED";
//	public static final String VRR_VCR_COLLABARATION_COLLABARATIONBACK_FORWARD_TO_COMPANY = "VRR_VCR_COLLABARATION_COLLABARATIONBACK_FORWARD_TO_COMPANY";
//	public static final String VENDOR_REGISTRATION_COMPLETED = "VENDOR_REGISTRATION_COMPLETED";
//	
//	public static final String REQUEST_APPROVED_STATUS = "REQUEST_APPROVED_STATUS";

	
//	Bid Sheet
	public static final String BIDSHEET_SEND_TO_VENDOR = "BidSheet_Send_To_Vendor";
	public static final String Bid_Withdraw_Email_To_Vendor ="Bid_Withdraw_Email_To_Vendor";
	public static final String Bid_Withdraw_Email_To_Company ="Bid_Withdraw_Email_To_Company";
	public static final String Bid_Update_Email_To_Vendor="Bid_Update_Email_To_Vendor";
	public static final String Bid_Update_Email_To_Company="Bid_Update_Email_To_Company";

	@Deprecated
	public static final String DOCUMENT_EXPIRY = "DOCUMENT_EXPIRY";
	
	
	
 
	
	

	

	
	
}
