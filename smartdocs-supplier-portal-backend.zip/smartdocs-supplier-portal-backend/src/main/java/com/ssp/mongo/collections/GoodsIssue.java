package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.dto.CreateGIRLineItems;
import com.ssp.dto.CreateGoodsIssue;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.GoodsIssueItems;

@Document(collection = "GoodsIssue")
public class GoodsIssue {

	@Id
	private String id;
	
	private String type;
	private String prrRefId;
	private String requestId;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String requestorEmail;
	private String requestorName;
	private String receiverEmail;
	private String receiverName;
	private String initatorEmail;
	private String companyCode;
	private String companyName;
	private String currency;
	private String supplierId;
	private ZonedDateTime createdDate;
	private String createdBy;
	private double totalAmount;
	private List<GIReceiver> receivers;
	private String initator;
	private List<GoodsIssueItems> lineItems;
	private List<DocumentHelper> attachments;
	
	private String status;
	private String agentName;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	
	private String channel;
	private GeneralState state;
	private String comment;
	private ZonedDateTime lastUpdatedDate;
	private String lastUpdatedBy;
	private ZonedDateTime deliveryDate;
	
	public GoodsIssue() {
		
	}
	
	public GoodsIssue(CreateGoodsIssue createGoodsIssue) {
		this.type = createGoodsIssue.getType();
		this.purchasingOrg = createGoodsIssue.getPurchasingOrg();
		this.purchasingGroup = createGoodsIssue.getPurchasingGroup();
		this.paymentTerms=createGoodsIssue.getPaymentTerms();
		this.requestorEmail=createGoodsIssue.getRequestorEmail();
		this.receivers = createGoodsIssue.getReceivers();
		this.companyCode=createGoodsIssue.getCompanyCode();
		this.currency=createGoodsIssue.getCurrency();
		this.createdDate = ZonedDateTime.now();
		this.totalAmount = createGoodsIssue.getTotalAmount();
		this.channel = "PORTAL";
		this.requestorName=createGoodsIssue.getRequestorName();
		this.companyName=createGoodsIssue.getCompanyName();
		this.deliveryDate=createGoodsIssue.getDeliveryDate();
		int index=1; 
		List<GoodsIssueItems> lineitems=new ArrayList<>();
		for(CreateGIRLineItems line:createGoodsIssue.getRequestItems()) 
		{
			GoodsIssueItems lne=new GoodsIssueItems(line);
			lne.setItemNo(index);
			lne.setStatus(status);
			lineitems.add(lne);
			index++;
		}
		this.setLineItems(lineitems);
		this.comment=createGoodsIssue.getNotes();
		this.attachments = createGoodsIssue.getAttachments();
	}
		
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPrrRefId() {
		return prrRefId;
	}
	public void setPrrRefId(String prrRefId) {
		this.prrRefId = prrRefId;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	
	
	public List<GIReceiver> getReceivers() {
		return receivers;
	}

	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getInitatorEmail() {
		return initatorEmail;
	}
	public void setInitatorEmail(String initatorEmail) {
		this.initatorEmail = initatorEmail;
	}

	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public List<GoodsIssueItems> getLineItems() {
		return lineItems;
	}
	public void setLineItems(List<GoodsIssueItems> lineItems) {
		this.lineItems = lineItems;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getRequestId() {
		return requestId;
	}

	public boolean isSAPSynch() {
		return isSAPSynch;
	}

	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getInitator() {
		return initator;
	}

	public void setInitator(String initator) {
		this.initator = initator;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public ZonedDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(ZonedDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	
	
	
}
