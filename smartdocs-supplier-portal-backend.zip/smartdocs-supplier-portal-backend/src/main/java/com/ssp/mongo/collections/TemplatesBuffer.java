package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;

public class TemplatesBuffer {
	
	@Id
	private String id;
	private String subject;
	private String templateId;
	private String templateBody;
	
	
	
	public TemplatesBuffer() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getTemplateBody() {
		return templateBody;
	}
	public void setTemplateBody(String templateBody) {
		this.templateBody = templateBody;
	}
	
	

}
