package com.ssp.mongo.collections;

public class RequestLog {
   
	private int seqId;
	private String currAgent;
	private String actualUser;
	private String activity;
	private String commentsExist;
	private String endDate;
	private String endTime;
	private String comments;
	private String isNew;
	private String activityText;
	private Integer step;
	
	public RequestLog() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RequestLog(int seqId, String currAgent, String actualUser,
			String activity, String commentsExist, String endDate, String endTime, String comments, String isNew,
			String activityText) {
		super();
	
		this.seqId = seqId;
		this.currAgent = currAgent;
		this.actualUser = actualUser;
		this.activity = activity;
		this.commentsExist = commentsExist;
		this.endDate = endDate;
		this.endTime = endTime;
		this.comments = comments;
		this.isNew = isNew;
		this.activityText = activityText;
	}
	
	public RequestLog(int seqId, String currAgent, String actualUser,
			String activity, String commentsExist, String endDate, String endTime, String comments, String isNew,
			String activityText,Integer step) {
		super();
	
		this.seqId = seqId;
		this.currAgent = currAgent;
		this.actualUser = actualUser;
		this.activity = activity;
		this.commentsExist = commentsExist;
		this.endDate = endDate;
		this.endTime = endTime;
		this.comments = comments;
		this.isNew = isNew;
		this.activityText = activityText;
		this.step = step;
	}
	
	
	public Integer getStep() {
		return step;
	}
	public void setStep(Integer step) {
		this.step = step;
	}
	public int getSeqId() {
		return seqId;
	}
	public void setSeqId(int seqId) {
		this.seqId = seqId;
	}
	public String getCurrAgent() {
		return currAgent;
	}
	public void setCurrAgent(String currAgent) {
		this.currAgent = currAgent;
	}
	public String getActualUser() {
		return actualUser;
	}
	public void setActualUser(String actualUser) {
		this.actualUser = actualUser;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getCommentsExist() {
		return commentsExist;
	}
	public void setCommentsExist(String commentsExist) {
		this.commentsExist = commentsExist;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getIsNew() {
		return isNew;
	}
	public void setIsNew(String isNew) {
		this.isNew = isNew;
	}
	public String getActivityText() {
		return activityText;
	}
	public void setActivityText(String activityText) {
		this.activityText = activityText;
	}
	
}
