package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.PaymentLineItem;

@Document(collection = "payment")
public class Payment {

	@Id
	private String id;
	private String paymentReference;
	private String systemId;
	private String companyCode;
	private String cheqNumber;
	private ZonedDateTime cheqDate;
	private Double amount;
	private String currency;
	private String notes;
	private String fiscalYear;
	private String supplierId;
	private String paymentMethod;

	private String status;
	private String bankName;
	private String bankType;
	private String bankAccountNo;
	private String bankCountryKey;
	private String paymentMethodDescription;
	private String headerText;
	private List<PaymentLineItem> paymentItems;

	public String getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(String fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPaymentReference() {
		return paymentReference;
	}

	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCheqNumber() {
		return cheqNumber;
	}

	public void setCheqNumber(String cheqNumber) {
		this.cheqNumber = cheqNumber;
	}

	public ZonedDateTime getCheqDate() {
		return cheqDate;
	}

	public void setCheqDate(ZonedDateTime cheqDate) {
		this.cheqDate = cheqDate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public List<PaymentLineItem> getPaymentItems() {
		return paymentItems;
	}

	public void setPaymentItems(List<PaymentLineItem> paymentItems) {
		this.paymentItems = paymentItems;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getBankCountryKey() {
		return bankCountryKey;
	}

	public void setBankCountryKey(String bankCountryKey) {
		this.bankCountryKey = bankCountryKey;
	}

	public String getPaymentMethodDescription() {
		return paymentMethodDescription;
	}

	public void setPaymentMethodDescription(String paymentMethodDescription) {
		this.paymentMethodDescription = paymentMethodDescription;
	}

	public String getHeaderText() {
		return headerText;
	}

	public void setHeaderText(String headerText) {
		this.headerText = headerText;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
