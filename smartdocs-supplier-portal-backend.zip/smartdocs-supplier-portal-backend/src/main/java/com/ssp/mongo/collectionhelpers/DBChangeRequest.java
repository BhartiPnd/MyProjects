package com.ssp.mongo.collectionhelpers;

import java.util.List;

public class DBChangeRequest {

	private List<DBESelectedStatus> dbeSelectedStatus;
	 
	private boolean noMoreDBE;
	public List<DBESelectedStatus> getDbeSelectedStatus() {
		return dbeSelectedStatus;
	}
	public void setDbeSelectedStatus(List<DBESelectedStatus> dbeSelectedStatus) {
		this.dbeSelectedStatus = dbeSelectedStatus;
	}
	 
	public boolean isNoMoreDBE() {
		return noMoreDBE;
	}
	public void setNoMoreDBE(boolean noMoreDBE) {
		this.noMoreDBE = noMoreDBE;
	}
	
	
	
}
