package com.ssp.mongo.collections.dataObject;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "GLAccount")
public class GLAccount {

		@Id
		private String id;
		private String accountNo;
		private String description;
		private List<String> companyCode;
	
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public List<String> getCompanyCode() {
			return companyCode;
		}
		public void setCompanyCode(List<String> companyCode) {
			this.companyCode = companyCode;
		}
		 		
		
}
