package com.ssp.mongo.collections.smartbuy;

import com.ssp.mongo.collections.workflow.WorkItem;
import com.ssp.mongo.util.JsonResponse;

public class PurchaseOrderRequestInboxDetail {

	private PurchaseOrderRequestDetail purchaseOrderReq;
	private WorkItem workItem;
	private String status;
	private String error;
	
	public PurchaseOrderRequestInboxDetail() {
		super();
		this.status = JsonResponse.RESULT_SUCCESS;
	}
	public PurchaseOrderRequestDetail getPurchaseOrderReq() {
		return purchaseOrderReq;
	}
	public void setPurchaseOrderReq(PurchaseOrderRequestDetail purchaseOrderReq) {
		this.purchaseOrderReq = purchaseOrderReq;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getStatus() {
		return status;
	}
	public String getError() {
		return error;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setError(String error) {
		this.error = error;
	}
	
}
