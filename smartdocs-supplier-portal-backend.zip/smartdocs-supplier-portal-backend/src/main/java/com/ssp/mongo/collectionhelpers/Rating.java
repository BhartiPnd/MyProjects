package com.ssp.mongo.collectionhelpers;

public class Rating {

	private int score;
	private String lable;
	private int upTo;
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getLable() {
		return lable;
	}
	public void setLable(String lable) {
		this.lable = lable;
	}
	public int getUpTo() {
		return upTo;
	}
	public void setUpTo(int upTo) {
		this.upTo = upTo;
	}
	
	
}
