package com.ssp.mongo.collectionhelpers;

public class ReverseAuctionParticipent {

	private String bidId;
	private String bidUUID;
	private String title;
	private double amount;
	
	//Display purpose not use in db.
	private boolean isYours;

	public String getBidId() {
		return bidId;
	}

	public void setBidId(String bidId) {
		this.bidId = bidId;
	}

	public String getBidUUID() {
		return bidUUID;
	}

	public void setBidUUID(String bidUUID) {
		this.bidUUID = bidUUID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public boolean isYours() {
		return isYours;
	}

	public void setYours(boolean isYours) {
		this.isYours = isYours;
	}

	@Override
	public String toString() {
		return "ReverseAuctionParticipent [bidId=" + bidId + ", bidUUID=" + bidUUID + ", title=" + title + ", amount="
				+ amount + ", isYours=" + isYours + "]";
	}

	public ReverseAuctionParticipent(String bidId, String bidUUID, String title, Double amount) {
		super();
		this.bidId = bidId;
		this.bidUUID = bidUUID;
		this.title = title;
		if(amount!=null)
		{
			this.amount = amount;
		}
		 
	}
	
	

}
