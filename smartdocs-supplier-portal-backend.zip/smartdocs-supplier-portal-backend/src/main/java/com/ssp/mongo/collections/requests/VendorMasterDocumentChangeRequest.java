package com.ssp.mongo.collections.requests;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;

import com.ssp.dto.UploadVendorMasterDocumentRequest;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.security.services.UserPrinciple;

public class VendorMasterDocumentChangeRequest {

	
	
	@Id
	private String id;
	
	private long refId;
	
	private String status;
	private String comments;
	
	private String supplierId;
	
	private String documentType;
	
	private String uploadedBy;
	
	private DocumentHelper  document;
	 
	private ZonedDateTime validityStartDate;
	private ZonedDateTime validityEndDate;
	private int version;
	private ZonedDateTime lastUpdated;
	
	private List<FieldValues> fieldValues;
	// this is mainly for supporting documents. that added in approval etc. 
	private List<DocumentHelper> attachments;
	
	private boolean isSAPSynch;
	private Long sapSynchDate;
	private boolean isSAPSynchACK;
	
	public VendorMasterDocumentChangeRequest() {
		
		super();
	}
	public VendorMasterDocumentChangeRequest(UploadVendorMasterDocumentRequest request,UserPrinciple logedInUser) {
		super();
		this.documentType=request.getDocumentType();
		this.setDocument(request.getDocument());
		this.validityStartDate=request.getValidityStartDate();
		this.validityEndDate=request.getValidityEndDate();
		this.lastUpdated=ZonedDateTime.now();
		this.uploadedBy=logedInUser.getEmail();
		this.supplierId=logedInUser.getSupplierId();
		this.fieldValues=request.getFieldValues();
	}
	public void refresh(UploadVendorMasterDocumentRequest request,UserPrinciple logedInUser) {
		 
		this.setDocument(request.getDocument());
		this.validityStartDate=request.getValidityStartDate();
		this.validityEndDate=request.getValidityEndDate();
		this.lastUpdated=ZonedDateTime.now();
		this.uploadedBy=logedInUser.getEmail();
		this.fieldValues=request.getFieldValues();
	}
	
	public long getRefId() {
		return refId;
	}
	 
	public String getStatus() {
		return status;
	}
	public String getComments() {
		return comments;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public int getVersion() {
		return version;
	}
	public String getDocumentType() {
		return documentType;
	}
	 
	public ZonedDateTime getValidityStartDate() {
		return validityStartDate;
	}
	public ZonedDateTime getValidityEndDate() {
		return validityEndDate;
	}
	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}
	public boolean isSAPSynch() {
		return isSAPSynch;
	}
	public Long getSapSynchDate() {
		return sapSynchDate;
	}
	public boolean isSAPSynchACK() {
		return isSAPSynchACK;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	 
	public void setStatus(String status) {
		this.status = status;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	 
	public void setVersion(int version) {
		this.version = version;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	 
	public void setValidityStartDate(ZonedDateTime validityStartDate) {
		this.validityStartDate = validityStartDate;
	}
	public void setValidityEndDate(ZonedDateTime validityEndDate) {
		this.validityEndDate = validityEndDate;
	}
	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public void setSAPSynchACK(boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public String getId() {
		return id;
	}
	public DocumentHelper getDocument() {
		return document;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setDocument(DocumentHelper document) {
		this.document = document;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	
	
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	
	public List<FieldValues> getFieldValues() {
		return fieldValues;
	}
	public void setFieldValues(List<FieldValues> fieldValues) {
		this.fieldValues = fieldValues;
	}
	public void addAttachments(List<DocumentHelper>  attachments,String uploadedBy,int usrUploaded) {
		resetAttachmentUploadeByInfo( attachments, uploadedBy, usrUploaded);
		if(attachments!=null && attachments.size()>0) {
			if(this.getAttachments()==null){
				this.setAttachments(new ArrayList<>());
			}
			for(DocumentHelper docHelper:attachments) {
				this.getAttachments().add(docHelper);
			}
		}
		else {
			
		}
	}
	public List<DocumentHelper> resetAttachmentUploadeByInfo(List<DocumentHelper> attachments,String uploadedBy,int usrUploaded) {
		if(attachments!=null && attachments.size()>0)
		{
			for(DocumentHelper attachment:attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isNotBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
				
			}
			
		}
		return attachments;
	}
	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		 
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					}
					
				}
			}
			if(this.document!=null)
			{
					if(this.document.getUploadedDate()==null) {
						this.document.setUploadedDate(ZonedDateTime.now());
					}
					if(this.document.getUploadedBy()==null|| StringUtils.isBlank(uploadedBy)) {
						this.document.setUploadedBy(uploadedBy);
						this.document.setUsrUploaded(usrUploaded);
					}
				
			}
	} 
}
