package com.ssp.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.InvoiceTemplateLineItems;

@Document(collection = "InvoiceTemplate")
public class InvoiceTemplate {

	@Id
	private String id;
	private String supplierId;
	private String companyCode;
	private String title;
	private String owner;
	private String global;
	private String invoiceType;
	private ZonedDateTime createdDateTime;
	private List<InvoiceTemplateLineItems> items;
	private Address remittoaddress;
	private Address shiptoaddress;
	private String requestor;
	private String requestorEmail;
	private double totalInvoiceAmount;
	private String notes;

	public InvoiceTemplate() {
		super();
		this.createdDateTime = ZonedDateTime.now();

	}

	public InvoiceTemplate(String title, String owner, String global, String invoiceType,
			List<InvoiceTemplateLineItems> items) {
		super();
		this.title = title;
		this.owner = owner;
		this.global = global;
		this.invoiceType = invoiceType;
		this.createdDateTime = ZonedDateTime.now();
		this.items = items;
	}

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getOwner() {
		return owner;
	}

	public String getGlobal() {
		return global;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public List<InvoiceTemplateLineItems> getItems() {
		return items;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void setGlobal(String global) {
		this.global = global;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public void setItems(List<InvoiceTemplateLineItems> items) {
		this.items = items;
	}

	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public Address getRemittoaddress() {
		return remittoaddress;
	}

	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}

	public Address getShiptoaddress() {
		return shiptoaddress;
	}

	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

}
