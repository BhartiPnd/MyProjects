package com.ssp.mongo.collectionhelpers;

import java.util.List;
import java.util.Map;


public class ApprovalMatrixDefination {
	
	
	private Map<String,String> attributeValues;
	private List<ApprovalMatrixApprovers>approvers;
	private int totalLevel; 
	private int weight;
	
	 
	public Map<String, String> getAttributeValues() {
		return attributeValues;
	}
	public void setAttributeValues(Map<String, String> attributeValues) {
		this.attributeValues = attributeValues;
	}
	public List<ApprovalMatrixApprovers> getApprovers() {
		return approvers;
	}
	public void setApprovers(List<ApprovalMatrixApprovers> approvers) {
		this.approvers = approvers;
	}
	public int getTotalLevel() {
		return totalLevel;
	}
	public void setTotalLevel(int totalLevel) {
		this.totalLevel = totalLevel;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	} 
	
	
}
