package com.ssp.mongo.collections;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "StorageLocation")
public class StorageLocation {

	@Id
	private String id;	 		
	private String storageLocationId;
	private String description;
	private String plantCode;
	private String status;
	
	public StorageLocation() {
		super();
	}

	public StorageLocation(String id, String storageLocationId, String description, String plantCode,String status) {
		super();
		this.id = id;
		this.storageLocationId = storageLocationId;
		this.description = description;
		this.plantCode = plantCode;
		this.status=status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStorageLocationId() {
		return storageLocationId;
	}

	public void setStorageLocationId(String storageLocationId) {
		this.storageLocationId = storageLocationId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
