package com.ssp.mongo.collections;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.config.GlobalConfig;
import com.ssp.dto.CreateExpenseRequest;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.NewExpenseItems;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;

@Document(collection = "expense")
public class Expense extends AbstractAuditingEntity {

	@Id
	private String id;
	private String title;
	private String invoiceNumber;
	private String companycode;
	
	// for whom created. 
	private String employeeId;
	private String employeeEmail;
	private String employee;
	
	// who created. workflow purpose we should use this email. 
	private String creator;
	 
	
	private long sspInvoiceReferenceNo;


	private String channel;

	private String referencenumber;

	private ZonedDateTime expenseDateFrom;
	private ZonedDateTime expenseDateTo;

	private String status;
	private String statusDesc;
	private Double grandTotal;
	private String currency;

	// private Double taxamount;
	// private String paymentterms;

	// private Map<String,String> headerAttributes;
	private List<DocumentHelper> attachments;
	private String notes;
	//private String comment;

	 
	private List<NewExpenseItems> newExpenseitems;

	private Boolean isSAPSynch;
	private Long SAPSynchDate;
	private Boolean isSAPSynchACK;

	private List<AdhocApprover> adhocApprovers;
	// private List<ActivityLog> activityLogs;

	private String location;
	private String remarks;

	private String employeeFirstName;
	private String employeeLastName;
	private List<ActivityLog> activityLogs;
	// view only field // not for db purpose.
	private boolean isOwner;
	private boolean analyticsSyncStatus;
	public Expense() {
		super();
		this.isSAPSynch = false;
		this.SAPSynchDate = null;
		this.isSAPSynchACK = false;

		// TODO Auto-generated constructor stub
	}

	public Expense(CreateExpenseRequest invoiceRequest) {

		this.isSAPSynch = false;
		this.SAPSynchDate = null;
		this.isSAPSynchACK = false;
		this.setCurrency(GlobalConfig.DEFAULT_CURRENCY);
		this.invoiceNumber = invoiceRequest.getInvoiceNumber();

		this.expenseDateFrom=invoiceRequest.getExpenseDateFrom();
		this.expenseDateTo=invoiceRequest.getExpenseDateTo();
		
		this.grandTotal = invoiceRequest.getGrandTotal();
		this.remarks = invoiceRequest.getRemarks();
		this.notes = invoiceRequest.getNotes();
		this.attachments = invoiceRequest.getAttachments();
		if (invoiceRequest.getNewExpenseitems() != null) {
			this.setNewExpenseitems(invoiceRequest.getNewExpenseitems());
		}
		 
	 

		this.adhocApprovers = invoiceRequest.getAdhocApprovers();
		this.employeeId = invoiceRequest.getEmployeeId();
		this.title = invoiceRequest.getTitle();
		this.employeeEmail=invoiceRequest.getEmployeeEmail();

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	 

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getReferencenumber() {
		return referencenumber;
	}

	public void setReferencenumber(String referencenumber) {
		this.referencenumber = referencenumber;
	}

	public ZonedDateTime getExpenseDateFrom() {
		return expenseDateFrom;
	}

	public void setExpenseDateFrom(ZonedDateTime expenseDateFrom) {
		this.expenseDateFrom = expenseDateFrom;
	}

	public ZonedDateTime getExpenseDateTo() {
		return expenseDateTo;
	}

	public void setExpenseDateTo(ZonedDateTime expenseDateTo) {
		this.expenseDateTo = expenseDateTo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	 
	 

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public Long getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(Long sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}

	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}

	/*
	 * public List<ActivityLog> getActivityLogs() { return activityLogs; }
	 * 
	 * 
	 * public void setActivityLogs(List<ActivityLog> activityLogs) {
	 * this.activityLogs = activityLogs; }
	 */

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(Double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public long getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}

	public void setSspInvoiceReferenceNo(long sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmployee() {
		return employee;
	}

	public void setEmployee(String employee) {
		this.employee = employee;
	}

	public List<NewExpenseItems> getNewExpenseitems() {
		return newExpenseitems;
	}

	public void setNewExpenseitems(List<NewExpenseItems> newExpenseitems) {
		this.newExpenseitems = newExpenseitems;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}

	public void resubmitUpdate(CreateExpenseRequest expRequest) {
		this.isSAPSynch = false;
		this.SAPSynchDate = null;
		this.isSAPSynchACK = false;
		
		this.invoiceNumber = expRequest.getInvoiceNumber();
		this.expenseDateFrom=expRequest.getExpenseDateFrom();
		this.expenseDateTo=expRequest.getExpenseDateTo();
		
		this.grandTotal = expRequest.getGrandTotal();
		this.remarks = expRequest.getRemarks();
		this.notes = expRequest.getNotes();
		this.attachments = expRequest.getAttachments();
		if (expRequest.getNewExpenseitems() != null) {
			this.setNewExpenseitems(expRequest.getNewExpenseitems());
		}
		this.adhocApprovers = expRequest.getAdhocApprovers();
		this.employeeId = expRequest.getEmployeeId();
		this.title = expRequest.getTitle();
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public String getEmployeeLastName() {
		return employeeLastName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public void addAttachments(List<DocumentHelper> attachments) {

		if (attachments != null && attachments.size() > 0) {
			if (this.getAttachments() == null) {
				this.setAttachments(new ArrayList<>());
			}
			for (DocumentHelper docHelper : attachments) {
				this.getAttachments().add(docHelper);
			}
		} else {

		}
	}

	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}

	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					}
				}
			}
		
	}
}
