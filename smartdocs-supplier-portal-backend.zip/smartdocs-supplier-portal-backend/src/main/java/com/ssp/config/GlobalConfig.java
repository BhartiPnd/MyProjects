package com.ssp.config;

public class GlobalConfig {

	public static final String DEFAULT_CURRENCY="USD";
	
	private GlobalConfig() {}
}
