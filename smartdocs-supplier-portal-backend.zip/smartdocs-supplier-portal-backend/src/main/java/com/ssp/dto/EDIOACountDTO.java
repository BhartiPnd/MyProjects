package com.ssp.dto;

public class EDIOACountDTO {

	private long exceptionsCount;
	private long processedCount;

	public EDIOACountDTO() {
		super();
	}

	public long getExceptionsCount() {
		return exceptionsCount;
	}

	public void setExceptionsCount(long exceptionsCount) {
		this.exceptionsCount = exceptionsCount;
	}

	public long getProcessedCount() {
		return processedCount;
	}

	public void setProcessedCount(long processedCount) {
		this.processedCount = processedCount;
	}

}
