package com.ssp.dto;

public class AlkemResponse {

	private String timestamp;
	
 	private String Uid;
	
	private String email;
	
	private String hash;

	public String getTimestamp() {
		return timestamp;
	}

 
	public String getEmail() {
		return email;
	}

	public String getHash() {
		return hash;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	 

	public String getUid() {
		return Uid;
	}


	public void setUid(String uid) {
		Uid = uid;
	}


	public void setEmail(String email) {
		this.email = email;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}
	
	
	
}
