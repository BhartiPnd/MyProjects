package com.ssp.dto;

import java.time.ZonedDateTime;

public class SupplierInfoDTO {

	private String id;
	private String name;
	private double price;
	private ZonedDateTime validityTo;
	private ZonedDateTime validityFrom;

	public SupplierInfoDTO() {

	}

	

	



	public SupplierInfoDTO(String id, String name, double price, ZonedDateTime validityTo, ZonedDateTime validityFrom) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.validityTo = validityTo;
		this.validityFrom = validityFrom;
	}







	public ZonedDateTime getValidityTo() {
		return validityTo;
	}







	public void setValidityTo(ZonedDateTime validityTo) {
		this.validityTo = validityTo;
	}







	public ZonedDateTime getValidityFrom() {
		return validityFrom;
	}







	public void setValidityFrom(ZonedDateTime validityFrom) {
		this.validityFrom = validityFrom;
	}







	public String getId() {
		return id;
	}












	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
