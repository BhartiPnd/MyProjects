package com.ssp.dto;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collections.audit.TermsAndConditionsLog;

@Document(collection = "supplier")
public class VendorTandcLog {

	
	private String supplierId;
    private String name;
    private Address address;
    private String agreedBy;
    private String ipAddress;
    private String status;
    private String version;
    private ZonedDateTime dateTime;
	public String getSupplierId() {
		return supplierId;
	}
	public String getName() {
		return name;
	}
	public Address getAddress() {
		return address;
	}
	public String getAgreedBy() {
		return agreedBy;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public String getStatus() {
		return status;
	}
	public String getVersion() {
		return version;
	}
	public ZonedDateTime getDateTime() {
		return dateTime;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setAgreedBy(String agreedBy) {
		this.agreedBy = agreedBy;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}
    
	public void updateLogData(TermsAndConditionsLog log,String currentVerion) {
		this.agreedBy=log.getUser();
		this.ipAddress=log.getIp();
		if(currentVerion.equalsIgnoreCase(log.getVersion()))
		{
			this.status="Active";
		}
		else {
			this.status="InActive";
		}
		this.version=log.getVersion();
	    this.dateTime=log.getZonedDateTime();
	}
    
}
