package com.ssp.dto;

import javax.validation.constraints.NotBlank;

public class ResetPasswordRequest {

	 	@NotBlank
	    private String uuid;

	    @NotBlank
	    private String password;

		public String getUuid() {
			return uuid;
		}

		public String getPassword() {
			return password;
		}

		public void setUuid(String uuid) {
			this.uuid = uuid;
		}

		public void setPassword(String password) {
			this.password = password;
		}
	    
	    
}
