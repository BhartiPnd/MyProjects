package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.CommentLog;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.LineItems;
import com.ssp.mongo.collections.AbstractAuditingEntity;
import com.ssp.mongo.collections.list.InvoiceType;
import com.ssp.mongo.collections.requests.BankDetail;
import com.ssp.travler.InvoieValidationResult;

@Document(collection = "invoice")
public class InvoiceDetail extends AbstractAuditingEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8822587014610860952L;
	
	@Id
	private String id;
	private long sspInvoiceReferenceNo;
	private String invoiceNumber;
	private String sapInvoiceNo;

	private String supplierId;
	private String supplier;

	private String companyCode;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime supplyDate;

	private Address remittoaddress;
	private Address shiptoaddress;
	private String tempBufferId; 
	private String currency;
	//private Double taxAmount; 
	//private Double subTotal; // total of invoice line item netAmount.
	//private Double totalDiscount; // total of invoice line item discount.
									// display only not participate in any
									// calculation . already calculated.
	//private Double additionalDiscount; // new additional header discount.

	// private Double totalNetAmount; // subTotal-additionalDiscount
	//private Double freightAmount; // input based on invoice type.
	 
	private String paymentterms;
	private String paymenttermsDesc;
	private String freightCarrier;
	private String poNumber;
	private String poDescription;

	// PO// NOnPo// Expense
	private String invoiceCategory;

	private String status;
	private String statusDesc;

	private Map<String, String> headerAttributes;
	private String invoiceType;
	private InvoiceType invoiceTypeDetail;
	private String invoiceTypeDesc;
	
	private String creator;
	private BankDetail bankDetails;
	private boolean oneTime;
	
	private boolean isCreatedByVendor;

	private String channel;
	private String channelDesc;
	private String requestId;
	private String invoiceDocId;
	private List<DocumentHelper> attachments;
	private String notes;
	// private String comments;
	private List<LineItems> invoiceitems;

	private String buyer;
	private String requestor;

	// private String requestorEmailAddress;
	private List<CommentLog> commentLogs;

	private boolean creditMemo;

	private String cadsNumber;
	private String billAccNumber;
	private String billAccName;

	private List<AdhocApprover> adhocApprovers;
	private List<ActivityLog> activityLogs;
	// private WorkFlow workFlow;
	
	// input field.
	private float taxPercent; 
	//calculated
	private double subTotal;
	// editable.
	private double discount;
	// calculated
	private double netAmount;
	// editable
	private double taxAmount;
	// editable
	private double freightAmount;
	// calculated
	private double totalAmount;
	// input
	private double totalInvoiceAmount;

	private Boolean isSAPSynch;
	private Long SAPSynchDate;
	private Boolean isSAPSynchACK;
	private String requestorEmail;
	private String shoppingCartNo;
	private String shipmentType;
	private boolean confidential;
	private boolean afterFactPO;
	private List<InvoieValidationResult> validationResut;
	private String eventNumber;
	private String eventDescription;
	private boolean analyticsSyncStatus;
	private DocumentHelper email; 
	private String bankAccountNumber;
	 
	private String costCenter;
	private String wbsElement;
    private String glAccount;
	private String accountNumber;
	private String approver;
 
	private ZonedDateTime invoiceDocumentDate;
	private String datesOfService;
	private String invoiceTypeCategory;
	private ZonedDateTime paidDate;
	private boolean asset;
	private String abaNo;
	private ActivityLog recentActivity;
	private boolean duplicate;
	private String logicalSystem;
	private String year;
	
	InvoieValidationResult exceptions;
	
	public InvoiceType getInvoiceTypeDetail() {
		return invoiceTypeDetail;
	}

	public String getChannelDesc() {
		return channelDesc;
	}

	public void setInvoiceTypeDetail(InvoiceType invoiceTypeDetail) {
		this.invoiceTypeDetail = invoiceTypeDetail;
	}

	public void setChannelDesc(String channelDesc) {
		this.channelDesc = channelDesc;
	}
	
	public String getTempBufferId() {
		return tempBufferId;
	}

	public void setTempBufferId(String tempBufferId) {
		this.tempBufferId = tempBufferId;
	}

	public String getId() {
		return id;
	}

	public long getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}

	public ZonedDateTime getDueDate() {
		return dueDate;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}

	public Address getRemittoaddress() {
		return remittoaddress;
	}

	public Address getShiptoaddress() {
		return shiptoaddress;
	}

	public String getPaymentterms() {
		return paymentterms;
	}

	public String getFreightCarrier() {
		return freightCarrier;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public String getInvoiceCategory() {
		return invoiceCategory;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public String getSupplier() {
		return supplier;
	}

	public String getStatus() {
		return status;
	}

	public Map<String, String> getHeaderAttributes() {
		return headerAttributes;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	 
	public String getCreator() {
		return creator;
	}

	public String getChannel() {
		return channel;
	}

	public String getRequestId() {
		return requestId;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public String getNotes() {
		return notes;
	}
	//
	// public String getComments() {
	// return comments;
	// }

	public List<LineItems> getInvoiceitems() {
		return invoiceitems;
	}

	/*
	 * public String getRequestorEmailAddress() { return requestorEmailAddress;
	 * }
	 */

	 
	public List<CommentLog> getCommentLogs() {
		return commentLogs;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public Long getSAPSynchDate() {
		return SAPSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setSspInvoiceReferenceNo(long sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}

	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}

	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setHeaderAttributes(Map<String, String> headerAttributes) {
		this.headerAttributes = headerAttributes;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	 

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	// public void setComments(String comments) {
	// this.comments = comments;
	// }

	/*
	 * public String getCadsNo() { return cadsNo; }
	 * 
	 * public void setCadsNo(String cadsNo) { this.cadsNo = cadsNo; }
	 */

	public void setInvoiceitems(List<LineItems> invoiceitems) {
		this.invoiceitems = invoiceitems;
	}

	/*
	 * public void setRequestorEmailAddress(String requestorEmailAddress) {
	 * this.requestorEmailAddress = requestorEmailAddress; }
	 */
	 

	public void setCommentLogs(List<CommentLog> commentLogs) {
		this.commentLogs = commentLogs;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public void setSAPSynchDate(Long sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public String getCurrency() {
		return currency;
	}

	 

	public Float getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(Float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	 

	public String getSapInvoiceNo() {
		return sapInvoiceNo;
	}

	public void setSapInvoiceNo(String sapInvoiceNo) {
		this.sapInvoiceNo = sapInvoiceNo;
	}

	public boolean isCreditMemo() {
		return creditMemo;
	}

	public String getRequestor() {
		return requestor;
	}

	public String getCadsNumber() {
		return cadsNumber;
	}

	public String getBillAccNumber() {
		return billAccNumber;
	}

	public String getBillAccName() {
		return billAccName;
	}

	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public void setCadsNumber(String cadsNumber) {
		this.cadsNumber = cadsNumber;
	}

	public void setBillAccNumber(String billAccNumber) {
		this.billAccNumber = billAccNumber;
	}

	public void setBillAccName(String billAccName) {
		this.billAccName = billAccName;
	}

	 

	public void addCommentLogs(String commentLogs, String userId) {
		if ((commentLogs != null && !commentLogs.trim().equals(""))) {
			if (this.getCommentLogs() == null) {
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(false, commentLogs, userId));
		}

	}

	public void addCommentLogs(boolean workFlow, String commentLogs, String userId, String oldStatus,
			String newStatus) {
		if (workFlow || (commentLogs != null && !commentLogs.trim().equals(""))) {
			if (this.getCommentLogs() == null) {
				this.setCommentLogs(new ArrayList<>());
			}
			this.getCommentLogs().add(new CommentLog(workFlow, commentLogs, userId, oldStatus, newStatus));
		}
	}

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public void addActivityLogs(ActivityLog activityLog) {
		if (this.getActivityLogs() == null) {
			this.setActivityLogs(new ArrayList<>());
		}
		if (this.getActivityLogs().size() > 1) {
			ActivityLog activityLog2 = this.activityLogs.get(this.getActivityLogs().size() - 1);
			if (activityLog.getStep() == activityLog2.getStep()) {
				activityLog.setSeq(activityLog2.getSeq() + 1);
			}
		}

		this.getActivityLogs().add(activityLog);
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}

	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}

	public String getShoppingCartNo() {
		return shoppingCartNo;
	}

	public void setShoppingCartNo(String shoppingCartNo) {
		this.shoppingCartNo = shoppingCartNo;
	}

	public String getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(String shipmentType) {
		this.shipmentType = shipmentType;
	}

	public boolean isConfidential() {
		return confidential;
	}

	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}

	public String getPoDescription() {
		return poDescription;
	}

	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}

	public boolean isAfterFactPO() {
		return afterFactPO;
	}

	public void setAfterFactPO(boolean afterFactPO) {
		this.afterFactPO = afterFactPO;
	}

	public List<InvoieValidationResult> getValidationResut() {
		return validationResut;
	}

	public void setValidationResut(List<InvoieValidationResult> validationResut) {
		this.validationResut = validationResut;
	}

	public String getEventNumber() {
		return eventNumber;
	}

	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public boolean isAnalyticsSyncStatus() {
		return analyticsSyncStatus;
	}

	public void setAnalyticsSyncStatus(boolean analyticsSyncStatus) {
		this.analyticsSyncStatus = analyticsSyncStatus;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getAbaNo() {
		return abaNo;
	}

	public void setAbaNo(String abaNo) {
		this.abaNo = abaNo;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public String getGlAccount() {
		return glAccount;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getApprover() {
		return approver;
	}

	public ZonedDateTime getInvoiceDocumentDate() {
		return invoiceDocumentDate;
	}

	 

	public ZonedDateTime getPaidDate() {
		return paidDate;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public void setInvoiceDocumentDate(ZonedDateTime invoiceDocumentDate) {
		this.invoiceDocumentDate = invoiceDocumentDate;
	}
	public void setPaidDate(ZonedDateTime paidDate) {
		this.paidDate = paidDate;
	}
	public String getDatesOfService() {
		return datesOfService;
	}
	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}

	public boolean isCreatedByVendor() {
		return isCreatedByVendor;
	}

	public void setCreatedByVendor(boolean isCreatedByVendor) {
		this.isCreatedByVendor = isCreatedByVendor;
	}

	public String getInvoiceTypeCategory() {
		return invoiceTypeCategory;
	}

	public void setInvoiceTypeCategory(String invoiceTypeCategory) {
		this.invoiceTypeCategory = invoiceTypeCategory;
	}

	public String getInvoiceTypeDesc() {
		return invoiceTypeDesc;
	}

	public void setInvoiceTypeDesc(String invoiceTypeDesc) {
		this.invoiceTypeDesc = invoiceTypeDesc;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public boolean isDuplicate() {
		return duplicate;
	}

	public void setDuplicate(boolean duplicate) {
		this.duplicate = duplicate;
	}

	public String getInvoiceDocId() {
		return invoiceDocId;
	}

	public void setInvoiceDocId(String invoiceDocId) {
		this.invoiceDocId = invoiceDocId;
	}

	public String getLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	 

	public String getPaymenttermsDesc() {
		return paymenttermsDesc;
	}

	public void setPaymenttermsDesc(String paymenttermsDesc) {
		this.paymenttermsDesc = paymenttermsDesc;
	}

	public DocumentHelper getEmail() {
		return email;
	}

	public void setEmail(DocumentHelper email) {
		this.email = email;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public double getFreightAmount() {
		return freightAmount;
	}

	public void setFreightAmount(double freightAmount) {
		this.freightAmount = freightAmount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	public void setTaxPercent(float taxPercent) {
		this.taxPercent = taxPercent;
	}

	 

	public InvoieValidationResult getExceptions() {
		return exceptions;
	}

	public void setExceptions(InvoieValidationResult exceptions) {
		this.exceptions = exceptions;
	}

	public ActivityLog getRecentActivity() {
		return recentActivity;
	}

	public void setRecentActivity(ActivityLog recentActivity) {
		this.recentActivity = recentActivity;
	}

	public BankDetail getBankDetails() {
		return bankDetails;
	}

	public boolean isOneTime() {
		return oneTime;
	}

	public void setBankDetails(BankDetail bankDetails) {
		this.bankDetails = bankDetails;
	}

	public void setOneTime(boolean oneTime) {
		this.oneTime = oneTime;
	}

	public boolean isAsset() {
		return asset;
	}

	public void setAsset(boolean asset) {
		this.asset = asset;
	}
	
	
}
