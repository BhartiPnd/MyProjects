package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.requests.FieldValues;

public class UploadVendorMasterDocumentRequest {

	private String supplierId;
	private String documentType;
	
	private long refId;
	private String action;
	private String comment;
	
	private DocumentHelper  document;
	private List<FieldValues> fieldValues;
	private ZonedDateTime validityStartDate;
	private ZonedDateTime validityEndDate;
	 
	public String getSupplierId() {
		return supplierId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public DocumentHelper getDocument() {
		return document;
	}
	public ZonedDateTime getValidityStartDate() {
		return validityStartDate;
	}
	public ZonedDateTime getValidityEndDate() {
		return validityEndDate;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public void setDocument(DocumentHelper document) {
		this.document = document;
	}
	public void setValidityStartDate(ZonedDateTime validityStartDate) {
		this.validityStartDate = validityStartDate;
	}
	public void setValidityEndDate(ZonedDateTime validityEndDate) {
		this.validityEndDate = validityEndDate;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public List<FieldValues> getFieldValues() {
		return fieldValues;
	}
	public void setFieldValues(List<FieldValues> fieldValues) {
		this.fieldValues = fieldValues;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	  
	
	
}
