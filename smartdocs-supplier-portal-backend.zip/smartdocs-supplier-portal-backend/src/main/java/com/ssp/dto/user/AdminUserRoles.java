package com.ssp.dto.user;

public class AdminUserRoles {

	private String role;
	private boolean hasAccess;
	public AdminUserRoles() {
		super();
	}
	public AdminUserRoles(String role, boolean hasAccess) {
		super();
		this.role = role;
		this.hasAccess = hasAccess;
	}
	public String getRole() {
		return role;
	}
	public boolean isHasAccess() {
		return hasAccess;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public void setHasAccess(boolean hasAccess) {
		this.hasAccess = hasAccess;
	}
	
	
}
