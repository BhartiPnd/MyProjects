package com.ssp.dto;

public class SubmitExpenseReportDTO {
	
	private String reportId;
	private String title;
	private String wbsElementNumber;
	private String policy;
	private String supervisor;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getPolicy() {
		return policy;
	}
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	public String getSupervisor() {
		return supervisor;
	}
	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWbsElementNumber() {
		return wbsElementNumber;
	}
	public void setWbsElementNumber(String wbsElementNumber) {
		this.wbsElementNumber = wbsElementNumber;
	}
	
	
}
