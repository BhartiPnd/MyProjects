package com.ssp.dto.requests;

public class BidReassigneRequest {
	
	private String bidNo;
	private String supplierId;
	private String newOwner;
	public String getBidNo() {
		return bidNo;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getNewOwner() {
		return newOwner;
	}
	public void setBidNo(String bidNo) {
		this.bidNo = bidNo;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setNewOwner(String newOwner) {
		this.newOwner = newOwner;
	}
	
	
}
