package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXBidder;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.RequiredDocumentType;
import com.ssp.mongo.collections.rfx.RequiredInfo;

public class RfxUpdateDto {
	
	private String rfxNo;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	private List<RFXItems> items;
	private List<RFXBidder> bidders;
	private List<RequiredDocumentType> requiredDocuments;
	private List<RequiredInfo> requiredInfo;
	private List<DocumentHelper> attachments;
	
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}
	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}
	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}
	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	public List<RFXBidder> getBidders() {
		return bidders;
	}
	public void setBidders(List<RFXBidder> bidders) {
		this.bidders = bidders;
	}
	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}
	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}
	public List<RequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}
	public void setRequiredInfo(List<RequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	
	
}
