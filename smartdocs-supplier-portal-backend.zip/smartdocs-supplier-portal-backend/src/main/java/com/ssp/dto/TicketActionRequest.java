package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class TicketActionRequest {
	
	public static final String ACTION_EVENT_CHANGE_STATUS="ChangeStatus";
	public static final String ACTION_EVENT_CHANGE_COMMENT="Comment";
	public static final String ACTION_EVENT_CHANGE_COLLABORATED="Collaborated";
	public static final String ACTION_EVENT_CHANGE_PRIORITY="ChangePriority";

	private String id;
	private List<DocumentHelper> attachments;
	private String notes;
	
	private String event;
	private String data;
	private boolean changeStatus;
	private String isCreator;
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getIsCreator() {
		return isCreator;
	}

	public void setIsCreator(String isCreator) {
		this.isCreator = isCreator;
	}

	public boolean isChangeStatus() {
		return changeStatus;
	}

	public void setChangeStatus(boolean changeStatus) {
		this.changeStatus = changeStatus;
	}

	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		if(this.attachments!=null && this.attachments.size()>0)
		{
			for(DocumentHelper attachment:this.attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
				
			}
			
		}
	}
}
