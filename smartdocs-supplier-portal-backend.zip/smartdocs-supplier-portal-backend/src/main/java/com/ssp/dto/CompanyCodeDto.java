package com.ssp.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.ToleranceConfig;
import com.ssp.mongo.collections.CompanyCode;
import com.ssp.mongo.collections.EsclationConfig;

@Document(collection = "companycode")
public class CompanyCodeDto {

	@Id
	private String id;
	private String companycode;
	private String name;
	
	// this means this is head office or main organization.
	private boolean isMain;
	private String paymentTerm;
	private boolean paymentBlock; 
	private Address primaryAddress;
	private List<Address> address;
	//private List<Address> shiptoaddress;

	private Long createddatetime;
	private Long modifieddatetime;
	
	private ToleranceConfig toleranceConfig;
	private EsclationConfig esclationConfig;

	
	
	public CompanyCodeDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CompanyCodeDto(CompanyCode cc) {
		this.id = cc.getId();
		this.companycode = cc.getCompanycode();
		this.name = cc.getName();
		this.primaryAddress = cc.getPrimaryAddress();
		this.address = cc.getAddress();
		this.createddatetime = cc.getCreateddatetime();
		this.modifieddatetime = cc.getModifieddatetime();
		this.toleranceConfig = cc.getToleranceConfig();
		this.esclationConfig = cc.getEsclationConfig();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

 
	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	@Override
	public String toString() {
		return "CompanyCode [id=" + id + ", companycode=" + companycode
				+ ", name=" + name + ", address="
				+ address  
				+ ", createddatetime=" + createddatetime
				+ ", modifieddatetime=" + modifieddatetime + "]";
	}

	public void copy(CompanyCodeDto cc){
		this.companycode = cc.getCompanycode();
		this.name = cc.getName();
		this.address = cc.getAddress();
		//this.shiptoaddress = cc.getShiptoaddress();
	}

	public Address getPrimaryAddress() {
		return primaryAddress;
	}

	public void setPrimaryAddress(Address primaryAddress) {
		this.primaryAddress = primaryAddress;
	}

	public boolean isMain() {
		return isMain;
	}

	public void setMain(boolean isMain) {
		this.isMain = isMain;
	}

	public ToleranceConfig getToleranceConfig() {
		return toleranceConfig;
	}

	public void setToleranceConfig(ToleranceConfig toleranceConfig) {
		this.toleranceConfig = toleranceConfig;
	}

	public EsclationConfig getEsclationConfig() {
		return esclationConfig;
	}

	public void setEsclationConfig(EsclationConfig esclationConfig) {
		this.esclationConfig = esclationConfig;
	}

	public String getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public boolean isPaymentBlock() {
		return paymentBlock;
	}

	public void setPaymentBlock(boolean paymentBlock) {
		this.paymentBlock = paymentBlock;
	}
	
}
