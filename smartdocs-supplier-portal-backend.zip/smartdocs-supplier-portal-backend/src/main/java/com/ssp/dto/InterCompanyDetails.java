package com.ssp.dto;

public class InterCompanyDetails {

	private String tradingPartner;
	private String customerId;
	private String groupKey;

	public InterCompanyDetails(String tradingPartner, String constomerId, String groupKey) {
		super();
		this.tradingPartner = tradingPartner;
		this.customerId = constomerId;
		this.groupKey = groupKey;
	}

	public InterCompanyDetails() {

	}

	public String getTradingPartner() {
		return tradingPartner;
	}

	public void setTradingPartner(String tradingPartner) {
		this.tradingPartner = tradingPartner;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getGroupKey() {
		return groupKey;
	}

	public void setGroupKey(String groupKey) {
		this.groupKey = groupKey;
	}

}
