package com.ssp.dto;

import com.ssp.mongo.collections.requests.VendorRegistrationRequest;

public class CreateVendorRegistrationRequest  extends VendorRegistrationRequest{

	private String activityCode;
//	private String requestorEmail;
	private String action;
//	private String collaboratedUser;

	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
//	public String getRequestorEmail() {
//		return requestorEmail;
//	}
//	public void setRequestorEmail(String requestorEmail) {
//		this.requestorEmail = requestorEmail;
//	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
//	public String getCollaboratedUser() {
//		return collaboratedUser;
//	}
//	public void setCollaboratedUser(String collaboratedUser) {
//		this.collaboratedUser = collaboratedUser;
//	}
	
	
}
