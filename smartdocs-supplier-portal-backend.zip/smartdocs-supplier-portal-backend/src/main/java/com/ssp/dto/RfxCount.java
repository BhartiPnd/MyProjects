package com.ssp.dto;

public class RfxCount {
	
	private long all;
	private long open;
	private long myBids;
	private long inEvaluation;
	private long awarded;
	private long cancelled;
	private long closed;
	
	public long getOpen() {
		return open;
	}
	public void setOpen(long open) {
		this.open = open;
	}
	
	public long getInEvaluation() {
		return inEvaluation;
	}
	public void setInEvaluation(long inEvaluation) {
		this.inEvaluation = inEvaluation;
	}
	public long getAwarded() {
		return awarded;
	}
	public void setAwarded(long awarded) {
		this.awarded = awarded;
	}
	public long getCancelled() {
		return cancelled;
	}
	public void setCancelled(long cancelled) {
		this.cancelled = cancelled;
	}
	public long getClosed() {
		return closed;
	}
	public void setClosed(long closed) {
		this.closed = closed;
	}
	public long getAll() {
		return all;
	}
	public void setAll(long all) {
		this.all = all;
	}
	public long getMyBids() {
		return myBids;
	}
	public void setMyBids(long myBids) {
		this.myBids = myBids;
	}
	
	

}
