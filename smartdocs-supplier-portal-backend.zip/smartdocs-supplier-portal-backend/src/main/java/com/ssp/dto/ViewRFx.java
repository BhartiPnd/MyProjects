package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.BidRFx;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.RequiredDocumentType;
import com.ssp.mongo.collections.rfx.RequiredInfo;
import com.ssp.mongo.collections.rfx.Rfx;

public class ViewRFx {
	
	private String id;
	private String title;
	private String companyCode;
	private String companyName;
	private String rfxNo;
	private String type;
	private String status;
	private String visibility;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;
	
	private String requestorEmail;
	private String requestorName;
	
	private String buyerEmail;
	private String buyerName;
	private String classification;
	
	private String category;

	private List<RequiredDocumentType> requiredDocuments;
	
	private List<RFXItems> items;  
	private List<DocumentHelper> attachments;
	private List<DocumentHelper> originalDocuments;
	
	private List<RequiredInfo> questions;    
	
	private boolean awarded;
	private boolean canBid;
	private boolean canQanda;

	private ZonedDateTime submissionStartDate;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	private ZonedDateTime publishedDate;

	private BidRFx bidRFx;
	
	public ViewRFx() {
		super();
	}
	public ViewRFx(Rfx rfx) {
		this.id=rfx.getId();
		this.title=rfx.getTitle();
		this.status=rfx.getStatus();
		this.companyCode = rfx.getCompanyCode();
		this.publishedDate=rfx.getPublishedDate();
		this.rfxNo=rfx.getRfxNo();
		this.visibility=rfx.getVisibility();
		this.requiredDocuments=rfx.getRequiredDocuments();
		this.items=rfx.getItems();
		this.attachments=rfx.getAttachments();
		this.questions=rfx.getRequiredInfo();
		this.purchasingGroup = rfx.getPurchasingGroup();
		this.purchasingGroupDesc = rfx.getPurchasingGroupDesc();
		this.submissionStartDate=rfx.getSubmissionStartDate();
		this.submissionEndDate=rfx.getSubmissionEndDate();
		this.qAndADeadline=rfx.getqAndADeadline();
		this.publishedDate=rfx.getPublishedDate();
		this.buyerEmail = rfx.getBuyerEmail();
		this.buyerName = rfx.getBuyerName();
		this.type = rfx.getType();
		this.purchasingOrg = rfx.getPurchasingOrg();
		this.purchasingOrgDesc = rfx.getPurchasingOrgDesc();
		this.requestorEmail = rfx.getRequestorEmail();
		this.requestorName = rfx.getRequestorName();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getRfxNo() {
		return rfxNo;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<RFXItems> getItems() {
		return items;
	}

	public void setItems(List<RFXItems> items) {
		this.items = items;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public List<DocumentHelper> getOriginalDocuments() {
		return originalDocuments;
	}

	public void setOriginalDocuments(List<DocumentHelper> originalDocuments) {
		this.originalDocuments = originalDocuments;
	}

	public List<RequiredInfo> getQuestions() {
		return questions;
	}

	public void setQuestions(List<RequiredInfo> questions) {
		this.questions = questions;
	}

	public boolean isAwarded() {
		return awarded;
	}

	public void setAwarded(boolean awarded) {
		this.awarded = awarded;
	}

	public boolean isCanBid() {
		return canBid;
	}

	public void setCanBid(boolean canBid) {
		this.canBid = canBid;
	}

	public boolean isCanQanda() {
		return canQanda;
	}

	public void setCanQanda(boolean canQanda) {
		this.canQanda = canQanda;
	}

	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	public BidRFx getBidRFx() {
		return bidRFx;
	}

	public void setBidRFx(BidRFx bidRFx) {
		this.bidRFx = bidRFx;
	}
	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}
	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	
	
}
