package com.ssp.dto;

import java.util.List;

public class AwardedLine {
	
	private String lineNo;
	private String itemNumber;
	private String itemName;
	private String uom;
	private String uomDesc;
	private double quantity;
	private String currency;
	private List<AwardedBidders> awardedBidders;
	
	public AwardedLine() {
		super();
	}

	public String getLineNo() {
		return lineNo;
	}

	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<AwardedBidders> getAwardedBidders() {
		return awardedBidders;
	}

	public void setAwardedBidders(List<AwardedBidders> awardedBidders) {
		this.awardedBidders = awardedBidders;
	}
	
}
