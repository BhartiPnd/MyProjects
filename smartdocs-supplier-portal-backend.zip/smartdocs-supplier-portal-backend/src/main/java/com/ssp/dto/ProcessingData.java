package com.ssp.dto;

public class ProcessingData {

	private boolean sapDuplicateCheck;
	private boolean vendorBankDetail;
	private boolean attachAllRegionTaxForm;
	
	public boolean isSapDuplicateCheck() {
		return sapDuplicateCheck;
	}
	public void setSapDuplicateCheck(boolean sapDuplicateCheck) {
		this.sapDuplicateCheck = sapDuplicateCheck;
	}
	public boolean isVendorBankDetail() {
		return vendorBankDetail;
	}
	public void setVendorBankDetail(boolean vendorBankDetail) {
		this.vendorBankDetail = vendorBankDetail;
	}
	public boolean isAttachAllRegionTaxForm() {
		return attachAllRegionTaxForm;
	}
	public void setAttachAllRegionTaxForm(boolean attachAllRegionTaxForm) {
		this.attachAllRegionTaxForm = attachAllRegionTaxForm;
	}
}
