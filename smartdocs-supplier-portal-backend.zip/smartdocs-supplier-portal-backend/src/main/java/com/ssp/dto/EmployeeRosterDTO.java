package com.ssp.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.CustomUserCompanies;

@Document(collection = "employeeMaster")
public class EmployeeRosterDTO {
	
	private String employeeId;
	private String name;
	private CustomUserCompanies allowedCompanies;
	private List<String> authPermissionGroups;
	private String department;
	private String title;
	private String phoneNumber;
	private String approvalLimit;
	private String manager;
	private String currency;
	private String status;
	private String email;
	
	public EmployeeRosterDTO() {
		super();
	}
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public CustomUserCompanies getAllowedCompanies() {
		return allowedCompanies;
	}

	public void setAllowedCompanies(CustomUserCompanies allowedCompanies) {
		this.allowedCompanies = allowedCompanies;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<String> getAuthPermissionGroups() {
		return authPermissionGroups;
	}

	public void setAuthPermissionGroups(List<String> authPermissionGroups) {
		this.authPermissionGroups = authPermissionGroups;
	}

	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getApprovalLimit() {
		return approvalLimit;
	}
	public void setApprovalLimit(String approvalLimit) {
		this.approvalLimit = approvalLimit;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	
}
