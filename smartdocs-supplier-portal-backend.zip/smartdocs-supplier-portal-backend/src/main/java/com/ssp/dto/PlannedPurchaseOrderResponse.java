package com.ssp.dto;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class PlannedPurchaseOrderResponse {

	private Map<String,String> monthList;
	private Map<String,String> weeksList;
	private List<PlannedPurchaseOrderDto>  monthData;
	private List<PlannedPurchaseOrderDto>  weeksData;
	private Map<String,Set<String>> pps;
	
	public PlannedPurchaseOrderResponse(Map<String, String> monthList, Map<String, String> weeksList,
			List<PlannedPurchaseOrderDto> monthData, List<PlannedPurchaseOrderDto> weeksData,Map<String,Set<String>> pps) {
		super();
		this.monthList = monthList;
		this.weeksList = weeksList;
		this.monthData = monthData;
		this.weeksData = weeksData;
		this.pps=pps;
	}
	public Map<String, String> getMonthList() {
		return monthList;
	}
	public void setMonthList(Map<String, String> monthList) {
		this.monthList = monthList;
	}
	public Map<String, String> getWeeksList() {
		return weeksList;
	}
	public void setWeeksList(Map<String, String> weeksList) {
		this.weeksList = weeksList;
	}
	public List<PlannedPurchaseOrderDto> getMonthData() {
		return monthData;
	}
	public void setMonthData(List<PlannedPurchaseOrderDto> monthData) {
		this.monthData = monthData;
	}
	public List<PlannedPurchaseOrderDto> getWeeksData() {
		return weeksData;
	}
	public void setWeeksData(List<PlannedPurchaseOrderDto> weeksData) {
		this.weeksData = weeksData;
	}
	public Map<String, Set<String>> getPps() {
		return pps;
	}
	public void setPps(Map<String, Set<String>> pps) {
		this.pps = pps;
	}
	
	
}
 