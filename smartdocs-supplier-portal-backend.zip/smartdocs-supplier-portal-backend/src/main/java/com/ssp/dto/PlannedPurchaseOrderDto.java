package com.ssp.dto;

import java.time.ZonedDateTime;

public class PlannedPurchaseOrderDto {
	
	private String _id;
	private String material;
	private String productionPlant;
	private String materialDescription;
	private long totalQty;
	private long count;
	private String month;
	private String year;
	private int weekNo;
	private ZonedDateTime  openDate;
	private ZonedDateTime  finishDate;
	private String view;
	private int index;
	private String fixVendor;
	private String unitOfMeasure;
	private String companyCode;
	private boolean ploExists;
	public long getTotalQty() {
		return totalQty;
	}
	public void setTotalQty(long totalQty) {
		this.totalQty = totalQty;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getProductionPlant() {
		return productionPlant;
	}
	public void setProductionPlant(String productionPlant) {
		this.productionPlant = productionPlant;
	}
	public int getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(int weekNo) {
		this.weekNo = weekNo;
	}
	public ZonedDateTime getOpenDate() {
		return openDate;
	}
	public void setOpenDate(ZonedDateTime openDate) {
		this.openDate = openDate;
	}
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getMaterialDescription() {
		return materialDescription;
	}
	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}
	public String getFixVendor() {
		return fixVendor;
	}
	public void setFixVendor(String fixVendor) {
		this.fixVendor = fixVendor;
	}
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public boolean isPloExists() {
		return ploExists;
	}
	public void setPloExists(boolean ploExists) {
		this.ploExists = ploExists;
	}
	public ZonedDateTime getFinishDate() {
		return finishDate;
	}
	public void setFinishDate(ZonedDateTime finishDate) {
		this.finishDate = finishDate;
	}
	
	
	
}
