package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class InboxActionRequest {
	
	public static final String ACTION_APPROVE="Approve";
	public static final String ACTION_REJECT="Reject";
	public static final String ACTION_FORWARD="Forward";
	public static final String ACTION_COLLOBORATE="Collaborate";
	public static final String ACTION_COLLOBORATE_BACK="CollaborateBack";
	public static final String ACTION_CANCEL="Cancel";
	
	
	private String action;
	private String type;
	private String id;
	private String notes;
	private List<AdhocApprover> adhocApprovers;
	private List<DocumentHelper> attachments;
	private String collaboratedUsers;
	private String activityCode;
 
	
	private String forwardTo;
	
	public String getAction() {
		return action;
	}
	public String getType() {
		return type;
	}
	public String getId() {
		return id;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCollaboratedUsers() {
		return collaboratedUsers;
	}
	public void setCollaboratedUsers(String collaboratedUsers) {
		this.collaboratedUsers = collaboratedUsers;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}
	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getForwardTo() {
		return forwardTo;
	}
	public void setForwardTo(String forwardTo) {
		this.forwardTo = forwardTo;
	}
	
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		if(this.attachments!=null && this.attachments.size()>0)
		{
			for(DocumentHelper attachment:this.attachments) {
				if(attachment.getUploadedDate()==null) {
					attachment.setUploadedDate(ZonedDateTime.now());
				}
				if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
					attachment.setUploadedBy(uploadedBy);
					attachment.setUsrUploaded(usrUploaded);
				}
				
			}
			
		}
	}
	
}
