package com.ssp.dto.plannedpo;

public class PlannedPurchaseOrderCol {

}
