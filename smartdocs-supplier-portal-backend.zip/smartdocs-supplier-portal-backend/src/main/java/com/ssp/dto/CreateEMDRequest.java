package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.Map;

import org.springframework.data.annotation.Id;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;

public class CreateEMDRequest {

	private String id;
	private String requestId;
	private String documentType;
	private String  employeeId;
	private String  status;
	
	private DocumentHelper attachment;
	private ZonedDateTime uploadedDate;
	private ZonedDateTime expirationDate;
	private Map<String, String> mataData;
	
	
	private String activityCode;
	private String requestorEmail;
	private String action;
	private String collaboratedUser;
	
	private String notes;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	public Map<String, String> getMataData() {
		return mataData;
	}
	public void setMataData(Map<String, String> mataData) {
		this.mataData = mataData;
	}
	 
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	
	
	
}
