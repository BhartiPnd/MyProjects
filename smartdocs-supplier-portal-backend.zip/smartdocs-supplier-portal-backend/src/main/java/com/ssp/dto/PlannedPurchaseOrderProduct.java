package com.ssp.dto;

import java.util.ArrayList;
import java.util.List;

public class PlannedPurchaseOrderProduct {

	private String product;
	private String prpductDescription;
	private  List<PlannedPurchaseOrderProductWeekData> weekData=new ArrayList<>();
	
	public PlannedPurchaseOrderProduct() {
		super();
	}
	public PlannedPurchaseOrderProduct(String product, String prpductDescription,
			List<PlannedPurchaseOrderProductWeekData> weekData) {
		super();
		this.product = product;
		this.prpductDescription = prpductDescription;
		this.weekData = weekData;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPrpductDescription() {
		return prpductDescription;
	}
	public void setPrpductDescription(String prpductDescription) {
		this.prpductDescription = prpductDescription;
	}
	public List<PlannedPurchaseOrderProductWeekData> getWeekData() {
		return weekData;
	}
	public void setWeekData(List<PlannedPurchaseOrderProductWeekData> weekData) {
		this.weekData = weekData;
	}
	
}
