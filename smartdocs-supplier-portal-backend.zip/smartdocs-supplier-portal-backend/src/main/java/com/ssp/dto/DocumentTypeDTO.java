package com.ssp.dto;

import java.util.List;

public class DocumentTypeDTO {
	
	private String title;
	private String desc;
	private boolean confidential;
	private List<String> allowedUsers;
	private List<String> supportedFileTypes;
	private int maxFileSizeOfSignleDoc;
	private int maxAllowedDoc;
	private boolean required;
	
	
	public String getTitle() {
		return title;
	}
	public String getDesc() {
		return desc;
	}
	public boolean isConfidential() {
		return confidential;
	}
	public List<String> getAllowedUsers() {
		return allowedUsers;
	}
	
	public List<String> getSupportedFileTypes() {
		return supportedFileTypes;
	}
	public int getMaxFileSizeOfSignleDoc() {
		return maxFileSizeOfSignleDoc;
	}
	public int getMaxAllowedDoc() {
		return maxAllowedDoc;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}
	public void setAllowedUsers(List<String> allowedUsers) {
		this.allowedUsers = allowedUsers;
	}
	
	public void setSupportedFileTypes(List<String> supportedFileTypes) {
		this.supportedFileTypes = supportedFileTypes;
	}
	public void setMaxFileSizeOfSignleDoc(int maxFileSizeOfSignleDoc) {
		this.maxFileSizeOfSignleDoc = maxFileSizeOfSignleDoc;
	}
	public void setMaxAllowedDoc(int maxAllowedDoc) {
		this.maxAllowedDoc = maxAllowedDoc;
	}
	public boolean isRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	
	

}
