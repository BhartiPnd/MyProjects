package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.smartbuy.PurchaseReqRequestLine;

@Document(collection = "PurchaseReqRequest")
public class PurchaseReqRequestDto {
	
	@Id
	private String id;
	private String requestId;
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private List<GIReceiver> receivers;
	private String receiverEmail;
	private String receiverName;
	private String paymentTerms;
	private Double amount;
	private String currency;
	private ZonedDateTime createdDate;
	private String status;
	private String statusDesc;
	private String createdBy;
	private String plant;
	private String storageLocation;
	private Double totalAmount;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	private String type;
	private String typeDesc;
	private String agentName;
	private String requestorEmail;
	private GeneralState state;
	private String company;
	private String requestor;
	private ZonedDateTime deliveryDate;
	private List<PurchaseReqRequestLine> requestItems; //newly added

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getStorageLocation() {
		return storageLocation;
	}

	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public boolean isSAPSynch() {
		return isSAPSynch;
	}

	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public List<PurchaseReqRequestLine> getRequestItems() {
		return requestItems;
	}

	public void setRequestItems(List<PurchaseReqRequestLine> requestItems) {
		this.requestItems = requestItems;
	}

	public List<GIReceiver> getReceivers() {
		return receivers;
	}

	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	
}
