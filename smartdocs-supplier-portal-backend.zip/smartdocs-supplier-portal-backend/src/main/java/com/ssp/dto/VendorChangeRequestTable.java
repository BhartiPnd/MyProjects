package com.ssp.dto;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "VendorChangeRequest")
public class VendorChangeRequestTable {
	@Id
	private String id;
	private String prefix; 
	private long refId;
	
	private String type; 
	
	private String supplierId;
	private String supplierName;
	
	private String status;
	 
	private String createdUserId;
	private String createdUserName;
	
	private ZonedDateTime createdDate;
	private Long createddatetime;
	private Long modifieddatetime;
	private Long lastUpdated;
	private String statusDesc;

	public String getId() {
		return id;
	}

	public String getPrefix() {
		return prefix;
	}

	public long getRefId() {
		return refId;
	}

	public String getType() {
		return type;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public String getStatus() {
		return status;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public Long getLastUpdated() {
		return lastUpdated;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public void setLastUpdated(Long lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	
}
