package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;


public class DBCommitedVendor {
	
	private String subcontractorId;
	private String subcontractorName;
	private double commitedAmount;
	private List<String> dbeTypes;
	private String desc;
	
	private ZonedDateTime reportDate;
	
	private boolean isSubContractorDBVendor;
	
	public String getSubcontractorId() {
		return subcontractorId;
	}
	public String getSubcontractorName() {
		return subcontractorName;
	}
	public double getCommitedAmount() {
		return commitedAmount;
	}
	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}
	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}
	public void setCommitedAmount(double commitedAmount) {
		this.commitedAmount = commitedAmount;
	}
	public List<String> getDbeTypes() {
		return dbeTypes;
	}
	public void setDbeTypes(List<String> dbeTypes) {
		this.dbeTypes = dbeTypes;
	}
	public boolean isSubContractorDBVendor() {
		return isSubContractorDBVendor;
	}
	public void setSubContractorDBVendor(boolean isSubContractorDBVendor) {
		this.isSubContractorDBVendor = isSubContractorDBVendor;
	}
	public ZonedDateTime getReportDate() {
		return reportDate;
	}
	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
/*	private boolean isSubContractorDBVendor;
	private boolean isSubContractorPortalVendor;
	private double amountOfSubcontracts;
	private double amountEarnedToDate;
	private double amountPaidToDate;
	private List<String> dbeTypes;
	private ZonedDateTime lastUpdated ;
*/
	
}
