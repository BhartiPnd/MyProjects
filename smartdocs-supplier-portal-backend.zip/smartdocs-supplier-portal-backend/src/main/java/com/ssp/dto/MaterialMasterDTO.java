package com.ssp.dto;

import com.ssp.mongo.collections.dataObject.MaterialMaster;

public class MaterialMasterDTO {
	
	private MaterialMaster materialMaster;
	private Double unitPrice;
	
	
	public MaterialMasterDTO() {
		
	}
	

	public MaterialMasterDTO(MaterialMaster materialMaster, Double unitPrice) {
		super();
		this.materialMaster = materialMaster;
		this.unitPrice = unitPrice;
	}



	public MaterialMaster getMaterialMaster() {
		return materialMaster;
	}
	public void setMaterialMaster(MaterialMaster materialMaster) {
		this.materialMaster = materialMaster;
	}
	public Double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	
	
	
	

}
