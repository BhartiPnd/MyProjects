package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.nimbusds.openid.connect.sdk.claims.Address;
import com.ssp.mongo.collectionhelpers.AchRequest;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Contact;
import com.ssp.mongo.collectionhelpers.DBChangeRequest;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.OtherChangeRequest;
import com.ssp.mongo.collectionhelpers.ProductCategoriesChangeRequest;
import com.ssp.mongo.collectionhelpers.TaxAndW9Change;
import com.ssp.mongo.collections.requests.BankDetailChange;

public class VendorChangeRequestUpdateDTO {

	private String id;
	private String prefix; 
	private long refId;
	
	private String type; 
	private String companyCode;
	private String supplierId;
	private String status;
	 
	private String createdUserId;
	private String createdUserName;
	
	private ZonedDateTime createdDate;
	
	//TODO : to be changed with zonedate time.
	private Long createddatetime;
	private Long modifieddatetime;
	private Long lastUpdated;

	private List<DocumentHelper> attachments;
	
	// action approve reject. 	
	//private String notes;
	
	// submit + resubmit 
	private String comment;
	
	// if address Change Request.

	private String action;

	// Leagal Status changes
//	private String legalStatus;
	//private String orgSME;
	private Address address;
	private Contact contact;
	private AchRequest achRequest;
	private DBChangeRequest dbeChangeRequest; 
	private ProductCategoriesChangeRequest pccr; 
	private OtherChangeRequest other;
	private TaxAndW9Change taxAndW9;
	private BankDetailChange bankDetailChange;
	
	//private boolean isCollaborated;
	//private String collaboratedUser;
	private List<ActivityLog> activityLogs;
	private String statusDesc;
	private boolean syncToSAP;
	private String agentName;
	private GeneralState state;
	
	
	private String notes;
	private String activityCode;
	private String requestorEmail;
	//sprivate String actionA;
	private String collaboratedUser;
	
	
	
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public String getRequestId() {
		return String.valueOf(refId);
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
