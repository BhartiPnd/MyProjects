package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.NewExpenseItems;

public class CreateExpenseRequest {
	
	private String action;
	private String id;
	private String collaboratedUser;
	
	// this is only used in case of resubmit. 
	private long sspInvoiceReferenceNo;
	
	
	private String invoiceNumber;
	private String employeeId;
	private String employeeEmail;
	
	private List<AdhocApprover> adhocApprovers;
	
	private  Double grandTotal;
	private String remarks;
	private String notes;
	
	private String title;
	
	private ZonedDateTime expenseDateFrom;
	private ZonedDateTime expenseDateTo;

 
	private List<NewExpenseItems> newExpenseitems;
	
	private Map<String, String> headerAttributes;
	private List<DocumentHelper> attachments;
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	 
	
	public Double getGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(Double grandTotal) {
		this.grandTotal = grandTotal;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Map<String, String> getHeaderAttributes() {
		return headerAttributes;
	}
	public void setHeaderAttributes(Map<String, String> headerAttributes) {
		this.headerAttributes = headerAttributes;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}
	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<NewExpenseItems> getNewExpenseitems() {
		return newExpenseitems;
	}
	public void setNewExpenseitems(List<NewExpenseItems> newExpenseitems) {
		this.newExpenseitems = newExpenseitems;
	}
	public long getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}
	public void setSspInvoiceReferenceNo(long sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					}
				}
			}
	}
	public String getEmployeeEmail() {
		return employeeEmail;
	}
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	public ZonedDateTime getExpenseDateFrom() {
		return expenseDateFrom;
	}
	public ZonedDateTime getExpenseDateTo() {
		return expenseDateTo;
	}
	public void setExpenseDateFrom(ZonedDateTime expenseDateFrom) {
		this.expenseDateFrom = expenseDateFrom;
	}
	public void setExpenseDateTo(ZonedDateTime expenseDateTo) {
		this.expenseDateTo = expenseDateTo;
	}
	
	

}
