package com.ssp.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreType;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreType
public class LandTParkPostResponseContainer {

 
	
	@JsonProperty("WA_OUTPUT")
	private  LandTParkPostResponse  WA_OUTPUT;

	public LandTParkPostResponse getWA_OUTPUT() {
		return WA_OUTPUT;
	}

	public void setWA_OUTPUT(LandTParkPostResponse wA_OUTPUT) {
		WA_OUTPUT = wA_OUTPUT;
	}

	@Override
	public String toString() {
		return "LandTParkPostResponseContainer [WA_OUTPUT=" + WA_OUTPUT + "]";
	}

	 
	
	
}