package com.ssp.dto;

public class AllowedCompanyCodes {

	
	private String companyCode ;
	private String groupId;
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public AllowedCompanyCodes(String companyCode, String groupId) {
		super();
		this.companyCode = companyCode;
		this.groupId = groupId;
	}
	public AllowedCompanyCodes() {
		super();
	}
}
