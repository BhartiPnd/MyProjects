package com.ssp.dto;

public class PlannedPurchaseOrderProductWeekData {

	private String id;
	private int week;
	private int year;
	private double quantity;
	private String uom;
	
	public PlannedPurchaseOrderProductWeekData() {
		super();
	}
	public PlannedPurchaseOrderProductWeekData(String id, int week, int year, double quantity, String uom) {
		super();
		this.id = id;
		this.week = week;
		this.year = year;
		this.quantity = quantity;
		this.uom = uom;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "PlannedPurchaseOrderProductWeekData [id=" + id + ", week=" + week + ", year=" + year + ", quantity="
				+ quantity + ", uom=" + uom + "]";
	}
	
	
}
