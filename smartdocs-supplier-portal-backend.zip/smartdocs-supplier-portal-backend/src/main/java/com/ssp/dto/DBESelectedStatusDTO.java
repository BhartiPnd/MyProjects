package com.ssp.dto;

import java.time.ZonedDateTime;

import com.ssp.mongo.collectionhelpers.DBESelectedStatus;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.list.GeneralList;

public class DBESelectedStatusDTO{
	
	private String dbe;
	private String dbedesc;
	private boolean selected;
	private ZonedDateTime certificationExpiryDate;
	private DocumentHelper attachment;
	
	private String documentType;
	private String verificationSource;
	private boolean certificationDateRequire;
	private boolean attachmentRequire;
	private int order;
	
	public DBESelectedStatusDTO() {
		
	}
	
	public DBESelectedStatusDTO(GeneralList dbeType,boolean selected,ZonedDateTime certificationExpiryDate,DocumentHelper attachment) {
		this.dbe=dbeType.getTitle();
		this.selected=selected;
		this.certificationExpiryDate=certificationExpiryDate;
		this.attachment=attachment;
		this.dbedesc=dbeType.getDesc();
		this.verificationSource=dbeType.getVerificationSource();
		this.certificationDateRequire=dbeType.isCertificationDateRequire();
		this.attachmentRequire=dbeType.isAttachmentRequire();
		this.documentType=dbeType.getDocumentType();
		this.order=dbeType.getOrder(); 
		
	}
	public DBESelectedStatusDTO(GeneralList dbeType) {
		this.dbe=dbeType.getTitle();
		this.selected=false;
		this.certificationExpiryDate=null;
		this.attachment=null;
		this.dbedesc=dbeType.getDesc();
		this.verificationSource=dbeType.getVerificationSource();
		this.certificationDateRequire=dbeType.isCertificationDateRequire();
		this.attachmentRequire=dbeType.isAttachmentRequire();
		this.documentType=dbeType.getDocumentType();
		this.order=dbeType.getOrder(); 
		
	}
	public DBESelectedStatusDTO(DBESelectedStatus st,GeneralList dbeType) {
		this.dbe=st.getDbe();
		this.selected=st.isSelected();
		this.certificationExpiryDate=st.getCertificationExpiryDate();
		this.attachment=st.getAttachment();
		if(dbeType!=null) {
			this.dbedesc=dbeType.getDesc();
			this.verificationSource=dbeType.getVerificationSource();
			this.certificationDateRequire=dbeType.isCertificationDateRequire();
			this.attachmentRequire=dbeType.isAttachmentRequire();
			this.documentType=dbeType.getDocumentType();
			this.order=dbeType.getOrder(); 
		}
	}
	public String getDbe() {
		return dbe;
	}
	public boolean isSelected() {
		return selected;
	}
	public ZonedDateTime getCertificationExpiryDate() {
		return certificationExpiryDate;
	}
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setDbe(String dbe) {
		this.dbe = dbe;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public void setCertificationExpiryDate(ZonedDateTime certificationExpiryDate) {
		this.certificationExpiryDate = certificationExpiryDate;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public String getDbedesc() {
		return dbedesc;
	}
	public String getDocumentType() {
		return documentType;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public boolean isCertificationDateRequire() {
		return certificationDateRequire;
	}
	public boolean isAttachmentRequire() {
		return attachmentRequire;
	}
	public int getOrder() {
		return order;
	}
	public void setDbedesc(String dbedesc) {
		this.dbedesc = dbedesc;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public void setCertificationDateRequire(boolean certificationDateRequire) {
		this.certificationDateRequire = certificationDateRequire;
	}
	public void setAttachmentRequire(boolean attachmentRequire) {
		this.attachmentRequire = attachmentRequire;
	}
	public void setOrder(int order) {
		this.order = order;
	} 
	
	
}
