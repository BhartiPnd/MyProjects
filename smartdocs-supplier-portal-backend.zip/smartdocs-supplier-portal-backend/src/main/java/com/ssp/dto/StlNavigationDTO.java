package com.ssp.dto;

import java.util.List;

public class StlNavigationDTO {

		private long inboxCount;
			
		private long processedCount;
			
		private long junkCount;
		
		//private List<String> emails;
		
		private List<StlNavigationL2DTO> level2;
		
		public List<StlNavigationL2DTO> getLevel2() {
			return level2;
		}

		public void setLevel2(List<StlNavigationL2DTO> level2) {
			this.level2 = level2;
		}

		public long getInboxCount() {
			return inboxCount;
		}

		public void setInboxCount(long inboxCount) {
			this.inboxCount = inboxCount;
		}

		public long getProcessedCount() {
			return processedCount;
		}

		public void setProcessedCount(long processedCount) {
			this.processedCount = processedCount;
		}

		public long getJunkCount() {
			return junkCount;
		}

		public void setJunkCount(long junkCount) {
			this.junkCount = junkCount;
		}

		 
		
		
		
}
