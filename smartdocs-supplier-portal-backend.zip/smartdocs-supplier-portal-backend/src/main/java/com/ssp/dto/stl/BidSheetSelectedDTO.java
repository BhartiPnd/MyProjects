package com.ssp.dto.stl;

import java.util.List;

public class BidSheetSelectedDTO {
	
	public static final String STATUS_REVIEWED = "REVIEWED";
	
	
	private String action;
	private List<String> responseIds;
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public List<String> getResponseIds() {
		return responseIds;
	}
	public void setResponseIds(List<String> responseIds) {
		this.responseIds = responseIds;
	}

}
