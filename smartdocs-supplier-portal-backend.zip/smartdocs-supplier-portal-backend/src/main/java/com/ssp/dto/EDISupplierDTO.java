package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.EDICustomSelector;

public class EDISupplierDTO {

	private String supplierId;
	private String supplierName;
	private EDICustomSelector companies;

	public EDISupplierDTO() {
		super();
	}

	public EDISupplierDTO(String supplierId, String supplierName, EDICustomSelector companies) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.companies = companies;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public EDICustomSelector getCompanies() {
		return companies;
	}

	public void setCompanies(EDICustomSelector companies) {
		this.companies = companies;
	}

}
