package com.ssp.dto;

import java.util.List;

public class SAPSyncReportContainer {
	
	private List<SAPSyncReport> portalToSap;
	private List<SAPSyncReport> sapToPoral;
	public SAPSyncReportContainer() {
		super();
	}
	public SAPSyncReportContainer(List<SAPSyncReport> portalToSap, List<SAPSyncReport> sapToPoral) {
		super();
		this.portalToSap = portalToSap;
		this.sapToPoral = sapToPoral;
	}
	public List<SAPSyncReport> getPortalToSap() {
		return portalToSap;
	}
	public void setPortalToSap(List<SAPSyncReport> portalToSap) {
		this.portalToSap = portalToSap;
	}
	public List<SAPSyncReport> getSapToPoral() {
		return sapToPoral;
	}
	public void setSapToPoral(List<SAPSyncReport> sapToPoral) {
		this.sapToPoral = sapToPoral;
	}
	
	
}
