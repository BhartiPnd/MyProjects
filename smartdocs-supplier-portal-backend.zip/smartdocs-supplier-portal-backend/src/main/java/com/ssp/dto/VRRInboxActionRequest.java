package com.ssp.dto;

import com.ssp.mongo.collections.requests.VendorRegistrationRequest;

public class VRRInboxActionRequest extends VendorRegistrationRequest{

	private String action;
	private String itemId;
	private String collaboratedUsers;
	private String activityCode;
	private String forwardTo;
	
	public String getAction() {
		return action;
	}
	public String getItemId() {
		return itemId;
	}
	public String getCollaboratedUsers() {
		return collaboratedUsers;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public String getForwardTo() {
		return forwardTo;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public void setCollaboratedUsers(String collaboratedUsers) {
		this.collaboratedUsers = collaboratedUsers;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public void setForwardTo(String forwardTo) {
		this.forwardTo = forwardTo;
	}
	
	
	
}
