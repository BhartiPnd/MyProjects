package com.ssp.dto;

 
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties
public class LandTParkPostResponse {
	
	@JsonProperty("INVOICE")
	private String invoice;
	
	@JsonProperty("YEAR")
	private String year;
	
	@JsonProperty("MBLNR")
	private String mblnr;
	
	@JsonProperty("TAX_CODE")
	private String taxCode;
	
	@JsonProperty("TAX_AMT")
	private double taxAmount;
	
	@JsonProperty("BAS_AMT")
	private double basAmount;
	 
	@JsonProperty("LOG")
	private String log;
	
	
	@JsonProperty("MESSAGE")
	private String message;
	
	
	public String getInvoice() {
		return invoice;
	}

	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMblnr() {
		return mblnr;
	}

	public void setMblnr(String mblnr) {
		this.mblnr = mblnr;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public double getBasAmount() {
		return basAmount;
	}

	public void setBasAmount(double basAmount) {
		this.basAmount = basAmount;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	@Override
	public String toString() {
		return "LandTParkPostResponse [invoice=" + invoice + ", year=" + year + ", mblnr=" + mblnr + ", taxCode="
				+ taxCode + ", taxAmount=" + taxAmount + ", basAmount=" + basAmount + ", log=" + log + "]";
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
