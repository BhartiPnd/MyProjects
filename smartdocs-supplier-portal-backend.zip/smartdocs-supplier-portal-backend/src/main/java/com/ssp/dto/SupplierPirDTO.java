package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.Address;

public class SupplierPirDTO {
	
	private String supplierId;
	private String supplierName;
	private Address suplieraddress;
	private List<MaterialMasterDTO> materialMasterDTOs;
	
	
	
	public SupplierPirDTO() {
		
	}
	
	public SupplierPirDTO(String supplierId, String supplierName, Address suplieraddress,
			List<MaterialMasterDTO> materialMasterDTOs) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.suplieraddress = suplieraddress;
		this.materialMasterDTOs = materialMasterDTOs;
	}


	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public Address getSuplieraddress() {
		return suplieraddress;
	}
	public void setSuuplieraddress(Address suplieraddress) {
		this.suplieraddress = suplieraddress;
	}
	public List<MaterialMasterDTO> getMaterialMasterDTOs() {
		return materialMasterDTOs;
	}
	public void setMaterialMasterDTOs(List<MaterialMasterDTO> materialMasterDTOs) {
		this.materialMasterDTOs = materialMasterDTOs;
	}
	
	
	
	
	

}
