package com.ssp.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ssp.mongo.collectionhelpers.DBChangeRequest;
import com.ssp.mongo.collectionhelpers.DBESelectedStatus;
import com.ssp.mongo.collections.list.GeneralList;

public class DBChangeRequestDTO {

	private List<DBESelectedStatusDTO> dbeSelectedStatus;
	private boolean noMoreDBE;
	
	public DBChangeRequestDTO() {
		
	}
	public DBChangeRequestDTO(DBChangeRequest dbChangeRequest, Map<String,GeneralList> dbList) {
		this.noMoreDBE=dbChangeRequest.isNoMoreDBE();
		if(dbChangeRequest.getDbeSelectedStatus()!=null) {
			this.dbeSelectedStatus=new ArrayList<>();
			for(DBESelectedStatus status:dbChangeRequest.getDbeSelectedStatus() )
			{
				GeneralList dbeType=dbList.get(status.getDbe());
				this.dbeSelectedStatus.add(new DBESelectedStatusDTO(status,dbeType));
			}
			
		}
	}

	public DBChangeRequestDTO(List<GeneralList> dbList) {
		this.dbeSelectedStatus = new ArrayList<>();
		for (GeneralList dbeType : dbList) {
			this.dbeSelectedStatus.add(new DBESelectedStatusDTO(dbeType));
		}

	}
	public List<DBESelectedStatusDTO> getDbeSelectedStatus() {
		return dbeSelectedStatus;
	}
	public void setDbeSelectedStatus(List<DBESelectedStatusDTO> dbeSelectedStatus) {
		this.dbeSelectedStatus = dbeSelectedStatus;
	}
	public boolean isNoMoreDBE() {
		return noMoreDBE;
	}
	public void setNoMoreDBE(boolean noMoreDBE) {
		this.noMoreDBE = noMoreDBE;
	}
	
}
