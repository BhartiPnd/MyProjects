package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.Phone;

public class VendorContact {
	
	private String contactId;
	private String firstname;
	private String lastname;
	private String email;
	private Phone  phonenumber;
	private Phone  fax;
	private Phone  mobile;
	private String  functionName;
	private boolean admin;
	
	private boolean isPortalAccount;
	private ZonedDateTime lastLogin;
	private List<String> roles;
	
	
	public VendorContact() {
		super();
	}

	public VendorContact(String firstname, String lastname,String email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	 
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Phone getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Phone phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Phone getFax() {
		return fax;
	}

	public void setFax(Phone fax) {
		this.fax = fax;
	}

	public Phone getMobile() {
		return mobile;
	}

	public void setMobile(Phone mobile) {
		this.mobile = mobile;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean isPortalAccount() {
		return isPortalAccount;
	}

	public void setPortalAccount(boolean isPortalAccount) {
		this.isPortalAccount = isPortalAccount;
	}

	public ZonedDateTime getLastLogin() {
		return lastLogin;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setLastLogin(ZonedDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	
}
