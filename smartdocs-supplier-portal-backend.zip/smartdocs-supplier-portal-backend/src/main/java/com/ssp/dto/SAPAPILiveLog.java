package com.ssp.dto;

import java.time.ZonedDateTime;

public class SAPAPILiveLog {

	private String api;
	private String xml;
	private ZonedDateTime date;
	public SAPAPILiveLog(String api, String xml, ZonedDateTime date) {
		super();
		this.api = api;
		this.xml = xml;
		this.date = date;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getXml() {
		return xml;
	}
	public void setXml(String xml) {
		this.xml = xml;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	
}
