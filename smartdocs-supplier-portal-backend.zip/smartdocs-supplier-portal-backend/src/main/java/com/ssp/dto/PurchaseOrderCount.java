package com.ssp.dto;

public class PurchaseOrderCount {

	private long myOrders;
	private long notAcknowledged;
	private long acknowledged;
	private long all;

	public PurchaseOrderCount() {
		super();
	}

	public long getMyOrders() {
		return myOrders;
	}

	public void setMyOrders(long myOrders) {
		this.myOrders = myOrders;
	}

	public long getNotAcknowledged() {
		return notAcknowledged;
	}

	public void setNotAcknowledged(long notAcknowledged) {
		this.notAcknowledged = notAcknowledged;
	}

	public long getAcknowledged() {
		return acknowledged;
	}

	public void setAcknowledged(long acknowledged) {
		this.acknowledged = acknowledged;
	}

	public long getAll() {
		return all;
	}

	public void setAll(long all) {
		this.all = all;
	}

}
