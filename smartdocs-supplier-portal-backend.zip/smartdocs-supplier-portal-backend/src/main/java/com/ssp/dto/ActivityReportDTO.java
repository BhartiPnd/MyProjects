package com.ssp.dto;

public class ActivityReportDTO {

	private long ocrInvoices;
	private long portalInvoices;
	private long lawtrackInvoices;
	private long expenses;
	
	private long asn;
	
	private long oa;
	
	private long ach;
	
	private long vrr;
	
	private long vcr;
	
	
	private long psDBReports;
	private long consDBReports;

	
	private long vendorUserAccessedSystem;
	private long vendorUserLoggedIn;
	
	private long ptcUsersAccessedSystem;
	private long ptcUsersLoggedIn;
	public long getOcrInvoices() {
		return ocrInvoices;
	}
	public void setOcrInvoices(long ocrInvoices) {
		this.ocrInvoices = ocrInvoices;
	}
	public long getPortalInvoices() {
		return portalInvoices;
	}
	public void setPortalInvoices(long portalInvoices) {
		this.portalInvoices = portalInvoices;
	}
	public long getExpenses() {
		return expenses;
	}
	public void setExpenses(long expenses) {
		this.expenses = expenses;
	}
	public long getAsn() {
		return asn;
	}
	public void setAsn(long asn) {
		this.asn = asn;
	}
	public long getOa() {
		return oa;
	}
	public void setOa(long oa) {
		this.oa = oa;
	}
	public long getAch() {
		return ach;
	}
	public void setAch(long ach) {
		this.ach = ach;
	}
	public long getVrr() {
		return vrr;
	}
	public void setVrr(long vrr) {
		this.vrr = vrr;
	}
	public long getVcr() {
		return vcr;
	}
	public void setVcr(long vcr) {
		this.vcr = vcr;
	}
	public long getPsDBReports() {
		return psDBReports;
	}
	public void setPsDBReports(long psDBReports) {
		this.psDBReports = psDBReports;
	}
	public long getConsDBReports() {
		return consDBReports;
	}
	public void setConsDBReports(long consDBReports) {
		this.consDBReports = consDBReports;
	}
	public long getVendorUserAccessedSystem() {
		return vendorUserAccessedSystem;
	}
	public void setVendorUserAccessedSystem(long vendorUserAccessedSystem) {
		this.vendorUserAccessedSystem = vendorUserAccessedSystem;
	}
	public long getVendorUserLoggedIn() {
		return vendorUserLoggedIn;
	}
	public void setVendorUserLoggedIn(long vendorUserLoggedIn) {
		this.vendorUserLoggedIn = vendorUserLoggedIn;
	}
	public long getPtcUsersAccessedSystem() {
		return ptcUsersAccessedSystem;
	}
	public void setPtcUsersAccessedSystem(long ptcUsersAccessedSystem) {
		this.ptcUsersAccessedSystem = ptcUsersAccessedSystem;
	}
	public long getPtcUsersLoggedIn() {
		return ptcUsersLoggedIn;
	}
	public void setPtcUsersLoggedIn(long ptcUsersLoggedIn) {
		this.ptcUsersLoggedIn = ptcUsersLoggedIn;
	}
	public long getLawtrackInvoices() {
		return lawtrackInvoices;
	}
	public void setLawtrackInvoices(long lawtrackInvoices) {
		this.lawtrackInvoices = lawtrackInvoices;
	}
	
	
	
}
