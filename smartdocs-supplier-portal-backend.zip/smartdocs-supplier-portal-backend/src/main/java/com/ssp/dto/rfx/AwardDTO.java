package com.ssp.dto.rfx;

import java.util.List;

import com.ssp.dto.AwardedLine;

public class AwardDTO {

	private String rfxId;
	private boolean splitAward;
	private List<AwardedLine> selectedLines; 

	public AwardDTO() {
		super();
	}

	public String getRfxId() {
		return rfxId;
	}

	public void setRfxId(String rfxId) {
		this.rfxId = rfxId;
	}

	public boolean isSplitAward() {
		return splitAward;
	}

	public void setSplitAward(boolean splitAward) {
		this.splitAward = splitAward;
	}


	public List<AwardedLine> getSelectedLines() {
		return selectedLines;
	}

	public void setSelectedLines(List<AwardedLine> selectedLines) {
		this.selectedLines = selectedLines;
	}

}
