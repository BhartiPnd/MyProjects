package com.ssp.dto;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;

import com.ssp.mongo.collections.EmployeeMaster;

public class EmployeeMasterDto {

	private String id;
	private String firstName;
	private String lastName;
	private String email;
	private String employeeId;
	private String phoneNumber;
	private String manager;
	private String gender;
	private String status;
	private boolean success;
	private Double approvalLimit;
	private String currency;
	private String successMsg;
	private String failureMsg;
	private String role;
	private String location;
	private boolean setupUser;
	private String companyCode;
	
	public EmployeeMasterDto() {
		super();
	}
	
	public EmployeeMasterDto(EmployeeMaster existingEmp) {
		this.id = existingEmp.getId();
		this.firstName = existingEmp.getFirstName();
		this.lastName = existingEmp.getLastName();
		this.email = existingEmp.getEmail();
		this.employeeId = existingEmp.getEmployeeId();
		this.phoneNumber = existingEmp.getPhoneNumber();
		this.manager = existingEmp.getManager();
		this.gender = existingEmp.getGender();
		this.approvalLimit = existingEmp.getApprovalLimit();
		this.currency = existingEmp.getCurrency();
		this.location = existingEmp.getLocation();
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Double getApprovalLimit() {
		return approvalLimit;
	}
	public void setApprovalLimit(Double approvalLimit) {
		this.approvalLimit = approvalLimit;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getFailureMsg() {
		return failureMsg;
	}
	public void setFailureMsg(String failureMsg) {
		this.failureMsg = failureMsg;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSuccessMsg() {
		return successMsg;
	}
	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public boolean isSetupUser() {
		return setupUser;
	}

	public void setSetupUser(boolean setupUser) {
		this.setupUser = setupUser;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
