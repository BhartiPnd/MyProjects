package com.ssp.dto;

public class InboxItemCount {

	private long invoice;
	private long expense;
	private long vrr;
	private long vcr;
	private long ach;
	private long oa;
	private long smd;
	private long vur;
	private long ticket;
	private long prr;
	private long por;
	private long gir;
	private long rfx;
	private long bidSheet;
	
	public long getInvoice() {
		return invoice;
	}
	public long getExpense() {
		return expense;
	}
	public long getVrr() {
		return vrr;
	}
	public long getVcr() {
		return vcr;
	}
	public void setInvoice(long invoice) {
		this.invoice = invoice;
	}
	public void setExpense(long expense) {
		this.expense = expense;
	}
	public void setVrr(long vrr) {
		this.vrr = vrr;
	}
	public void setVcr(long vcr) {
		this.vcr = vcr;
	}
	public long getOa() {
		return oa;
	}
	public void setOa(long oa) {
		this.oa = oa;
	}
	public long getSmd() {
		return smd;
	}
	public void setSmd(long smd) {
		this.smd = smd;
	}
	public long getAch() {
		return ach;
	}
	public void setAch(long ach) {
		this.ach = ach;
	}
	public long getVur() {
		return vur;
	}
	public void setVur(long vur) {
		this.vur = vur;
	}
	public long getTicket() {
		return ticket;
	}
	public void setTicket(long ticket) {
		this.ticket = ticket;
	}
	public long getPrr() {
		return prr;
	}
	public void setPrr(long prr) {
		this.prr = prr;
	}
	public long getPor() {
		return por;
	}
	public void setPor(long por) {
		this.por = por;
	}
	public long getGir() {
		return gir;
	}
	public void setGir(long gir) {
		this.gir = gir;
	}
	public long getRfx() {
		return rfx;
	}
	public void setRfx(long rfx) {
		this.rfx = rfx;
	}
	public long getBidSheet() {
		return bidSheet;
	}
	public void setBidSheet(long bidSheet) {
		this.bidSheet = bidSheet;
	}
	
	
	
	
}
