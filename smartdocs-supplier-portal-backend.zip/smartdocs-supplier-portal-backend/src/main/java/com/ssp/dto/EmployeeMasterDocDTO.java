package com.ssp.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.CustomCountries;
import com.ssp.mongo.collectionhelpers.FormField;
import com.ssp.mongo.collections.employee.EBDPermissions;
import com.ssp.mongo.collections.employee.EmployeeMasterDocType;
import com.ssp.mongo.collections.employee.EmployeeMasterDocument;
import com.ssp.mongo.collections.workflow.config.BusinessRules;

@Document(collection = "employeeDocType")
public class EmployeeMasterDocDTO extends EmployeeMasterDocType{
 
	
	private boolean hasPermission;
	private EBDPermissions permission;
	private String status;
	private List<EmployeeMasterDocument> documents;

	public boolean isHasPermission() {
		return hasPermission;
	}
	public boolean hasPermission() {
		return hasPermission;
	}
	public void setHasPermission(boolean hasPermission) {
		this.hasPermission = hasPermission;
	}
	public List<EmployeeMasterDocument> getDocuments() {
		return documents;
	}
	public void setDocuments(List<EmployeeMasterDocument> documents) {
		this.documents = documents;
	}
	public EBDPermissions getPermission() {
		return permission;
	}
	public void setPermission(EBDPermissions permission) {
		this.permission = permission;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	 
	
	
}
