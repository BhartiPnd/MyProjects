package com.ssp.dto;

import java.util.HashMap;
import java.util.Map;

public class PlannedPurchaseOrderLocation {
	
	
	private Map<String, PlannedPurchaseOrderProduct> products=new HashMap<>();
	public PlannedPurchaseOrderLocation() {
		super();
	}
	
	public PlannedPurchaseOrderLocation(Map<String, PlannedPurchaseOrderProduct> products) {
		super();
		this.products = products;
	}
	public Map<String, PlannedPurchaseOrderProduct> getProducts() {
		return products;
	}

	public void setProducts(Map<String, PlannedPurchaseOrderProduct> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "PlannedPurchaseOrderLocation [products=" + products + "]";
	}
	  
}
