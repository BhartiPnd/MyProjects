package com.ssp.dto;

import java.time.ZonedDateTime;

public class RFXBidResponseTableDTO {

	private String bidNo;
	private String rfxNo;
	private ZonedDateTime createdDateTime;
	private String status;
	private String supplierId;
	private String supplierName;
	private String bidSubmittedBy;
	private String title; 
	private String bidSubmittedByName;
	private boolean isAwarded;
	private boolean isSurrogateBid;
	private String awardStatus;
	private boolean portalAward;
	
	public RFXBidResponseTableDTO() {
		super();

	}
	public RFXBidResponseTableDTO(String bidNo, String rfxNo, ZonedDateTime createdDateTime, String status,
			String supplierId, String supplierName, String bidSubmittedBy, String title, String bidSubmittedByName, boolean isAwarded, 
			boolean isSurrogateBid, String awardStatus, boolean portalAward) {
		super();
		this.bidNo = bidNo;
		this.rfxNo = rfxNo;
		this.createdDateTime = createdDateTime;
		this.status = status;
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.bidSubmittedBy = bidSubmittedBy;
		this.title = title;
		this.bidSubmittedByName = bidSubmittedByName;
		this.isAwarded = isAwarded;
		this.isSurrogateBid = isSurrogateBid;
		this.awardStatus = awardStatus;
		this.portalAward = portalAward;
	}
	public String getBidNo() {
		return bidNo;
	}
	public void setBidNo(String bidNo) {
		this.bidNo = bidNo;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getBidSubmittedBy() {
		return bidSubmittedBy;
	}
	public void setBidSubmittedBy(String bidSubmittedBy) {
		this.bidSubmittedBy = bidSubmittedBy;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBidSubmittedByName() {
		return bidSubmittedByName;
	}
	public void setBidSubmittedByName(String bidSubmittedByName) {
		this.bidSubmittedByName = bidSubmittedByName;
	}
	public boolean isAwarded() {
		return isAwarded;
	}
	public void setAwarded(boolean awarded) {
		this.isAwarded = awarded;
	}
	public boolean isSurrogateBid() {
		return isSurrogateBid;
	}
	public void setSurrogateBid(boolean isSurrogateBid) {
		this.isSurrogateBid = isSurrogateBid;
	}
	public String getAwardStatus() {
		return awardStatus;
	}
	public void setAwardStatus(String awardStatus) {
		this.awardStatus = awardStatus;
	}
	public boolean isPortalAward() {
		return portalAward;
	}
	public void setPortalAward(boolean portalAward) {
		this.portalAward = portalAward;
	}
	
	
	
}
