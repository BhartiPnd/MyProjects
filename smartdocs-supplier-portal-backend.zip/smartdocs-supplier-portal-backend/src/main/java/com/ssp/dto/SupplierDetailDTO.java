package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.CompanyEntitiy;
import com.ssp.mongo.collectionhelpers.Contact;
import com.ssp.mongo.collectionhelpers.DiverseBusinessClassifications;
import com.ssp.mongo.collectionhelpers.DiverseBusinessStatus;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.Rating;

@Document(collection = "supplier")
public class SupplierDetailDTO {

	private String id;
	private String supplierId;
	private String name;
	private String dbaName;
	private String primaryEmail;	
	private String phone;
	private String phoneCntryCode;	
	private String phoneExtension;
	private String fax;
	private String faxCntryCode;
	private String ssnNo;
	private String empIdNo;
	private boolean  paymentBlock;
	private Address address;
	private String location;
	private String accountingGroup;
	private DiverseBusinessStatus diverseBusinessStatus;
	
	private List<CompanyEntitiy> companies;
	private String paymentTerms;
	
	
	private List<Contact> contacts;
	private List<DocumentHelper> documents;
	
	private List<String> productCategories;
	
	private List<DiverseBusinessClassifications>  diverseBusinessClassifications ;
	
	private String category;
	
	private boolean isDBVendor;
	
	private Long createddatetime;
	private Long modifieddatetime;
	
	private Boolean isVendorReigistered;
	private Boolean isSAPSynch;
	private Long SAPSynchDate;
	private Boolean isSAPSynchACK;
	
	private boolean nonPo;
	private String logicalSystem;
	
	private float score;
	private String websiteUrl;
	private String ecomURL;
	private boolean tandcaccepted;
	
	private ZonedDateTime auditExpiration;
	
	private List<Rating> rating;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDbaName() {
		return dbaName;
	}

	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPhoneCntryCode() {
		return phoneCntryCode;
	}

	public void setPhoneCntryCode(String phoneCntryCode) {
		this.phoneCntryCode = phoneCntryCode;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getFaxCntryCode() {
		return faxCntryCode;
	}

	public void setFaxCntryCode(String faxCntryCode) {
		this.faxCntryCode = faxCntryCode;
	}

	public String getSsnNo() {
		return ssnNo;
	}

	public void setSsnNo(String ssnNo) {
		this.ssnNo = ssnNo;
	}

	public String getEmpIdNo() {
		return empIdNo;
	}

	public void setEmpIdNo(String empIdNo) {
		this.empIdNo = empIdNo;
	}

	public boolean isPaymentBlock() {
		return paymentBlock;
	}

	public void setPaymentBlock(boolean paymentBlock) {
		this.paymentBlock = paymentBlock;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAccountingGroup() {
		return accountingGroup;
	}

	public void setAccountingGroup(String accountingGroup) {
		this.accountingGroup = accountingGroup;
	}

	public DiverseBusinessStatus getDiverseBusinessStatus() {
		return diverseBusinessStatus;
	}

	public void setDiverseBusinessStatus(DiverseBusinessStatus diverseBusinessStatus) {
		this.diverseBusinessStatus = diverseBusinessStatus;
	}

	public List<CompanyEntitiy> getCompanies() {
		return companies;
	}

	public void setCompanies(List<CompanyEntitiy> companies) {
		this.companies = companies;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}

	public List<DocumentHelper> getDocuments() {
		return documents;
	}

	public void setDocuments(List<DocumentHelper> documents) {
		this.documents = documents;
	}

	public List<String> getProductCategories() {
		return productCategories;
	}

	public void setProductCategories(List<String> productCategories) {
		this.productCategories = productCategories;
	}

	public List<DiverseBusinessClassifications> getDiverseBusinessClassifications() {
		return diverseBusinessClassifications;
	}

	public void setDiverseBusinessClassifications(List<DiverseBusinessClassifications> diverseBusinessClassifications) {
		this.diverseBusinessClassifications = diverseBusinessClassifications;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isDBVendor() {
		return isDBVendor;
	}

	public void setDBVendor(boolean isDBVendor) {
		this.isDBVendor = isDBVendor;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public Boolean getIsVendorReigistered() {
		return isVendorReigistered;
	}

	public void setIsVendorReigistered(Boolean isVendorReigistered) {
		this.isVendorReigistered = isVendorReigistered;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public Long getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(Long sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public boolean isNonPo() {
		return nonPo;
	}

	public void setNonPo(boolean nonPo) {
		this.nonPo = nonPo;
	}

	public String getLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEcomURL() {
		return ecomURL;
	}

	public void setEcomURL(String ecomURL) {
		this.ecomURL = ecomURL;
	}

	public boolean isTandcaccepted() {
		return tandcaccepted;
	}

	public void setTandcaccepted(boolean tandcaccepted) {
		this.tandcaccepted = tandcaccepted;
	}

	public ZonedDateTime getAuditExpiration() {
		return auditExpiration;
	}

	public void setAuditExpiration(ZonedDateTime auditExpiration) {
		this.auditExpiration = auditExpiration;
	}

	public List<Rating> getRating() {
		return rating;
	}

	public void setRating(List<Rating> rating) {
		this.rating = rating;
	}
	
	
	
	
}
