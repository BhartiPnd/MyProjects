package com.ssp.dto.smartbuy;

import java.time.ZonedDateTime;

public class CreatePurchaseReqRequestLine {

	private String materialCode;
	private String materialDesc;
	private String materialGroup;
	private String materialGroupDesc;
	private String category;
	private String suppliedBy;
	private String supplierId;
	private boolean isMaterialMaster;
	private double qty;
	private String uom;
	private double unitprice;
	private String currency;
	private String perUOM;
	private Long per;
	private String plant;
	private String storageLocation;
	private ZonedDateTime deliveryDate;
	private String accountAssignmentType;
	private String costCenter;
	private String glAccount;
	private String wbsElementNo;
	private boolean inventory;
	private String internalOrder;
	private String project;
	private String networkNo;
	private String text;
 	private Double factor;
 	private Double perFactor;
	
	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSuppliedBy() {
		return suppliedBy;
	}
	public void setSuppliedBy(String suppliedBy) {
		this.suppliedBy = suppliedBy;
	}
	public boolean isMaterialMaster() {
		return isMaterialMaster;
	}
	public void setMaterialMaster(boolean isMaterialMaster) {
		this.isMaterialMaster = isMaterialMaster;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(double unitprice) {
		this.unitprice = unitprice;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPerUOM() {
		return perUOM;
	}
	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}
	public Long getPer() {
		return per;
	}
	public void setPer(Long per) {
		this.per = per;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getAccountAssignmentType() {
		return accountAssignmentType;
	}
	public void setAccountAssignmentType(String accountAssignmentType) {
		this.accountAssignmentType = accountAssignmentType;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getWbsElementNo() {
		return wbsElementNo;
	}
	public void setWbsElementNo(String wbsElementNo) {
		this.wbsElementNo = wbsElementNo;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public String getMaterialGroupDesc() {
		return materialGroupDesc;
	}
	public void setMaterialGroupDesc(String materialGroupDesc) {
		this.materialGroupDesc = materialGroupDesc;
	}
	public String getInternalOrder() {
		return internalOrder;
	}
	public void setInternalOrder(String internalOrder) {
		this.internalOrder = internalOrder;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getNetworkNo() {
		return networkNo;
	}
	public void setNetworkNo(String networkNo) {
		this.networkNo = networkNo;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public boolean isInventory() {
		return inventory;
	}
	public void setInventory(boolean inventory) {
		this.inventory = inventory;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Double getFactor() {
		return factor;
	}
	public void setFactor(Double factor) {
		this.factor = factor;
	}
	public Double getPerFactor() {
		return perFactor;
	}
	public void setPerFactor(Double perFactor) {
		this.perFactor = perFactor;
	}
	
	
	
}
