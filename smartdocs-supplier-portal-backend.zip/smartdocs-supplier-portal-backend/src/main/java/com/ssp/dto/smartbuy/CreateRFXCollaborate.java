package com.ssp.dto.smartbuy;

import java.time.ZonedDateTime;

public class CreateRFXCollaborate {
	private String id;
	private String rfxNo;
	private Integer questionNo;
	private String supplierId;
	private String supplierName;
	private String answeredBy;
	private String answeredByName;
	private String question;
	private String answer;
	private ZonedDateTime createdDate;
	private ZonedDateTime answerDate;
	private boolean displayEveryOne;
	private String createdBy;
	// this field is just for vendor to make sure it is there question or no. 
	private boolean isYourQuestion;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public Integer getQuestionNo() {
		return questionNo;
	}
	public void setQuestionNo(Integer questionNo) {
		this.questionNo = questionNo;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getAnsweredBy() {
		return answeredBy;
	}
	public void setAnsweredBy(String answeredBy) {
		this.answeredBy = answeredBy;
	}
	public String getAnsweredByName() {
		return answeredByName;
	}
	public void setAnsweredByName(String answeredByName) {
		this.answeredByName = answeredByName;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public ZonedDateTime getAnswerDate() {
		return answerDate;
	}
	public void setAnswerDate(ZonedDateTime answerDate) {
		this.answerDate = answerDate;
	}
	public boolean isDisplayEveryOne() {
		return displayEveryOne;
	}
	public void setDisplayEveryOne(boolean displayEveryOne) {
		this.displayEveryOne = displayEveryOne;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public boolean isYourQuestion() {
		return isYourQuestion;
	}
	public void setYourQuestion(boolean isYourQuestion) {
		this.isYourQuestion = isYourQuestion;
	}
	

}
