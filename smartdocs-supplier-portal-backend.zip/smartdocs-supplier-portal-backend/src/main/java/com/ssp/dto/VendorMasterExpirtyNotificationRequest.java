package com.ssp.dto;

public class VendorMasterExpirtyNotificationRequest {

	private String documentType;
	private String supplierId;
	private String comment;
	
	
	public String getDocumentType() {
		return documentType;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getComment() {
		return comment;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
}
