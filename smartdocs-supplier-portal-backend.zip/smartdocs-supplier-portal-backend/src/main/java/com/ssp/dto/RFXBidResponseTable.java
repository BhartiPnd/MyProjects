package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.BidRequiredInfo;
import com.ssp.mongo.collections.rfx.RFXCollaborate;
import com.ssp.mongo.collections.rfx.RFXItems;

@Document(collection = "bidRFx")
public class RFXBidResponseTable {
	
	@Id
	private String id; 
	private String bidNo;
	private String rfxNo;
	private ZonedDateTime createdDateTime;
	private String status;
	private String supplierId;
	private String supplierName;
	private String bidSubmittedBy;
	private String title; 
	private String bidSubmittedByName;
	private boolean isAwarded;
	private String awardId;
	private List<RFXItems> items;
	private List<BidRequiredInfo> requiredInfo;
	private List<DocumentHelper> attachments;
	private List<RFXCollaborate> collaborate;
	private Boolean isSurrogateBid;
	private String surragoteBidBy;
	private Boolean isOwner;
	private boolean noBid;
	private Boolean isErpSynchACK;
	private Address supplierAddress;
	private String awardStatus;
	private boolean portalAward;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBidNo() {
		return bidNo;
	}
	public void setBidNo(String bidNo) {
		this.bidNo = bidNo;
	}
	
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	
	
	public List<BidRequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}
	public void setRequiredInfo(List<BidRequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getBidSubmittedBy() {
		return bidSubmittedBy;
	}
	public void setBidSubmittedBy(String bidSubmittedBy) {
		this.bidSubmittedBy = bidSubmittedBy;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBidSubmittedByName() {
		return bidSubmittedByName;
	}
	public void setBidSubmittedByName(String bidSubmittedByName) {
		this.bidSubmittedByName = bidSubmittedByName;
	}
	public boolean isAwarded() {
		return isAwarded;
	}
	public void setAwarded(boolean isAwarded) {
		this.isAwarded = isAwarded;
	}
	public String getAwardId() {
		return awardId;
	}
	public void setAwardId(String awardId) {
		this.awardId = awardId;
	}
	public Boolean getIsSurrogateBid() {
		return isSurrogateBid;
	}
	public void setIsSurrogateBid(Boolean isSurrogateBid) {
		this.isSurrogateBid = isSurrogateBid;
	}
	public String getSurragoteBidBy() {
		return surragoteBidBy;
	}
	public void setSurragoteBidBy(String surragoteBidBy) {
		this.surragoteBidBy = surragoteBidBy;
	}
	public Boolean getIsOwner() {
		return isOwner;
	}
	public void setIsOwner(Boolean isOwner) {
		this.isOwner = isOwner;
	}
	public boolean isNoBid() {
		return noBid;
	}
	public void setNoBid(boolean noBid) {
		this.noBid = noBid;
	}
	public Boolean getIsErpSynchACK() {
		return isErpSynchACK;
	}
	public void setIsErpSynchACK(Boolean isErpSynchACK) {
		this.isErpSynchACK = isErpSynchACK;
	}
	public List<RFXCollaborate> getCollaborate() {
		return collaborate;
	}
	public void setCollaborate(List<RFXCollaborate> collaborate) {
		this.collaborate = collaborate;
	}
	public Address getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(Address supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	public String getAwardStatus() {
		return awardStatus;
	}
	public void setAwardStatus(String awardStatus) {
		this.awardStatus = awardStatus;
	}
	public boolean isPortalAward() {
		return portalAward;
	}
	public void setPortalAward(boolean portalAward) {
		this.portalAward = portalAward;
	}
	
	
}
