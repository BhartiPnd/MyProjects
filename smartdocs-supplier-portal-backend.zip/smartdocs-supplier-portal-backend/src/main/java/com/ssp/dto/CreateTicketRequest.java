package com.ssp.dto;

import java.util.List;
import java.util.Map;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class CreateTicketRequest {

	private String title;
	private String description;
	private String itemType;
	private String itemId;
	private String status;
	private String severity;
	
	private String category;
	private String subCategory;
	private String notes;
	private List<DocumentHelper> attachments;
	
	private Map<String, Object> metaData;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	 
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Map<String, Object> getMetaData() {
		return metaData;
	}
	public void setMetaData(Map<String, Object> metaData) {
		this.metaData = metaData;
	}
	
	
}
