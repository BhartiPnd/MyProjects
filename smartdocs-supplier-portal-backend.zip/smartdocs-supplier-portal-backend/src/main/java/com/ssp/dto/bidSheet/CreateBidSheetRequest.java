package com.ssp.dto.bidSheet;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.AuditTrackingLog;
import com.ssp.mongo.collections.bidsheet.BidSheetItems;
import com.ssp.mongo.collections.bidsheet.VendorDetail;

public class CreateBidSheetRequest {

	private String id;
	private String requestId;
	private String title;
	private String proposalType;
	private String companyCode;
	private String companyName;
	private String purchasingOrg;
	private String purchasingOrgDesc;
	private String requestorEmail;
	private String requestorName;
	private String plant;
	private String purchasingGrp;
	private String purchasingGrpDesc;
	private boolean scheduled;
	private List<AuditTrackingLog> logs;
	private String frequency;
	private String occurance;
	private ZonedDateTime startDate;
	private ZonedDateTime endDate;
	private ZonedDateTime effectiveDate;
	private ZonedDateTime expirationDate;
	
	private List<DocumentHelper> attachments;
	private List<BidSheetItems> items;
	private List<VendorDetail> vendors;
	List<Map<String, String>> bidSheetItems;
	
	private ZonedDateTime publishedDate;
	private String status;
	private String fileName;
	
	private String activityCode;
	private String action;
	private String collaboratedUser;
	private String notes;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getProposalType() {
		return proposalType;
	}
	public void setProposalType(String proposalType) {
		this.proposalType = proposalType;
	}
	
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}
	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public boolean isScheduled() {
		return scheduled;
	}
	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}
	public List<AuditTrackingLog> getLogs() {
		return logs;
	}
	public void setLogs(List<AuditTrackingLog> logs) {
		this.logs = logs;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getOccurance() {
		return occurance;
	}
	public void setOccurance(String occurance) {
		this.occurance = occurance;
	}
	public ZonedDateTime getStartDate() {
		return startDate;
	}
	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}
	public ZonedDateTime getEndDate() {
		return endDate;
	}
	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public List<BidSheetItems> getItems() {
		return items;
	}
	public void setItems(List<BidSheetItems> items) {
		this.items = items;
	}
	public List<VendorDetail> getVendors() {
		return vendors;
	}
	public void setVendors(List<VendorDetail> vendors) {
		this.vendors = vendors;
	}
	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	public List<Map<String, String>> getBidSheetItems() {
		return bidSheetItems;
	}
	public void setBidSheetItems(List<Map<String, String>> bidSheetItems) {
		this.bidSheetItems = bidSheetItems;
	}
	
	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPurchasingGrp() {
		return purchasingGrp;
	}

	public void setPurchasingGrp(String purchasingGrp) {
		this.purchasingGrp = purchasingGrp;
	}

	public String getPurchasingGrpDesc() {
		return purchasingGrpDesc;
	}

	public void setPurchasingGrpDesc(String purchasingGrpDesc) {
		this.purchasingGrpDesc = purchasingGrpDesc;
	}
	public ZonedDateTime getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(ZonedDateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	
}
