package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collections.GRR;
import com.ssp.mongo.collections.PurchaseOrder;
import com.ssp.mongo.collections.workflow.WorkItem;

public class GRRDetail {
	
	private GRR grr;
	
	private WorkItem workitem;
	
	private PurchaseOrder purchaseOrder;
	
	private List<ActivityLog> activityLogs;
	
	public GRRDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GRRDetail(GRR grr, WorkItem workitem, PurchaseOrder purchaseOrder, List<ActivityLog> activityLogs) {
		super();
		this.grr = grr;
		this.workitem = workitem;
		this.purchaseOrder = purchaseOrder;
		this.activityLogs = activityLogs;
	}

	public GRR getGrr() {
		return grr;
	}

	public void setGrr(GRR grr) {
		this.grr = grr;
	}

	public WorkItem getWorkitem() {
		return workitem;
	}

	public void setWorkitem(WorkItem workitem) {
		this.workitem = workitem;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	
}
