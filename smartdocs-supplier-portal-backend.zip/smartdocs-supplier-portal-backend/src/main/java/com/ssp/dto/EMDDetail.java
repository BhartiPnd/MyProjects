package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.Map;
import org.springframework.data.mongodb.core.mapping.Document;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collections.Agent;
import com.ssp.mongo.collections.workflow.WorkItem;

@Document(collection = "EmployeeMasterDocument")
public class EMDDetail {

	private String id;
	private String requestId;
	private String documentType;
	private String  employeeId;
	private String  status;
	private DocumentHelper attachment;
	private ZonedDateTime uploadedDate;
	private ZonedDateTime expirationDate;
	private String agentName;
	private Map<String, String> mataData;
	private GeneralState state;
	private WorkItem workItem;
	private String requestorEmail;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DocumentHelper getAttachment() {
		return attachment;
	}

	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}

	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}

	public ZonedDateTime getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(ZonedDateTime expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Map<String, String> getMataData() {
		return mataData;
	}

	public void setMataData(Map<String, String> mataData) {
		this.mataData = mataData;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	 
	public void updateAgent(Agent agent) 
	{
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
		
	}
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	
}
