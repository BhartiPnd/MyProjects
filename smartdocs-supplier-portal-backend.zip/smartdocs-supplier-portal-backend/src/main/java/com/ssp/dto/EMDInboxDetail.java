package com.ssp.dto;


import com.ssp.mongo.collections.workflow.WorkItem;

public class EMDInboxDetail {
	
	private EMDDetail emdDetail;
	private WorkItem workItem;
	private String status;
	private String error;
	public EMDDetail getEmdDetail() {
		return emdDetail;
	}
	public void setEmdDetail(EMDDetail emdDetail) {
		this.emdDetail = emdDetail;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
