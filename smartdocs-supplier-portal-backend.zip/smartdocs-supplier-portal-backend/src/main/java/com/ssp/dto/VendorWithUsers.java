package com.ssp.dto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.UserView;

@Document(collection = "supplier")
public class VendorWithUsers {

	private String supplierId;
	private String name;
	private Address address;
	
	private List<UserView> users;

	public String getSupplierId() {
		return supplierId;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}

	public List<UserView> getUsers() {
		return users;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setUsers(List<UserView> users) {
		this.users = users;
	}
	
	
}
