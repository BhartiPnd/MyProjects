package com.ssp.dto.rfx.bid;

import java.util.List;
import java.util.Map;

import com.ssp.mongo.collections.rfx.RFXItems;

public class BidLines {

	private RFXItems itemDatail;
	
	private List<RFXItems> bidLine;
	public BidLines() {
		super();
	}
	public BidLines( RFXItems itemDatail, List<RFXItems> item) {
		super();
		this.itemDatail = itemDatail;
		this.bidLine = item;
	}
	public RFXItems getItemDatail() {
		return itemDatail;
	}
	public void setItemDatail(RFXItems itemDatail) {
		this.itemDatail = itemDatail;
	}
	public List<RFXItems> getBidLine() {
		return bidLine;
	}
	public void setBidLine(List<RFXItems> bidLine) {
		this.bidLine = bidLine;
	}
	

	 
 
	
	
}
