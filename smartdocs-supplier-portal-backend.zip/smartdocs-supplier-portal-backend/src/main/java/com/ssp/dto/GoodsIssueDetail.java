package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;
import com.ssp.mongo.collectionhelpers.GoodsIssueItems;
import com.ssp.mongo.collections.Agent;
import com.ssp.mongo.collections.ticket.Ticket;
import com.ssp.mongo.collections.workflow.WorkItem;

@Document(collection = "GoodsIssue")
public class GoodsIssueDetail {

	@Id
	private String id;
	
	private String type;
	private String prrRefId;
	private String requestId;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String requestorEmail;
	private String typeDesc;
	private String initatorEmail;
	private List<GIReceiver> receivers;
	private String companyCode;
	private String companyName;
	private String currency;
	private String supplierId;
	private ZonedDateTime createdDate;
	private String createdBy;
	private double totalAmount;
	private String company;
	private List<GoodsIssueItems> lineItems;
	private List<DocumentHelper> attachments;
	
	private String status;
	private String agentName;
	private boolean isSAPSynch;
	private ZonedDateTime SAPSynchDate;
	private boolean syncToSAP;
	private String supplier;
	private Address supplierAddress;
	private GeneralState state;
	private String purchasingGroupDesc;
	private String purchasingOrgDesc;
	private String paymentTermsDesc;
	private String requestor;
	private String comment;
	private ZonedDateTime lastUpdatedDate;
	private String lastUpdatedBy;
	private WorkItem workItem;
	private String requestorName;
	private String initator;
	private String channel;
	private List<Ticket> tickets;

 
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPrrRefId() {
		return prrRefId;
	}
	public void setPrrRefId(String prrRefId) {
		this.prrRefId = prrRefId;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getInitatorEmail() {
		return initatorEmail;
	}
	public void setInitatorEmail(String initatorEmail) {
		this.initatorEmail = initatorEmail;
	}
	
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public List<GoodsIssueItems> getLineItems() {
		return lineItems;
	}
	public void setLineItems(List<GoodsIssueItems> lineItems) {
		this.lineItems = lineItems;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public void updateAgent(Agent agent) {
		if(agent!=null)
		{	
			this.agentName=agent.getAgentName();
		 
		}else {
			this.agentName=null;
	 
		}
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getRequestId() {
		return requestId;
	}

	public boolean isSAPSynch() {
		return isSAPSynch;
	}

	public void setSAPSynch(boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public ZonedDateTime getSAPSynchDate() {
		return SAPSynchDate;
	}

	public void setSAPSynchDate(ZonedDateTime sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}

	public boolean isSyncToSAP() {
		return syncToSAP;
	}

	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}

	public GeneralState getState() {
		return state;
	}

	public void setState(GeneralState state) {
		this.state = state;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public String getTypeDesc() {
		return typeDesc;
	}
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public Address getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(Address supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}
	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}
	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}
	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}
	public String getPaymentTermsDesc() {
		return paymentTermsDesc;
	}
	public void setPaymentTermsDesc(String paymentTermsDesc) {
		this.paymentTermsDesc = paymentTermsDesc;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public ZonedDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(ZonedDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public String getInitator() {
		return initator;
	}
	public void setInitator(String initator) {
		this.initator = initator;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public List<Ticket> getTickets() {
		return tickets;
	}
	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}
	public List<GIReceiver> getReceivers() {
		return receivers;
	}
	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}
	
	
}
