package com.ssp.dto.plannedpo;

import java.util.List;

import com.ssp.dto.PlannedPurchaseOrderDto;

public class PlannedPurchaseOrderRow {
	
	private String material;
	private String materialDescription;
	private String productionPlant;
	private String productionPlantDesc;
	private List<PlannedPurchaseOrderDto> cols;
	
	
	public PlannedPurchaseOrderRow(String material, String materialDescription, String productionPlant,String plantDesc,
			List<PlannedPurchaseOrderDto> cols) {
		super();
		this.material = material;
		this.materialDescription = materialDescription;
		this.productionPlant = productionPlant;
		this.cols = cols;
		this.productionPlantDesc = plantDesc;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getMaterialDescription() {
		return materialDescription;
	}
	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}
	public String getProductionPlant() {
		return productionPlant;
	}
	public void setProductionPlant(String productionPlant) {
		this.productionPlant = productionPlant;
	}
	public List<PlannedPurchaseOrderDto> getCols() {
		return cols;
	}
	public void setCols(List<PlannedPurchaseOrderDto> cols) {
		this.cols = cols;
	}
	public String getProductionPlantDesc() {
		return productionPlantDesc;
	}
	public void setProductionPlantDesc(String productionPlantDesc) {
		this.productionPlantDesc = productionPlantDesc;
	}
	
	 
	
	
}
