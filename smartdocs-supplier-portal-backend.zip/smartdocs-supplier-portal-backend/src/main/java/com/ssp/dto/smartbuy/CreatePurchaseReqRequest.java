package com.ssp.dto.smartbuy;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.dto.SynapseApproveWorkItem;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;

public class CreatePurchaseReqRequest {

	
	private String title;		
	private String description;
	private String companyCode;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String requestId;
	private List<GIReceiver> receivers;
	private String currency;
	private String supplierId;
	private String plant;
	private String storageLocation;
	private List<DocumentHelper> attachments;
	private String notes;
	private List<CreatePurchaseReqRequestLine> requestItems;
	private String type; //newly added
	
	private double totalAmount;
	private String receiverEmail;
	private String receiverName;
	
	
	private String activityCode;
	private String requestorEmail;
	private String action;
	private String collaboratedUser;
	private ZonedDateTime deliveryDate;
	
	
	public CreatePurchaseReqRequest() {
		super();
	}
	public CreatePurchaseReqRequest(SynapseApproveWorkItem approveWorkItem) {
		super();
		this.notes=approveWorkItem.getComment();
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public List<CreatePurchaseReqRequestLine> getRequestItems() {
		return requestItems;
	}
	public void setRequestItems(List<CreatePurchaseReqRequestLine> requestItems) {
		this.requestItems = requestItems;
	}
	public String getNotes() {
		return notes;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getStorageLocation() {
		return storageLocation;
	}
	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public List<GIReceiver> getReceivers() {
		return receivers;
	}
	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}
	public String getReceiverEmail() {
		return receiverEmail;
	}
	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	
	
}
