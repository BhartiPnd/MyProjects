package com.ssp.dto;

import java.time.ZonedDateTime;

public class PurcahseInfoRecordSupplierDTO {
	
	private String supplierId;
	private String supplierName;
	private Double unitPrice;
	private Double movingPrice;
	private ZonedDateTime validityFrom;
	private ZonedDateTime validityTo;
	
	
	public PurcahseInfoRecordSupplierDTO() {
		
	}
	
	public PurcahseInfoRecordSupplierDTO(String supplierId, String supplierName, Double unitPrice, Double movingPrice, ZonedDateTime validityFrom,
			ZonedDateTime validityTo) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.unitPrice = unitPrice;
		this.movingPrice = movingPrice;
		this.validityFrom = validityFrom;
		this.validityTo = validityTo;
	}




	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public Double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Double getMovingPrice() {
		return movingPrice;
	}
	public void setMovingPrice(Double movingPrice) {
		this.movingPrice = movingPrice;
	}

	public ZonedDateTime getValidityFrom() {
		return validityFrom;
	}

	public void setValidityFrom(ZonedDateTime validityFrom) {
		this.validityFrom = validityFrom;
	}

	public ZonedDateTime getValidityTo() {
		return validityTo;
	}

	public void setValidityTo(ZonedDateTime validityTo) {
		this.validityTo = validityTo;
	}
	

}
