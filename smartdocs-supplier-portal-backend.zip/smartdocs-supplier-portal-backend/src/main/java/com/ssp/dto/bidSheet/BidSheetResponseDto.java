package com.ssp.dto.bidSheet;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class BidSheetResponseDto {
	
	private String activity;
	private String comment;
	private String bidSheetResponseId;
	private DocumentHelper attachment;
	
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getBidSheetResponseId() {
		return bidSheetResponseId;
	}
	public void setBidSheetResponseId(String bidSheetResponseId) {
		this.bidSheetResponseId = bidSheetResponseId;
	}
	
	public BidSheetResponseDto(String activity, String comment, String bidSheetResponseId,
			DocumentHelper attachment) {
		super();
		this.activity = activity;
		this.comment = comment;
		this.bidSheetResponseId = bidSheetResponseId;
		this.attachment = attachment;
	}
	
	public BidSheetResponseDto() {
		super();
		
	}
	
	
	
}
