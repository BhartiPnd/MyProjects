package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.AdhocApprover;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.LineItems;
import com.ssp.mongo.collections.requests.BankDetail;

/**
 * @author Mahesh
 *
 */
public class CreateInvoiceRequest {

	// work Item Related
	// in case of approve approve or reject.
	private String activityCode;
	private String action;
	private String id;
	private String collaboratedUser;

	private String sspInvoiceReferenceNo;
	private String invoiceNumber;
	private String poNumber;
	private String poDescription;

	// only if company user submiting invoice.
	private String supplierId;
	private String companyCode;

	private ZonedDateTime dueDate;
	private ZonedDateTime supplyDate;

	private Address remittoaddress;
	private Address shiptoaddress;
	private String currency;
	 
	private float taxPercent; // input field.

	// editable.
	private double discount;
	// editable
	private double taxAmount;
	// editable
	private double freightAmount;
	 	
	// input
	private double totalInvoiceAmount;
	

	private String paymentterms;
	private String freightCarrier;

	private String invoiceCategory;

	private String status;
	private boolean editable;

	private Map<String, String> headerAttributes;
	private String invoiceType;
 

	private List<DocumentHelper> attachments;
	private String notes;
	private String comments;
	private List<LineItems> invoiceitems;
	private List<AdhocApprover> adhocApprovers;

	private boolean creditMemo;
	private String requestor;

	private String cadsNumber;
	private String billAccNumber;
	private String billAccName;
	private ZonedDateTime invoiceDate;

	private String shoppingCartNo;

	private boolean isAdhoc;

	private boolean passive;
	private String passiveUser;
	private String datesOfService;
	private String invoiceTypeCategory;
	private String shipmentType;
	private boolean confidential;
	private String eventNumber;
	private String eventDescription;
	private String forwardUser;
	
	private List<String> removedAttachments;

	private boolean afterFactPO;
	private String requestorEmail;
	private String bankAccountNumber;
	private String abaNo;
	private boolean asset;
	
	private BankDetail bankDetails;
	private boolean oneTime;
	private String businessArea;
	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public ZonedDateTime getDueDate() {
		return dueDate;
	}

	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}

	public Address getRemittoaddress() {
		return remittoaddress;
	}

	public Address getShiptoaddress() {
		return shiptoaddress;
	}

//	public double getSubTotal() {
//		return subTotal;
//	}

 

 
	public double getFreightAmount() {
		return freightAmount;
	}

	public float getTaxPercent() {
		return taxPercent;
	}

	public String getPaymentterms() {
		return paymentterms;
	}

	public String getFreightCarrier() {
		return freightCarrier;
	}

	public String getInvoiceCategory() {
		return invoiceCategory;
	}

	public String getStatus() {
		return status;
	}

	public Map<String, String> getHeaderAttributes() {
		return headerAttributes;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public String getNotes() {
		return notes;
	}

	public String getComments() {
		return comments;
	}

	public List<LineItems> getInvoiceitems() {
		return invoiceitems;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}

	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}

	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}

	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}

//	public void setSubTotal(Double subTotal) {
//		this.subTotal = subTotal;
//	}
 
	public void setFreightAmount(Double freightAmount) {
		this.freightAmount = freightAmount;
	}

	public void setTaxPercent(Float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}

	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setHeaderAttributes(Map<String, String> headerAttributes) {
		this.headerAttributes = headerAttributes;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setInvoiceitems(List<LineItems> invoiceitems) {
		this.invoiceitems = invoiceitems;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public boolean isCreditMemo() {
		return creditMemo;
	}

	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getCadsNumber() {
		return cadsNumber;
	}

	public String getBillAccNumber() {
		return billAccNumber;
	}

	public String getBillAccName() {
		return billAccName;
	}

	public void setCadsNumber(String cadsNumber) {
		this.cadsNumber = cadsNumber;
	}

	public void setBillAccNumber(String billAccNumber) {
		this.billAccNumber = billAccNumber;
	}

	public void setBillAccName(String billAccName) {
		this.billAccName = billAccName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCollaboratedUser() {
		return collaboratedUser;
	}

	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}

	public List<AdhocApprover> getAdhocApprovers() {
		return adhocApprovers;
	}

	public void setAdhocApprovers(List<AdhocApprover> adhocApprovers) {
		this.adhocApprovers = adhocApprovers;
	}

	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public String getShoppingCartNo() {
		return shoppingCartNo;
	}

	public void setShoppingCartNo(String shoppingCartNo) {
		this.shoppingCartNo = shoppingCartNo;
	}

	public boolean isAdhoc() {
		return isAdhoc;
	}

	public void setAdhoc(boolean isAdhoc) {
		this.isAdhoc = isAdhoc;
	}

	public boolean isPassive() {
		return passive;
	}

	public void setPassive(boolean passive) {
		this.passive = passive;
	}

	public String getPassiveUser() {
		return passiveUser;
	}

	public void setPassiveUser(String passiveUser) {
		this.passiveUser = passiveUser;
	}

	public String getDatesOfService() {
		return datesOfService;
	}

	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}

	public String getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(String shipmentType) {
		this.shipmentType = shipmentType;
	}

	public boolean isConfidential() {
		return confidential;
	}

	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}

	public String getPoDescription() {
		return poDescription;
	}

	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}

	public String getEventNumber() {
		return eventNumber;
	}

	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public boolean isAfterFactPO() {
		return afterFactPO;
	}

	public void setAfterFactPO(boolean afterFactPO) {
		this.afterFactPO = afterFactPO;
	}

	public String getForwardUser() {
		return forwardUser;
	}

	public void setForwardUser(String forwardUser) {
		this.forwardUser = forwardUser;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getAbaNo() {
		return abaNo;
	}

	public void setAbaNo(String abaNo) {
		this.abaNo = abaNo;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}

	public void setSspInvoiceReferenceNo(String sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}

	public String getInvoiceTypeCategory() {
		return invoiceTypeCategory;
	}

	public void setInvoiceTypeCategory(String invoiceTypeCategory) {
		this.invoiceTypeCategory = invoiceTypeCategory;
	}

	public List<String> getRemovedAttachments() {
		return removedAttachments;
	}

	public void setRemovedAttachments(List<String> removedAttachments) {
		this.removedAttachments = removedAttachments;
	}
	public void resetAttachmentUploadeByInfo(String uploadedBy,int usrUploaded) {
		 
			if(this.attachments!=null && this.attachments.size()>0)
			{
				for(DocumentHelper attachment:this.attachments) {
					if(attachment.getUploadedDate()==null) {
						attachment.setUploadedDate(ZonedDateTime.now());
					}
					if(attachment.getUploadedBy()==null || StringUtils.isBlank(uploadedBy)) {
						attachment.setUploadedBy(uploadedBy);
						attachment.setUsrUploaded(usrUploaded);
					}
				}
			}
	}

	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public Double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public void setTaxPercent(float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public void setFreightAmount(double freightAmount) {
		this.freightAmount = freightAmount;
	}

	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public boolean isAsset() {
		return asset;
	}

	public void setAsset(boolean asset) {
		this.asset = asset;
	}

	public BankDetail getBankDetails() {
		return bankDetails;
	}

	public boolean isOneTime() {
		return oneTime;
	}

	public void setBankDetails(BankDetail bankDetails) {
		this.bankDetails = bankDetails;
	}

	public void setOneTime(boolean oneTime) {
		this.oneTime = oneTime;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
	
}
