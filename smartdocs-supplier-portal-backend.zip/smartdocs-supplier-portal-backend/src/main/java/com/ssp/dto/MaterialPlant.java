package com.ssp.dto;

public class MaterialPlant {
	 
	private String description;
	private String id;
	private String uom;
	public MaterialPlant() {
		super();
		 
	}
	public MaterialPlant(String id,String description) 
	{
		super();
		this.id = id;
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "MaterialPlant [_id="+ ", description=" + description + ", id=" + id + "]";
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	
	
}
