package com.ssp.dto.bidSheet;

import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.bidsheet.BidSheetResponseData;

public class BidSheetResponseUpdate {

	private DocumentHelper attachment;
	private List<BidSheetResponseData> bidSheetResponseData;
	
	
	public BidSheetResponseUpdate() {
		super();
	}
	
	public DocumentHelper getAttachment() {
		return attachment;
	}
	public void setAttachment(DocumentHelper attachment) {
		this.attachment = attachment;
	}
	public List<BidSheetResponseData> getBidSheetResponseData() {
		return bidSheetResponseData;
	}
	public void setBidSheetResponseData(List<BidSheetResponseData> bidSheetResponseData) {
		this.bidSheetResponseData = bidSheetResponseData;
	}

	public BidSheetResponseUpdate(DocumentHelper attachment, List<BidSheetResponseData> bidSheetResponseData) {
		super();
		this.attachment = attachment;
		this.bidSheetResponseData = bidSheetResponseData;
	}
	
	
}
