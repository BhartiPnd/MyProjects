package com.ssp.dto;

import org.springframework.data.annotation.Id;

public class ItemHelperDTO {

	@Id
	private String id;
	private String purchaseOrderNumber;
	private POitmHelperDTO items;

	public ItemHelperDTO() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public POitmHelperDTO getItems() {
		return items;
	}

	public void setItems(POitmHelperDTO items) {
		this.items = items;
	}

}
