package com.ssp.dto.rfx.bid;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import com.ssp.dto.RFXBidResponseTable;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.Rfx;

public class BidComparison {

	 private List<RFXBidResponseTable> bids;
	 
//	 private List<RequiredQuestions> requiredQuestions;
	
	private List<BidLines> items;
	// private Map<String,RFXItems> item;
	
	 
	 private Map<String,List<DocumentHelper>> attachments;
	 
	 public BidComparison() {
		 
	 }
	 
	 public BidComparison(Rfx rfx,List<RFXBidResponseTable> bidDetails) {
		 
		 this.bids=bidDetails;
		 
//		 this.requiredQuestions=new ArrayList<RequiredQuestions>();
//		 if(rfx.getQuestions()!=null)
//		 {	for(RFxQandA q:rfx.getQuestions()) {
//			 	Map<String,String> answer=new HashedMap();
//			 	for(RFXBidResponseTable bid:bidDetails) {
//			 		answer.put(bid.getBidNo(),  getAnswer(bid, q.getQuestion()));
//			 	}
//			 	this.requiredQuestions.add(new RequiredQuestions(q.getQuestion(),answer));
//		 	}
//		 }
		 this.items=new ArrayList<BidLines>();
		 if(rfx.getItems()!=null)
		 {for(RFXItems q:rfx.getItems()) {
			 List<RFXItems> bidLine=new ArrayList<RFXItems>();
			 for(RFXBidResponseTable bid:bidDetails) {
				 bidLine.add(getBid(bid, q.getLineNo()));
			 }
			 this.items.add(new BidLines(q,bidLine));
		 }
		 }
		 
		 this.attachments=new HashedMap();
		 for(RFXBidResponseTable bid:bidDetails) {
			 attachments.put(bid.getBidNo(), bid.getAttachments());
		 }
		 
	 }
	 
//	 private String getAnswer(RFXBidResponseTable bid,String que) {
//		 String answer="";
//		  
//			 for(BidRequiredInfo ans:bid.getQuestions()) {
//				 if(ans.getQuestion().equals(que)) {
//					 answer=ans.getAnswer();
//				 }
//			 }
//		 return answer;
//	 }
	 
	 private RFXItems getBid(RFXBidResponseTable bid,String lineNo) {
		 RFXItems item=null;
		  
			 for(RFXItems rfxLine:bid.getItems()) {
				 if(rfxLine.getLineNo().equalsIgnoreCase(lineNo)) {
					 item=rfxLine;
				 }
			 }
		 return item;
	 }

	public List<RFXBidResponseTable> getBids() {
		return bids;
	}

	public void setBids(List<RFXBidResponseTable> bids) {
		this.bids = bids;
	}

//	public List<RequiredQuestions> getRequiredQuestions() {
//		return requiredQuestions;
//	}
//
//	public void setRequiredQuestions(List<RequiredQuestions> requiredQuestions) {
//		this.requiredQuestions = requiredQuestions;
//	}

	

	 

	public List<BidLines> getItems() {
		return items;
	}

	public void setItems(List<BidLines> items) {
		this.items = items;
	}

	public Map<String, List<DocumentHelper>> getAttachments() {
		return attachments;
	}

	public void setAttachments(Map<String, List<DocumentHelper>> attachments) {
		this.attachments = attachments;
	}
	 
	 
}



