package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collections.Supplier;
import com.ssp.mongo.collections.pir.PurchaseInfoRecord;

public class PriceComparisionInfo {

	// private PurchaseInfoRecord purchaseInfoRecord;

	private PurchaseInfoRecordDTO purchaseInfoRecordDTO;
	private List<SupplierInfoDTO> supplierInfoDTOs;

	public PriceComparisionInfo() {

	}

	public PriceComparisionInfo(PurchaseInfoRecordDTO purchaseInfoRecordDTO,
			List<SupplierInfoDTO> supplierInfoDTOs) {
		super();
		this.purchaseInfoRecordDTO = purchaseInfoRecordDTO;
		this.supplierInfoDTOs = supplierInfoDTOs;
	}

	//
	// public PriceComparisionInfo(PurchaseInfoRecord purchaseInfoRecord,
	// List<Supplier> suppliers) {
	// super();
	// this.purchaseInfoRecord = purchaseInfoRecord;
	// this.suppliers = suppliers;
	// }
	//
	// public PurchaseInfoRecord getPurchaseInfoRecord() {
	// return purchaseInfoRecord;
	// }
	//
	// public void setPurchaseInfoRecord(PurchaseInfoRecord purchaseInfoRecord) {
	// this.purchaseInfoRecord = purchaseInfoRecord;
	// }
	//
	// public List<Supplier> getSuppliers() {
	// return suppliers;
	// }

	
	public List<SupplierInfoDTO> getSupplierInfoDTOs() {
		return supplierInfoDTOs;
	}

	public PurchaseInfoRecordDTO getPurchaseInfoRecordDTO() {
		return purchaseInfoRecordDTO;
	}

	public void setPurchaseInfoRecordDTO(PurchaseInfoRecordDTO purchaseInfoRecordDTO) {
		this.purchaseInfoRecordDTO = purchaseInfoRecordDTO;
	}

	public void setSupplierInfoDTOs(List<SupplierInfoDTO> supplierInfoDTOs) {
		this.supplierInfoDTOs = supplierInfoDTOs;
	}

	

}
