package com.ssp.dto;

import java.time.ZonedDateTime;

public class POitmHelperDTO {

	private Integer PO_LNE;
	private Integer OA_LNE;
	private String MAT_CODE;
	private String MAT_DES;
	private Double PO_QTY;
	private Double OC_QTY;
	private Double PO_UNT_PRCE;
	private ZonedDateTime DLVRY_DATE;
	private Double netValue;
	private String ediStatus;
	private String PO_UOM;
	private String perUOM;
	private String currency;
	private String supplierMatNo;
	private String supplierMatDesc;
	private ZonedDateTime ackDeliveryDate;

	public POitmHelperDTO() {
		super();
	}

	public Integer getPO_LNE() {
		return PO_LNE;
	}

	public void setPO_LNE(Integer pO_LNE) {
		PO_LNE = pO_LNE;
	}

	public String getMAT_CODE() {
		return MAT_CODE;
	}

	public void setMAT_CODE(String mAT_CODE) {
		MAT_CODE = mAT_CODE;
	}

	public String getMAT_DES() {
		return MAT_DES;
	}

	public void setMAT_DES(String mAT_DES) {
		MAT_DES = mAT_DES;
	}

	public Double getPO_QTY() {
		return PO_QTY;
	}

	public void setPO_QTY(Double pO_QTY) {
		PO_QTY = pO_QTY;
	}

	public Double getOC_QTY() {
		return OC_QTY;
	}

	public void setOC_QTY(Double oC_QTY) {
		OC_QTY = oC_QTY;
	}

	public Double getPO_UNT_PRCE() {
		return PO_UNT_PRCE;
	}

	public void setPO_UNT_PRCE(Double pO_UNT_PRCE) {
		PO_UNT_PRCE = pO_UNT_PRCE;
	}

	public ZonedDateTime getDLVRY_DATE() {
		return DLVRY_DATE;
	}

	public void setDLVRY_DATE(ZonedDateTime dLVRY_DATE) {
		DLVRY_DATE = dLVRY_DATE;
	}

	public Double getNetValue() {
		return netValue;
	}

	public void setNetValue(Double netValue) {
		this.netValue = netValue;
	}

	public String getEdiStatus() {
		return ediStatus;
	}

	public void setEdiStatus(String ediStatus) {
		this.ediStatus = ediStatus;
	}

	public Integer getOA_LNE() {
		return OA_LNE;
	}

	public void setOA_LNE(Integer oA_LNE) {
		OA_LNE = oA_LNE;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPO_UOM() {
		return PO_UOM;
	}

	public void setPO_UOM(String pO_UOM) {
		PO_UOM = pO_UOM;
	}

	public String getPerUOM() {
		return perUOM;
	}

	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}

	public String getSupplierMatNo() {
		return supplierMatNo;
	}

	public void setSupplierMatNo(String supplierMatNo) {
		this.supplierMatNo = supplierMatNo;
	}

	public String getSupplierMatDesc() {
		return supplierMatDesc;
	}

	public void setSupplierMatDesc(String supplierMatDesc) {
		this.supplierMatDesc = supplierMatDesc;
	}

	public ZonedDateTime getAckDeliveryDate() {
		return ackDeliveryDate;
	}

	public void setAckDeliveryDate(ZonedDateTime ackDeliveryDate) {
		this.ackDeliveryDate = ackDeliveryDate;
	}

}
