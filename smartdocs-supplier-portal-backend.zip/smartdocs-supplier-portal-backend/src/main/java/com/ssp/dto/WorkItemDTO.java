package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collections.workflow.WorkFlowState;
import com.ssp.travler.InvoieValidationResult;


@Document(collection = "workitem")
public class WorkItemDTO {

	@Id
	private String id;

	private String itemType;
	private String itemId;

	private String status;
	private int currentStep;
	private List<String> approvers;
	private boolean addHoc;
	private String collaboratedUsers;
	private String collaboratedBy;

	private boolean editable;

	// logged in user who created the requrest.
	private String requestor;

	private String refNo;
	private String type;
	private String typeDesc;
	private String supplierId;
	private String supplier;
	private String category;

	private List<ActivityLog> activityLogs;

	private String title;
	private Map<String, Object> metaData;

	private ZonedDateTime createdDate;
	
	private ZonedDateTime lastUpdated;

	private ZonedDateTime startDate;

	private Boolean isSAPSynch;
	private Long SAPSynchDate;
	private Boolean isSAPSynchACK;
	private List<InvoieValidationResult> exceptions;
	private String statusDesc;
	private boolean owner;
	private  WorkFlowState state;
	public String getId() {
		return id;
	}
	public String getItemType() {
		return itemType;
	}
	public String getItemId() {
		return itemId;
	}
	public String getStatus() {
		return status;
	}
	public int getCurrentStep() {
		return currentStep;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public boolean isAddHoc() {
		return addHoc;
	}
	public String getCollaboratedUsers() {
		return collaboratedUsers;
	}
	public String getCollaboratedBy() {
		return collaboratedBy;
	}
	public boolean isEditable() {
		return editable;
	}
	public String getRequestor() {
		return requestor;
	}
	public String getRefNo() {
		return refNo;
	}
	public String getType() {
		return type;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplier() {
		return supplier;
	}
	public String getCategory() {
		return category;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public String getTitle() {
		return title;
	}
	public Map<String, Object> getMetaData() {
		return metaData;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public ZonedDateTime getStartDate() {
		return startDate;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public Long getSAPSynchDate() {
		return SAPSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public List<InvoieValidationResult> getExceptions() {
		return exceptions;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setCurrentStep(int currentStep) {
		this.currentStep = currentStep;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	public void setAddHoc(boolean addHoc) {
		this.addHoc = addHoc;
	}
	public void setCollaboratedUsers(String collaboratedUsers) {
		this.collaboratedUsers = collaboratedUsers;
	}
	public void setCollaboratedBy(String collaboratedBy) {
		this.collaboratedBy = collaboratedBy;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setMetaData(Map<String, Object> metaData) {
		this.metaData = metaData;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSAPSynchDate(Long sAPSynchDate) {
		SAPSynchDate = sAPSynchDate;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public void setExceptions(List<InvoieValidationResult> exceptions) {
		this.exceptions = exceptions;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public boolean isOwner() {
		return owner;
	}
	public void setOwner(boolean owner) {
		this.owner = owner;
	}
	public String getTypeDesc() {
		return typeDesc;
	}
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}
	public WorkFlowState getState() {
		return state;
	}
	public void setState(WorkFlowState state) {
		this.state = state;
	}
	
	
	
}
