package com.ssp.dto.user;

import java.util.List;

import com.ssp.dto.UserTable;
import com.ssp.mongo.collections.User;

public class AdminUserRD {

	private String email;
	private String firstname;
	private String lastname;
	private boolean isEmailEnabled;
	private List<AdminUserRoles> rolesAccess;
	
	public AdminUserRD() {
		super();
	}
	public AdminUserRD(UserTable user,
			List<AdminUserRoles> rolesAccess) {
		super();
		this.email = user.getEmail();
		this.firstname = user.getFirstname();
		this.lastname = user.getLastname();
		this.isEmailEnabled = user.isEmailEnabled();
		this.rolesAccess = rolesAccess;
	}
	public AdminUserRD(User user,
			List<AdminUserRoles> rolesAccess) {
		super();
		this.email = user.getEmail();
		this.firstname = user.getFirstname();
		this.lastname = user.getLastname();
		this.isEmailEnabled = user.isEmailEnabled();
		this.rolesAccess = rolesAccess;
	}
	public String getEmail() {
		return email;
	}
	public String getFirstname() {
		return firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public boolean isEmailEnabled() {
		return isEmailEnabled;
	}
	public List<AdminUserRoles> getRolesAccess() {
		return rolesAccess;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public void setEmailEnabled(boolean isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}
	public void setRolesAccess(List<AdminUserRoles> rolesAccess) {
		this.rolesAccess = rolesAccess;
	}
	
	
}
