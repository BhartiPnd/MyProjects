package com.ssp.dto;

import java.util.List;

public class DBSubmissionLine {

	private boolean isSubContractorPortalVendor;
	private String subcontractorId;
	private boolean isSubContractorDBVendor;
	private String subcontractorName;
	private List<String> dbeTypes;
	
	// CommitedAmountOn Commitement Sheet.
	private double commitedAmount;
	private double amountOfSubcontracts;
	private double amountEarnedThisMonth;
	private double amountPaidThisMonth;	
	private double amountEarnedToDate;
	private double amountPaidToDate;
	
	public String getSubcontractorId() {
		return subcontractorId;
	}
	public boolean isSubContractorDBVendor() {
		return isSubContractorDBVendor;
	}
	public String getSubcontractorName() {
		return subcontractorName;
	}
	public double getCommitedAmount() {
		return commitedAmount;
	}
	public double getAmountOfSubcontracts() {
		return amountOfSubcontracts;
	}
	public double getAmountEarnedThisMonth() {
		return amountEarnedThisMonth;
	}
	public double getAmountPaidThisMonth() {
		return amountPaidThisMonth;
	}
	public double getAmountEarnedToDate() {
		return amountEarnedToDate;
	}
	public double getAmountPaidToDate() {
		return amountPaidToDate;
	}
	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}
	public void setSubContractorDBVendor(boolean isSubContractorDBVendor) {
		this.isSubContractorDBVendor = isSubContractorDBVendor;
	}
	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}
	public void setCommitedAmount(double commitedAmount) {
		this.commitedAmount = commitedAmount;
	}
	public void setAmountOfSubcontracts(double amountOfSubcontracts) {
		this.amountOfSubcontracts = amountOfSubcontracts;
	}
	public void setAmountEarnedThisMonth(double amountEarnedThisMonth) {
		this.amountEarnedThisMonth = amountEarnedThisMonth;
	}
	public void setAmountPaidThisMonth(double amountPaidThisMonth) {
		this.amountPaidThisMonth = amountPaidThisMonth;
	}
	public void setAmountEarnedToDate(double amountEarnedToDate) {
		this.amountEarnedToDate = amountEarnedToDate;
	}
	public void setAmountPaidToDate(double amountPaidToDate) {
		this.amountPaidToDate = amountPaidToDate;
	}
	 
	public boolean isSubContractorPortalVendor() {
		return isSubContractorPortalVendor;
	}
	public void setSubContractorPortalVendor(boolean isSubContractorPortalVendor) {
		this.isSubContractorPortalVendor = isSubContractorPortalVendor;
	}
	public List<String> getDbeTypes() {
		return dbeTypes;
	}
	public void setDbeTypes(List<String> dbeTypes) {
		this.dbeTypes = dbeTypes;
	}
	 
	
}
