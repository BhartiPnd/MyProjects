package com.ssp.dto.rfx.bid;

import java.util.List;
import java.util.Map;


public class RequiredQuestions {

	// private Integer sequence;
	private String question;
	private Map<String, String> answer;

	public RequiredQuestions() {
		super();
	}

	public RequiredQuestions(String question, Map<String, String> answer) {
		super();
		// this.sequence = sequence;
		this.question = question;
		this.answer = answer;
	}

//		public Integer getSequence() {
//			return sequence;
//		}
//		public void setSequence(Integer sequence) {
//			this.sequence = sequence;
//		}
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Map<String, String> getAnswer() {
		return answer;
	}

	public void setAnswer(Map<String, String> answer) {
		this.answer = answer;
	}

}
