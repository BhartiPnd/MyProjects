package com.ssp.dto.smartbuy;

import java.time.ZonedDateTime;
import com.ssp.mongo.collections.smartbuy.PurchaseOrderReq;

public class PoPorDto {

	private String referenceNo;
	private String referenceName;
	private String requestor;
	private String requestorName;
	private ZonedDateTime createdOn;
	
	public PoPorDto() {
		super();
	}

	public PoPorDto(PurchaseOrderReq getPorById, String reqName) {
		super();
		this.referenceNo = getPorById.getRequestId();
		this.referenceName = "Purchase Order Request";
		this.requestor = getPorById.getRequestorEmail();
		this.createdOn = getPorById.getCreatedDate();
		this.requestorName = reqName;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getReferenceName() {
		return referenceName;
	}

	public void setReferenceName(String referenceName) {
		this.referenceName = referenceName;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public ZonedDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(ZonedDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	
}
