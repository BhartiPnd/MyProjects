package com.ssp.dto.user;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ssp.mongo.collections.PermissionGroup;

public class AdminUserDataTableContainer {

	private List<PermissionGroup> roles;
	private Page<AdminUserRD> users;
	
	public List<PermissionGroup> getRoles() {
		return roles;
	}
 
	public void setRoles(List<PermissionGroup> roles) {
		this.roles = roles;
	}

	public Page<AdminUserRD> getUsers() {
		return users;
	}

	public void setUsers(Page<AdminUserRD> users) {
		this.users = users;
	}
	
	
	
}
