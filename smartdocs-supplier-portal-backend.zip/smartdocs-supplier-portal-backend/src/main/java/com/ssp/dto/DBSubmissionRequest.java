package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

public class DBSubmissionRequest {

	
	private String title;
	private String year;
	private String month;
	private boolean isFinalReport;
	private String contractId;
	private String primeVendorId;
	private String submissionType;
	private String requestId;
	private double contractAmountPaidTillDate;
	
	private String comment;
	private List<DocumentHelper> attachments;
	
	
	private List<DBSubmissionLine> lines;
	
	private ZonedDateTime reportDate;
	
	public String getTitle() {
		return title;
	}


	public boolean isFinalReport() {
		return isFinalReport;
	}


	public String getContractId() {
		return contractId;
	}

 
	public String getPrimeVendorId() {
		return primeVendorId;
	}




	public String getSubmissionType() {
		return submissionType;
	}


	public List<DBSubmissionLine> getLines() {
		return lines;
	}


	public String getComment() {
		return comment;
	}


	public List<DocumentHelper> getAttachments() {
		return attachments;
	}


	 


	public void setTitle(String title) {
		this.title = title;
	}


	public void setFinalReport(boolean isFinalReport) {
		this.isFinalReport = isFinalReport;
	}


	public void setContractId(String contractId) {
		this.contractId = contractId;
	}



	public void setPrimeVendorId(String primeVendorId) {
		this.primeVendorId = primeVendorId;
	}


	

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}


	public void setLines(List<DBSubmissionLine> lines) {
		this.lines = lines;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}


	public String getYear() {
		return year;
	}


	public String getMonth() {
		return month;
	}


	public void setYear(String year) {
		this.year = year;
	}


	public void setMonth(String month) {
		this.month = month;
	}


	public double getContractAmountPaidTillDate() {
		return contractAmountPaidTillDate;
	}


	public void setContractAmountPaidTillDate(double contractAmountPaidTillDate) {
		this.contractAmountPaidTillDate = contractAmountPaidTillDate;
	}


	public String getRequestId() {
		return requestId;
	}


	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}


	public ZonedDateTime getReportDate() {
		return reportDate;
	}


	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	
	//private Double totalDBAmount;
	
	
}
