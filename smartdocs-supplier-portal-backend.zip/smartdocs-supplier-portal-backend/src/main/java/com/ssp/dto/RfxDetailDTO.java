package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXItems;

@Document(collection = "rfx")
public class RfxDetailDTO {
	
	private String id;
	private String title;
	private String companyCode;
	private String rfxNo;
	private String type;
	
	private String visibility;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	
	private String status;
	private ZonedDateTime submissionStartDate;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;
	
	private String requestorEmail;
	private String requestorName;
	
	private String buyerEmail;
	private String buyerName;
	
	private List<RFXItems> items;
	private List<DocumentHelper> attachments;
	
	
	
	
	public RfxDetailDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	
	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getRfxNo() {
		return rfxNo;
	}
	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}
	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}
	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public String getBuyerEmail() {
		return buyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public List<RFXItems> getItems() {
		return items;
	}
	public void setItems(List<RFXItems> items) {
		this.items = items;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	
	
	
	

}
