package com.ssp.dto.smartbuy;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXBidder;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.RequiredDocumentType;
import com.ssp.mongo.collections.rfx.RequiredInfo;

public class CreateRfx {

	private String id;
	private String title;
	private String companyCode;
	private String rfxNo;
	private String type;

	private String visibility;
	
	private String purchasingGroup;
	private String purchasingGroupDesc;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;

	private String requestorEmail;
	private String requestorName;
	private String buyerEmail;
	private String buyerName;
	private List<RFXItems> items;
	private List<RFXBidder> bidders;
	private List<RequiredDocumentType> requiredDocuments;
	private List<RequiredInfo> requiredInfo;

	private String status;

	private ZonedDateTime submissionStartDate;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	private ZonedDateTime publishedDate;

	private List<DocumentHelper> attachments;

	private String activityCode;
	private String action;
	private String collaboratedUser;
	private String notes;
	private boolean isOwner;
	
	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}

	public String getRfxNo() {
		return rfxNo;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public List<RFXItems> getItems() {
		return items;
	}

	public void setItems(List<RFXItems> items) {
		this.items = items;
	}

	public List<RFXBidder> getBidders() {
		return bidders;
	}

	public void setBidders(List<RFXBidder> bidders) {
		this.bidders = bidders;
	}

	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public List<RequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}

	public void setRequiredInfo(List<RequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCollaboratedUser() {
		return collaboratedUser;
	}

	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}
	
	
}
