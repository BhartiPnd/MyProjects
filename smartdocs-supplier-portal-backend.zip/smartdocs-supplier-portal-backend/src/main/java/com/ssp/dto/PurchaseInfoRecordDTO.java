package com.ssp.dto;

import java.time.ZonedDateTime;

import com.ssp.mongo.collections.pir.PurchaseInfoRecord;

public class PurchaseInfoRecordDTO {

	private String id;
	private String materialCode;
	private String supplierId;
	private String plant;
	private String purchasingOrg;
	private String purchasingGroup;
	private String informationRecord;
	private String materialName;
	private String currency;
	private String uomDesc;
	private double quantity;
	private String uom;
	private String deliveryDays;
	private ZonedDateTime validityFrom;
	private ZonedDateTime validityTo;

	public PurchaseInfoRecordDTO() {

	}

	public PurchaseInfoRecordDTO(PurchaseInfoRecord purchaseInfoRecord,String materialName,String currency,String uomDesc) {
		this.id=purchaseInfoRecord.getId();
		this.materialCode=purchaseInfoRecord.getMaterialCode();
		this.supplierId=purchaseInfoRecord.getSupplierId();
		this.plant=purchaseInfoRecord.getPlant();
		this.purchasingGroup=purchaseInfoRecord.getPurchasingGroup();
		this.purchasingOrg=purchaseInfoRecord.getPurchasingOrg();
		this.informationRecord=purchaseInfoRecord.getInformationRecord();
		this.materialName=materialName;
		this.currency=currency;
		this.uomDesc=uomDesc;
		this.quantity=purchaseInfoRecord.getQuantity();
		this.uom=purchaseInfoRecord.getUom();
		this.deliveryDays=purchaseInfoRecord.getDeliveryDays();
		this.validityFrom=purchaseInfoRecord.getValidityFrom();
		this.validityTo=purchaseInfoRecord.getValidityTo();
				
		

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getInformationRecord() {
		return informationRecord;
	}

	public void setInformationRecord(String informationRecord) {
		this.informationRecord = informationRecord;
	}

	public String getMaterialName() {
		return materialName;
	}

	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getUomDesc() {
		return uomDesc;
	}

	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getDeliveryDays() {
		return deliveryDays;
	}

	public void setDeliveryDays(String deliveryDays) {
		this.deliveryDays = deliveryDays;
	}

	public ZonedDateTime getValidityFrom() {
		return validityFrom;
	}

	public void setValidityFrom(ZonedDateTime validityFrom) {
		this.validityFrom = validityFrom;
	}

	public ZonedDateTime getValidityTo() {
		return validityTo;
	}

	public void setValidityTo(ZonedDateTime validityTo) {
		this.validityTo = validityTo;
	}

}
