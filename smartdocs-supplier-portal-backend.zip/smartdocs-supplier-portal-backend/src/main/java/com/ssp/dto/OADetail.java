package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collections.OrderConfirmation;
import com.ssp.mongo.collections.PurchaseOrder;
import com.ssp.mongo.collections.list.PaymentTerms;

public class OADetail {

	private OrderConfirmation orderAck;
	private PurchaseOrder purchaseOrder;
	private String supplierName;
	private PaymentTerms paymentTerm;
	
	private List<ActivityLog> activityLogs;
	private String workItemStatus;
	
/*	private boolean invalid;
	private String message;*/
	
	public OADetail() {
		super();
	}
	public OADetail(OrderConfirmation orderAck, PurchaseOrder purchaseOrder, String supplierName,
			PaymentTerms paymentTerm,List<ActivityLog> activityLogs,String workItemStatus) {
		super();
		this.orderAck = orderAck;
		this.purchaseOrder = purchaseOrder;
		this.supplierName = supplierName;
		this.paymentTerm = paymentTerm;
		this.activityLogs=activityLogs;
		this.workItemStatus=workItemStatus;
	}
	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}
 
	public OrderConfirmation getOrderAck() {
		return orderAck;
	}
	public PaymentTerms getPaymentTerm() {
		return paymentTerm;
	}
	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	 
	public void setOrderAck(OrderConfirmation orderAck) {
		this.orderAck = orderAck;
	}
	public void setPaymentTerm(PaymentTerms paymentTerm) {
		this.paymentTerm = paymentTerm;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	public String getWorkItemStatus() {
		return workItemStatus;
	}
	public void setWorkItemStatus(String workItemStatus) {
		this.workItemStatus = workItemStatus;
	}
	
	
}
