package com.ssp.dto;

import java.util.List;

public class VendorContactInvitationRequest {
	
	private String supplierId;
	private String email;
	private List<String> roles;
	
	public String getSupplierId() {
		return supplierId;
	}
	public String getEmail() {
		return email;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	
	
}
