package com.ssp.dto;

import java.time.ZonedDateTime;

public class SAPSyncReport {

	private long count;
	private ZonedDateTime createdDateTime;
	private int dataSize;
	 
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	@Override
	public String toString() {
		return "DailyConversationCount [count=" + count + ", createdDateTime=" + createdDateTime + "]";
	}
	public int getDataSize() {
		return dataSize;
	}
	public void setDataSize(int dataSize) {
		this.dataSize = dataSize;
	}
	
}
