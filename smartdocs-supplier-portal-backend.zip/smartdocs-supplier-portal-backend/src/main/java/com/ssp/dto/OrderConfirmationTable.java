package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;

@Document(collection = "orderconfirmation")
public class OrderConfirmationTable {

	@Id
	private String id;
	private String purchaseOrderNumber;
	private long refId;
	private String companyCode;
	private String orderconfreference;
	private String supplierId;
	private String supplierName;
	private String createdBy;
	private String channel;
	private ZonedDateTime createdDateTime;
	private List<DocumentHelper> attachments;
	private String status;
	private String statusDesc;
	private ZonedDateTime acknowledgedDeliveryDate;

	public String getId() {
		return id;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public long getRefId() {
		return refId;
	}

	public String getOrderconfreference() {
		return orderconfreference;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public ZonedDateTime getCreatedDateTime() {
		return createdDateTime;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public String getStatus() {
		return status;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public ZonedDateTime getAcknowledgedDeliveryDate() {
		return acknowledgedDeliveryDate;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	public void setOrderconfreference(String orderconfreference) {
		this.orderconfreference = orderconfreference;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDateTime(ZonedDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public void setAcknowledgedDeliveryDate(ZonedDateTime acknowledgedDeliveryDate) {
		this.acknowledgedDeliveryDate = acknowledgedDeliveryDate;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

}
