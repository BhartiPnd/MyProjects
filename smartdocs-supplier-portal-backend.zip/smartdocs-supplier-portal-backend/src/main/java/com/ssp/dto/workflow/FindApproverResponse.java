package com.ssp.dto.workflow;

import java.util.Set;

public class FindApproverResponse {

	private Set<String> approvers;
	private boolean autoApproved;
	private String autoApprovedBy;
	public FindApproverResponse() {
		super();
		
	}
	public FindApproverResponse(Set<String> approvers, boolean autoApproved) {
		super();
		this.approvers = approvers;
		this.autoApproved = autoApproved;
	}
	public FindApproverResponse(Set<String> approvers, boolean autoApproved,String autoApprovedBy) {
		super();
		this.approvers = approvers;
		this.autoApproved=autoApproved;
		this.autoApprovedBy=autoApprovedBy;
	}
	public Set<String> getApprovers() {
		return approvers;
	}

	public void setApprovers(Set<String> approvers) {
		this.approvers = approvers;
	}

	public boolean isAutoApproved() {
		return autoApproved;
	}

	public void setAutoApproved(boolean autoApproved) {
		this.autoApproved = autoApproved;
	}
	public String getAutoApprovedBy() {
		return autoApprovedBy;
	}
	public void setAutoApprovedBy(String autoApprovedBy) {
		this.autoApprovedBy = autoApprovedBy;
	}
	
	
	
	
	
}
