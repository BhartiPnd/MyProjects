package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collections.workflow.config.BusinessRules;

public class BusinessRulesDTO  extends BusinessRules{

	private boolean isPassed;

	private boolean isAgentPassed;
	private boolean exceptionCleared;
	private ZonedDateTime time;
	private String notes;
 
	private boolean clearException;
	
	private List<String> data;
	
	public BusinessRulesDTO() {
		super();
	}
	public BusinessRulesDTO(BusinessRules  br) {
		super(br);
	}
	public boolean isPassed() {
		return isPassed;
	}
	public void setPassed(boolean isPassed) {
		this.isPassed = isPassed;
	}
	public boolean isExceptionCleared() {
		return exceptionCleared;
	}
	public void setExceptionCleared(boolean exceptionCleared) {
		this.exceptionCleared = exceptionCleared;
	}
	public boolean isAgentPassed() {
		return isAgentPassed;
	}
	public void setAgentPassed(boolean isAgentPassed) {
		this.isAgentPassed = isAgentPassed;
	}
	public String isNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public ZonedDateTime getTime() {
		return time;
	}
	public void setTime(ZonedDateTime time) {
		this.time = time;
	}
	public String getNotes() {
		return notes;
	}
	public boolean isClearException() {
		return clearException;
	}
	public void setClearException(boolean clearException) {
		this.clearException = clearException;
	}
	public List<String> getData() {
		return data;
	}
	public void setData(List<String> data) {
		this.data = data;
	}
	
	
}
