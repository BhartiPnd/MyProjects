package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.ProofOfDocument;

@Document(collection = "grr")
public class GRRTable {
	@Id
	private String id;
	private String grrReference;
	private long refId;
	private String systemid;
	private String ponumber;
	private Double amount;
	private String currency;
	private String companycode;
	private ZonedDateTime shipmentdate;
	private Address  remittoaddress;
	private  Address  shiptoaddress;
	private String statusDesc;
	
	private String status;
	private String notes;
	//private List<Item> items;

	private String requestId;
	private List<DocumentHelper> attachments;

	private ZonedDateTime createddatetime;
	private ZonedDateTime modifieddatetime;

	private String creator;
    private ZonedDateTime date;

	private Boolean isSAPSynch;
	private ZonedDateTime sapSynchDate;
	private Boolean isSAPSynchACK;

	private String supplierId;
	private String supplierName;
	private String customerActionStatus;
	
	private Boolean isPOD;
	private List<ProofOfDocument> proofOfDocuments;
	public String getId() {
		return id;
	}
	public String getSystemid() {
		return systemid;
	}
	public String getPonumber() {
		return ponumber;
	}
	public Double getAmount() {
		return amount;
	}
	public String getCurrency() {
		return currency;
	}
	public String getCompanycode() {
		return companycode;
	}
	public ZonedDateTime getShipmentdate() {
		return shipmentdate;
	}
	public Address getRemittoaddress() {
		return remittoaddress;
	}
	public Address getShiptoaddress() {
		return shiptoaddress;
	}
	public String getNotes() {
		return notes;
	}
	public String getRequestId() {
		return requestId;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public ZonedDateTime getCreateddatetime() {
		return createddatetime;
	}
	public ZonedDateTime getModifieddatetime() {
		return modifieddatetime;
	}
	public String getCreator() {
		return creator;
	}
	public ZonedDateTime getDate() {
		return date;
	}
	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}
	public ZonedDateTime getSapSynchDate() {
		return sapSynchDate;
	}
	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public Boolean getIsPOD() {
		return isPOD;
	}
	public List<ProofOfDocument> getProofOfDocuments() {
		return proofOfDocuments;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setSystemid(String systemid) {
		this.systemid = systemid;
	}
	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public void setShipmentdate(ZonedDateTime shipmentdate) {
		this.shipmentdate = shipmentdate;
	}
	public void setRemittoaddress(Address remittoaddress) {
		this.remittoaddress = remittoaddress;
	}
	public void setShiptoaddress(Address shiptoaddress) {
		this.shiptoaddress = shiptoaddress;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public void setCreateddatetime(ZonedDateTime createddatetime) {
		this.createddatetime = createddatetime;
	}
	public void setModifieddatetime(ZonedDateTime modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public void setDate(ZonedDateTime date) {
		this.date = date;
	}
	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}
	public void setSapSynchDate(ZonedDateTime sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}
	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public void setIsPOD(Boolean isPOD) {
		this.isPOD = isPOD;
	}
	public void setProofOfDocuments(List<ProofOfDocument> proofOfDocuments) {
		this.proofOfDocuments = proofOfDocuments;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getCustomerActionStatus() {
		return customerActionStatus;
	}
	public void setCustomerActionStatus(String customerActionStatus) {
		this.customerActionStatus = customerActionStatus;
	}
	public String getGrrReference() {
		return grrReference;
	}
	public void setGrrReference(String grrReference) {
		this.grrReference = grrReference;
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
