package com.ssp.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.CompanyEntitiy;
import com.ssp.mongo.collectionhelpers.Contact;
import com.ssp.mongo.collectionhelpers.DiverseBusinessClassifications;
import com.ssp.mongo.collectionhelpers.DiverseBusinessStatus;
import com.ssp.mongo.collectionhelpers.DocumentHelper;

@Document(collection = "supplier")
public class SupplierDto {
	
	@Id
	private String id;
	private String supplierId;
	private String name;
	private String dbaName;
	private String primaryEmail;	
	private String phone;
	private String phoneCntryCode;	
	private String phoneExtension;
	private String fax;
	private String faxCntryCode;
	private String ssnNo;
	private String empIdNo;
	private boolean  paymentBlock;
	private Address address;
	private String location;
	private String accountingGroup;
	private DiverseBusinessStatus diverseBusinessStatus;
	private List<CompanyEntitiy> companies;
	private String paymentTerms;
	private List<Contact> contacts;
	private List<DocumentHelper> documents;
	private List<String> productCategories;
	private List<DiverseBusinessClassifications>  diverseBusinessClassifications ;
	private boolean isDBVendor;
	private Long createddatetime;
	private Long modifieddatetime;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDbaName() {
		return dbaName;
	}
	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPhoneCntryCode() {
		return phoneCntryCode;
	}
	public void setPhoneCntryCode(String phoneCntryCode) {
		this.phoneCntryCode = phoneCntryCode;
	}
	public String getPhoneExtension() {
		return phoneExtension;
	}
	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getFaxCntryCode() {
		return faxCntryCode;
	}
	public void setFaxCntryCode(String faxCntryCode) {
		this.faxCntryCode = faxCntryCode;
	}
	public String getSsnNo() {
		return ssnNo;
	}
	public void setSsnNo(String ssnNo) {
		this.ssnNo = ssnNo;
	}
	public String getEmpIdNo() {
		return empIdNo;
	}
	public void setEmpIdNo(String empIdNo) {
		this.empIdNo = empIdNo;
	}
	public boolean isPaymentBlock() {
		return paymentBlock;
	}
	public void setPaymentBlock(boolean paymentBlock) {
		this.paymentBlock = paymentBlock;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAccountingGroup() {
		return accountingGroup;
	}
	public void setAccountingGroup(String accountingGroup) {
		this.accountingGroup = accountingGroup;
	}
	public DiverseBusinessStatus getDiverseBusinessStatus() {
		return diverseBusinessStatus;
	}
	public void setDiverseBusinessStatus(DiverseBusinessStatus diverseBusinessStatus) {
		this.diverseBusinessStatus = diverseBusinessStatus;
	}
	public List<CompanyEntitiy> getCompanies() {
		return companies;
	}
	public void setCompanies(List<CompanyEntitiy> companies) {
		this.companies = companies;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public List<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}
	public List<DocumentHelper> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentHelper> documents) {
		this.documents = documents;
	}
	public List<String> getProductCategories() {
		return productCategories;
	}
	public void setProductCategories(List<String> productCategories) {
		this.productCategories = productCategories;
	}
	public List<DiverseBusinessClassifications> getDiverseBusinessClassifications() {
		return diverseBusinessClassifications;
	}
	public void setDiverseBusinessClassifications(List<DiverseBusinessClassifications> diverseBusinessClassifications) {
		this.diverseBusinessClassifications = diverseBusinessClassifications;
	}
	public boolean isDBVendor() {
		return isDBVendor;
	}
	public void setDBVendor(boolean isDBVendor) {
		this.isDBVendor = isDBVendor;
	}
	public Long getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}
	public Long getModifieddatetime() {
		return modifieddatetime;
	}
	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}
	
	
}
