package com.ssp.dto;

import java.util.List;

public class EDIOrderConfirmationDTO {

	private String id;
	private String purchaseOrderNumber;
	private String companyCode;
	private long refId;
	private String orderconfreference;
	private String supplierId;
	private String createdBy;
	private List<EDIPOitmHelperDTO> items;
	private String createdDateTime;
	private String status;
	private String statusDesc;
	private String channel;
	private String comment;
	private Boolean isSAPSynch;
	private Long sapSynchDate;
	private Boolean isSAPSynchACK;
	private boolean deleted;
	private String poAcknowledgedDate;
	private String acknowledgedDeliveryDate;

	public EDIOrderConfirmationDTO() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public long getRefId() {
		return refId;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	public String getOrderconfreference() {
		return orderconfreference;
	}

	public void setOrderconfreference(String orderconfreference) {
		this.orderconfreference = orderconfreference;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<EDIPOitmHelperDTO> getItems() {
		return items;
	}

	public void setItems(List<EDIPOitmHelperDTO> items) {
		this.items = items;
	}

	public String getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Boolean getIsSAPSynch() {
		return isSAPSynch;
	}

	public void setIsSAPSynch(Boolean isSAPSynch) {
		this.isSAPSynch = isSAPSynch;
	}

	public Long getSapSynchDate() {
		return sapSynchDate;
	}

	public void setSapSynchDate(Long sapSynchDate) {
		this.sapSynchDate = sapSynchDate;
	}

	public Boolean getIsSAPSynchACK() {
		return isSAPSynchACK;
	}

	public void setIsSAPSynchACK(Boolean isSAPSynchACK) {
		this.isSAPSynchACK = isSAPSynchACK;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getPoAcknowledgedDate() {
		return poAcknowledgedDate;
	}

	public void setPoAcknowledgedDate(String poAcknowledgedDate) {
		this.poAcknowledgedDate = poAcknowledgedDate;
	}

	public String getAcknowledgedDeliveryDate() {
		return acknowledgedDeliveryDate;
	}

	public void setAcknowledgedDeliveryDate(String acknowledgedDeliveryDate) {
		this.acknowledgedDeliveryDate = acknowledgedDeliveryDate;
	}

}
