package com.ssp.dto;


public class VendorUserInvitationRequest {
	
	public static final String ACT_ADD_CONTACT="AddContact";
	public static final String ACT_DELETE="Delete"; 
 
	private String action;
	private String requestId;
	String comment;
	private String supplierId;
	
	public String getAction() {
		return action;
	}
	public String getRequestId() {
		return requestId;
	}
	 
	public void setAction(String action) {
		this.action = action;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	 
	
}
