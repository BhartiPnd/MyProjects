package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.GIReceiver;
import com.ssp.mongo.collectionhelpers.GeneralState;

public class CreateGoodsIssue {

	private String id;
	private String requestId;	
	private String title;		
	private String description;
	private String companyCode;
	private String companyName;
	private String purchasingOrg;
	private String purchasingGroup;
	private String paymentTerms;
	private String type;
	private List<GIReceiver> receivers;
	private Double totalAmount;
	private String currency;
	private String supplierId;
	private String plant;
	private String storageLocaion;
	private List<DocumentHelper> attachments;
	private String notes;
	private List<CreateGIRLineItems> requestItems;
	
	private String activityCode;
	private String requestorEmail;
	private String requestorName;
	private String action;
	private String collaboratedUser;
	private String signature;
	private String signedByEmail;
	private String signedByUserName;
	private String signedPersonRole;
	private String initatorEmail;
	private ZonedDateTime createdDate;
	private String createdBy;
	private String initator;
	private String status;
	private String agentName;
	private String channel;
	private GeneralState state;
	private ZonedDateTime deliveryDate;
	private String receiverEmail;
	private String receiverName;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	 
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getStorageLocaion() {
		return storageLocaion;
	}
	public void setStorageLocaion(String storageLocaion) {
		this.storageLocaion = storageLocaion;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public List<CreateGIRLineItems> getRequestItems() {
		return requestItems;
	}
	public void setRequestItems(List<CreateGIRLineItems> requestItems) {
		this.requestItems = requestItems;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/*public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}*/
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCollaboratedUser() {
		return collaboratedUser;
	}
	public void setCollaboratedUser(String collaboratedUser) {
		this.collaboratedUser = collaboratedUser;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getSignedByEmail() {
		return signedByEmail;
	}
	public void setSignedByEmail(String signedByEmail) {
		this.signedByEmail = signedByEmail;
	}
	public String getSignedByUserName() {
		return signedByUserName;
	}
	public void setSignedByUserName(String signedByUserName) {
		this.signedByUserName = signedByUserName;
	}
	public String getSignedPersonRole() {
		return signedPersonRole;
	}
	public void setSignedPersonRole(String signedPersonRole) {
		this.signedPersonRole = signedPersonRole;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public GeneralState getState() {
		return state;
	}
	public void setState(GeneralState state) {
		this.state = state;
	}
	public String getInitatorEmail() {
		return initatorEmail;
	}
	public void setInitatorEmail(String initatorEmail) {
		this.initatorEmail = initatorEmail;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getInitator() {
		return initator;
	}
	public void setInitator(String initator) {
		this.initator = initator;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequestorName() {
		return requestorName;
	}
	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public ZonedDateTime getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(ZonedDateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public List<GIReceiver> getReceivers() {
		return receivers;
	}
	public void setReceivers(List<GIReceiver> receivers) {
		this.receivers = receivers;
	}
	public String getReceiverEmail() {
		return receiverEmail;
	}
	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	
	
	
}
