package com.ssp.dto;

import java.util.List;

public class PurchaseInfoRecordMaterialDTO {
	
	private String materialCode;
	private String materialName;
	private String materialGrp;
	private List<PurcahseInfoRecordSupplierDTO> purcahseInfoRecordSupplierDTOs;
	
	
	
	
	
	
	
	public PurchaseInfoRecordMaterialDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	public PurchaseInfoRecordMaterialDTO(String materialCode, String materialName, String materialGrp,
			List<PurcahseInfoRecordSupplierDTO> purcahseInfoRecordSupplierDTOs) {
		super();
		this.materialCode = materialCode;
		this.materialName = materialName;
		this.materialGrp = materialGrp;
		this.purcahseInfoRecordSupplierDTOs = purcahseInfoRecordSupplierDTOs;
	}





	public String getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}
	public String getMaterialName() {
		return materialName;
	}
	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}
	public String getMaterialGrp() {
		return materialGrp;
	}
	public void setMaterialGrp(String materialGrp) {
		this.materialGrp = materialGrp;
	}
	public List<PurcahseInfoRecordSupplierDTO> getPurcahseInfoRecordSupplierDTOs() {
		return purcahseInfoRecordSupplierDTOs;
	}
	public void setPurcahseInfoRecordSupplierDTOs(List<PurcahseInfoRecordSupplierDTO> purcahseInfoRecordSupplierDTOs) {
		this.purcahseInfoRecordSupplierDTOs = purcahseInfoRecordSupplierDTOs;
	}

	
	
}
