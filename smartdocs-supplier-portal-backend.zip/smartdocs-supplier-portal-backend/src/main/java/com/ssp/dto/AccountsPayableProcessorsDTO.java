package com.ssp.dto;

public class AccountsPayableProcessorsDTO {

}
