package com.ssp.dto;

import com.ssp.mongo.collections.PurchaseOrder;
import com.ssp.mongo.collections.dataObject.CadsModel;
import com.ssp.mongo.collections.workflow.WorkItem;

public class InvoiceInboxDetail {
		
	private InvoiceDetail invoice;
	private PurchaseOrder purchaseOrder;
	private WorkItem workItem;
	private CadsModel cadModel;  
	private boolean myInbox;
	public InvoiceInboxDetail() {
		super();
	}
	public InvoiceInboxDetail(InvoiceDetail invoice, PurchaseOrder purchaseOrder,WorkItem workItem) {
		super();
		this.invoice = invoice;
		this.purchaseOrder = purchaseOrder;
		this.workItem=workItem;
	}
	public InvoiceInboxDetail(InvoiceDetail invoice, PurchaseOrder purchaseOrder,WorkItem workItem,CadsModel cadModel,boolean myInbox) {
		super();
		this.invoice = invoice;
		this.purchaseOrder = purchaseOrder;
		this.workItem=workItem;
		this.cadModel=cadModel;
		this.myInbox=myInbox;
	}
	public InvoiceInboxDetail(InvoiceDetail invoice, PurchaseOrder purchaseOrder,WorkItem workItem,CadsModel cadModel) {
		super();
		this.invoice = invoice;
		this.purchaseOrder = purchaseOrder;
		this.workItem=workItem;
		this.cadModel=cadModel;
		 
	}
	public InvoiceDetail getInvoice() {
		return invoice;
	}
	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}
	public void setInvoice(InvoiceDetail invoice) {
		this.invoice = invoice;
	}
	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public CadsModel getCadModel() {
		return cadModel;
	}
	public void setCadModel(CadsModel cadModel) {
		this.cadModel = cadModel;
	}
	public boolean isMyInbox() {
		return myInbox;
	}
	public void setMyInbox(boolean myInbox) {
		this.myInbox = myInbox;
	}
	 
	 
	
	
	
	
}
