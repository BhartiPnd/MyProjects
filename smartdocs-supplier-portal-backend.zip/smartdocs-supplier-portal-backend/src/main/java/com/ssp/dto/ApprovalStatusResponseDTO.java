package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.LogUser;

public class ApprovalStatusResponseDTO {

	
	private List<LogUser> currentApprovers;
	private String status;
	private String detail;
	private int totlaApprovelLevel;
	private int levelCompleted;
	private boolean approvealPermission;
	private String errorMessage;
	
	
	public List<LogUser> getCurrentApprovers() {
		return currentApprovers;
	}
	public void setCurrentApprovers(List<LogUser> currentApprovers) {
		this.currentApprovers = currentApprovers;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public int getTotlaApprovelLevel() {
		return totlaApprovelLevel;
	}
	public void setTotlaApprovelLevel(int totlaApprovelLevel) {
		this.totlaApprovelLevel = totlaApprovelLevel;
	}
	public int getLevelCompleted() {
		return levelCompleted;
	}
	public void setLevelCompleted(int levelCompleted) {
		this.levelCompleted = levelCompleted;
	}
	public boolean isApprovealPermission() {
		return approvealPermission;
	}
	public void setApprovealPermission(boolean approvealPermission) {
		this.approvealPermission = approvealPermission;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
}
