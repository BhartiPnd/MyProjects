package com.ssp.dto.smartbuy;

import com.ssp.mongo.collections.bidsheet.BidSheetRequest;
import com.ssp.mongo.collections.workflow.WorkItem;
import com.ssp.mongo.util.JsonResponse;

public class BidSheetRequestInboxDetail {
	
	private BidSheetRequest bidSheet;
	private WorkItem workItem;
	private String status;
	private String error;
	
	public BidSheetRequestInboxDetail() {
		super();
		this.status = JsonResponse.RESULT_SUCCESS;
	}
	
	public BidSheetRequest getBidSheet() {
		return bidSheet;
	}
	public void setBidSheet(BidSheetRequest bidSheet) {
		this.bidSheet = bidSheet;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
