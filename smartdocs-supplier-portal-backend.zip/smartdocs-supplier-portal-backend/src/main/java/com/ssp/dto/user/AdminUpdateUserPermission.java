package com.ssp.dto.user;

public class AdminUpdateUserPermission {

	private String email;
	private String permission;
	private boolean enable;

	public String getEmail() {
		return email;
	}

	public String getPermission() {
		return permission;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

}
