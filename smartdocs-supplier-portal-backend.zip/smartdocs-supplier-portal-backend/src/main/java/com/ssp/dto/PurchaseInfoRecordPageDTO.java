package com.ssp.dto;

import com.ssp.mongo.collections.pir.PurchaseInfoRecord;

public class PurchaseInfoRecordPageDTO {
	private PurchaseInfoRecord purchaseInfoRecord;
	private String materialName;
	private String materialGroup;
	private String itemCategory;
	private String supplierName;
	private Double movingPrice;
	
	
	
	
	
	
	
	
	
	
	public PurchaseInfoRecordPageDTO() {
	
	}
//	public PurchaseInfoRecordPageDTO(PurchaseInfoRecord purchaseInfoRecord ,String materialName,String materialGrooup,String itemCategory,String suppliername,Double movingPrice) {
//		
//	}
	
	
	
	
	
	
	public PurchaseInfoRecord getPurchaseInfoRecord() {
		return purchaseInfoRecord;
	}
	
	public PurchaseInfoRecordPageDTO(PurchaseInfoRecord purchaseInfoRecord, String materialName, String materialGroup,
		String itemCategory, String supplierName, Double movingPrice) {
	super();
	this.purchaseInfoRecord = purchaseInfoRecord;
	this.materialName = materialName;
	this.materialGroup = materialGroup;
	this.itemCategory = itemCategory;
	this.supplierName = supplierName;
	this.movingPrice = movingPrice;
}
	public void setPurchaseInfoRecord(PurchaseInfoRecord purchaseInfoRecord) {
		this.purchaseInfoRecord = purchaseInfoRecord;
	}
	public String getMaterialName() {
		return materialName;
	}
	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public String getItemCategory() {
		return itemCategory;
	}
	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public Double getMovingPrice() {
		return movingPrice;
	}
	public void setMovingPrice(Double movingPrice) {
		this.movingPrice = movingPrice;
	}
	
	
	

}
