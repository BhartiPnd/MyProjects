package com.ssp.dto;

import java.util.List;
import java.util.Map;

import com.ssp.mongo.collections.dataObject.MaterialMaster;


public class PriceComparision {

	private List<MaterialMaster> materialMasters;
	private List<SupplierDto> suppliers;
	private List<Map<String,SupplierPIR>> priceComparisionInfos;
	
	public List<MaterialMaster> getMaterialMasters() {
		return materialMasters;
	}
	
	public void setMaterialMasters(List<MaterialMaster> materialMasters) {
		this.materialMasters = materialMasters;
	}
	
	public PriceComparision() {
		super();
	}
	
	public List<SupplierDto> getSuppliers() {
		return suppliers;
	}
	
	public void setSuppliers(List<SupplierDto> suppliers) {
		this.suppliers = suppliers;
	}
	
	public List<Map<String,SupplierPIR>> getPriceComparisionInfos() {
		return priceComparisionInfos;
	}
	
	public void setPriceComparisionInfos(List<Map<String,SupplierPIR>> priceComparisionInfos) {
		this.priceComparisionInfos = priceComparisionInfos;
	}
	
	public PriceComparision(List<MaterialMaster> materialMasters, List<SupplierDto> suppliers,
			List<Map<String,SupplierPIR>> priceComparisionInfos) {
		super();
		this.materialMasters = materialMasters;
		this.suppliers = suppliers;
		this.priceComparisionInfos = priceComparisionInfos;
	}
	
}
