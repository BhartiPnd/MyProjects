package com.ssp.dto.rfx;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.rfx.RFXBidder;
import com.ssp.mongo.collections.rfx.RFXItems;
import com.ssp.mongo.collections.rfx.RequiredDocumentType;
import com.ssp.mongo.collections.rfx.RequiredInfo;

public class RfxView {
	
	private String id;
	private String title;
	private String companyCode;
	private String companyName;
	private String rfxNo;
	private String type;
	
	private String visibility;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	
	private String purchasingOrg;
	private String purchasingOrgDesc;
	
	private String requestorEmail;
	private String requestorName;
	
	private String buyerEmail;
	private String buyerName;
	private boolean isOwner;
	

	private List<RFXItems> items;
	private List<RFXBidder> bidders;
	private List<RequiredDocumentType> requiredDocuments;
	private List<RequiredInfo> requiredInfo;
	
//	from when vendor can submit their bid
	private ZonedDateTime submissionStartDate;
	
//	till when vendor can submit their bid
	private ZonedDateTime submissionEndDate;
	
//	till when vendor can ask question
	private ZonedDateTime qAndADeadline;
	
//	when rfx published
	private ZonedDateTime publishedDate;
	
	private String status;

	private List<DocumentHelper> attachments;
	private boolean isErpSynch;
	private Long erpSynchDate;
	private boolean isErpSynchAck;
	private boolean syncToERP;
	
	private String createdBy;
	private ZonedDateTime createdDate;
	private String lastModifiedBy;
	private ZonedDateTime lastModifiedDate;
	
	private int questionSequenceNo;
	private boolean canBid;
	
	
	private String bidSelected;
	private String selectedBidId;
	
	private boolean isTeamMember;
	private boolean canQanda;
	private boolean canEdit;
	private boolean canRevoke;
	private boolean canEvaluate;
	
	public String getRfxNo() {
		return rfxNo;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

	public String getPurchasingOrg() {
		return purchasingOrg;
	}
	

	public boolean isOwner() {
		return isOwner;
	}

	public void setOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}

	public void setPurchasingOrg(String purchasingOrg) {
		this.purchasingOrg = purchasingOrg;
	}

	public String getPurchasingOrgDesc() {
		return purchasingOrgDesc;
	}

	public void setPurchasingOrgDesc(String purchasingOrgDesc) {
		this.purchasingOrgDesc = purchasingOrgDesc;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public List<RFXItems> getItems() {
		return items;
	}

	public void setItems(List<RFXItems> items) {
		this.items = items;
	}

	public List<RFXBidder> getBidders() {
		return bidders;
	}

	public void setBidders(List<RFXBidder> bidders) {
		this.bidders = bidders;
	}

	public List<RequiredDocumentType> getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(List<RequiredDocumentType> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public List<RequiredInfo> getRequiredInfo() {
		return requiredInfo;
	}

	public void setRequiredInfo(List<RequiredInfo> requiredInfo) {
		this.requiredInfo = requiredInfo;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public boolean isErpSynch() {
		return isErpSynch;
	}

	public void setErpSynch(boolean isErpSynch) {
		this.isErpSynch = isErpSynch;
	}

	public Long getErpSynchDate() {
		return erpSynchDate;
	}

	public void setErpSynchDate(Long erpSynchDate) {
		this.erpSynchDate = erpSynchDate;
	}

	public boolean isErpSynchAck() {
		return isErpSynchAck;
	}

	public void setErpSynchAck(boolean isErpSynchAck) {
		this.isErpSynchAck = isErpSynchAck;
	}

	public boolean isSyncToERP() {
		return syncToERP;
	}

	public void setSyncToERP(boolean syncToERP) {
		this.syncToERP = syncToERP;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public ZonedDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(ZonedDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getQuestionSequenceNo() {
		return questionSequenceNo;
	}

	public void setQuestionSequenceNo(int questionSequenceNo) {
		this.questionSequenceNo = questionSequenceNo;
	}

	public boolean isCanBid() {
		return canBid;
	}

	public void setCanBid(boolean canBid) {
		this.canBid = canBid;
	}
	

	public boolean isCanQanda() {
		return canQanda;
	}

	public void setCanQanda(boolean canQanda) {
		this.canQanda = canQanda;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBidSelected() {
		return bidSelected;
	}

	public void setBidSelected(String bidSelected) {
		this.bidSelected = bidSelected;
	}

	public String getSelectedBidId() {
		return selectedBidId;
	}

	public void setSelectedBidId(String selectedBidId) {
		this.selectedBidId = selectedBidId;
	}

	public boolean isTeamMember() {
		return isTeamMember;
	}

	public void setTeamMember(boolean isTeamMember) {
		this.isTeamMember = isTeamMember;
	}

	public boolean isCanEdit() {
		return canEdit;
	}

	public void setCanEdit(boolean canEdit) {
		this.canEdit = canEdit;
	}

	public boolean isCanRevoke() {
		return canRevoke;
	}

	public void setCanRevoke(boolean canRevoke) {
		this.canRevoke = canRevoke;
	}

	public boolean isCanEvaluate() {
		return canEvaluate;
	}

	public void setCanEvaluate(boolean canEvaluate) {
		this.canEvaluate = canEvaluate;
	}

	
}
