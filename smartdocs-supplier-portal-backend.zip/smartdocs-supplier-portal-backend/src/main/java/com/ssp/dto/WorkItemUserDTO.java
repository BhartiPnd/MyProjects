package com.ssp.dto;

import com.ssp.mongo.collections.workflow.WorkItemUser;

public class WorkItemUserDTO {
	
	private WorkItemUser workItemUser;
	private boolean isSubstitute;
	
	public WorkItemUserDTO() {
		
	}
	public WorkItemUserDTO(WorkItemUser workItemUser, boolean isSubstitute) {
		super();
		this.workItemUser = workItemUser;
		this.isSubstitute = isSubstitute;
	}
	public WorkItemUser getWorkItemUser() {
		return workItemUser;
	}
	public boolean isSubstitute() {
		return isSubstitute;
	}
	public void setWorkItemUser(WorkItemUser workItemUser) {
		this.workItemUser = workItemUser;
	}
	public void setSubstitute(boolean isSubstitute) {
		this.isSubstitute = isSubstitute;
	}
		
		
}
