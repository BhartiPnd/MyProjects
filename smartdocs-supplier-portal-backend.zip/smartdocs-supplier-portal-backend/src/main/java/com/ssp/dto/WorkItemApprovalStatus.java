package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.ssp.mongo.collectionhelpers.ActivityLog;

public class WorkItemApprovalStatus {

	private String status;
	private String statusDesc;
	private String collaboratedBy;
	private List<String> approvers;
	private ZonedDateTime assignedDateTime;
	
	private List<ActivityLog> activityLogs;
	
	public String getStatus() {
		return status;
	}
	public String getCollaboratedBy() {
		return collaboratedBy;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setCollaboratedBy(String collaboratedBy) {
		this.collaboratedBy = collaboratedBy;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	public ZonedDateTime getAssignedDateTime() {
		return assignedDateTime;
	}
	public void setAssignedDateTime(ZonedDateTime assignedDateTime) {
		this.assignedDateTime = assignedDateTime;
	}
	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}
	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
}
