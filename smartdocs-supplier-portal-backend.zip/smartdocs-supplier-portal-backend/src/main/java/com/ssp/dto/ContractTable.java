package com.ssp.dto;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.ssp.mongo.collections.diversitySpend.LatestDBSubmission;

@Document(collection = "Contract")
public class ContractTable {
	
	@Id
	private String id;

	private String number;
	private String name;
	
	// central or parent
	private String type;
	
	// this field used for SB Submission. PS and Constrcution. 
	private String contractType;
	private String owner;
	
	private String supplierId;
	private String supplierName;
	// who the primary Supplier or Primary Contractor is .
	
	private String description;
	private String status;
	
	@Field("startDate")
	private ZonedDateTime startDate;
	@Field("endDate")
	private ZonedDateTime endDate;
	
	
	@Field("createdDate")
	private ZonedDateTime createdDate;
	
	private String createdBy;
	
	private String purchasingOrganization;
	private String purchasingGroup;
	private String paymentTerms;
	
	private LatestDBSubmission dbSubmission;
	
	private ZonedDateTime latestDBSubmissionDate;
	//private List<ContractLineItems> contractLineItems;
	//private List<DocumentHelper> attachments;
	
	//Contract Amount
	private Double targetValue;
	
	// Contract Amount Paid Till Date 
	private Double amountPaidTillDate;
	
	//Released Value
	private Double relValue;
	private String currency;

		
	private Float dbGoalPercent;
	private Double dbGoalAmount;

	private String purchasingGroupDesc;
	
	//	private double dbConsumed;
	
	// private double totalCommitedAmount;
	/*
	private double totalDBAmountPaidtillDate;
	
	//% of DB in relation to contracts
	private double dbGoalAchivedPercent;
	
	//% of DB amount in relation to Amount paid to Prime vendor
	private double dbPercentOfAmountPaidtoPrimeVendor;
	
	
	// construction.
	private double totalCommitedAmount=0.0;
	private double totalEarnedTillDate=0.0;
	private double totalPaidTillDate=0.0;
	private boolean finalReport;
	private String latestDBReportId;*/
	 

	public String getId() {
		return id;
	}


	public String getNumber() {
		return number;
	}


	public String getName() {
		return name;
	}


	public String getType() {
		return type;
	}


	public String getOwner() {
		return owner;
	}


	public String getSupplierId() {
		return supplierId;
	}


	public String getDescription() {
		return description;
	}


	public String getStatus() {
		return status;
	}
	public ZonedDateTime getStartDate() {
		return startDate;
	}
	public ZonedDateTime getEndDate() {
		return endDate;
	}
	public Double getTargetValue() {
		return targetValue;
	}
	public Double getRelValue() {
		return relValue;
	}
	public String getCurrency() {
		return currency;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public String getPurchasingOrganization() {
		return purchasingOrganization;
	}
	public String getPurchasingGroup() {
		return purchasingGroup;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}
	public void setTargetValue(Double targetValue) {
		this.targetValue = targetValue;
	}
	public void setRelValue(Double relValue) {
		this.relValue = relValue;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setPurchasingOrganization(String purchasingOrganization) {
		this.purchasingOrganization = purchasingOrganization;
	}
	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public Float getDbGoalPercent() {
		return dbGoalPercent;
	}
	public Double getDbGoalAmount() {
		return dbGoalAmount;
	}
	public Double getAmountPaidTillDate() {
		return amountPaidTillDate;
	}
	public void setDbGoalPercent(Float dbGoalPercent) {
		this.dbGoalPercent = dbGoalPercent;
	}
	public void setDbGoalAmount(Double dbGoalAmount) {
		this.dbGoalAmount = dbGoalAmount;
	}
	public void setAmountPaidTillDate(Double amountPaidTillDate) {
		this.amountPaidTillDate = amountPaidTillDate;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public ZonedDateTime getLatestDBSubmissionDate() {
		return latestDBSubmissionDate;
	}
	public void setLatestDBSubmissionDate(ZonedDateTime latestDBSubmissionDate) {
		this.latestDBSubmissionDate = latestDBSubmissionDate;
	}


	public LatestDBSubmission getDbSubmission() {
		return dbSubmission;
	}
	public void setDbSubmission(LatestDBSubmission dbSubmission) {
		this.dbSubmission = dbSubmission;
	}


	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}


	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}
	
	
}
