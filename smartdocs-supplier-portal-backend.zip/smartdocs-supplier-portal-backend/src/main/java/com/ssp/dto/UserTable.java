package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.annotation.Id;

import com.ssp.mongo.collectionhelpers.CustomRoles;

public class UserTable {

	@Id
	private String id;
	private String email;
	private String firstname;
	private String lastname;
	private String mobile;
	private String location;
	private String language;
	private String timezone;
	private String dateformate;
	private String dateAndTimeFormate;
	private String decimalformate;
	private String currency;

	private String supplier;
	private String supplierId;
	private String role;
	private String companycode;
	private String azureId;

	private String pic;
	 
	private Long createddatetime;
	private Long modifieddatetime;
 

	private int invalidPasswordAttempts;
	 
	private String profileId;

	// this is for company users only. for RBAC model.
	private List<String> authPermissionGroups;
	// private List<Permission> permissions;

	private List<CustomRoles> userRoles;
	
	private ZonedDateTime passwordExpiry;
	private ZonedDateTime lastLogin;
	private ZonedDateTime lastActivity;
	private boolean isEmailEnabled;
 
	
	 
	 
	
	public UserTable() {
		super();
	}

 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if(StringUtils.isNotBlank(email)) {
			this.email=email.toLowerCase().trim();
		}
		else{
			this.email = email;
		}
	}

	 

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getDateformate() {
		return dateformate;
	}

	public void setDateformate(String dateformate) {
		this.dateformate = dateformate;
	}

	public String getDecimalformate() {
		return decimalformate;
	}

	public void setDecimalformate(String decimalformate) {
		this.decimalformate = decimalformate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
 
	public String getAzureId() {
		return azureId;
	}

	public void setAzureId(String azureId) {
		this.azureId = azureId;
	}

	 

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public ZonedDateTime getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(ZonedDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public List<String> getAuthPermissionGroups() {
		return authPermissionGroups;
	}

	public void setAuthPermissionGroups(List<String> authPermissionGroups) {
		this.authPermissionGroups = authPermissionGroups;
	}

	 
	public List<CustomRoles> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<CustomRoles> userRoles) {
		this.userRoles = userRoles;
	}

	public boolean isEmailEnabled() {
		return isEmailEnabled;
	}

	public void setEmailEnabled(boolean isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}
 

	public String getDateAndTimeFormate() {
		return dateAndTimeFormate;
	}

	public void setDateAndTimeFormate(String dateAndTimeFormate) {
		this.dateAndTimeFormate = dateAndTimeFormate;
	}
	public ZonedDateTime getPasswordExpiry() {
		return passwordExpiry;
	}

	public void setPasswordExpiry(ZonedDateTime passwordExpiry) {
		this.passwordExpiry = passwordExpiry;
	}
	public String getName() {
		return this.getFirstname()+" "+this.getLastname();
	}

	public int getInvalidPasswordAttempts() {
		return invalidPasswordAttempts;
	}

	public void setInvalidPasswordAttempts(int invalidPasswordAttempts) {
		this.invalidPasswordAttempts = invalidPasswordAttempts;
	}
	public void addInvalidPasswordAttempt() {
		invalidPasswordAttempts=invalidPasswordAttempts+1;
	}

/*	public String getMobileAccess() {
		return mobileAccess;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setMobileAccess(String mobileAccess) {
		this.mobileAccess = mobileAccess;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}*/


	public ZonedDateTime getLastActivity() {
		return lastActivity;
	}


	public void setLastActivity(ZonedDateTime lastActivity) {
		this.lastActivity = lastActivity;
	}
	
	
}
