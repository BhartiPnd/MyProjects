package com.ssp.dto;


import java.util.List;
import java.util.Map;

import com.ssp.mongo.collectionhelpers.AchRequest;
import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.Contact;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collectionhelpers.OtherChangeRequest;
import com.ssp.mongo.collectionhelpers.ProductCategoriesChangeRequest;
import com.ssp.mongo.collectionhelpers.TaxAndW9Change;
import com.ssp.mongo.collections.list.GeneralList;
import com.ssp.mongo.collections.requests.BankDetailChange;
import com.ssp.mongo.collections.requests.VendorChangeRequest;

public class VendorChangeRequestDTO {
	private String id;
	private String prefix; 
	private long refId;
	
	private String type; 
	
	private String supplierId;
	private String status;
	 
	private String createdUserId;
	private String createdUserName;
	
	private String companyCode;
	private Long createddatetime;
	private Long modifieddatetime;
	private Long lastUpdated;

	private List<DocumentHelper> attachments;

	private String action;
	// if address Change Request.
	private Address address;
	private Contact contact;
	private BankDetailChange bankDetailChange;
	
	private AchRequest achRequest;
	private DBChangeRequestDTO dbeChangeRequest; 
	private ProductCategoriesChangeRequest pccr; 
	private OtherChangeRequest other;
	private  TaxAndW9Change taxAndW9;
	private List<ActivityLog> activityLogs;
	private String paymentsTerms;
	private String requestorEmail;
	private String statusDesc;
	//private boolean isCollaborated;
	//private String collaboratedUser;
	
	public VendorChangeRequestDTO() {
		super();
	}
	public VendorChangeRequestDTO(VendorChangeRequest vcr, Map<String,GeneralList> dbList) {
		super();
		this.id=vcr.getId();
		this.refId=vcr.getRefId();
		this.action = vcr.getAction();
		this.type=vcr.getType(); 
		this.companyCode = vcr.getCompanyCode();
		this.supplierId=vcr.getSupplierId();
		this.status=vcr.getStatus();
		 
		this.createdUserId=vcr.getCreatedUserId();
		this.createdUserName=vcr.getCreatedUserName();
		this.requestorEmail=vcr.getRequestorEmail();
		//DiverseBusinessUpdate
		this.createddatetime=vcr.getCreateddatetime();
		this.modifieddatetime=vcr.getModifieddatetime();
		this.lastUpdated=vcr.getLastUpdated();
		
		this.attachments=vcr.getAttachments();

		//this.action=vcr.getAction()''
		// if address Change Request.
		if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CHANGE_ADDRESS)) {
			this.address=vcr.getAddress();
		}
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CONTACT)) {
			this.contact=vcr.getContact();
		}
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CHANGE_TAXANDW9)) {
			this.taxAndW9=vcr.getTaxAndW9();
		}
		
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CHANGE_ACH)) {
			this.achRequest=vcr.getAchRequest();
		} 
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CHANGE_DBE)) {
			//this.achRequest=vcr.getAchRequest();
			if(vcr.getDbeChangeRequest()!=null) {
				this.dbeChangeRequest=new DBChangeRequestDTO(vcr.getDbeChangeRequest(),dbList);
			}
		} 
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.CHANGE_PRODUCT_CATEGORY)) {
			this.pccr=vcr.getPccr();
		} 
		
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.OTHER)) {
			this.other=vcr.getOther();
		} 
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.BANK_DETAIl_CHANGE)) {
			this.bankDetailChange=vcr.getBankDetailChange();
		} 
		else if(vcr.getType().equalsIgnoreCase(VendorChangeRequest.PAYMENT_TERMS_CHANGE)) {
			this.paymentsTerms=vcr.getPaymentsTerms();
		} 
		
		
		this.activityLogs=vcr.getActivityLogs();
		this.statusDesc=vcr.getStatusDesc();
		//this.isCollaborated=vcr.isCollaborated();
		//this.collaboratedUser=vcr.getCollaboratedUser();
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	 
	public String getSupplierId() {
		return supplierId;
	}
	
	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Long createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Long getModifieddatetime() {
		return modifieddatetime;
	}

	public void setModifieddatetime(Long modifieddatetime) {
		this.modifieddatetime = modifieddatetime;
	}

	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}


	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public Long getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Long lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	public AchRequest getAchRequest() {
		return achRequest;
	}

	public void setAchRequest(AchRequest achRequest) {
		this.achRequest = achRequest;
	}

	 


	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public long getRefId() {
		return refId;
	}

	public void setRefId(long refId) {
		this.refId = refId;
	}

	 
	 

	public DBChangeRequestDTO getDbeChangeRequest() {
		return dbeChangeRequest;
	}

	public void setDbeChangeRequest(DBChangeRequestDTO dbeChangeRequest) {
		this.dbeChangeRequest = dbeChangeRequest;
	}

	public ProductCategoriesChangeRequest getPccr() {
		return pccr;
	}

	public void setPccr(ProductCategoriesChangeRequest pccr) {
		this.pccr = pccr;
	}


	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public TaxAndW9Change getTaxAndW9() {
		return taxAndW9;
	}
	public void setTaxAndW9(TaxAndW9Change taxAndW9) {
		this.taxAndW9 = taxAndW9;
	}
	public OtherChangeRequest getOther() {
		return other;
	}
	public void setOther(OtherChangeRequest other) {
		this.other = other;
	}
	public BankDetailChange getBankDetailChange() {
		return bankDetailChange;
	}
	public void setBankDetailChange(BankDetailChange bankDetailChange) {
		this.bankDetailChange = bankDetailChange;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getPaymentsTerms() {
		return paymentsTerms;
	}
	public void setPaymentsTerms(String paymentsTerms) {
		this.paymentsTerms = paymentsTerms;
	}
	public String getRequestorEmail() {
		return requestorEmail;
	}
	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}
	
}
