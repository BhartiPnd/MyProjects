package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collections.pir.PurchaseInfoRecord;

public class PurchaseInforRecordDTO {
	
	
	private List<String> materialCode;
	private List<String> supplierId;
	
	
	
	
	
	
	
	
	public List<String> getMaterialCode() {
		return materialCode;
	}
	public void setMaterialCode(List<String> materialCode) {
		this.materialCode = materialCode;
	}
	public List<String> getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(List<String> supplierId) {
		this.supplierId = supplierId;
	}
	
	
	
	

}
