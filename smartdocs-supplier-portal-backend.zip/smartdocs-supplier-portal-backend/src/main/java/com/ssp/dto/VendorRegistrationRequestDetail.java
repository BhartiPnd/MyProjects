package com.ssp.dto;

import com.ssp.mongo.collections.requests.VendorRegistrationRequest;
import com.ssp.mongo.collections.workflow.WorkItem;

public class VendorRegistrationRequestDetail {

	
	private VendorRegistrationRequest vendorRegistrationRequest;
	private WorkItem workItem;
	 
	public VendorRegistrationRequest getVendorRegistrationRequest() {
		return vendorRegistrationRequest;
	}
	public void setVendorRegistrationRequest(VendorRegistrationRequest vendorRegistrationRequest) {
		this.vendorRegistrationRequest = vendorRegistrationRequest;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
}
