package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.DocumentHelper;
import com.ssp.mongo.collections.diversitySpend.Tier2Submission;

@Document(collection = "DBSubmission")
public class DBSubmissionResponse {

	
	@Id
	private String id;

	private String requestId;
	
	private String contractId;
	private String contractName;
	
	private ZonedDateTime startDate;
	private ZonedDateTime endDate;
	
	private String year;
	private String month;
	
	private String primeVendorId;
	private String primeVendorName;
	
	private String submissionType;
	
	private String title;
	private boolean isFinalReport;
	private double contractAmountPaidToDate;
	
	private Double contractAmountPaidTillDate;
	
	private ZonedDateTime submissionDate;
	
	private double totalDBAmount;
	private String currency;
	
	// some calculated fields start 
	private double totalDBAmountPaidtillDate;
	//% of DB in relation to contracts
	private double dbGoalAchivedPercent;
		//% of DB amount in relation to Amount paid to Prime vendor
	private double percentOfDBAmountPiad;
	// calculated field end
	
	// construction.
	private double totalCommitedAmount=0.0;
	private double totalEarnedTillDate=0.0;
	private double totalPaidTillDate=0.0;
	
	private List<Tier2Submission> list;
	private String submittedBy;
	private String submittedByName;
	private String comment;
	private List<DocumentHelper> attachments;
	private ZonedDateTime reportDate;
	
	public String getId() {
		return id;
	}
	public String getRequestId() {
		return requestId;
	}
	public String getContractId() {
		return contractId;
	}
	public String getContractName() {
		return contractName;
	}
	public ZonedDateTime getStartDate() {
		return startDate;
	}
	public ZonedDateTime getEndDate() {
		return endDate;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public String getPrimeVendorId() {
		return primeVendorId;
	}
	public String getPrimeVendorName() {
		return primeVendorName;
	}
	public String getSubmissionType() {
		return submissionType;
	}
	public String getTitle() {
		return title;
	}
	public boolean isFinalReport() {
		return isFinalReport;
	}
	public Double getContractAmountPaidTillDate() {
		return contractAmountPaidTillDate;
	}
	public ZonedDateTime getSubmissionDate() {
		return submissionDate;
	}
	public double getTotalDBAmount() {
		return totalDBAmount;
	}
	public String getCurrency() {
		return currency;
	}
	public double getTotalDBAmountPaidtillDate() {
		return totalDBAmountPaidtillDate;
	}
	public double getDbGoalAchivedPercent() {
		return dbGoalAchivedPercent;
	}
	public double getPercentOfDBAmountPiad() {
		return percentOfDBAmountPiad;
	}
	public double getTotalCommitedAmount() {
		return totalCommitedAmount;
	}
	public double getTotalEarnedTillDate() {
		return totalEarnedTillDate;
	}
	public double getTotalPaidTillDate() {
		return totalPaidTillDate;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	public void setStartDate(ZonedDateTime startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setPrimeVendorId(String primeVendorId) {
		this.primeVendorId = primeVendorId;
	}
	public void setPrimeVendorName(String primeVendorName) {
		this.primeVendorName = primeVendorName;
	}
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setFinalReport(boolean isFinalReport) {
		this.isFinalReport = isFinalReport;
	}
	public void setContractAmountPaidTillDate(Double contractAmountPaidTillDate) {
		this.contractAmountPaidTillDate = contractAmountPaidTillDate;
	}
	public void setSubmissionDate(ZonedDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}
	public void setTotalDBAmount(double totalDBAmount) {
		this.totalDBAmount = totalDBAmount;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setTotalDBAmountPaidtillDate(double totalDBAmountPaidtillDate) {
		this.totalDBAmountPaidtillDate = totalDBAmountPaidtillDate;
	}
	public void setDbGoalAchivedPercent(double dbGoalAchivedPercent) {
		this.dbGoalAchivedPercent = dbGoalAchivedPercent;
	}
	public void setPercentOfDBAmountPiad(double percentOfDBAmountPiad) {
		this.percentOfDBAmountPiad = percentOfDBAmountPiad;
	}
	public void setTotalCommitedAmount(double totalCommitedAmount) {
		this.totalCommitedAmount = totalCommitedAmount;
	}
	public void setTotalEarnedTillDate(double totalEarnedTillDate) {
		this.totalEarnedTillDate = totalEarnedTillDate;
	}
	public void setTotalPaidTillDate(double totalPaidTillDate) {
		this.totalPaidTillDate = totalPaidTillDate;
	}
	public List<Tier2Submission> getList() {
		return list;
	}
	public void setList(List<Tier2Submission> list) {
		this.list = list;
	}
	public String getSubmittedBy() {
		return submittedBy;
	}
	public String getSubmittedByName() {
		return submittedByName;
	}
	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}
	public void setSubmittedByName(String submittedByName) {
		this.submittedByName = submittedByName;
	}
	public double getContractAmountPaidToDate() {
		return contractAmountPaidToDate;
	}
	public void setContractAmountPaidToDate(double contractAmountPaidToDate) {
		this.contractAmountPaidToDate = contractAmountPaidToDate;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}
	public ZonedDateTime getReportDate() {
		return reportDate;
	}
	public void setReportDate(ZonedDateTime reportDate) {
		this.reportDate = reportDate;
	}
	
	
	
}
