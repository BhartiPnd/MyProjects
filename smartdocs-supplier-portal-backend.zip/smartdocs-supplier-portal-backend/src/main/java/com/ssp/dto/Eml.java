package com.ssp.dto;

import java.util.ArrayList;
import java.util.List;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.internet.InternetAddress;

public class Eml {

	private String fromEmail;
	private String fromUser;

	private List<String> recipientAddress;
	private String subject;
	private String type;
	private String content;

	public Eml() {
		super();

	}

	public Eml(Message msg) throws Exception {
		super();
		parseEml(msg);
	}

	private void parseEml(Message msg) throws Exception {
		// sender information
		Address[] froms = msg.getFrom();
		if (froms != null) {
			InternetAddress addr = (InternetAddress) froms[0];
			this.fromEmail = addr.getAddress();
			this.fromUser = addr.getPersonal();
		}
		// Recipient Information
		Address[] tos = msg.getAllRecipients();
		recipientAddress = new ArrayList<>();
		if(tos!=null) {
		for (Address a : tos) {
			InternetAddress addr = (InternetAddress) a;
			System.out.println("====> Recipient address:" + addr.getAddress());
			recipientAddress.add(addr.getAddress());
		}
		}

		this.subject = msg.getSubject();
		// getContent () is to obtain the contents of the package, Part equivalent
		// packaging
		Object o = msg.getContent();
		if (o instanceof Multipart multipart) {
			reMultipart(multipart);
		} else if (o instanceof Part part) {
			rePart(part);
		} else {
			this.type = msg.getContentType();
			this.content = (String) msg.getContent();
			/*
			 * System.out.println ( "content" + msg.getContent ()); map.put("content",
			 * msg.getContent());
			 */
		}

	}

	private void rePart(Part part) throws Exception {
		if (part.getDisposition() != null) {
			/*
			 * String strFileNmae = part.getFileName(); if(strFileNmae != null) { //
			 * MimeUtility.decodeText solve the garbage problem attachment name
			 * strFileNmae=MimeUtility.decodeText(strFileNmae); System.out.println (
			 * "Annex found:" + strFileNmae);
			 * 
			 * // Open input stream attachments InputStream in = part.getInputStream();
			 * 
			 * String strFile = "C:\\Users\\lin\\Desktop\\test\\" + strFileNmae;
			 * FileOutputStream out = new FileOutputStream(strFile); byte[] bytes = new
			 * byte[1024]; while(in.read(bytes,0,1024) != -1){ out.write(bytes); }
			 * 
			 * in.close(); out.close();
			 * 
			 * }
			 * 
			 * System.out.println ( "Content Type:" + MimeUtility.decodeText
			 * (part.getContentType ())); System.out.println ( "Attachment content:" +
			 * part.getContent ());
			 */

		} else {
			if (part.getContentType().startsWith("text/plain")) {
				this.content = (String) part.getContent();
				// System.out.println ( "text:" + part.getContent ());
			} else {
				// System.out.println ( "HTML content:" + part.getContent ());
			}
		}
	}

	private void reMultipart(Multipart multipart) throws Exception {
		// System.out.println ( "Total Mail" + multipart.getCount () + "parts");
		// sequentially processing each part
		for (int j = 0, n = multipart.getCount(); j < n; j++) {
			// System.out.println ( "Treatment" + j + "portion");
			Part part = multipart.getBodyPart(j); // unpack, remove respective portions of MultiPart,
			// Each part may be the message content,
			// may also be another small parcel (MultipPart) Analyzing Package contents //
			// This is not a small package, this part is generally text Content-Type:
			// multipart / alternative
			if (part.getContent() instanceof Multipart) {
				Multipart p = (Multipart) part.getContent(); // turn into a small package
				// recursive iteration
				reMultipart(p);
			} else {
				rePart(part);
			}
		}
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getFromUser() {
		return fromUser;
	}

	public void setFromUser(String fromUser) {
		this.fromUser = fromUser;
	}

	public List<String> getRecipientAddress() {
		return recipientAddress;
	}

	public void setRecipientAddress(List<String> recipientAddress) {
		this.recipientAddress = recipientAddress;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
