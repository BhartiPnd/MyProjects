package com.ssp.dto;

import com.ssp.mongo.collectionhelpers.Address;

public class EDIPOitmHelperDTO {

	private Integer PO_LNE;
	private String MAT_CODE;
	private String MAT_DES;
	private Double PO_QTY;
	private Double OC_QTY;
	private String PO_UOM;
	private Double PO_UNT_PRCE;
	private String PLANT;
	private String SPARTNO;
	private String SLOCATION;
	private String storageLocationDesc;
	private String DLVRY_DATE;
	public boolean DELIVERY_COMP_IND;
	private Address shipToAddress;
	private boolean grnRequired;
	private String manuFactorePartNo;
	private Double Original_OTY;
	private Double grQuantity;
	private String ackDeliveryDate;
	private String plantDesc;
	private String PO_UOMDesc;
	private String perUOM;
	private Long per;
	private Double netValue;
	private Double pendingTolerance;
	private boolean deleted;
	private String taxCode;
	private String itemText;
	private String supplierMatNo;
	private String supplierMatDesc;
	private String ediStatus;

	public EDIPOitmHelperDTO() {
		super();
	}

	public Integer getPO_LNE() {
		return PO_LNE;
	}

	public void setPO_LNE(Integer pO_LNE) {
		PO_LNE = pO_LNE;
	}

	public String getMAT_CODE() {
		return MAT_CODE;
	}

	public void setMAT_CODE(String mAT_CODE) {
		MAT_CODE = mAT_CODE;
	}

	public String getMAT_DES() {
		return MAT_DES;
	}

	public void setMAT_DES(String mAT_DES) {
		MAT_DES = mAT_DES;
	}

	public Double getPO_QTY() {
		return PO_QTY;
	}

	public void setPO_QTY(Double pO_QTY) {
		PO_QTY = pO_QTY;
	}

	public Double getOC_QTY() {
		return OC_QTY;
	}

	public void setOC_QTY(Double oC_QTY) {
		OC_QTY = oC_QTY;
	}

	public String getPO_UOM() {
		return PO_UOM;
	}

	public void setPO_UOM(String pO_UOM) {
		PO_UOM = pO_UOM;
	}

	public Double getPO_UNT_PRCE() {
		return PO_UNT_PRCE;
	}

	public void setPO_UNT_PRCE(Double pO_UNT_PRCE) {
		PO_UNT_PRCE = pO_UNT_PRCE;
	}

	public String getPLANT() {
		return PLANT;
	}

	public void setPLANT(String pLANT) {
		PLANT = pLANT;
	}

	public String getSPARTNO() {
		return SPARTNO;
	}

	public void setSPARTNO(String sPARTNO) {
		SPARTNO = sPARTNO;
	}

	public String getSLOCATION() {
		return SLOCATION;
	}

	public void setSLOCATION(String sLOCATION) {
		SLOCATION = sLOCATION;
	}

	public String getStorageLocationDesc() {
		return storageLocationDesc;
	}

	public void setStorageLocationDesc(String storageLocationDesc) {
		this.storageLocationDesc = storageLocationDesc;
	}

	public String getDLVRY_DATE() {
		return DLVRY_DATE;
	}

	public void setDLVRY_DATE(String dLVRY_DATE) {
		DLVRY_DATE = dLVRY_DATE;
	}

	public boolean isDELIVERY_COMP_IND() {
		return DELIVERY_COMP_IND;
	}

	public void setDELIVERY_COMP_IND(boolean dELIVERY_COMP_IND) {
		DELIVERY_COMP_IND = dELIVERY_COMP_IND;
	}

	public Address getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(Address shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public boolean isGrnRequired() {
		return grnRequired;
	}

	public void setGrnRequired(boolean grnRequired) {
		this.grnRequired = grnRequired;
	}

	public String getManuFactorePartNo() {
		return manuFactorePartNo;
	}

	public void setManuFactorePartNo(String manuFactorePartNo) {
		this.manuFactorePartNo = manuFactorePartNo;
	}

	public Double getOriginal_OTY() {
		return Original_OTY;
	}

	public void setOriginal_OTY(Double original_OTY) {
		Original_OTY = original_OTY;
	}

	public Double getGrQuantity() {
		return grQuantity;
	}

	public void setGrQuantity(Double grQuantity) {
		this.grQuantity = grQuantity;
	}

	public String getAckDeliveryDate() {
		return ackDeliveryDate;
	}

	public void setAckDeliveryDate(String ackDeliveryDate) {
		this.ackDeliveryDate = ackDeliveryDate;
	}

	public String getPlantDesc() {
		return plantDesc;
	}

	public void setPlantDesc(String plantDesc) {
		this.plantDesc = plantDesc;
	}

	public String getPO_UOMDesc() {
		return PO_UOMDesc;
	}

	public void setPO_UOMDesc(String pO_UOMDesc) {
		PO_UOMDesc = pO_UOMDesc;
	}

	public String getPerUOM() {
		return perUOM;
	}

	public void setPerUOM(String perUOM) {
		this.perUOM = perUOM;
	}

	public Long getPer() {
		return per;
	}

	public void setPer(Long per) {
		this.per = per;
	}

	public Double getNetValue() {
		return netValue;
	}

	public void setNetValue(Double netValue) {
		this.netValue = netValue;
	}

	public Double getPendingTolerance() {
		return pendingTolerance;
	}

	public void setPendingTolerance(Double pendingTolerance) {
		this.pendingTolerance = pendingTolerance;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getItemText() {
		return itemText;
	}

	public void setItemText(String itemText) {
		this.itemText = itemText;
	}

	public String getSupplierMatNo() {
		return supplierMatNo;
	}

	public void setSupplierMatNo(String supplierMatNo) {
		this.supplierMatNo = supplierMatNo;
	}

	public String getSupplierMatDesc() {
		return supplierMatDesc;
	}

	public void setSupplierMatDesc(String supplierMatDesc) {
		this.supplierMatDesc = supplierMatDesc;
	}

	public String getEdiStatus() {
		return ediStatus;
	}

	public void setEdiStatus(String ediStatus) {
		this.ediStatus = ediStatus;
	}

}
