package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collectionhelpers.SMDDocument;
import com.ssp.mongo.collections.config.Field;
import com.ssp.mongo.collections.config.VendorMasterDocumentType;
import com.ssp.mongo.collections.requests.VendorMasterDocumentChangeRequest;
import com.ssp.mongo.collections.workflow.WorkItem;

public class VendorMasterDocumentTypeDTO {

	private String id;
	private String documentFolderId;
	private String name;
	private String description;

	private boolean isRequired;
	private boolean allowMultiple;
	
	private boolean canResubmit;
	private String action;
	
	private long refId;
	private boolean accessRestricted;
	private List<String> allowedUsers;

	private boolean hasPendignDocument;
	private List<Field> fields;
	
	private List<VendorMasterDocumentChangeRequest> pendingRequests;
	
	private SMDDocument document;
	
	public VendorMasterDocumentTypeDTO() {
		// TODO Auto-generated constructor stub
	}
	public VendorMasterDocumentTypeDTO(VendorMasterDocumentType dt,SMDDocument document,List<VendorMasterDocumentChangeRequest> pendingRequests) 
	{
		this.id=dt.getId();
		this.canResubmit=true;
		this.action="SUBMIT";
		this.documentFolderId=dt.getDocumentFolderId();
		this.name=dt.getName();
		this.description=dt.getDescription();
		this.isRequired=dt.isRequired();
		this.allowMultiple=dt.isAllowMultiple();
		this.accessRestricted=dt.isAccessRestricted();
		this.fields=dt.getFields();
		this.document=document;
		this.pendingRequests=pendingRequests;
		if(pendingRequests!=null && pendingRequests.size()>0) {
			this.canResubmit=false;
			this.hasPendignDocument=true;
			for(VendorMasterDocumentChangeRequest pendingRequest:pendingRequests) {
				if(WorkItem.STATUS_REJECTED.equalsIgnoreCase(pendingRequest.getStatus())) 
				{
					this.action="RESUBMIT";
					this.canResubmit=true;
					this.refId=pendingRequest.getRefId();
				}
			}
		}
		
		
		
	}
	public String getId() {
		return id;
	}
	public String getDocumentFolderId() {
		return documentFolderId;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public boolean isRequired() {
		return isRequired;
	}
	public boolean isAllowMultiple() {
		return allowMultiple;
	}
	public boolean isAccessRestricted() {
		return accessRestricted;
	}
	public List<String> getAllowedUsers() {
		return allowedUsers;
	}
	 
	public SMDDocument getDocument() {
		return document;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setDocumentFolderId(String documentFolderId) {
		this.documentFolderId = documentFolderId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}
	public void setAllowMultiple(boolean allowMultiple) {
		this.allowMultiple = allowMultiple;
	}
	public void setAccessRestricted(boolean accessRestricted) {
		this.accessRestricted = accessRestricted;
	}
	public void setAllowedUsers(List<String> allowedUsers) {
		this.allowedUsers = allowedUsers;
	}
	 
	public List<Field> getFields() {
		return fields;
	}
	public void setFields(List<Field> fields) {
		this.fields = fields;
	}
	public void setDocument(SMDDocument document) {
		this.document = document;
	}
	public List<VendorMasterDocumentChangeRequest> getPendingRequests() {
		return pendingRequests;
	}
	public void setPendingRequests(List<VendorMasterDocumentChangeRequest> pendingRequests) {
		this.pendingRequests = pendingRequests;
	}
	public boolean isHasPendignDocument() {
		return hasPendignDocument;
	}
	public void setHasPendignDocument(boolean hasPendignDocument) {
		this.hasPendignDocument = hasPendignDocument;
	}
	public boolean isCanResubmit() {
		return canResubmit;
	}
	public String getAction() {
		return action;
	}
	public void setCanResubmit(boolean canResubmit) {
		this.canResubmit = canResubmit;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	 
	
}
