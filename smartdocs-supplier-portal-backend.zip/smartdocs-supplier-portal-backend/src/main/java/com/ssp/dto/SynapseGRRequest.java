package com.ssp.dto;

import java.util.Map;

public class SynapseGRRequest {
	private String poNumber;
	private String user;
	private boolean fullGr;
	private Map<String,String> poItemGrQuantity;
	private String channel;
	private String comment;
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	public boolean isFullGr() {
		return fullGr;
	}
	public void setFullGr(boolean fullGr) {
		this.fullGr = fullGr;
	}
	public Map<String, String> getPoItemGrQuantity() {
		return poItemGrQuantity;
	}
	public void setPoItemGrQuantity(Map<String, String> poItemGrQuantity) {
		this.poItemGrQuantity = poItemGrQuantity;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	

	
}
