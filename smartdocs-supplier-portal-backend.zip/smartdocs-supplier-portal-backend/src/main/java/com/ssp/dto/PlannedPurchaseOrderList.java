package com.ssp.dto;

import java.util.HashMap;
import java.util.Map;

public class PlannedPurchaseOrderList {
	
	private int fromWeek;
	private int fromWeekYear;
	private int toWeek;
	private int toWeekYear;
	 
	
	private Map<String, PlannedPurchaseOrderLocation> locations=new HashMap<>();

	public PlannedPurchaseOrderList() {
		super();
	}

	public PlannedPurchaseOrderList(int fromWeek, int fromWeekYear, int toWeek, int toWeekYear
			) {
		super();
		this.fromWeek = fromWeek;
		this.fromWeekYear = fromWeekYear;
		this.toWeek = toWeek;
		this.toWeekYear = toWeekYear;
	}


	public int getFromWeek() {
		return fromWeek;
	}


	public void setFromWeek(int fromWeek) {
		this.fromWeek = fromWeek;
	}


	public int getFromWeekYear() {
		return fromWeekYear;
	}


	public void setFromWeekYear(int fromWeekYear) {
		this.fromWeekYear = fromWeekYear;
	}


	public int getToWeek() {
		return toWeek;
	}


	public void setToWeek(int toWeek) {
		this.toWeek = toWeek;
	}


	public int getToWeekYear() {
		return toWeekYear;
	}


	public void setToWeekYear(int toWeekYear) {
		this.toWeekYear = toWeekYear;
	}


	public Map<String, PlannedPurchaseOrderLocation> getLocations() {
		return locations;
	}


	public void setLocations(Map<String, PlannedPurchaseOrderLocation> locations) {
		this.locations = locations;
	}

	@Override
	public String toString() {
		return "PlannedPurchaseOrderList [fromWeek=" + fromWeek + ", fromWeekYear=" + fromWeekYear + ", toWeek="
				+ toWeek + ", toWeekYear=" + toWeekYear + ", locations=" + locations + "]";
	}

 
 

}
