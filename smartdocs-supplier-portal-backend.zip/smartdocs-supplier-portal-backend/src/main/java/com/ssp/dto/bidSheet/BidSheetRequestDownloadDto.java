package com.ssp.dto.bidSheet;

public class BidSheetRequestDownloadDto {
	
	private String itemNumber;
	private String itemName;
	private String packSize;
	private Double ninetyDayVolumn;
	private Integer per;
	private String uom;
	private String uomDesc;
	private String currency;
	
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getPackSize() {
		return packSize;
	}
	public void setPackSize(String packSize) {
		this.packSize = packSize;
	}
	public Double getNinetyDayVolumn() {
		return ninetyDayVolumn;
	}
	public void setNinetyDayVolumn(Double ninetyDayVolumn) {
		this.ninetyDayVolumn = ninetyDayVolumn;
	}
	public Integer getPer() {
		return per;
	}
	public void setPer(Integer per) {
		this.per = per;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getUomDesc() {
		return uomDesc;
	}
	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	

}
