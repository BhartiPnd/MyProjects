package com.ssp.dto;

public class CreateSubstituteConfig {

	private String id;
	private String user;
	private String fromDate;
	private String toDate;
	private String substituteUser;
	private boolean isActive;
	
	
	public String getId() {
		return id;
	}
	public String getUser() {
		return user;
	}
	public String getFromDate() {
		return fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public String getSubstituteUser() {
		return substituteUser;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setSubstituteUser(String substituteUser) {
		this.substituteUser = substituteUser;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
}
