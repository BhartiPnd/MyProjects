package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.ActivityLog;
import com.ssp.travler.InvoieValidationResult;

@Document(collection = "invoice")
public class InvoiceTable {

	
	private String id;
	private long sspInvoiceReferenceNo;
	private String invoiceNumber;
	private String sapInvoiceNo;
	
	private String supplierId;
	private String supplier;
	
	private String companyCode;
	private String company;
	private String tempBufferId;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime supplyDate;
	
	private String currency;
	
	//private Double subTotal;  // total of invoice line item netAmount. 
	//private Double totalDiscount;  // total of invoice line item discount. display only not participate in any calculation . already calculated. 
	//private Double additionalDiscount; // new additional header discount. 
	
	//private Double freightAmount; // input based on invoice type.
	//private Float  taxPercent; // input field.  
	private Double taxPercent;
	private Double subTotal;
	private Double discount;
	private Double netAmount;
	private Double taxAmount;
	private Double freightAmount;
	//private Double totalAmount;
	private Double totalInvoiceAmount;
	
	
	private String paymentterms;
	private String freightCarrier;
	private String poNumber;
	private String poDescription;
	
	private boolean isCreatedByVendor;
	// PO// NOnPo// Expense
	private String invoiceCategory;
	
	private String status;
	private String statusDesc;
	 
	private String invoiceType;
	private String invoiceTypeDesc;

	private String creator;

	// Supplier portal or SAP.
	private String channel;
	private String channelDesc;

	private String requestId;
	
	 
	private String buyer;
	private String  requestor;

	private boolean creditMemo;
	
 
	private String cadsNumber;
	private String billAccNumber;
	private String billAccName;
	private String logicalSystem;
	private String year;
	private InvoieValidationResult exceptions;
	private List<String> approvers;
	private ActivityLog recentActivity;
	
	public String getId() {
		return id;
	}
	public long getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public String getSapInvoiceNo() {
		return sapInvoiceNo;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplier() {
		return supplier;
	}
	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}
	public ZonedDateTime getDueDate() {
		return dueDate;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}
	public String getCurrency() {
		return currency;
	}
	 
	public String getPaymentterms() {
		return paymentterms;
	}
	public String getFreightCarrier() {
		return freightCarrier;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public String getInvoiceCategory() {
		return invoiceCategory;
	}
	public String getStatus() {
		return status;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	 
	public String getCreator() {
		return creator;
	}
	public String getChannel() {
		return channel;
	}
	public String getRequestId() {
		return requestId;
	}
	public String getBuyer() {
		return buyer;
	}
	public String getRequestor() {
		return requestor;
	}
	public boolean isCreditMemo() {
		return creditMemo;
	}
	public String getCadsNumber() {
		return cadsNumber;
	}
	public String getBillAccNumber() {
		return billAccNumber;
	}
	public String getBillAccName() {
		return billAccName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setSspInvoiceReferenceNo(long sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public void setSapInvoiceNo(String sapInvoiceNo) {
		this.sapInvoiceNo = sapInvoiceNo;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	 
	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}
	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}
	public void setCadsNumber(String cadsNumber) {
		this.cadsNumber = cadsNumber;
	}
	public void setBillAccNumber(String billAccNumber) {
		this.billAccNumber = billAccNumber;
	}
	public void setBillAccName(String billAccName) {
		this.billAccName = billAccName;
	}
	
	 public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
 
	 
	 public String getPoDescription() {
		return poDescription;
	}
	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}
	
 
	 
	public boolean isCreatedByVendor() {
		return isCreatedByVendor;
	}
	public void setCreatedByVendor(boolean isCreatedByVendor) {
		this.isCreatedByVendor = isCreatedByVendor;
	}
	public String getInvoiceTypeDesc() {
		return invoiceTypeDesc;
	}
	public void setInvoiceTypeDesc(String invoiceTypeDesc) {
		this.invoiceTypeDesc = invoiceTypeDesc;
	}
	public String getChannelDesc() {
		return channelDesc;
	}
	public void setChannelDesc(String channelDesc) {
		this.channelDesc = channelDesc;
	}
	public String getLogicalSystem() {
		return logicalSystem;
	}
	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}
 
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getTempBufferId() {
		return tempBufferId;
	}
	public void setTempBufferId(String tempBufferId) {
		this.tempBufferId = tempBufferId;
	}
	public Double getTaxPercent() {
		return taxPercent;
	}
	public void setTaxPercent(Double taxPercent) {
		this.taxPercent = taxPercent;
	}
	public Double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	public Double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}
	public Double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Double getFreightAmount() {
		return freightAmount;
	}
	public void setFreightAmount(Double freightAmount) {
		this.freightAmount = freightAmount;
	}
	public Double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}
	public void setTotalInvoiceAmount(Double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}
	public InvoieValidationResult getExceptions() {
		return exceptions;
	}
	public void setExceptions(InvoieValidationResult exceptions) {
		this.exceptions = exceptions;
	}
	public List<String> getApprovers() {
		return approvers;
	}
	public void setApprovers(List<String> approvers) {
		this.approvers = approvers;
	}
	public ActivityLog getRecentActivity() {
		return recentActivity;
	}
	public void setRecentActivity(ActivityLog recentActivity) {
		this.recentActivity = recentActivity;
	}
	
	 
}
