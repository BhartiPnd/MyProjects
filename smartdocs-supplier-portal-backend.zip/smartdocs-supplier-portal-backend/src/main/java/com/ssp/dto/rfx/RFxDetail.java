package com.ssp.dto.rfx;

import java.util.List;

import com.ssp.dto.RFXBidResponseTable;
import com.ssp.dto.RFXBidResponseTableDTO;
import com.ssp.dto.rfx.bid.BidComparison;
import com.ssp.mongo.collections.rfx.RFXCollaborate;
import com.ssp.mongo.collections.rfx.RfxTabulation;
import com.ssp.mongo.collections.workflow.WorkItem;
import com.ssp.service.util.GeneralUtil;

public class RFxDetail {
	
	private RfxView rfx;
	private List<RFXBidResponseTableDTO> bidds;
	private List<RFXCollaborate> collaboration;
	private BidComparison bcomp;
	private List<RfxTabulation> rfxTabulations;
	// this meas due date is passed and not published.
	private boolean isddpasseedNotPublished;
	private WorkItem workItem;
	
	public RFxDetail(RfxView rfx, List<RFXBidResponseTableDTO> bidds,BidComparison bcomp,  List<RFXCollaborate> collaboration, WorkItem workItem,List<RfxTabulation> rfxTabulations) {
		super();
		this.rfx = rfx;
		this.bidds = bidds;
		this.collaboration = collaboration;
		if(!GeneralUtil.nowIsBefore(rfx.getSubmissionStartDate())) {
			this.isddpasseedNotPublished=true;
		}
		this.bcomp=bcomp;
		this.workItem = workItem;
		this.rfxTabulations=rfxTabulations;
	}

	public RfxView getRfx() {
		return rfx;
	}

	public void setRfx(RfxView rfx) {
		this.rfx = rfx;
	}

	public List<RFXBidResponseTableDTO> getBidds() {
		return bidds;
	}

	public void setBidds(List<RFXBidResponseTableDTO> bidds) {
		this.bidds = bidds;
	}

	public List<RFXCollaborate> getCollaboration() {
		return collaboration;
	}

	public void setCollaboration(List<RFXCollaborate> collaboration) {
		this.collaboration = collaboration;
	}

	public boolean isIsddpasseedNotPublished() {
		return isddpasseedNotPublished;
	}

	public void setIsddpasseedNotPublished(boolean isddpasseedNotPublished) {
		this.isddpasseedNotPublished = isddpasseedNotPublished;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public BidComparison getBcomp() {
		return bcomp;
	}

	public void setBcomp(BidComparison bcomp) {
		this.bcomp = bcomp;
	}

	public List<RfxTabulation> getRfxTabulations() {
		return rfxTabulations;
	}

	public void setRfxTabulations(List<RfxTabulation> rfxTabulations) {
		this.rfxTabulations = rfxTabulations;
	}

	 
	
	
}
