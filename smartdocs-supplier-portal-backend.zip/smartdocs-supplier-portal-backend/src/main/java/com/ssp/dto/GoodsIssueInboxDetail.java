package com.ssp.dto;


import com.ssp.mongo.collections.workflow.WorkItem;

public class GoodsIssueInboxDetail {
	 
	
	private GoodsIssueDetail goodsIssueDetail;
	private WorkItem workItem;
	private String status;
	private String error;
	
	public GoodsIssueDetail getGoodsIssueDetail() {
		return goodsIssueDetail;
	}
	public void setGoodsIssueDetail(GoodsIssueDetail goodsIssueDetail) {
		this.goodsIssueDetail = goodsIssueDetail;
	}
	public WorkItem getWorkItem() {
		return workItem;
	}
	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}
	public String getStatus() {
		return status;
	}
	public String getError() {
		return error;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
