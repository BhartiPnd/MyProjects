package com.ssp.dto.plannedpo;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;

import com.ssp.dto.MaterialPlant;
import com.ssp.dto.PlannedPurchaseOrderDto;

public class PlannedPurchaseOrderTable {
		
	
	private List<MaterialPlant> products;
	private List<MaterialPlant> plants;
	
	private Map<String,PlannedPOHeader> monthList;
	private Map<String,PlannedPOHeader> weeksList;
	//private Map<String ,PlannedPurchaseOrderRow> rows=new HashedMap<>();
	private Map<String ,PlannedPurchaseOrderDto> data=new HashedMap<>();
	/*
	 * public Map<String, PlannedPurchaseOrderRow> getRows() { return rows; }
	 * 
	 * public void setRows(Map<String, PlannedPurchaseOrderRow> rows) { this.rows =
	 * rows; }
	 */

	public Map<String, PlannedPOHeader> getMonthList() {
		return monthList;
	}

	public void setMonthList(Map<String, PlannedPOHeader> monthList) {
		this.monthList = monthList;
	}

	public Map<String, PlannedPOHeader> getWeeksList() {
		return weeksList;
	}

	public void setWeeksList(Map<String, PlannedPOHeader> weeksList) {
		this.weeksList = weeksList;
	}

	public List<MaterialPlant> getProducts() {
		return products;
	}

	public void setProducts(List<MaterialPlant> products) {
		this.products = products;
	}

	public List<MaterialPlant> getPlants() {
		return plants;
	}

	public void setPlants(List<MaterialPlant> plants) {
		this.plants = plants;
	}

	public Map<String, PlannedPurchaseOrderDto> getData() {
		return data;
	}

	public void setData(Map<String, PlannedPurchaseOrderDto> data) {
		this.data = data;
	}

	 

	 
	
	
	
	
}
