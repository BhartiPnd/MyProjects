package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ssp.mongo.collectionhelpers.Phone;

public class ContactDto {

	private String supplierId;
	private String contactId;
	private String firstname;
	private String lastname;
	private String email;
	private Phone  phonenumber;
	private Phone  fax;
	private Phone  mobile;
	private String  functionName;
	private boolean admin;
	
	private boolean isPortalAccount;
	private boolean asPrimaryEmail;
	
	private List<String> roles;
	
	private ZonedDateTime date;
	private boolean sendInvitation;
	
	public ContactDto() {
		super();
	}

	/*public Contact(String firstname, String lastname,String email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	 
	}*/

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if(StringUtils.isNotBlank(email)) {
			this.email=email.toLowerCase().trim();
		}
		else{
			this.email = email;
		}
	}

	public Phone getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Phone phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Phone getFax() {
		return fax;
	}

	public void setFax(Phone fax) {
		this.fax = fax;
	}

	public Phone getMobile() {
		return mobile;
	}

	public void setMobile(Phone mobile) {
		this.mobile = mobile;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean isPortalAccount() {
		return isPortalAccount;
	}

	public void setPortalAccount(boolean isPortalAccount) {
		this.isPortalAccount = isPortalAccount;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public boolean isAsPrimaryEmail() {
		return asPrimaryEmail;
	}

	public void setAsPrimaryEmail(boolean asPrimaryEmail) {
		this.asPrimaryEmail = asPrimaryEmail;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public ZonedDateTime getDate() {
		return date;
	}

	public void setDate(ZonedDateTime date) {
		this.date = date;
	}

	public boolean isSendInvitation() {
		return sendInvitation;
	}

	public void setSendInvitation(boolean sendInvitation) {
		this.sendInvitation = sendInvitation;
	}
	
	
}
