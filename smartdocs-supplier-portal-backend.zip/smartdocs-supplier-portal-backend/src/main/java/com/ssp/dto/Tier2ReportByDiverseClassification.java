package com.ssp.dto;

public class Tier2ReportByDiverseClassification {
	private String dbeType;
	private Double amount;
	private String subcontractorId;
	private String subcontractorName;

	
	
 	public Tier2ReportByDiverseClassification() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Tier2ReportByDiverseClassification(String dbeType, Double amount, String subcontractorId,
			String subcontractorName) {
		super();
		this.dbeType = dbeType;
		this.amount = amount;
		this.subcontractorId = subcontractorId;
		this.subcontractorName = subcontractorName;
	} 
	public String getDbeType() {
		return dbeType;
	}
	public void setDbeType(String dbeType) {
		this.dbeType = dbeType;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getSubcontractorId() {
		return subcontractorId;
	}
	public void setSubcontractorId(String subcontractorId) {
		this.subcontractorId = subcontractorId;
	}
	public String getSubcontractorName() {
		return subcontractorName;
	}
	public void setSubcontractorName(String subcontractorName) {
		this.subcontractorName = subcontractorName;
	}
 
	
	
	
	
	 
	
	
}
