package com.ssp.dto;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collections.rfx.Rfx;

@Document(collection = "rfx")
public class RFXDto {

	private String id;
	private String title;
	private String companyCode;
	private String rfxNo;
	private String type;

	private String visibility;
	private String purchasingGroup;
	private String purchasingGroupDesc;
	private String requestorEmail;
	private String requestorName;
	private String buyerEmail;
	private String buyerName;

	private String status;

	private ZonedDateTime submissionStartDate;
	private ZonedDateTime submissionEndDate;
	private ZonedDateTime qAndADeadline;
	private ZonedDateTime publishedDate;

	private String createdBy;
	private String createdByName;
	private ZonedDateTime createdDate;
	
	
	public RFXDto() {
		// TODO Auto-generated constructor stub
	}
	

	

	public RFXDto(Rfx rfx,String name) {
		super();
		this.id = rfx.getId();
		this.title = rfx.getTitle();
		this.companyCode = rfx.getCompanyCode();
		this.rfxNo = rfx.getRfxNo();
		this.type = rfx.getType();
		this.visibility = rfx.getVisibility();
		this.purchasingGroup = rfx.getPurchasingGroup();
		this.purchasingGroupDesc = rfx.getPurchasingOrgDesc();
		this.requestorEmail = rfx.getRequestorEmail();
		this.requestorName = rfx.getRequestorName();
		this.buyerEmail = rfx.getBuyerEmail();
		this.buyerName = rfx.getBuyerName();
		this.status = rfx.getStatus();
		this.submissionStartDate = rfx.getSubmissionStartDate();
		this.submissionEndDate = rfx.getSubmissionEndDate();
		this.qAndADeadline = rfx.getqAndADeadline();
		this.publishedDate = rfx.getPublishedDate();
		this.createdBy = rfx.getCreatedBy();
		this.createdByName = name;
		this.createdDate = rfx.getCreatedDate();
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ZonedDateTime getqAndADeadline() {
		return qAndADeadline;
	}

	public void setqAndADeadline(ZonedDateTime qAndADeadline) {
		this.qAndADeadline = qAndADeadline;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getPurchasingGroup() {
		return purchasingGroup;
	}

	public void setPurchasingGroup(String purchasingGroup) {
		this.purchasingGroup = purchasingGroup;
	}

	public String getPurchasingGroupDesc() {
		return purchasingGroupDesc;
	}

	public void setPurchasingGroupDesc(String purchasingGroupDesc) {
		this.purchasingGroupDesc = purchasingGroupDesc;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(ZonedDateTime publishedDate) {
		this.publishedDate = publishedDate;
	}

	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getRfxNo() {
		return rfxNo;
	}

	public void setRfxNo(String rfxNo) {
		this.rfxNo = rfxNo;
	}

	public ZonedDateTime getSubmissionStartDate() {
		return submissionStartDate;
	}

	public void setSubmissionStartDate(ZonedDateTime submissionStartDate) {
		this.submissionStartDate = submissionStartDate;
	}

	public ZonedDateTime getSubmissionEndDate() {
		return submissionEndDate;
	}

	public void setSubmissionEndDate(ZonedDateTime submissionEndDate) {
		this.submissionEndDate = submissionEndDate;
	}

}
