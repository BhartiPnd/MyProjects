package com.ssp.dto.smartbuy;

public class PoPrrPorDto {

	private String purchaseOrderNumber;
	private PoPorDto purchaseOrderReqDto;
	private PoPrrDto purchaseReqRequestDto;
	
	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}
	public PoPorDto getPurchaseOrderReqDto() {
		return purchaseOrderReqDto;
	}
	public void setPurchaseOrderReqDto(PoPorDto purchaseOrderReqDto) {
		this.purchaseOrderReqDto = purchaseOrderReqDto;
	}
	public PoPrrDto getPurchaseReqRequestDto() {
		return purchaseReqRequestDto;
	}
	public void setPurchaseReqRequestDto(PoPrrDto purchaseReqRequestDto) {
		this.purchaseReqRequestDto = purchaseReqRequestDto;
	}
	
}
