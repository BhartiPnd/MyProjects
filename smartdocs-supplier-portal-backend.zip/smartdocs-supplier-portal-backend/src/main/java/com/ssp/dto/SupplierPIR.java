package com.ssp.dto;

import com.ssp.mongo.collections.pir.PurchaseInfoRecord;

public class SupplierPIR {
	
	private PurchaseInfoRecord purchaseInfoRecord;
	private String supplierName;
	private String materialName;
	
	public SupplierPIR() {
		super();
	}
	
	public PurchaseInfoRecord getPurchaseInfoRecord() {
		return purchaseInfoRecord;
	}
	public void setPurchaseInfoRecord(PurchaseInfoRecord purchaseInfoRecord) {
		this.purchaseInfoRecord = purchaseInfoRecord;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getMaterialName() {
		return materialName;
	}

	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}

	public SupplierPIR(PurchaseInfoRecord purchaseInfoRecord, String supplierName, String materialName) {
		super();
		this.purchaseInfoRecord = purchaseInfoRecord;
		this.supplierName = supplierName;
		this.materialName = materialName;
	}

	
	
	
}
