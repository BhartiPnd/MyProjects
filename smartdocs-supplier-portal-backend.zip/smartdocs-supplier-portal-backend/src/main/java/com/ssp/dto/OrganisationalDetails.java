package com.ssp.dto;

public class OrganisationalDetails {

	private String companyCode;
	private String purchaseOrg;
	private boolean vendorOrPayee;
	private boolean vendorChange;
	private boolean sapVendorName;
	private String accountGroup;
	private String vendorClassification;
	private boolean paymentTerms;
	private String reconAccount;
	private String language;

	public OrganisationalDetails() {

	}
	
	public OrganisationalDetails(String companyCode, String purchaseOrg, boolean vendorOrPayee, boolean vendorChange,
			boolean sapVendorName, String accountGroup, String vendorClassification, boolean paymentTerms,
			String reconAccount, String language) {
		super();
		this.companyCode = companyCode;
		this.purchaseOrg = purchaseOrg;
		this.vendorOrPayee = vendorOrPayee;
		this.vendorChange = vendorChange;
		this.sapVendorName = sapVendorName;
		this.accountGroup = accountGroup;
		this.vendorClassification = vendorClassification;
		this.paymentTerms = paymentTerms;
		this.reconAccount = reconAccount;
		this.language = language;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPurchaseOrg() {
		return purchaseOrg;
	}

	public void setPurchaseOrg(String purchaseOrg) {
		this.purchaseOrg = purchaseOrg;
	}

	public boolean isVendorOrPayee() {
		return vendorOrPayee;
	}

	public void setVendorOrPayee(boolean vendorOrPayee) {
		this.vendorOrPayee = vendorOrPayee;
	}

	public boolean isVendorChange() {
		return vendorChange;
	}

	public void setVendorChange(boolean vendorChange) {
		this.vendorChange = vendorChange;
	}

	public boolean isSapVendorName() {
		return sapVendorName;
	}

	public void setSapVendorName(boolean sapVendorName) {
		this.sapVendorName = sapVendorName;
	}

	public String getAccountGroup() {
		return accountGroup;
	}

	public void setAccountGroup(String accountGroup) {
		this.accountGroup = accountGroup;
	}

	public String getVendorClassification() {
		return vendorClassification;
	}

	public void setVendorClassification(String vendorClassification) {
		this.vendorClassification = vendorClassification;
	}

	public boolean isPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(boolean paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getReconAccount() {
		return reconAccount;
	}

	public void setReconAccount(String reconAccount) {
		this.reconAccount = reconAccount;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

}
