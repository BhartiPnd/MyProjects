package com.ssp.dto;

import java.util.List;

import com.ssp.mongo.collections.dataObject.MaterialMaster;

public class PIR {

	private MaterialMaster material;
	private List<SupplierPIR> supplierPIR;
	
	public PIR() {
		super();
	}
	
	public PIR(MaterialMaster material, List<SupplierPIR> supplierPIR) {
		super();
		this.material = material;
		this.supplierPIR = supplierPIR;
	}

	public MaterialMaster getMaterial() {
		return material;
	}
	public void setMaterial(MaterialMaster material) {
		this.material = material;
	}
	public List<SupplierPIR> getSupplierPIR() {
		return supplierPIR;
	}
	public void setSupplierPIR(List<SupplierPIR> supplierPIR) {
		this.supplierPIR = supplierPIR;
	}
	
	
}
