package com.ssp.dto;


public class WorkItemSapSync {

	private String itemId;
	private String itemType;
	private boolean syncToSAP;
	
	
	public WorkItemSapSync(String itemId, String itemType) {
		this.itemId = itemId;
		this.itemType = itemType;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public boolean isSyncToSAP() {
		return syncToSAP;
	}
	public void setSyncToSAP(boolean syncToSAP) {
		this.syncToSAP = syncToSAP;
	}
	
}
