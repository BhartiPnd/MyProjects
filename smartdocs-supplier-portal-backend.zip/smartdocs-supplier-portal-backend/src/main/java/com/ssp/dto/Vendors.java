package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.ssp.mongo.collectionhelpers.Address;
import com.ssp.mongo.collectionhelpers.DiverseBusinessClassifications;
import com.ssp.mongo.collectionhelpers.Rating;

@Document(collection = "supplier")
public class Vendors {
	
	private String id;
	private String supplierId;
	private String name;
	private Boolean isDBVendor;
	private String primaryEmail;	
	private Address address;
	private List<DiverseBusinessClassifications>  diverseBusinessClassifications ;
	private boolean  paymentBlock;
	
	private String category;
	private float score;
	private String websiteUrl;
	private String ecomURL;
	private ZonedDateTime auditExpiration;
	
	private List<Rating> rating;	
	 
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<DiverseBusinessClassifications> getDiverseBusinessClassifications() {
		return diverseBusinessClassifications;
	}
	public void setDiverseBusinessClassifications(List<DiverseBusinessClassifications> diverseBusinessClassifications) {
		this.diverseBusinessClassifications = diverseBusinessClassifications;
	}
	public Boolean getIsDBVendor() {
		return isDBVendor;
	}
	public void setIsDBVendor(Boolean isDBVendor) {
		this.isDBVendor = isDBVendor;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isPaymentBlock() {
		return paymentBlock;
	}
	public void setPaymentBlock(boolean paymentBlock) {
		this.paymentBlock = paymentBlock;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getWebsiteUrl() {
		return websiteUrl;
	}
	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}
	public String getEcomURL() {
		return ecomURL;
	}
	public void setEcomURL(String ecomURL) {
		this.ecomURL = ecomURL;
	}
	public ZonedDateTime getAuditExpiration() {
		return auditExpiration;
	}
	public void setAuditExpiration(ZonedDateTime auditExpiration) {
		this.auditExpiration = auditExpiration;
	}
	public List<Rating> getRating() {
		return rating;
	}
	public void setRating(List<Rating> rating) {
		this.rating = rating;
	}
	 
	
}
