package com.ssp.dto;

import com.ssp.mongo.collections.config.system.SystemConfiguration;
import com.ssp.security.services.UserPrinciple;

public class JwtResponse {
	
	public static final String LOGIN_SSO="sso";
	//public static final String LOGIN_SURRAGOTE="surragp";
	public static final String LOGIN_BASIC_UP="basic";
	
    private String token;
    private String type = "Bearer";
    private final String loginType;
    private UserPrinciple user;
    private SystemConfiguration systemConfig;

    public JwtResponse(String accessToken,UserPrinciple user,String loginType,SystemConfiguration systemConfig) {
        this.token = accessToken;
        this.user=user;
        this.loginType=loginType;
        this.systemConfig=systemConfig;
    }

    public String getAccessToken() {
        return token;
    }

    public void setAccessToken(String accessToken) {
        this.token = accessToken;
    }

    public String getTokenType() {
        return type;
    }

    public void setTokenType(String tokenType) {
        this.type = tokenType;
    }
	public UserPrinciple getUser() {
		return user;
	}
	public String getLoginType() {
		return loginType;
	}

	public void setUser(UserPrinciple user) {
		this.user = user;
	}

	public SystemConfiguration getSystemConfig() {
		return systemConfig;
	}

	public void setSystemConfig(SystemConfiguration systemConfig) {
		this.systemConfig = systemConfig;
	}
    
}