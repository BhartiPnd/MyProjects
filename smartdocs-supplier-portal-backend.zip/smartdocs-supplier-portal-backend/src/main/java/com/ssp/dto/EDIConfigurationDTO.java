package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.List;
import com.ssp.mongo.collections.EDIConfiguration;

public class EDIConfigurationDTO {

	private String id;
	private String userName;
	private String password;
	private String apiBaseUrl;
	private String workspaceId;
	private String connectorId;
	private List<EDISupplierDTO> suppliers;
	private ZonedDateTime createdDate;
	private String createdBy;
	private ZonedDateTime updatedDate;
	private String updatedBy;

	public EDIConfigurationDTO() {
		super();
	}

	public EDIConfigurationDTO(EDIConfiguration ediConfiguration) {
		this.id = ediConfiguration.getId();
		this.userName = ediConfiguration.getUserName();
		this.password = ediConfiguration.getPassword();
		this.apiBaseUrl = ediConfiguration.getApiBaseUrl();
		this.workspaceId = ediConfiguration.getWorkspaceId();
		this.connectorId = ediConfiguration.getConnectorId();
		this.createdDate = ediConfiguration.getCreatedDate();
		this.createdBy = ediConfiguration.getCreatedBy();
		this.updatedDate = ediConfiguration.getUpdatedDate();
		this.updatedBy = ediConfiguration.getUpdatedBy();
		this.suppliers = ediConfiguration.getSuppliers();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getApiBaseUrl() {
		return apiBaseUrl;
	}

	public void setApiBaseUrl(String apiBaseUrl) {
		this.apiBaseUrl = apiBaseUrl;
	}

	public String getWorkspaceId() {
		return workspaceId;
	}

	public void setWorkspaceId(String workspaceId) {
		this.workspaceId = workspaceId;
	}

	public String getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(String connectorId) {
		this.connectorId = connectorId;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public ZonedDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(ZonedDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<EDISupplierDTO> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<EDISupplierDTO> suppliers) {
		this.suppliers = suppliers;
	}

}
