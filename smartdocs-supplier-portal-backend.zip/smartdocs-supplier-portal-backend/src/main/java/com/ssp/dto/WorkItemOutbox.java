package com.ssp.dto;

import java.time.ZonedDateTime;
import java.util.Map;

public class WorkItemOutbox {
	
	
	private String itemType;
	private String itemId;
	private String status;
	private String statusDesc;
	private Map<String, Object> metaData;
	private ZonedDateTime activityLogsDateTime;
	
	private String type;
	private String supplierId;
	private String supplier;
	private String category;
	private String requestor;
	private ZonedDateTime createdDate;
	
	public String getItemType() {
		return itemType;
	}
	public String getItemId() {
		return itemId;
	}
	public Map<String, Object> getMetaData() {
		return metaData;
	}
	 
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public void setMetaData(Map<String, Object> metaData) {
		this.metaData = metaData;
	}
	 
	public ZonedDateTime getActivityLogsDateTime() {
		return activityLogsDateTime;
	}
	public void setActivityLogsDateTime(ZonedDateTime activityLogsDateTime) {
		this.activityLogsDateTime = activityLogsDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public String getSupplier() {
		return supplier;
	}
	public String getCategory() {
		return category;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}
	
	
}
