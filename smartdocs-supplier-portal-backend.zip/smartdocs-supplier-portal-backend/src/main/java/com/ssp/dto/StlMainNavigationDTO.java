package com.ssp.dto;

public class StlMainNavigationDTO {

	private long newInvoices;
	private long inProgress;
	private long approvals;
	private long readyToPost;
	private long paid;
	
	private boolean webVerification;
	private String verificationUrl;
	
	private boolean webScan;
	private String webScanUrl;
	
	private boolean webGUIReadyToPost;
	private String webGUIURLReadyToPost;
	
	private boolean logicalSystem;
	
	public long getNewInvoices() {
		return newInvoices;
	}
	public void setNewInvoices(long newInvoices) {
		this.newInvoices = newInvoices;
	}
	public long getInProgress() {
		return inProgress;
	}
	public void setInProgress(long inProgress) {
		this.inProgress = inProgress;
	}
	public long getApprovals() {
		return approvals;
	}
	public void setApprovals(long approvals) {
		this.approvals = approvals;
	}
	public long getReadyToPost() {
		return readyToPost;
	}
	public void setReadyToPost(long readyToPost) {
		this.readyToPost = readyToPost;
	}
	public long getPaid() {
		return paid;
	}
	public void setPaid(long paid) {
		this.paid = paid;
	}
	public boolean isWebVerification() {
		return webVerification;
	}
	public void setWebVerification(boolean webVerification) {
		this.webVerification = webVerification;
	}
	public String getVerificationUrl() {
		return verificationUrl;
	}
	public void setVerificationUrl(String verificationUrl) {
		this.verificationUrl = verificationUrl;
	}
	public boolean isWebScan() {
		return webScan;
	}
	public void setWebScan(boolean webScan) {
		this.webScan = webScan;
	}
	public String getWebScanUrl() {
		return webScanUrl;
	}
	public void setWebScanUrl(String webScanUrl) {
		this.webScanUrl = webScanUrl;
	}
	public boolean isWebGUIReadyToPost() {
		return webGUIReadyToPost;
	}
	public void setWebGUIReadyToPost(boolean webGUIReadyToPost) {
		this.webGUIReadyToPost = webGUIReadyToPost;
	}
	public String getWebGUIURLReadyToPost() {
		return webGUIURLReadyToPost;
	}
	public void setWebGUIURLReadyToPost(String webGUIURLReadyToPost) {
		this.webGUIURLReadyToPost = webGUIURLReadyToPost;
	}
	public boolean isLogicalSystem() {
		return logicalSystem;
	}
	public void setLogicalSystem(boolean logicalSystem) {
		this.logicalSystem = logicalSystem;
	}
	
}
